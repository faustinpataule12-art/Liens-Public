# Query writing tips

- Start with the exact thing and the year when the topic changes over time: "Playwright python install chromium 2026".
- Official documentation first: add the product name plus "docs" or "API reference".
- One question per query. For comparisons, run one search per option, then compare.
- Quote an exact error message to find the real cause.
- Use words a page title would contain, not a full sentence.
- If the first results are weak, change the angle (another keyword, another site name), do not just add words.
- Open the best 1 to 3 results with `web_fetch`. A snippet is not a source.
- Keep the URL of everything you rely on so you can cite it.
