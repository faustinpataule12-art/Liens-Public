"""Read a web page as markdown with Jina Reader (r.jina.ai) from the terminal.
Prints one chunk and tells you the next offset, like the web_fetch tool.
Usage: python3 read_url.py URL [--offset N] [--limit N]
"""
import argparse
import sys
import time
import urllib.error
import urllib.request


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--offset", type=int, default=0)
    ap.add_argument("--limit", type=int, default=8000)
    a = ap.parse_args()
    url = a.url if a.url.startswith(("http://", "https://")) else "https://" + a.url
    req = urllib.request.Request(
        "https://r.jina.ai/" + url,
        headers={"X-Return-Format": "markdown", "User-Agent": "Mozilla/5.0"},
    )
    text = None
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                text = r.read().decode("utf-8", "replace")
            break
        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503, 504) and attempt == 0:
                time.sleep(1.5)
                continue
            sys.exit("Jina HTTP %s" % e.code)
        except Exception as e:
            sys.exit("Read failed: %s" % e)
    lim = min(20000, max(2000, a.limit))
    off = max(0, a.offset)
    end = min(len(text), off + lim)
    print(text[off:end])
    if end < len(text):
        print("\n[Characters %d-%d of %d. Next: --offset %d]" % (off, end, len(text), end))
    else:
        print("\n[End of document: %d characters. Do not read it again.]" % len(text))


if __name__ == "__main__":
    main()
