"""Search the web with Jina Search (s.jina.ai) from the terminal.
Optional environment variable JINA_API_KEY is sent as a Bearer header.
Usage: python3 search.py "query" [--max-chars N]
"""
import argparse
import os
import sys
import urllib.error
import urllib.parse
import urllib.request


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query")
    ap.add_argument("--max-chars", type=int, default=8000)
    a = ap.parse_args()
    req = urllib.request.Request(
        "https://s.jina.ai/" + urllib.parse.quote(a.query),
        headers={"User-Agent": "Mozilla/5.0"},
    )
    key = os.environ.get("JINA_API_KEY")
    if key:
        req.add_header("Authorization", "Bearer " + key)
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            text = r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        sys.exit("Jina HTTP %s" % e.code)
    except Exception as e:
        sys.exit("Search failed: %s" % e)
    if not text.strip():
        sys.exit("No result")
    print(text[: a.max_chars])
    if len(text) > a.max_chars:
        print("\n... (truncated, %d characters total)" % len(text))


if __name__ == "__main__":
    main()
