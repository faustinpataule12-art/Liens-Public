---
name: git-and-pull-requests
description: How to operate on GitHub repositories through api_call and the terminal. Use only when the user asks to create, read, change, save or delete something in a repository, to list repositories, to commit files, or to open a pull request. Covers the sha rule, the delete guard, read-back verification and what never to push.
---

# GitHub repositories

Use GitHub **only** when the user asks for work in a repository. A request for plain code is answered in the chat (`coding`).

## api_call on GitHub
- The app adds the GitHub token itself for any URL containing `github.com`. You never write the token. It also adds `per_page=100` to `api.github.com` lists.
- List all repositories of the account: `GET https://api.github.com/user/repos?per_page=100&affiliation=owner,collaborator,organization_member` (the app follows up to 3 pages and returns name, privacy, URL and a short description).
- Create a repository: `POST https://api.github.com/user/repos` with `{"name": "...", "private": false, "auto_init": true, "description": "..."}`.
- Read a file: `GET https://api.github.com/repos/<owner>/<repo>/contents/<path>`.
- Write or overwrite a file: `PUT .../contents/<path>` with `{"message": "...", "content": "<base64>", "sha": "<current sha>"}`.
  - To overwrite, first `GET` the file and use its current `sha`, otherwise GitHub answers 409. `write_file` does this by itself.
  - After a write on `/contents/`, the app re-reads the file and compares it with what you sent, and tells you if it matches. Do not claim success if the note says the check failed or could not be done.
- Pull request: no dedicated flow exists in the app. If the user explicitly asks, `POST .../repos/<owner>/<repo>/pulls` with `title`, `head`, `base`, `body` (needs the `repo` scope). TODO: confirm this flow with the owner; no commit-message or pull-request template was written because the app has none.

## Guards and permissions
- Every `DELETE` on `api.github.com` opens a blocking confirmation dialog for the user. If refused: do not retry, explain, wait for a clear instruction.
- Deleting, overwriting an existing file, force pushing, deleting branches or repositories, disabling Pages: only with the user's explicit, precise permission (`security`).
- Never force push. Never rewrite history on a repository you did not create in this task.
- Never put tokens, keys or private data in committed files or commit messages.
- Do not push repository clutter (README.md, `.gitkeep`, license, temporary files) as deliverables.
- `nps-workspace` and `nps-memory` are private working repositories. Do not use them for GitHub Pages (see `web-deploy`).

## Git in the terminal
- The runner already has `GH_TOKEN` and git configured for `https://github.com/<account>/<repo>` URLs. Use that exact URL form.
- Clone, commit and push in one `terminal_exec` command (fresh runner each time). Check the result with a separate read (`api_call` GET) before announcing it.
- "Authentication failed": check the URL form and that the token has the `repo` and `workflow` scopes.

## After any change
Read the real state back with a separate call. A success status alone does not prove the effect exists.
