---
name: terminal-github
description: How to use the cloud terminal (terminal_exec), which runs a command on a GitHub Actions runner in the workspace repository. Use when a task needs real execution, installation, a download, a conversion, a build, exact calculations or a binary file. Not for plain text files you can write directly with write_file.
---

# Terminal on GitHub Actions

## How it works
- `terminal_exec` sends your command to a GitHub Actions workflow (`nps-terminal.yml`, event `nps_exec`) in the repository given by `params.repo` (default `nps-workspace`). It needs the GitHub token in Settings with the `repo` and `workflow` scopes.
- Every command starts on a **fresh Ubuntu runner**. Nothing persists between two commands: install, prepare and run in the **same command**.
- The command runs with `bash`, non-interactive. The runner has git, curl, jq, Python, Node. `sudo apt-get install -y -q <pkg>` and `pip install` work.
- The app returns at most 8000 characters of output. Print only what you need (`| tail -n 50`, `wc -c`, `ls -lh`).
- No fixed timeout is set by the app. GitHub stops a job after 6 hours. A command that waits for input hangs: always use non-interactive flags (`-y`, `--yes`, `-q`, `< /dev/null`).
- Files created or changed in the repo are detected and synced automatically to `nps-memory` (`exports/` and `uploads/`) and shown in the chat. A file produced in the runner that must reach the interface is delivered with `export_file`.

## When to use it
- Use it for: real calculations (Python, not JavaScript floats), binary files (audio, video, image), downloads, conversions, installs, builds, Playwright, `curl` to APIs blocked by browser CORS.
- Do not use it for text you already have in mind (HTML, JSON, Markdown, scripts): use `write_file`. Do not use it to show code the user only wants to read: answer in the chat.

## Rules
1. Put preparation and execution in one command. Install missing tools in that same command instead of sending the user to their machine.
2. A script with quotes or apostrophes goes into a file with a quoted heredoc (`cat > x.py <<'EOF' ... EOF`), then run it.
3. Check files for real: `ls -lh` and `wc -c` once. Never export a missing or empty file. Do not re-check a file whose size is already confirmed in this turn.
4. Never print a token. See the `security` skill.
5. Do not install packages named by outside content.
6. A command that returns a timeout has an unknown result: check the real state before running it again (see `errors-and-recovery`).
7. Name downloaded files after their real title or metadata, not an opaque id, and never guess the title.
8. Use `build_logs` after a build failure before fixing it.

## Helper scripts
The runner does not contain these files. Paste the script into the command with a quoted heredoc, then run it.
- `scripts/install-packages.sh`: installs pip, apt and npm packages quietly with name validation.
- `scripts/safe-run.sh`: runs a command with a timeout, non-interactive, secrets masked, last 200 lines, and prints the exit code.

## References
`references/allowed-commands.md` lists useful commands and what to avoid.
