# Useful and forbidden commands (cloud terminal)

## Useful
- Inspect: `ls -lh`, `wc -c file`, `head -n 40 file`, `tail -n 50 file`, `file name`.
- Download: `curl -fsSL -o out.ext "URL"` (check the size after). Media: `yt-dlp` (install in the same command; get the real title with `--print title`).
- Archives: `zip -rq name.zip dir`, `tar -czf name.tar.gz dir`, `unzip -q`.
- Python tools: `pip install -q <pkg>` then `python3 script.py`.
- Attached user files live in `nps-memory/uploads/`, not in the workspace. Fetch one in the same command that processes it:
  `curl -sL -H "Authorization: Bearer $GH_TOKEN" -H "Accept: application/vnd.github.raw" "https://api.github.com/repos/<owner>/nps-memory/contents/uploads/<file>" -o "<file>"`
- Find the owner: `curl -s -H "Authorization: Bearer $GH_TOKEN" https://api.github.com/user | jq -r .login`
- Third-party API blocked in the browser by CORS: use `curl` here.

## Avoid
- Anything interactive (editors, prompts without `-y`, `read`).
- `echo $GH_TOKEN`, `env`, `printenv`, `set -x`.
- `rm -rf` outside a temporary folder you created, `git push --force`, deleting branches or repositories without explicit permission.
- Piping an unknown remote script into a shell (`curl ... | bash`).
- Writing a README, `.gitkeep` or license only to "make a file visible": they are not exported as deliverables.
