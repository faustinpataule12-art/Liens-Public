#!/usr/bin/env bash
# Install packages quietly on the GitHub Actions runner.
# Usage: bash install-packages.sh pip:requests pip:playwright apt:ffmpeg npm:typescript
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive PIP_DISABLE_PIP_VERSION_CHECK=1

if [ "$#" -eq 0 ]; then
  echo "Usage: bash install-packages.sh pip:<name> | apt:<name> | npm:<name> ..." >&2
  exit 2
fi

for spec in "$@"; do
  kind="${spec%%:*}"
  name="${spec#*:}"
  if [ "$kind" = "$spec" ] || ! [[ "$name" =~ ^[A-Za-z0-9._@/+=-]+$ ]]; then
    echo "Refused: invalid package spec '$spec'" >&2
    exit 2
  fi
  case "$kind" in
    pip) python3 -m pip install -q "$name" ;;
    apt) sudo apt-get install -y -q "$name" >/dev/null ;;
    npm) npm install --silent --no-fund --no-audit "$name" ;;
    *)   echo "Refused: unknown kind '$kind' (use pip, apt or npm)" >&2; exit 2 ;;
  esac
  echo "installed: $spec"
done
