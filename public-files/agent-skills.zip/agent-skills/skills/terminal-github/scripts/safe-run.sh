#!/usr/bin/env bash
# Run a command with a timeout, non-interactive, secrets masked, short output.
# Usage: bash safe-run.sh <timeout_seconds> "<command>"
T="${1:?usage: safe-run.sh <timeout_seconds> \"<command>\"}"
shift
export DEBIAN_FRONTEND=noninteractive CI=true PIP_DISABLE_PIP_VERSION_CHECK=1

timeout --signal=TERM --kill-after=10 "$T" bash -c "$*" < /dev/null 2>&1 \
  | sed -E 's/(ghp_|github_pat_|gho_|ghs_|sk-ant-|sk-|AIza)[A-Za-z0-9_-]+/\1***REDACTED***/g' \
  | tail -n 200
rc=${PIPESTATUS[0]}

echo "exit_code=$rc"
if [ "$rc" -eq 124 ]; then
  echo "TIMEOUT after ${T}s: the result is UNKNOWN. Check the real state before retrying."
fi
exit "$rc"
