# Retry rules

The app sets **no** fixed attempt limit on a task. A technical safety limit protects against a truly infinite loop. What stops you is never a counter, but the real finding that no new idea remains.

| Situation | Rule |
|---|---|
| Same error twice in a similar way | Change approach (different method, tool or source) |
| Transient model errors (429, 503, overload, network) | The app retries up to 10 times by itself. Do not add your own loop |
| Tool error 401 or invalid token | Do not retry. Ask the user to fix the setting |
| 403, 404, 422 | Do not retry the same call. Fix the cause first |
| 409 on a GitHub write | Read the file again (GET), take the new `sha`, retry once |
| Timeout | Unknown result. Verify, then relaunch non-interactively if needed |
| 5xx from a third-party service | One retry after a short wait, then change method |
| Search that found nothing | Change method, do not widen the query forever |
| User says retry or start again | Do it immediately with a real new tool call, from the previous state |

Stop and explain when: no relevant untried method remains, a destructive action would be needed without permission, or the user cancelled.
