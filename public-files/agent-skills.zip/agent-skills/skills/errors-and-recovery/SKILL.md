---
name: errors-and-recovery
description: What to do when a tool fails, times out, returns something unexpected, or a claim of success cannot be proven. Use for terminal errors (exit codes, missing commands or modules), HTTP errors, CORS failures, timeouts, empty files, and when the same attempt has failed twice. Covers diagnosis, changing method, and when to stop and explain.
---

# Errors and recovery

## Read the real result
- Every result is one of: succeeded, failed, unknown, timed_out, blocked, cancelled.
- Quote the exact error received. Do not list possible causes in the conditional and do not invent an external cause nothing confirmed.
- A result saying the wanted state already exists is not a failure: check the real state, then conclude.
- The app checks GitHub and Jina itself before using them. A failed check is a certainty: do not retry until the cause is fixed.

## Never repeat the identical thing that just failed
Understand the cause, adapt the method or change tool. If a solution failed twice in a similar way, change approach. While relevant untried methods remain, chain them yourself in the same turn.

## Common cases
| Symptom | Likely real cause | Do this |
|---|---|---|
| Exit code 127, "command not found" | Tool missing on the fresh runner | Install it in the same command, then run |
| `No module named 'x'` | Python package missing | `pip install -q <pip name>` and run in the same command (`cv2` is `opencv-python-headless`, `PIL` is `Pillow`, `docx` is `python-docx`, `bs4` is `beautifulsoup4`) |
| `ffmpeg` not found | Missing system tool | `sudo apt-get install -y -qq ffmpeg && <command>` |
| 403, "bot detection", Cloudflare | Site blocks automation | Add headers, try Playwright, or explain the block. Do not repeat the same call |
| 404 | Wrong URL or missing resource | Verify the address with a real listing or search. Do not retry the same URL |
| 429 | Rate limit | Change source or method, or explain the limit |
| `api_call` network or CORS error on a non-GitHub service | Browser policy, not an outage | Use `curl` in `terminal_exec` |
| "Authentication failed" in git | Wrong URL form or token scope | Use `https://github.com/<account>/<repo>`; the runner already has `GH_TOKEN` |
| "Permission denied" | Rights on a file | `chmod +x` or a writable path |
| "No space left on device" | Runner disk full | Remove temporary files, process less data |
| Video private or unavailable | Source restricted | Explain it honestly; no tool can force it |
| Timeout | Result is **unknown** | Check the job, process, file or resource before running again; relaunch non-interactively |
| Run finished but no result file | Result push may have failed | Check the repository state, then retry once |
| No workflow run started | Workflow missing on the default branch or Actions disabled | Verify `.github/workflows/nps-terminal.yml` and that Actions is enabled |

## Rules
1. A tool that depends on a setting: test that the setting exists first, instead of discovering the failure afterwards.
2. A command with quotes or apostrophes goes in a file (heredoc), not inline.
3. Do not build on a doubtful state. Stabilize it, then continue.
4. Never fabricate content to hide a failure (`security`).
5. Stop only when no new approach remains. Then say what was really observed, what you tried, and propose a real alternative. Retry limits: `references/retry-rules.md`.
6. For a stopped build, read `build_logs` before fixing.
