# Python style

- Python 3, standard library first. Add a dependency only when it saves real work, and name it so it can be installed (`pip install -q <name>`).
- One clear purpose per function. Names say what things are (`read_rows`, not `do`).
- Type hints on public functions when they help reading.
- Handle the expected failure (missing file, bad input, HTTP error) with a clear message; do not hide errors with a bare `except`.
- Read secrets from environment variables, never write them in the file. Do not print them.
- Use `argparse` for scripts with arguments, and `if __name__ == "__main__":`.
- Open files with `encoding="utf-8"`.
- Exact money or statistics: use `decimal` or a numeric library, not naive floats.
- A short docstring at the top: purpose, usage, needs.
- Check with `python3 -m py_compile file.py`, then run.
