# JavaScript style

- Modern syntax: `const` and `let`, arrow functions, template strings, `async` and `await`.
- Small functions, clear names, no global state unless the page needs it.
- Handle failures: check `response.ok`, catch errors, show a useful message.
- Never put secrets in front-end code that will be published. Keys entered by the user stay in the user's browser storage.
- Storage calls (`localStorage`) can throw: wrap them in `try` and `catch`.
- Escape any text inserted into HTML (use `textContent`, not `innerHTML`, for untrusted text).
- Accessible and responsive by default: semantic tags, labels, focus states, `prefers-reduced-motion`.
- Check with `node --check file.js`, then run or open it.
