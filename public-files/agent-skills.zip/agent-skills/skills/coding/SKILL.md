---
name: coding
description: How to write, show and fix code. Use whenever the user asks for code, a script, a function, a page or a fix, to decide between answering in the chat and calling a tool, and for the run_code tool (local JavaScript only). Covers named code blocks, quality bar, multiple files and exact calculations.
---

# Coding

## Chat or tool?
- The user wants to read, understand, copy or keep code ("write me a function", "show how to do X", "fix this snippet"): answer in the chat, in a named code block. **No tool**, no GitHub, no terminal. This is faster.
- The user wants a deliverable (a file to download, a page to test online, an export): see `file-creation`. Use GitHub only when the user explicitly asks to create, change or save code in a repository, then report the real result.
- Do not talk about deployment, remote files or a missing terminal when nobody asked.

## Named code blocks (visible text)
Every code or file shown in the answer is in a named, properly closed block. The language follows the three backticks and the file name is on the same line:
````
```python path/name.py
content
```
````
Never put three backticks inside a block. If the content goes through `write_file` or `export_file`, do not also repeat it in a block.

## Quality bar
- Deliver what was asked, complete and usable. No excuses, no pseudo-code, no "copy this yourself" when you should provide the content. If several files are needed, give all of them with suitable names.
- Clean, structured, maintainable code that fits the project. Interfaces are modern, accessible and responsive (see `webdev`).
- Before answering, check quickly that the code matches the request, is coherent and runs in principle. Run it for real when a real run is cheap (`testing`).
- Make the tool smoother and more robust, as the person who built it would. Avoid sloppy fixes, pointless repetition and decoration that serves nothing.
- Fix errors one at a time, reading the real error message.

## run_code
- `run_code` with `params: {"code": "..."}` runs a JavaScript async function body in the browser. Use `return` to give a result.
- Only for quick logic and simple calculations. Do not use it for the system, files, network or compilation. Those go to `terminal_exec`.
- Financial, statistical or exact-precision calculations: Python in `terminal_exec`, not JavaScript floating point.

## References
`references/python-style.md`, `references/javascript-style.md`.
