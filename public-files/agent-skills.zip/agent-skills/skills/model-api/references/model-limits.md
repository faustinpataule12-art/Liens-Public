# Model limits

The app hard-codes **no** context size and **no** rate limit. Each provider enforces its own.

| Item | What the app does | Where the real value comes from |
|---|---|---|
| Context window | Sends the last 40 messages, shortens old tool results | The provider's error message when exceeded |
| Output per call | 32000 tokens (32768 for Gemini) | Provider may cap lower |
| Requests per minute / day | Retries transient limits up to 10 times | Provider dashboard or documentation |
| Tool result size | Browser safety cap of 2,000,000 characters per result | Technical protection only |

TODO (owner): add a table of the models you actually support (name, context size, vision yes/no, free-tier limits). Do not fill it from memory; copy it from each provider's official documentation, with the date.

How to find a real limit: `web_search` the provider's official "rate limits" or "models" page, then `web_fetch` it. Report the page URL and the date you read it.
