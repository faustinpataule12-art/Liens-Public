# Error codes and what to do

| Code or message | Meaning | Action |
|---|---|---|
| 400 | Request rejected (bad body, too many tokens) | Read the message. Shrink the input or fix the field. |
| 401 | Key missing, invalid or expired | Ask the user to check the key in Settings. Do not retry. |
| 403 | Access forbidden or quota reached (GitHub: missing scope or rate limit) | Check scopes (`repo`, `workflow`). Wait; do not loop. |
| 404 | Resource not found | Check the URL, owner and repository with a real listing. |
| 409 | GitHub refused an overwrite (missing or old `sha`) | Read the file again (GET), take its current `sha`, retry once. `write_file` does this itself. |
| 422 | Invalid request body | Check the JSON fields against the documentation. |
| 429 | Rate limit (model, GitHub, Jina) | The app retries model calls. For tools, wait and change approach. |
| 500, 502, 503, 504, 529 | Provider overloaded or down | The app retries model calls. For tools, one retry after a short wait. |
| `UserByModelByDay` | Daily limit for this provider | Suggest another model or waiting. |
| "context length exceeded" | Input too large for the model | Summarize or cut. Read files in chunks. |
| CORS or "failed to fetch" on `api_call` to a non-GitHub service | The browser blocks it; the service is not necessarily down | Use `curl` in `terminal_exec`. |

Always quote the exact message received. Never list invented possible causes.
