---
name: model-api
description: How the model API (the agent's brain) is configured and behaves in the app. Use when the user asks about the model or provider, when a model error appears (rate limit, daily limit, missing key, context length), when the user wants to change model, or when you need to know what the app does about retries and limits.
---

# Model API

## What the app does (you do not control it)
- The user pastes any API key in Settings. The app detects the provider by itself:
  - key starting with `sk-ant-` is Anthropic (`/v1/messages`);
  - key starting with `AIza` is Google Gemini (`generateContent`);
  - any other key is tested live on OpenAI-compatible providers: Pollinations, Groq, OpenRouter, GitHub Models, Together AI, DeepSeek, Mistral, Fireworks AI, Perplexity, OpenAI. The one that answers is kept.
- The provider and the model are the user's choice. Do not switch them yourself, and do not claim to be a particular model unless the app tells you.
- The default model in the app state is `gemini-3.5-flash-lite`. TODO: the key-detection table uses `gemini-2.0-flash` as its default; confirm which one is intended.
- Calls are made from the browser. Output limit per call is large (32000 tokens, 32768 for Gemini).
- The app sends the last 40 messages. Old hidden tool results are shortened to about 2500 characters once they are more than 6 messages old, so keep important facts in your visible messages and in the activity journal.
- Images attached by the user are sent to the model as images (vision). Whether a given model understands images depends on that model. TODO: list vision-capable models.

## Retries and errors handled by the app
- Rate limit, overload, 429, 503, 529, "resource exhausted", "try again later" and network errors are retried automatically, up to 10 attempts, with a growing delay (1 s up to 10 s).
- A message containing `UserByModelByDay` becomes "daily limit reached for this provider": tell the user to try another model or come back later.
- A missing key gives an explicit error ("no key configured for the selected model"). Tell the user which Settings section to open; do not retry.
- Cancellation by the user stops everything: do not continue.

## Limits
- The app sets no context limit by itself. The model API returns a real error (for example "context length exceeded") when its real limit is hit. Do not invent a limit. See `references/model-limits.md` and `references/error-codes.md`.
- If the context is too large: summarize old results, read files in chunks (`offset` and `limit`), and keep terminal output short.

## Related keys in Settings
- GitHub token: terminal, `write_file`, `api_call` on GitHub (`repo` and `workflow` scopes).
- "Universal key": a `Bearer` header added to Jina search calls.
- OpenAI key: only for `transcribe_audio` (Whisper), even if another provider is the brain.

## Rules
1. Never show a key. Confirm it with its last 4 characters at most (`security`).
2. Do not tell the user that a key or setting is correct unless a test in this turn proved it.
3. For an unknown error, read the real message and use `errors-and-recovery`.
