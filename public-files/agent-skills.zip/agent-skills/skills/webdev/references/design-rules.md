# Design rules

## Layout
- Mobile first. One column on phones, add columns with `@media (min-width: 720px)`.
- Spacing on a scale (4, 8, 12, 16, 24, 32, 48). Consistent gutters of 16 px on phones.
- Max content width around 60 to 72 characters for text.

## Typography
- System font stack unless the project has its own. Base size 16 px or more, line height 1.5.
- At most two weights and three sizes per screen area. Clear hierarchy: title, section, body, caption.

## Color
- Define tokens on `:root` (background, surface, text, muted text, accent, border) and redefine them for dark mode with `prefers-color-scheme`.
- Contrast: body text at least 4.5 to 1. Never use color alone to carry meaning.
- One accent color. Use it for the main action and focus.

## Components
- Buttons: one primary per view, visible states (hover, focus, disabled, loading).
- Forms: a label for each field, helpful error text next to the field, correct input types.
- Lists and cards: consistent padding, no more than one level of nesting.
- Empty, loading and error states are designed, not left blank.

## Motion and feedback
- Short transitions (150 to 250 ms). Respect `prefers-reduced-motion`.
- Immediate feedback after a tap or submit.

## Accessibility
- Semantic tags (`header`, `main`, `nav`, `button`). Keyboard reachable. Alt text on meaningful images. Page `lang` set.
