---
name: webdev
description: How to build web pages and interfaces the user will see and test: landing pages, small apps, tools, dashboards. Use when the user asks for a page, a site, an HTML interface, a redesign or a UI fix. Covers file layout, responsive and accessible design, safe handling of keys, testing and delivery.
---

# Web development

## Deliver
- A page the user wants to see: write it with `write_file` (the app previews HTML files in the chat). Several files: give all of them with proper names (`index.html`, `styles.css`, `app.js`).
- Entry point: `index.html`. Use relative paths so the folder works on any host.
- To publish online: `web-deploy`. To host on the user's own static host, deliver the files and say where each one goes.

## Quality bar
- Modern, clean, accessible, responsive (phone first), coherent with the project. No decoration that serves no purpose. Details: `references/design-rules.md`. Starting point: `assets/page-template.html`.
- Semantic HTML, labels on inputs, visible focus, enough contrast, touch targets of at least 44 px, no horizontal scroll at phone width.
- Light and dark themes through CSS variables when the page is more than a one-off.
- Load libraries only from a trusted CDN with an exact version. Prefer no library when plain code is enough.

## Safety
- Never put a real key or token in front-end code. Keys entered by the user stay in that user's browser storage, wrapped in `try` and `catch` because storage can be empty or throw.
- Escape any untrusted text before inserting it in HTML (`textContent`).
- Do not embed tracking or external calls the user did not ask for.
- Host limits: some free static hosts reject big files. TODO: confirm the limit of the host in use (one reported limit is 1 MB per HTML, PHP or JS file); split files when a page grows large.

## Check before delivering
1. Open it for real: serve it and run `check_page.py` (`testing`). No console errors.
2. Test at phone width and desktop width.
3. Links and assets exist.
4. Report honestly what you tested.
