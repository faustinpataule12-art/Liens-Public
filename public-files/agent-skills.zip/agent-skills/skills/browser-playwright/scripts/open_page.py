"""Open a page with Playwright and print status, title and visible text.
Usage: python3 open_page.py URL [--wait-selector CSS] [--max-chars N]
"""
import argparse
from playwright.sync_api import sync_playwright


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--wait-selector")
    ap.add_argument("--max-chars", type=int, default=6000)
    a = ap.parse_args()
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        resp = page.goto(a.url, wait_until="domcontentloaded", timeout=45000)
        try:
            page.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        if a.wait_selector:
            page.wait_for_selector(a.wait_selector, timeout=15000)
        print("status:", resp.status if resp else "unknown")
        print("title:", page.title())
        print(page.inner_text("body")[: a.max_chars])
        browser.close()


if __name__ == "__main__":
    main()
