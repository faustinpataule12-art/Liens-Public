"""Take a PNG screenshot of a page. Deliver it afterwards with export_file.
Usage: python3 screenshot.py URL OUT.png [--full-page] [--width W] [--height H]
"""
import argparse
import os
from playwright.sync_api import sync_playwright


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("out")
    ap.add_argument("--full-page", action="store_true")
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=800)
    a = ap.parse_args()
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": a.width, "height": a.height})
        resp = page.goto(a.url, wait_until="domcontentloaded", timeout=45000)
        try:
            page.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        page.screenshot(path=a.out, full_page=a.full_page)
        browser.close()
    print("status:", resp.status if resp else "unknown")
    print("saved:", a.out, os.path.getsize(a.out), "bytes")


if __name__ == "__main__":
    main()
