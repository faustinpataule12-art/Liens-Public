"""Print a compact outline of a page: headings, links, forms, fields, buttons.
Usage: python3 extract_dom.py URL [--max-links N]
"""
import argparse
import json
from playwright.sync_api import sync_playwright

JS = """
(maxLinks) => {
  const t = (el) => (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().slice(0, 80);
  return {
    headings: [...document.querySelectorAll('h1,h2,h3')].map(h => h.tagName + ': ' + t(h)),
    links: [...document.querySelectorAll('a[href]')].slice(0, maxLinks).map(a => t(a) + ' -> ' + a.href),
    forms: [...document.forms].map(f => ({
      id: f.id || null, action: f.action || null, method: f.method || null,
      fields: [...f.elements].filter(e => e.name || e.id).map(e => ({
        tag: e.tagName.toLowerCase(), type: e.type || null, name: e.name || null,
        id: e.id || null, placeholder: e.placeholder || null
      }))
    })),
    buttons: [...document.querySelectorAll('button,[role=button],input[type=submit]')].map(t)
  };
}
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--max-links", type=int, default=40)
    a = ap.parse_args()
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(a.url, wait_until="domcontentloaded", timeout=45000)
        try:
            page.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        print("title:", page.title())
        print(json.dumps(page.evaluate(JS, a.max_links), ensure_ascii=False, indent=2))
        browser.close()


if __name__ == "__main__":
    main()
