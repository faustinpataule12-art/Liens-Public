"""Fill a form from a JSON file and optionally submit it. Never prints field values.
fields.json maps a CSS selector to a value. A value "env:NAME" is read from the
environment variable NAME, so secrets never appear in the command.
Usage: python3 fill_form.py URL fields.json [--submit CSS] [--screenshot OUT.png]
"""
import argparse
import json
import os
from playwright.sync_api import sync_playwright


def resolve(value):
    if isinstance(value, str) and value.startswith("env:"):
        name = value[4:]
        if name not in os.environ:
            raise SystemExit("Missing environment variable: " + name)
        return os.environ[name]
    return value


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("fields")
    ap.add_argument("--submit")
    ap.add_argument("--screenshot")
    a = ap.parse_args()
    with open(a.fields, encoding="utf-8") as fh:
        fields = json.load(fh)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(a.url, wait_until="domcontentloaded", timeout=45000)
        for selector, value in fields.items():
            page.wait_for_selector(selector, timeout=15000)
            page.fill(selector, str(resolve(value)))
            print("filled:", selector)
        if a.submit:
            page.click(a.submit)
            try:
                page.wait_for_load_state("networkidle", timeout=15000)
            except Exception:
                pass
            print("submitted:", a.submit)
        # Never print the query string: a GET form can put secrets in the URL.
        print("url:", page.url.split("?")[0].split("#")[0])
        print("title:", page.title())
        if a.screenshot:
            page.screenshot(path=a.screenshot, full_page=True)
            print("saved:", a.screenshot)
        browser.close()


if __name__ == "__main__":
    main()
