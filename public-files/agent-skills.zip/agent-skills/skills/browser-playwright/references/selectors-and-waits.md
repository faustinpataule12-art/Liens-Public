# Selectors and waits (Playwright, Python)

## Selectors, most stable first
1. `[data-testid="..."]`, then `#id`, then `[name="..."]`.
2. Role or label: `page.get_by_role("button", name="Send")`, `page.get_by_label("Email")`.
3. Text: `page.get_by_text("Continue")`.
4. Avoid long CSS chains and `nth-child` positions.
Always take the selector from a real read of the page (`extract_dom.py`), never from memory.

## Waits
- Wait for the element you need: `page.wait_for_selector(css, timeout=15000)`.
- After a click that navigates: `page.wait_for_load_state("networkidle", timeout=15000)`.
- No fixed `sleep` unless there is no other signal.

## When a page does not load or blocks
- Print the real status code and title. A 403 or a challenge page is a real obstacle: report it.
- Try one different method (another URL form, `web_fetch`, a different user agent), not the same call again.
- A search result link is a page, not necessarily the resource: open it to find the real file before downloading.

## Output
- Print only what you need. Output returned to you is capped at 8000 characters.
- Screenshots: save a PNG, check its size, then deliver with `export_file`.
