---
name: testing
description: How to prove that code, a web page, a file, an API call or a deployment really works before saying so. Use after writing or changing code, before delivering any file, after a deployment, and whenever you are about to write "it works". Covers local servers, Playwright checks, syntax checks, file integrity and HTTP checks in the cloud terminal.
---

# Testing

## Principle
Never say "it works" without a real output you just saw. A commit, a started workflow or a 200 on the wrong page proves nothing. Every result is one of: succeeded, failed, unknown, timed_out, blocked, cancelled. A timeout is *unknown*, not failed and not succeeded.

## What to check, by kind of work
| Work | Real check |
|---|---|
| Python code | `python3 -m py_compile file.py`, then run it or its tests (`scripts/run_tests.sh`) |
| JavaScript code | `node --check file.js`, then run it or `npm test` |
| Web page | serve it and open it with Playwright (`scripts/start_local_server.sh`, `scripts/check_page.py`): status, title, console errors, screenshot |
| Created file | existence, size, type, integrity: `ls -lh`, `wc -c`, `file`, `unzip -t`, open it with its library |
| API call | HTTP status, parse the JSON, then read the resource back with a separate GET |
| Deployment | workflow finished, build status, public URL answers 200 with the expected content (see `web-deploy`) |
| Quick logic | `run_code` (local JavaScript) for small pure calculations only |

## Rules
1. The runner is fresh for every `terminal_exec`. Start the server, run the check and stop the server in the **same command**. The helper scripts are not on the runner: paste them with a quoted heredoc.
2. Test the real artifact the user will get, not a copy or an assumption.
3. Print short output (the app returns 8000 characters). Show only the failing part.
4. After a build failure, call `build_logs` for the real error before changing code.
5. If a check fails, find the cause, fix it, check again. Change approach after two similar failures.
6. Do not re-check something already confirmed in this turn (a file whose size you just saw).
7. Do not deliver test leftovers (temporary files, screenshots nobody asked for).
8. Report honestly: what passed, what failed, what could not be tested. Template: `assets/test-report-template.md`.

## Scripts
- `scripts/run_tests.sh`: runs pytest, `npm test` or `node --test`, whichever exists; exit code 5 when there are no tests.
- `scripts/start_local_server.sh [dir] [port]`: serves a folder on localhost and waits until it answers.
- `scripts/check_page.py URL [--screenshot out.png] [--fail-on-console-error]`: Playwright check; needs `pip install -q playwright && playwright install --with-deps chromium`.

## Example (one terminal_exec command)
```
pip install -q playwright && playwright install --with-deps chromium >/dev/null
bash start_local_server.sh . 8000
python3 check_page.py http://localhost:8000/index.html --screenshot shot.png --fail-on-console-error
kill $(cat /tmp/local_server.pid)
```
