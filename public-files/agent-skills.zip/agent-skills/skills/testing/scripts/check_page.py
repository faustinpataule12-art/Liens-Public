"""Check that a page loads: status, title, console errors, failed requests, screenshot.
Usage: python3 check_page.py URL [--screenshot OUT.png] [--fail-on-console-error]
Exit code 1 when the status is 400 or more, or when asked and a console error exists.
"""
import argparse
import sys
from playwright.sync_api import sync_playwright


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--screenshot")
    ap.add_argument("--fail-on-console-error", action="store_true")
    a = ap.parse_args()
    errors, failed = [], []
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("requestfailed", lambda r: failed.append(r.url))
        resp = page.goto(a.url, wait_until="domcontentloaded", timeout=45000)
        try:
            page.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        status = resp.status if resp else 0
        print("status:", status)
        print("title:", page.title())
        print("text length:", len(page.inner_text("body")))
        print("console errors:", len(errors))
        for e in errors[:5]:
            print("  -", e[:200])
        print("failed requests:", len(failed))
        for u in failed[:5]:
            print("  -", u[:200])
        if a.screenshot:
            page.screenshot(path=a.screenshot, full_page=True)
            print("screenshot:", a.screenshot)
        browser.close()
    if status >= 400 or status == 0 or (a.fail_on_console_error and errors):
        sys.exit(1)


if __name__ == "__main__":
    main()
