#!/usr/bin/env bash
# Serve a folder on localhost in the background and wait until it answers.
# Usage: bash start_local_server.sh [dir] [port]
# Stop it with: kill $(cat /tmp/local_server.pid)
DIR="${1:-.}"
PORT="${2:-8000}"
cd "$DIR" || exit 2
nohup python3 -m http.server "$PORT" >/tmp/local_server.log 2>&1 &
echo $! > /tmp/local_server.pid
for i in $(seq 1 20); do
  if curl -fsS "http://localhost:$PORT/" >/dev/null 2>&1; then
    echo "server ready: http://localhost:$PORT/ (pid $(cat /tmp/local_server.pid))"
    exit 0
  fi
  sleep 0.5
done
echo "server did not answer on port $PORT"
cat /tmp/local_server.log
exit 1
