#!/usr/bin/env bash
# Run the tests of a project with whatever test runner exists.
# Usage: bash run_tests.sh [dir]   (exit code 5 = no tests found)
cd "${1:-.}" || exit 2
if ls test_*.py *_test.py tests 2>/dev/null | grep -q . ; then
  python3 -m pytest -q 2>&1 | tail -n 40
  exit "${PIPESTATUS[0]}"
elif [ -f package.json ] && grep -q '"test"' package.json; then
  npm test --silent 2>&1 | tail -n 40
  exit "${PIPESTATUS[0]}"
elif ls ./*.test.js ./*.test.mjs 2>/dev/null | grep -q . ; then
  node --test 2>&1 | tail -n 40
  exit "${PIPESTATUS[0]}"
else
  echo "No tests found. Check syntax and behavior by hand (py_compile, node --check, run the file)."
  exit 5
fi
