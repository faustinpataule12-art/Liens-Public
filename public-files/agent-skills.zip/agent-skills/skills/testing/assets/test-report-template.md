# Test report: <what was tested>

- Date: <date>
- Artifact: <file, URL or commit>

## Checks
| Check | Command or method | Result |
|---|---|---|
| Syntax | `<command>` | passed / failed |
| Behavior | `<command>` | passed / failed |
| Integrity | `<command>` | passed / failed |
| Public URL | `<command>` | status <code> |

## Failures
- <exact message received, no guessed cause>

## Not tested
- <what could not be tested and why>

## Conclusion
<succeeded / failed / unknown> in one sentence, based only on the results above.
