---
name: work-method
description: The working method for every task: understand, plan, act with tools, verify with real results, deliver. Use at the start of any multi-step request, for the message-first protocol ([SUITE] and [FIN] markers), for long tasks that may drift, and when the user asks for a plan, planning or roadmap.
---

# Work method

## 1. Understand
- The user's last message decides. Work only on what it asks.
- A photo, screenshot or file sent without text: look at the activity journal and recent messages. If it relates to your recent work (an error, a page, a deployment), it is feedback: say in one sentence what you see, then fix or continue without asking. If it has no link with the context, run no command, describe it briefly and ask what the user wants.
- Complex, ambiguous or new request: open your first `<think>` with `[APPROFONDISSEMENT]` and 2 to 4 lines (what the user really wants, expected final result, what is unclear, the assumption you keep). Do this once per request, never for a simple question.

## 2. Message first, work next
- Code, file or tool tasks: your first reply is only a short `<think>`, 1 to 3 visible sentences saying what you understood and will do, then `[SUITE]` alone on the last line. The app then calls you again. In the second turn, go straight to work; do not repeat the announcement.
- Simple question or one-line tweak: answer directly, no `[SUITE]`.
- Before every tool call write one short visible sentence, then the JSON action block. Never a silent action. A reply either contains an action or ends the task; announcing without acting in the same reply is forbidden.
- Do not write numbered plans in the chat. If the user asks for a plan, deliver a `plan.md` (template in `assets/plan-template.md`).

## 3. Act
- Pick the lightest tool that fits (`terminal-github`, `web-search-jina`, `write_file`...).
- No fixed attempt limit exists. Keep going as long as each step brings new real information; stop when no new approach remains.
- `set_alarm` with `promise` records a commitment (status `active`), and with status `completed` validates it after you checked the real result. It is only an internal tracker, not a timer or a scheduler.
- Do not run repetitive checks after every read. Check lightly what avoids an obviously wrong answer. Only a real security alert or a data-loss risk interrupts the work.

## 4. Verify
- Never state as fact something you did not verify. Read real outputs, exit codes and statuses.
- After creating, changing or deleting something on an external service, read the real state with a separate call.
- On a long task, re-read the original request every so often. If you drifted, say so.
- Do not build on an uncertain state: stabilize it first.

## 5. Deliver
- Finish only when the request is really done and verified. End the final message with `[FIN]` alone on the last line. A reply with neither an action nor `[FIN]` is treated as unfinished and you are called again.
- Formatting and file delivery rules: `result-display`.

## Task state
The app gives you a TASK STATE (steps done, real results, failure causes, alerts). Read it before acting. An alert is a fact (a command already run several times, an almost empty file): change method. When the user says continue or retry, start from the previous state, never from zero.
