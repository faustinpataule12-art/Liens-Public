# Plan: <project name>

> Goal: <one sentence>

## Overview
| Step | Task | Priority | Status |
|---|---|---|---|
| 1 | <task> | 🔴 high | 🔵 to do |
| 2 | <task> | 🟡 medium | 🔵 to do |
| 3 | <task> | 🟢 low | 🔵 to do |

## Details
### 1. <step name>
- What: <description>
- Done when: <check that proves it works>

### 2. <step name>
- What: <description>
- Done when: <check that proves it works>

## Risks
- ⚠️ <risk and how to handle it>

## Status legend
✅ done · 🔵 to do · 🟡 in progress · 🔴 blocked
