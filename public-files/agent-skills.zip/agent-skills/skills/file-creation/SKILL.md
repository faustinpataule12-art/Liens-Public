---
name: file-creation
description: How to create and deliver files. Use when the user wants a file to download or test (HTML, script, JSON, Markdown, Word, Excel, PDF, PowerPoint, archive, audio, image, QR code), or a README or report. Explains write_file versus terminal_exec plus export_file, the QR and MP3 tools, naming, and what not to export.
---

# File creation and delivery

## Decide first
| Situation | What to do |
|---|---|
| User only wants to read, understand or copy code | Answer in the chat in a named code block. **No tool.** |
| Text file you compose yourself (page, script, JSON, CSS, Markdown, text) | `write_file` with `params: {"path": "...", "content": "..."}` |
| Binary file, conversion, download, build, computed result | `terminal_exec` to produce it, then `export_file` |
| User asks only for a link | Give a verified direct link. Do not download the file |
| QR code | `generate_qr` with `params: {"text": "..."}` |
| Spoken audio from text | `generate_mp3` with `params: {"text": "...", "lang": "fr"}` (3000 characters max) |

## write_file
- Writes your content through the GitHub API (no shell), saves it in `nps-memory` (`exports/` and `uploads/`) and shows the file card in the chat, in one call.
- Needs the GitHub token. `content` must be non-empty. It re-reads the file and handles the existing `sha` itself.
- Never repeat the same content as a named code block in the visible text: the card comes from `content`. Writing it twice doubles the answer and risks two different copies.
- The entry point of a website is `index.html` at the root.

## terminal_exec then export_file
- Produce the file in the runner (see `terminal-github`), check `ls -lh` and `wc -c`. Never export a missing or empty file.
- `export_file` with `params: {"repo": "nps-workspace", "path": "<path>"}` reads the real file from the runner repository (not from your memory), saves it in `nps-memory` and shows the player and download button.
- Files produced by the terminal (zip, tar.gz, big files) are usually delivered automatically as a card. Then just say the file is in the card below; do not `cp`, `mv`, `ls` or `export_file` again.
- Say the file is "in the card below", never "on the remote space".

## Rules
1. One file card per file. No duplicate preview and block. No Markdown link to a local media file like `[Download](file.ext)`: it creates an empty fake player above the real one.
2. Export only the deliverable the user asked for. Never export README.md, `.gitkeep`, licenses or temporary files as deliverables.
3. Name files from real content (real title, clear name), not from an opaque id or hash. Never guess a title.
4. Never claim a file is ready before it is exported and visible.
5. Do not overwrite an existing file without a reason the user gave (`security`).
6. Scripts for the runner (paste with a quoted heredoc, after `pip install -q <lib>`):
   - `scripts/make_docx.py` (python-docx): Markdown-light text to Word.
   - `scripts/make_xlsx.py` (openpyxl): CSV or JSON to Excel.
   - `scripts/make_pdf.py` (reportlab): Markdown-light text to PDF.
   - `scripts/make_pptx.py` (python-pptx): JSON slides to PowerPoint.
7. `generate_mp3` calls the `/api/tts` backend of the app and `generate_qr` an external QR service. TODO: `/api/tts` exists only if the backend is deployed; confirm before promising audio.

## Templates (`assets/`)
`README-template.md`, `report-template.md`, `script-header-template.txt`. Use the README template only when the user asks for a README.
