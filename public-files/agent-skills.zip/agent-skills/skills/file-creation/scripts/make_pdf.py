"""Markdown-light text to a PDF. Supports '# ', '## ', '- ' and paragraphs.
Usage: python3 make_pdf.py input.md output.pdf   (needs: pip install -q reportlab)
"""
import sys
from xml.sax.saxutils import escape
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer


def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: make_pdf.py input.md output.pdf")
    styles = getSampleStyleSheet()
    story, para = [], []

    def flush():
        if para:
            story.append(Paragraph(escape(" ".join(para)), styles["BodyText"]))
            story.append(Spacer(1, 6))
            para.clear()

    with open(sys.argv[1], encoding="utf-8") as fh:
        for line in fh.read().splitlines():
            s = line.rstrip()
            if s.startswith("## "):
                flush(); story.append(Paragraph(escape(s[3:]), styles["Heading2"]))
            elif s.startswith("# "):
                flush(); story.append(Paragraph(escape(s[2:]), styles["Heading1"]))
            elif s.startswith("- "):
                flush(); story.append(Paragraph("&bull; " + escape(s[2:]), styles["BodyText"]))
            elif not s.strip():
                flush()
            else:
                para.append(s.strip())
    flush()
    SimpleDocTemplate(sys.argv[2], pagesize=A4).build(story)
    print("saved:", sys.argv[2])


if __name__ == "__main__":
    main()
