"""CSV or JSON (list of objects) to an Excel file (.xlsx) with a bold header.
Usage: python3 make_xlsx.py input.csv|input.json output.xlsx   (needs: pip install -q openpyxl)
"""
import csv
import json
import sys
from openpyxl import Workbook
from openpyxl.styles import Font


def load_rows(path):
    if path.lower().endswith(".json"):
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, list) or not data or not isinstance(data[0], dict):
            sys.exit("JSON must be a non-empty list of objects")
        header = list(data[0].keys())
        return [header] + [[row.get(k) for k in header] for row in data]
    with open(path, newline="", encoding="utf-8") as fh:
        return [row for row in csv.reader(fh)]


def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: make_xlsx.py input.csv|input.json output.xlsx")
    rows = load_rows(sys.argv[1])
    wb = Workbook()
    ws = wb.active
    for r in rows:
        ws.append(r)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for col in ws.columns:
        width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
        ws.column_dimensions[col[0].column_letter].width = min(60, width + 2)
    wb.save(sys.argv[2])
    print("saved:", sys.argv[2], "rows:", len(rows))


if __name__ == "__main__":
    main()
