"""JSON slides to a PowerPoint file.
slides.json: [{"title": "Title", "bullets": ["point 1", "point 2"]}, ...]
Usage: python3 make_pptx.py slides.json output.pptx   (needs: pip install -q python-pptx)
"""
import json
import sys
from pptx import Presentation


def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: make_pptx.py slides.json output.pptx")
    with open(sys.argv[1], encoding="utf-8") as fh:
        slides = json.load(fh)
    prs = Presentation()
    for s in slides:
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        slide.shapes.title.text = s.get("title", "")
        body = slide.placeholders[1].text_frame
        bullets = s.get("bullets", [])
        if bullets:
            body.text = str(bullets[0])
            for b in bullets[1:]:
                body.add_paragraph().text = str(b)
    prs.save(sys.argv[2])
    print("saved:", sys.argv[2], "slides:", len(slides))


if __name__ == "__main__":
    main()
