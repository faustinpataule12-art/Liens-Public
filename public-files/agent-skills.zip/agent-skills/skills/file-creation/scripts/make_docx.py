"""Markdown-light text to a Word file (.docx).
Supports: '# ', '## ', '### ' headings, '- ' bullets, blank-line separated paragraphs.
Usage: python3 make_docx.py input.md output.docx   (needs: pip install -q python-docx)
"""
import sys
from docx import Document


def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: make_docx.py input.md output.docx")
    doc = Document()
    with open(sys.argv[1], encoding="utf-8") as fh:
        lines = fh.read().splitlines()
    para = []

    def flush():
        if para:
            doc.add_paragraph(" ".join(para))
            para.clear()

    for line in lines:
        s = line.rstrip()
        if s.startswith("### "):
            flush(); doc.add_heading(s[4:], level=3)
        elif s.startswith("## "):
            flush(); doc.add_heading(s[3:], level=2)
        elif s.startswith("# "):
            flush(); doc.add_heading(s[2:], level=1)
        elif s.startswith("- "):
            flush(); doc.add_paragraph(s[2:], style="List Bullet")
        elif not s.strip():
            flush()
        else:
            para.append(s.strip())
    flush()
    doc.save(sys.argv[2])
    print("saved:", sys.argv[2])


if __name__ == "__main__":
    main()
