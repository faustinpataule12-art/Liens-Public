# <Project name>

<One sentence: what it is and who it is for.>

## Features
- <feature>
- <feature>

## Setup
1. <step>
2. <step>

## Usage
```
<command or example>
```

## Configuration
Secrets are never stored in this repository. Set them in the app settings or as repository secrets:
- `<SECRET_NAME>`: <what it is for>

## License
<license name>
