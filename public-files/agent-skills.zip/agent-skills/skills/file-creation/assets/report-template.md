# <Report title>

**Date:** <date> · **For:** <reader>

## Summary
<3 to 5 sentences: the answer first.>

## Findings
1. <finding, with the evidence or source URL>
2. <finding>

## Details
<Sections with real data only. Nothing invented.>

## Limits
- <what is unknown or could not be verified>

## Next steps
- <action>

## Sources
- <title> <URL>
