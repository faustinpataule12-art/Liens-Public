# <Research title>

**Question:** <the exact question> · **Date:** <date>

## Answer
<3 to 6 sentences, direct. State the confidence level.>

## Key findings
1. <finding> (sources: <1>, <2>)
2. <finding> (source: <3>)

## Comparison (if relevant)
| Option | Strength | Weakness | Evidence |
|---|---|---|---|
| <A> | <text> | <text> | <source> |
| <B> | <text> | <text> | <source> |

## Disagreements and uncertainty
- <where sources conflict, and what is not known>

## Method
<Queries used and pages read, in one short paragraph.>

## Sources
1. <title>, <URL>, <date read>
2. <title>, <URL>, <date read>
