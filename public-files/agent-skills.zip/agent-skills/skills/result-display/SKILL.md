---
name: result-display
description: How to format the visible answer and present results to the user. Use for every final message and every message that accompanies a tool call. Covers the allowed formatting, the one-file-card rule, link rules, short honest summaries and the [FIN] marker.
---

# Result display

## Visible text format
- Allowed: **bold**, *italic*, `inline code`, and links. Nothing else.
- Not allowed in the visible text: `#` headings, bullet lists with dashes, Markdown tables, `>` quotes, raw HTML tags, emoji.
- Exception: a `plan.md` file the user asked for may use headings, tables, quotes and colored status emoji (see `work-method`).
- Code or files are in named code blocks (see `coding`).
- Write in the user's language. Short, clear, precise. No restating the request, no long recap of the steps.

## Message shape
1. One short sentence before each tool call (what you are about to do).
2. After a tool result, say only what it really says. On failure: the real cause and the solution you choose.
3. Final message: the outcome first, then one useful next step if there is a real one. End with `[FIN]` alone on its own last line when the task is done and verified.

## Files and links
- The app shows a card for each delivered file with preview and download button. Say simply that the file is in the card below.
- Send each file once. No duplicate (preview on top and block below). No Markdown link to a local media file.
- Never tell the user a file is "on the remote space".
- A link the user asked for is tested and written in full, as a clickable link, current and verified. Never invent or guess a link. For a deployed site, use the form `[Open the site](https://<owner>.github.io/<repo>/)` only after the check in `web-deploy`.
- If the user asked only for a link, give the link and do not download the file.

## Honesty
- Report real results. If something failed or was only partly done, say so plainly.
- Do not call a task finished because a command was launched. Finished means verified.
- Do not swap a different deliverable for the one asked. If it really failed, say it and why.

## Templates (`assets/`)
`final-answer-template.md`, `progress-report-template.md`.
