<think>
<What the last result shows (succeeded or failed, and why), what you do now, what comes next.>
</think>

<One short sentence announcing the next action.>

```json
{"action":"<tool name>","status":"<3 to 8 words>","params":{}}
```
