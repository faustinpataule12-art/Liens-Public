<think>
<2 to 4 real sentences: what the last result shows, what it means for the goal.>
</think>

<Outcome in one or two sentences, in the user's language. What exists now and where.>

<If a file was delivered: one sentence saying it is in the card below.>
<If a link was asked: the verified link, written in full.>
<Only if useful: one concrete next step.>

[FIN]
