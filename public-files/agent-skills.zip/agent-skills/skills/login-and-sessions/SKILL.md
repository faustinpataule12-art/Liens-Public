---
name: login-and-sessions
description: How to connect to third-party services and handle authentication. Use when the user gives a token, key or account for a service, when a task needs an API outside GitHub, when a service asks for OAuth or a login, or when you must keep service knowledge for next time (service recipes in nps-memory/services/).
---

# Third-party services and authentication

## Learn the service like a competent developer
1. If the user gave an id or token for a service, assume it is meant to be used.
2. Check for a saved recipe first: `nps-memory/services/<service>.md` (list the folder or read the file with `api_call`). If it exists, use its base URL, auth header, endpoints and known pitfalls instead of rediscovering them.
3. No recipe: `web_search` and `web_fetch` the official documentation for the real endpoints, authentication and response format.
4. Make one minimal call and read the real status and body. Adjust to what the service answers, not to an assumption. Then chain the calls you need.
5. After any create, change or delete, read the resource back with a separate call before saying it worked.

## How api_call authenticates
- For URLs containing `github.com`, the app adds the GitHub token by itself.
- **No other service gets automatic authentication.** Pass the exact header the service expects in `params.headers` on every call.
- The browser applies CORS and blocks many third-party APIs. An immediate network or CORS error on a non-GitHub service is expected browser behavior, not an outage. Do not repeat it: switch to `curl` in `terminal_exec` (see `terminal-github`).

## Service recipes (notebook)
After the first success with a service, save a recipe: base URL, the auth header name and format (never the secret value), one real working example (method, endpoint, body), and every error met with its fix. Update it each time you learn something.
- Save it with `api_call`: `PUT https://api.github.com/repos/<owner>/nps-memory/contents/services/<service>.md` (base64 content; include the current `sha` to overwrite).
- TODO: the instructions in the app say to save recipes with `write_file`, but `write_file` only stores the file name in `exports/` and `uploads/` of `nps-memory`, never in `services/`. Decide whether `write_file` should accept a folder.

## OAuth
If the documentation describes OAuth (redirect to a login page, authorization code, user consent), you cannot do it alone. Tell the user plainly, give the exact manual step they must do once (create the app on the service, authorize, copy the token), and wait for their result. Never simulate or bypass the flow.

## Logins on websites
- Prefer an official API and token over a password login.
- Do not ask the user to type a website password in the chat.
- TODO: the app has no safe way to give a website password to the terminal runner (the command text itself is stored in the workspace repository). Decide on a secret mechanism (for example repository secrets) before enabling logins with Playwright. Until then, do not automate password logins.

## Secrets
Never show a full token or key in chat, files or recipes. Last 4 characters at most: "token saved, ending in ...a91f". See `security`.
