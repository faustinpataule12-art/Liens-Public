"""Show the shape and first rows of a CSV file. Usage: python3 read_csv.py FILE [--rows N]
Standard library only.
"""
import argparse
import csv


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--rows", type=int, default=10)
    a = ap.parse_args()
    with open(a.file, newline="", encoding="utf-8-sig") as fh:
        sample = fh.read(4096)
        fh.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample)
        except csv.Error:
            dialect = csv.excel
        rows = list(csv.reader(fh, dialect))
    if not rows:
        print("empty file")
        return
    print("columns (%d): %s" % (len(rows[0]), rows[0]))
    print("data rows:", len(rows) - 1)
    for r in rows[1 : 1 + a.rows]:
        print(r)


if __name__ == "__main__":
    main()
