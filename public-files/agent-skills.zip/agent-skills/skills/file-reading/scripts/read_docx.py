"""Print the paragraphs and tables of a Word file. Usage: python3 read_docx.py FILE
Needs: pip install -q python-docx
"""
import sys
from docx import Document


def main():
    if len(sys.argv) != 2:
        sys.exit("Usage: read_docx.py FILE")
    doc = Document(sys.argv[1])
    for p in doc.paragraphs:
        if p.text.strip():
            print(p.text)
    for n, table in enumerate(doc.tables, 1):
        print("\n--- table %d ---" % n)
        for row in table.rows:
            print(" | ".join(c.text.strip() for c in row.cells))


if __name__ == "__main__":
    main()
