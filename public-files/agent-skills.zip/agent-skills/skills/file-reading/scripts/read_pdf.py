"""Print the text of a PDF. Usage: python3 read_pdf.py FILE [--pages 1-3]
Needs: pip install -q pypdf
"""
import argparse
from pypdf import PdfReader


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--pages", default="")
    a = ap.parse_args()
    reader = PdfReader(a.file)
    total = len(reader.pages)
    first, last = 1, total
    if a.pages:
        parts = a.pages.split("-")
        first = int(parts[0])
        last = int(parts[-1])
    print("pages:", total)
    for i in range(max(1, first) - 1, min(total, last)):
        text = (reader.pages[i].extract_text() or "").strip()
        print("\n--- page %d ---\n%s" % (i + 1, text))
    print("\n(If pages are empty, the PDF may be scanned images: OCR is needed.)")


if __name__ == "__main__":
    main()
