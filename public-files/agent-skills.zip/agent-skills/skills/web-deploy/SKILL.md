---
name: web-deploy
description: Protocol to publish a website or file on GitHub Pages with real verification. Use when the user asks to deploy, publish or put a site online, clicks Deploy to GitHub Pages, or asks to disable or re-enable Pages. Never confirm success before the public URL answers 200 with the expected content.
---

# Deploy to GitHub Pages

A push or a commit does **not** prove a deployment. Follow all steps.

## 1. Target repository (public, decide alone)
- On free accounts GitHub Pages needs a **public** repository. Never use `nps-workspace` or `nps-memory` (private): the API answers 404 or 422.
- If the user gave no repository, pick a lowercase name (`site-web` or the project name) and check it: `GET https://api.github.com/repos/<owner>/<repo>`.
- If it does not exist, create it at once without asking: `POST https://api.github.com/user/repos` with `{"name": "<repo>", "private": false, "auto_init": true, "description": "Website deployed on GitHub Pages"}`.

## 2. Files
- The entry point must be `index.html` at the repository root. If the file has another name, save its content as `index.html`.
- Write with `api_call` `PUT .../contents/index.html` (base64 content, plus `sha` if the file exists) or with `terminal_exec`. Push the associated files too (`styles.css`, scripts, images).

## 3. Enable Pages
- `GET https://api.github.com/repos/<owner>/<repo>/pages`. If 404, enable it: `POST` the same URL with header `Accept: application/vnd.github.v3+json` and body `{"source":{"branch":"main","path":"/"}}` (or the default branch).
- Keep the `html_url` returned, usually `https://<owner>.github.io/<repo>/`.

## 4. Follow the real build
- `GET .../pages/builds/latest`: status goes `queued`, `building`, `built`. Or watch the Actions runs (`event=pages_build_deployment`). Use `build_logs` if it fails.

## 5. Verify the public URL (required before any confirmation)
- `web_fetch` on `https://<owner>.github.io/<repo>/`, or `curl -sL -I "https://<owner>.github.io/<repo>/"` in `terminal_exec`.
- Confirm only when it answers 200 with the expected content. A temporary 404 right after the build is normal propagation: tell the user the build is running, give the final URL, and say it will be active within 1 to 2 minutes.

## 6. Answer
- Give the clickable link, written in full: `[Open the site on GitHub Pages](https://<owner>.github.io/<repo>/)`.
- Never remove or hide the delivered files from the chat after deployment: preview and download stay available.

## 7. Disable or re-enable
- Disable (explicit request only): `DELETE .../pages`, then `GET` the same endpoint, which must now return 404. Confirm only if it does. The app asks the user to confirm the `DELETE`.
- Re-enable: `POST` as in step 3, then `GET` must return 200 with an `html_url`. Confirm only if it does.
- Even for a one or two word request, never confirm without the proof `GET`.
