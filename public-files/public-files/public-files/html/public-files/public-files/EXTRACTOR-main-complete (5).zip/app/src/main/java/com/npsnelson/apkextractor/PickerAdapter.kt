package com.npsnelson.apkextractor

import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Représente un élément affichable dans le sélecteur de fichiers (APK ou ZIP),
 * qu'il vienne d'un Uri (MediaStore, fichier téléchargé) ou d'un File local
 * (application installée / application système).
 */
data class PickerItem(
    val name: String,
    val uri: Uri? = null,
    val file: File? = null,
    val isZip: Boolean = false,
    val icon: Drawable? = null,
    val source: String = "apk_files", // "apk_files" | "installed" | "system"
    val alreadyInstalled: Boolean = false,
    val size: Long = 0L,
    val dateModified: Long = 0L
)

class PickerAdapter(
    private val onClick: (PickerItem) -> Unit
) : RecyclerView.Adapter<PickerAdapter.VH>() {

    private var items: List<PickerItem> = emptyList()

    fun submitList(newItems: List<PickerItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val imgIcon: ImageView = view.findViewById(R.id.imgPickerIcon)
        val txtName: TextView = view.findViewById(R.id.txtPickerName)
        val txtSubtitle: TextView = view.findViewById(R.id.txtPickerSubtitle)
        val txtBadge: TextView = view.findViewById(R.id.txtPickerBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_picker_file, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.txtName.text = item.name

        val typeLabel = if (item.isZip) "ZIP" else "APK"
        holder.txtSubtitle.text = "$typeLabel · ${formatSize(item.size)} · ${formatDate(item.dateModified)}"

        holder.txtBadge.text = when (item.source) {
            "installed" -> "Application"
            "system" -> "Système"
            "apk_files" -> if (item.alreadyInstalled) "Installée" else "Fichier"
            else -> "Fichier"
        }

        val fallbackIcon = if (item.isZip) R.drawable.ic_zip_archive else R.drawable.ic_apk_generic
        if (item.icon != null) {
            holder.imgIcon.setImageDrawable(item.icon)
        } else {
            holder.imgIcon.setImageResource(fallbackIcon)
        }

        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 o"
        val units = arrayOf("o", "Ko", "Mo", "Go")
        var size = bytes.toDouble()
        var unitIndex = 0
        while (size >= 1024 && unitIndex < units.size - 1) {
            size /= 1024
            unitIndex++
        }
        return "%.1f %s".format(size, units[unitIndex])
    }

    private fun formatDate(millis: Long): String {
        if (millis <= 0) return "date inconnue"
        val fmt = SimpleDateFormat("d MMM, HH:mm", Locale.FRENCH)
        return fmt.format(Date(millis))
    }
}
