package com.npsnelson.apkextractor

data class ApkEntry(
    val path: String,
    val name: String,
    val extension: String,
    val size: Long,
    val category: Category
) {
    enum class Category { HTML, ICON, SPLASH, IMAGE, JS, CSS, JSON_XML, OTHER }

    companion object {
        fun categorize(ext: String): Category {
            return when (ext.lowercase()) {
                "html", "htm" -> Category.HTML
                "js", "mjs", "ts" -> Category.JS
                "css" -> Category.CSS
                "json", "xml" -> Category.JSON_XML
                "png", "jpg", "jpeg", "webp", "gif", "svg", "bmp" -> Category.IMAGE
                else -> Category.OTHER
            }
        }

        fun categorize(path: String, ext: String): Category {
            val lowerPath = path.lowercase()
            val fileName = lowerPath.substringAfterLast('/')
            return when {
                fileName.contains("splash") || fileName.contains("launch_screen") || fileName.contains("startup") -> Category.SPLASH
                fileName.contains("icon") || fileName.startsWith("ic_") || fileName.contains("launcher") || fileName.contains("app_logo") -> Category.ICON
                else -> categorize(ext)
            }
        }

        val TEXT_EXTENSIONS = setOf(
            "html", "htm", "svg", "js", "mjs", "ts", "css", "json", "xml",
            "txt", "md", "gradle", "properties", "yml", "yaml", "kt",
            "java", "py", "sh", "cfg", "conf", "ini", "manifest", "pro"
        )
    }
}
