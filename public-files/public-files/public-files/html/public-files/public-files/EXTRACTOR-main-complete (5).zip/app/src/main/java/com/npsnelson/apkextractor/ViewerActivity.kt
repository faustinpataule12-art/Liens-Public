package com.npsnelson.apkextractor

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class ViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_APK_PATH = "extra_apk_path"
        const val EXTRA_ENTRY_PATH = "extra_entry_path"
        const val EXTRA_ENTRY_NAME = "extra_entry_name"
    }

    private lateinit var apkFile: File
    private lateinit var entryPath: String
    private lateinit var entryName: String
    private var isTextFile = true
    private var isRenderableDocument = false
    private var showingPreview = false
    private var sourceText = ""

    private val createFileLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri: Uri? -> uri?.let { saveEntryToUri(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)

        apkFile = File(intent.getStringExtra(EXTRA_APK_PATH)!!)
        entryPath = intent.getStringExtra(EXTRA_ENTRY_PATH)!!
        entryName = intent.getStringExtra(EXTRA_ENTRY_NAME) ?: entryPath

        val toolbar = findViewById<Toolbar>(R.id.toolbarViewer)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = entryName
        toolbar.setNavigationOnClickListener { finish() }

        val ext = entryName.substringAfterLast('.', "").lowercase()
        isTextFile = ext in ApkEntry.TEXT_EXTENSIONS
        isRenderableDocument = ext == "html" || ext == "htm" || ext == "svg"

        val txtContent = findViewById<TextView>(R.id.txtContent)
        val previewImage = findViewById<ImageView>(R.id.previewImage)
        val webPreview = findViewById<WebView>(R.id.webPreview)
        val isRasterImage = ext in setOf("png", "jpg", "jpeg", "webp", "gif", "bmp")
        if (isRasterImage) {
            try {
                val bytes = ApkExtractor.readEntryBytes(apkFile, entryPath)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bitmap != null) {
                    previewImage.setImageBitmap(bitmap)
                    previewImage.visibility = View.VISIBLE
                    txtContent.visibility = View.GONE
                } else {
                    txtContent.text = "Aperçu image indisponible. Utilisez « Enregistrer » ou « Partager »."
                }
            } catch (e: Exception) {
                txtContent.text = "Aperçu indisponible : ${e.message}"
            }
        } else if (isTextFile) {
            try {
                sourceText = ApkExtractor.readEntryText(apkFile, entryPath)
                txtContent.text = sourceText
                webPreview.visibility = View.GONE
                txtContent.visibility = View.VISIBLE
            } catch (e: Exception) {
                txtContent.text = "Impossible de lire ce fichier : ${e.message}"
            }
        } else {
            txtContent.text = "Aperçu non disponible pour ce type de fichier.\nUtilisez « Enregistrer » ou « Partager » pour le récupérer."
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.viewer_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_toggle_preview -> { togglePreview(); true }
            R.id.action_share_file -> { shareEntry(); true }
            R.id.action_save_file -> { createFileLauncher.launch(entryName); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun togglePreview() {
        if (!isRenderableDocument) {
            Toast.makeText(this, "Aperçu visuel non disponible pour ce fichier", Toast.LENGTH_SHORT).show()
            return
        }
        val txtContent = findViewById<TextView>(R.id.txtContent)
        val webPreview = findViewById<WebView>(R.id.webPreview)
        if (showingPreview) {
            webPreview.visibility = View.GONE
            txtContent.visibility = View.VISIBLE
            showingPreview = false
        } else {
            renderPreview(webPreview, txtContent)
        }
    }

    private fun renderPreview(webPreview: WebView, txtContent: TextView) {
        webPreview.settings.javaScriptEnabled = false
        webPreview.loadDataWithBaseURL("file:///android_asset/", sourceText, "text/html", "UTF-8", null)
        webPreview.visibility = View.VISIBLE
        txtContent.visibility = View.GONE
        showingPreview = true
    }

    private fun shareEntry() {
        try {
            val bytes = ApkExtractor.readEntryBytes(apkFile, entryPath)
            val outFile = File(cacheDir, entryName)
            FileOutputStream(outFile).use { it.write(bytes) }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Partager $entryName"))
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveEntryToUri(uri: Uri) {
        try {
            val bytes = ApkExtractor.readEntryBytes(apkFile, entryPath)
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, "Fichier enregistré ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur d'enregistrement : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
