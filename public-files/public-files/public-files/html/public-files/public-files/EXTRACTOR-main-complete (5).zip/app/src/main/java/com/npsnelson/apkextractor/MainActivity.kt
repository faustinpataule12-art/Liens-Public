package com.npsnelson.apkextractor

import android.content.Intent
import android.content.ContentValues
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.Button
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.EditText
import android.view.Gravity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: FileAdapter
    private lateinit var recycler: RecyclerView
    private lateinit var emptyState: LinearLayout
    private lateinit var selectionBar: LinearLayout
    private lateinit var txtSelectionCount: TextView

    private var currentApkFile: File? = null
    private var allEntries: List<ApkEntry> = emptyList()
    private var currentCategoryFilter: ApkEntry.Category? = null
    private var currentQuery: String = ""
    private var showPrimaryFilesOnly: Boolean = true
    private var showOtherFilesOnly: Boolean = false
    private var pendingEntry: ApkEntry? = null
    private var gridMode = false
    private var pendingPickerMode: Boolean? = null
    private var pickerOverlay: View? = null
    private var pickerFileType: String = "apk" // "apk" | "zip"
    private var pickerSource: String = "apk_files" // "apk_files" | "installed" | "system"
    private var pickerQuery: String = ""
    private var pickerAdapter: PickerAdapter? = null
    private var pickerLoadThread: Thread? = null

    private val createZipLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? -> uri?.let { finishZipExport(it) } }

    private val createFileLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri: Uri? -> uri?.let { finishFileExport(it) } }

    private var pendingZipFile: File? = null
    private var ctaAnimator: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))

        recycler = findViewById(R.id.recyclerFiles)
        emptyState = findViewById(R.id.emptyState)
        selectionBar = findViewById(R.id.selectionBar)
        txtSelectionCount = findViewById(R.id.txtSelectionCount)

        recycler.layoutManager = LinearLayoutManager(this)
        adapter = FileAdapter(
            onClick = { entry -> openViewer(entry) },
            onLongClick = { entry -> enterSelectionMode(entry) },
            onToggleSelection = { entry -> toggleSelection(entry) },
            onPreview = { entry -> openViewer(entry) },
            onDownload = { entry -> downloadEntry(entry) },
            onShare = { entry -> shareEntry(entry) }
        )
        recycler.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fabOpen).setOnClickListener {
            chooseImportType()
        }

        setupFilterChips()

        findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.editSearch)
            .addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    currentQuery = s?.toString().orEmpty()
                    applyFilters()
                }
                override fun afterTextChanged(s: Editable?) {}
            })

        findViewById<View>(R.id.btnZipSelection).setOnClickListener { zipSelection() }
        findViewById<View>(R.id.btnShareSelection).setOnClickListener { shareSelection() }
        findViewById<View>(R.id.btnCancelSelection).setOnClickListener { exitSelectionMode() }

        findViewById<View>(R.id.btnMainPermissionGrant).setOnClickListener { openAllFilesAccessSettings() }
        findViewById<View>(R.id.ctaPermission).setOnClickListener { openAllFilesAccessSettings() }
        updateMainPermissionBanner()

        updateEmptyState()
    }

    private fun setupFilterChips() {
        val chipGroup = findViewById<ChipGroup>(R.id.chipGroupFilters)
        chipGroup.setOnCheckedStateChangeListener { group, checkedIds ->
            val id = checkedIds.firstOrNull() ?: R.id.chipPrimary
            showPrimaryFilesOnly = id == R.id.chipPrimary
            showOtherFilesOnly = false
            currentCategoryFilter = when (id) {
                R.id.chipHtml -> ApkEntry.Category.HTML
                R.id.chipImg -> ApkEntry.Category.IMAGE
                R.id.chipIcon -> ApkEntry.Category.ICON
                R.id.chipSplash -> ApkEntry.Category.SPLASH
                else -> null
            }
            applyFilters()
        }
    }

    private fun chooseImportType() {
        openPickerWithPermission()
    }

    private fun openPickerWithPermission() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingPickerMode = true
            requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1001)
            return
        }
        openPicker()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingPickerMode?.let { pendingPickerMode = null; openPicker() }
        }
    }

    override fun onResume() {
        super.onResume()
        updateMainPermissionBanner()
        if (pickerOverlay != null) reloadPickerList()
    }

    override fun onPause() {
        super.onPause()
        ctaAnimator?.cancel()
        ctaAnimator = null
    }

    /** Accès complet au stockage : requis (Android 11+) pour scanner les vrais fichiers APK/ZIP sur le disque. */
    private fun hasFullFileAccess(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

    /** Affiche/masque la bannière discrète et le gros bouton animé d'autorisation "tous les fichiers". */
    private fun updateMainPermissionBanner() {
        val granted = hasFullFileAccess()
        findViewById<View>(R.id.rowMainPermissionBanner)?.visibility = if (granted) View.GONE else View.VISIBLE
        val cta = findViewById<View>(R.id.ctaPermission)
        if (granted) {
            cta?.visibility = View.GONE
            ctaAnimator?.cancel()
            ctaAnimator = null
        } else {
            cta?.visibility = View.VISIBLE
            if (ctaAnimator == null) {
                val hand = findViewById<View>(R.id.txtCtaHand)
                val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 0.8f, 1f)
                val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.8f, 1f)
                ctaAnimator = ObjectAnimator.ofPropertyValuesHolder(hand, scaleX, scaleY).apply {
                    duration = 650
                    repeatCount = ObjectAnimator.INFINITE
                    startDelay = 250
                    start()
                }
            }
        }
    }

    /** Ouvre l'écran système "Autoriser l'accès à tous les fichiers" (Android 11+). */
    private fun openAllFilesAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
            })
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) {}
        }
    }

    // ---------- Sélecteur de fichiers (façon Google Files : liste, icônes réelles, recherche, onglets directs) ----------

    private fun openPicker() {
        pickerOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        pickerFileType = "apk"
        pickerSource = "apk_files"
        pickerQuery = ""

        val root = LayoutInflater.from(this).inflate(R.layout.dialog_picker, null) as ViewGroup
        pickerOverlay = root

        val recycler = root.findViewById<RecyclerView>(R.id.recyclerPicker)
        recycler.layoutManager = LinearLayoutManager(this)
        pickerAdapter = PickerAdapter { item -> selectPickerItem(item) }
        recycler.adapter = pickerAdapter

        root.findViewById<EditText>(R.id.editPickerSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                pickerQuery = s?.toString().orEmpty()
                reloadPickerList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        root.findViewById<View>(R.id.btnPickerClose).setOnClickListener { closePicker() }

        root.findViewById<View>(R.id.btnPermissionGrant).setOnClickListener { openAllFilesAccessSettings() }

        val btnTypeApk = root.findViewById<TextView>(R.id.btnTypeApk)
        val btnTypeZip = root.findViewById<TextView>(R.id.btnTypeZip)
        val rowSourceTabs = root.findViewById<View>(R.id.rowSourceTabs)
        val btnSourceDownloaded = root.findViewById<TextView>(R.id.btnSourceDownloaded)
        val btnSourceInstalled = root.findViewById<TextView>(R.id.btnSourceInstalled)
        val btnSourceSystem = root.findViewById<TextView>(R.id.btnSourceSystem)

        fun style(btn: TextView, active: Boolean) {
            btn.setBackgroundResource(if (active) R.drawable.bg_tab_active else R.drawable.bg_tab_inactive)
            btn.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF9498A8.toInt())
        }

        fun refreshTabStyles() {
            style(btnTypeApk, pickerFileType == "apk")
            style(btnTypeZip, pickerFileType == "zip")
            rowSourceTabs.visibility = if (pickerFileType == "apk") View.VISIBLE else View.GONE
            style(btnSourceDownloaded, pickerSource == "apk_files")
            style(btnSourceInstalled, pickerSource == "installed")
            style(btnSourceSystem, pickerSource == "system")
        }

        // Chaque bouton applique son choix immédiatement (aucune confirmation) et recharge la liste.
        btnTypeApk.setOnClickListener { pickerFileType = "apk"; refreshTabStyles(); reloadPickerList() }
        btnTypeZip.setOnClickListener { pickerFileType = "zip"; refreshTabStyles(); reloadPickerList() }
        btnSourceDownloaded.setOnClickListener { pickerSource = "apk_files"; refreshTabStyles(); reloadPickerList() }
        btnSourceInstalled.setOnClickListener { pickerSource = "installed"; refreshTabStyles(); reloadPickerList() }
        btnSourceSystem.setOnClickListener { pickerSource = "system"; refreshTabStyles(); reloadPickerList() }

        refreshTabStyles()
        (window.decorView.findViewById(android.R.id.content) as ViewGroup).addView(root, ViewGroup.LayoutParams(-1, -1))
        reloadPickerList()
    }

    private fun closePicker() {
        pickerLoadThread?.interrupt()
        pickerLoadThread = null
        pickerOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        pickerOverlay = null
        pickerAdapter = null
    }

    private fun selectPickerItem(item: PickerItem) {
        closePicker()
        if (item.uri != null) extractApk(item.uri, item.isZip) else item.file?.let { extractApkFile(it, item.isZip) }
    }

    /** Recharge la liste en arrière-plan (le scan des apps installées peut être coûteux) puis met à jour l'UI. */
    private fun reloadPickerList() {
        val overlay = pickerOverlay ?: return
        val progress = overlay.findViewById<ProgressBar>(R.id.progressPicker)
        val emptyView = overlay.findViewById<TextView>(R.id.txtPickerEmpty)
        val countView = overlay.findViewById<TextView>(R.id.txtPickerCount)
        val recycler = overlay.findViewById<RecyclerView>(R.id.recyclerPicker)
        val bannerRow = overlay.findViewById<View>(R.id.rowPermissionBanner)

        pickerLoadThread?.interrupt()
        progress.visibility = View.VISIBLE
        emptyView.visibility = View.GONE
        recycler.visibility = View.GONE

        val apkOnly = pickerFileType == "apk"
        val sourceFilter = if (apkOnly) pickerSource else null
        val query = pickerQuery
        val needsDiskScan = !apkOnly || sourceFilter == "apk_files"
        bannerRow.visibility = if (needsDiskScan && !hasFullFileAccess()) View.VISIBLE else View.GONE

        val thread = Thread {
            val items = loadPickerItems(apkOnly, sourceFilter)
                .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
                .sortedByDescending { it.dateModified }
            runOnUiThread {
                if (pickerOverlay == null) return@runOnUiThread
                progress.visibility = View.GONE
                countView.text = "${items.size} fichier(s) trouvé(s)"
                if (items.isEmpty()) {
                    emptyView.visibility = View.VISIBLE
                    recycler.visibility = View.GONE
                } else {
                    emptyView.visibility = View.GONE
                    recycler.visibility = View.VISIBLE
                    pickerAdapter?.submitList(items)
                }
            }
        }
        pickerLoadThread = thread
        thread.start()
    }

    /** Parcourt le vrai système de fichiers (pas MediaStore) pour trouver tous les .apk ou .zip, où qu'ils soient. */
    private fun scanDiskFiles(apkOnly: Boolean): List<File> {
        val extension = if (apkOnly) ".apk" else ".zip"
        val roots = mutableListOf<File>()
        try {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)?.let { roots += it }
        } catch (_: Exception) {}
        try {
            Environment.getExternalStorageDirectory()?.let { roots += it }
        } catch (_: Exception) {}

        val results = mutableListOf<File>()
        val visited = HashSet<String>()
        val excludedDirNames = setOf("Android", ".thumbnails", ".trash")

        fun walk(dir: File, depth: Int) {
            if (depth > 6) return
            val canonical = try { dir.canonicalPath } catch (_: Exception) { dir.path }
            if (!visited.add(canonical)) return
            val children = try { dir.listFiles() } catch (_: Exception) { null } ?: return
            for (child in children) {
                if (child.isDirectory) {
                    if (child.name in excludedDirNames || child.name.startsWith(".")) continue
                    walk(child, depth + 1)
                } else if (child.name.endsWith(extension, ignoreCase = true)) {
                    results += child
                }
            }
        }
        for (root in roots) walk(root, 0)
        return results.distinctBy { it.canonicalPath }
    }

    /** Construit la liste des APK/ZIP disponibles pour l'onglet demandé, avec vrai nom, icône, taille et date. */
    private fun loadPickerItems(apkOnly: Boolean, sourceFilter: String?): List<PickerItem> {
        val files = mutableListOf<PickerItem>()
        if ((!apkOnly || sourceFilter == "apk_files") && hasFullFileAccess()) {
            try {
                scanDiskFiles(apkOnly).forEach { file ->
                    var displayName = file.name
                    var icon: Drawable? = null
                    var alreadyInstalled = false
                    if (apkOnly) {
                        try {
                            packageManager.getPackageArchiveInfo(file.path, PackageManager.GET_META_DATA)?.applicationInfo?.let { info ->
                                info.sourceDir = file.path
                                info.publicSourceDir = file.path
                                displayName = packageManager.getApplicationLabel(info).toString()
                                icon = packageManager.getApplicationIcon(info)
                                alreadyInstalled = try {
                                    packageManager.getPackageInfo(info.packageName, 0)
                                    true
                                } catch (_: PackageManager.NameNotFoundException) {
                                    false
                                }
                            }
                        } catch (_: Exception) {
                            // APK illisible par le PackageManager (debug non aligné, etc.) : on garde le vrai nom de fichier.
                        }
                    }
                    files += PickerItem(
                        name = displayName,
                        file = file,
                        isZip = !apkOnly,
                        icon = icon,
                        source = "apk_files",
                        alreadyInstalled = alreadyInstalled,
                        size = file.length(),
                        dateModified = file.lastModified()
                    )
                }
            } catch (_: Exception) {
                // Scan disque indisponible (permission retirée entre-temps, etc.) : on continue avec les autres sources.
            }
        }
        if (apkOnly && (sourceFilter == null || sourceFilter == "installed" || sourceFilter == "system")) {
            packageManager.getInstalledApplications(PackageManager.GET_META_DATA).forEach { app ->
                val source = app.sourceDir?.let(::File) ?: return@forEach
                val isSystem = (app.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                val sourceType = if (isSystem) "system" else "installed"
                if (sourceFilter != null && sourceFilter != sourceType) return@forEach
                val label = try { packageManager.getApplicationLabel(app).toString() } catch (_: Exception) { app.packageName }
                val icon = try { packageManager.getApplicationIcon(app) } catch (_: Exception) { null }
                files += PickerItem(
                    name = label,
                    file = source,
                    isZip = false,
                    icon = icon,
                    source = sourceType,
                    size = try { source.length() } catch (_: Exception) { 0L },
                    dateModified = try { source.lastModified() } catch (_: Exception) { 0L }
                )
            }
        }
        return files
    }

    // ---------- Extraction ----------

    private fun extractApk(uri: Uri, isZip: Boolean) {
        try {
            val file = ApkExtractor.copyUriToCache(this, uri, "import_${System.currentTimeMillis()}")
            extractApkFile(file, isZip)
        } catch (e: Exception) {
            supportActionBar?.title = "Erreur d’importation"
        }
    }

    private fun extractApkFile(file: File, isZip: Boolean) {
        try {
            currentApkFile?.takeIf { it.parentFile == cacheDir }?.delete()
            currentApkFile = null
            allEntries = emptyList()
            adapter.submitList(emptyList())
            updateEmptyState()
            val apkFile = if (isZip) findApkInsideZip(file) else file
            if (apkFile == null) {
                throw IllegalArgumentException("Aucun fichier APK trouvé dans ce ZIP")
            }
            val entries = ApkExtractor.listEntries(apkFile)
            currentApkFile = apkFile
            adapter.apkFile = apkFile
            allEntries = entries
            currentCategoryFilter = null
            showPrimaryFilesOnly = true
            showOtherFilesOnly = false
            currentQuery = ""
            findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.editSearch).setText("")
            findViewById<ChipGroup>(R.id.chipGroupFilters).check(R.id.chipPrimary)
            applyFilters()
            supportActionBar?.title = "${entries.size} fichiers trouvés"
        } catch (e: Exception) {
            supportActionBar?.title = if (isZip) "Aucun APK trouvé dans le ZIP" else "Erreur de lecture APK"
        }
    }

    private fun findApkInsideZip(file: File): File? {
        return try {
            ZipFile(file).use { zip ->
                val entry = zip.entries().asSequence()
                    .firstOrNull { !it.isDirectory && it.name.lowercase().endsWith(".apk") }
                    ?: return null
                val output = File(cacheDir, "embedded_${System.currentTimeMillis()}.apk")
                zip.getInputStream(entry).use { input ->
                    FileOutputStream(output).use { out -> input.copyTo(out) }
                }
                output
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun applyFilters() {
        var list = allEntries
        if (showPrimaryFilesOnly) {
            list = list.filter { it.category == ApkEntry.Category.HTML || it.category == ApkEntry.Category.ICON || it.category == ApkEntry.Category.SPLASH }
        }
        if (showOtherFilesOnly) {
            list = list.filter { it.category != ApkEntry.Category.HTML && it.category != ApkEntry.Category.ICON && it.category != ApkEntry.Category.SPLASH }
        }
        currentCategoryFilter?.let { cat -> list = list.filter { it.category == cat } }
        if (currentQuery.isNotBlank()) {
            list = list.filter { it.path.contains(currentQuery, ignoreCase = true) }
        }
        adapter.submitList(list)
        updateEmptyState()
    }

    private fun updateEmptyState() {
        val hasApk = currentApkFile != null
        emptyState.visibility = if (!hasApk) View.VISIBLE else View.GONE
        recycler.visibility = if (hasApk) View.VISIBLE else View.GONE
        findViewById<View>(R.id.editSearch).parent.parent.let { (it as View).visibility = if (hasApk) View.VISIBLE else View.GONE }
        findViewById<View>(R.id.chipGroupFilters).parent.let { (it as View).visibility = if (hasApk) View.VISIBLE else View.GONE }
        invalidateOptionsMenu()
    }

    // ---------- Viewer ----------

    private fun openViewer(entry: ApkEntry) {
        val apk = currentApkFile ?: return
        val intent = Intent(this, ViewerActivity::class.java).apply {
            putExtra(ViewerActivity.EXTRA_APK_PATH, apk.absolutePath)
            putExtra(ViewerActivity.EXTRA_ENTRY_PATH, entry.path)
            putExtra(ViewerActivity.EXTRA_ENTRY_NAME, entry.name)
        }
        startActivity(intent)
    }

    private fun downloadEntry(entry: ApkEntry) {
        val apk = currentApkFile ?: return
        try {
            val bytes = ApkExtractor.readEntryBytes(apk, entry.path)
            val mime = when (entry.extension.lowercase()) {
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "webp" -> "image/webp"
                "gif" -> "image/gif"
                "zip" -> "application/zip"
                else -> "application/octet-stream"
            }
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, entry.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/NPS APK Extractor")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
            }
            val target = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            } else null
            if (target == null) throw IllegalStateException("Téléchargement indisponible")
            contentResolver.openOutputStream(target)?.use { it.write(bytes) }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentResolver.update(target, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            }
            Toast.makeText(this, "Téléchargé dans Download/NPS APK Extractor", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur de téléchargement : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun finishFileExport(destUri: Uri) {
        val apk = currentApkFile ?: return
        val entry = pendingEntry ?: return
        try {
            contentResolver.openOutputStream(destUri)?.use { output ->
                output.write(ApkExtractor.readEntryBytes(apk, entry.path))
            }
            Toast.makeText(this, "${entry.name} enregistré ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur d'enregistrement : ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            pendingEntry = null
        }
    }

    private fun shareEntry(entry: ApkEntry) {
        val apk = currentApkFile ?: return
        try {
            val outFile = File(cacheDir, entry.name)
            outFile.parentFile?.mkdirs()
            outFile.writeBytes(ApkExtractor.readEntryBytes(apk, entry.path))
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Partager ${entry.name}"))
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur de partage : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Sélection multiple ----------

    private fun enterSelectionMode(entry: ApkEntry) {
        adapter.selectionMode = true
        adapter.selectedPaths.add(entry.path)
        adapter.notifyDataSetChanged()
        selectionBar.visibility = View.VISIBLE
        updateSelectionCount()
    }

    private fun toggleSelection(entry: ApkEntry) {
        if (adapter.selectedPaths.contains(entry.path)) {
            adapter.selectedPaths.remove(entry.path)
        } else {
            adapter.selectedPaths.add(entry.path)
        }
        if (adapter.selectedPaths.isEmpty()) {
            exitSelectionMode()
        } else {
            adapter.notifyDataSetChanged()
            updateSelectionCount()
        }
    }

    private fun exitSelectionMode() {
        adapter.clearSelection()
        selectionBar.visibility = View.GONE
    }

    private fun updateSelectionCount() {
        txtSelectionCount.text = "${adapter.selectedPaths.size} sélectionné(s)"
    }

    private fun toggleGrid() {
        gridMode = !gridMode
        recycler.layoutManager = if (gridMode) GridLayoutManager(this, 2) else LinearLayoutManager(this)
        invalidateOptionsMenu()
    }

    // ---------- Export ZIP ----------

    private fun zipSelection() {
        val apk = currentApkFile ?: return
        val paths = adapter.selectedPaths.toList()
        if (paths.isEmpty()) return
        val zipFile = File(cacheDir, "export_${System.currentTimeMillis()}.zip")
        ApkExtractor.buildZip(apk, paths, zipFile)
        saveLocalFileToDownloads(zipFile, "extraction_nps.zip")
    }

    private fun zipAll() {
        val apk = currentApkFile ?: return
        if (allEntries.isEmpty()) return
        val zipFile = File(cacheDir, "export_all_${System.currentTimeMillis()}.zip")
        ApkExtractor.buildZip(apk, allEntries.map { it.path }, zipFile)
        saveLocalFileToDownloads(zipFile, "extraction_complete_nps.zip")
    }

    private fun saveLocalFileToDownloads(file: File, displayName: String) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/NPS APK Extractor")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
            }
            val target = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Téléchargement indisponible")
            contentResolver.openOutputStream(target)?.use { output -> file.inputStream().use { it.copyTo(output) } }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentResolver.update(target, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            }
            Toast.makeText(this, "ZIP téléchargé dans Download/NPS APK Extractor", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur de téléchargement : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun finishZipExport(destUri: Uri) {
        val zip = pendingZipFile ?: return
        try {
            ApkExtractor.copyFileToUri(this, zip, destUri)
            Toast.makeText(this, "ZIP enregistré ✓", Toast.LENGTH_SHORT).show()
            exitSelectionMode()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur d'enregistrement : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareSelection() {
        val apk = currentApkFile ?: return
        val paths = adapter.selectedPaths.toList()
        if (paths.isEmpty()) return
        val zipFile = File(cacheDir, "share_${System.currentTimeMillis()}.zip")
        ApkExtractor.buildZip(apk, paths, zipFile)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zipFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Partager les fichiers"))
    }

    private fun shareAll() {
        val apk = currentApkFile ?: return
        if (allEntries.isEmpty()) return
        try {
            val zipFile = File(cacheDir, "share_complete_${System.currentTimeMillis()}.zip")
            ApkExtractor.buildZip(apk, allEntries.map { it.path }, zipFile)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zipFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Partager le ZIP complet"))
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur de partage : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareUploadedApk() {
        val apk = currentApkFile ?: return
        try {
            val copy = File(cacheDir, "uploaded_${System.currentTimeMillis()}.apk")
            apk.inputStream().use { input -> copy.outputStream().use { output -> input.copyTo(output) } }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", copy)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Partager l’APK"))
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur de partage : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Menu ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val hasApk = currentApkFile != null
        listOf(R.id.action_share_apk, R.id.action_zip_all, R.id.action_share_all, R.id.action_toggle_grid, R.id.action_select_all, R.id.action_show_other_files, R.id.action_show_all_files).forEach { menu.findItem(it)?.isVisible = hasApk }
        menu.findItem(R.id.action_toggle_grid)?.title = if (gridMode) "Afficher en liste" else "Afficher en grille"
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_zip_all -> { zipAll(); true }
            R.id.action_share_all -> { shareAll(); true }
            R.id.action_share_apk -> { shareUploadedApk(); true }
            R.id.action_toggle_grid -> { toggleGrid(); true }
            R.id.action_show_all_files -> {
                showPrimaryFilesOnly = false
                showOtherFilesOnly = false
                currentCategoryFilter = null
                applyFilters()
                true
            }
            R.id.action_show_other_files -> {
                showPrimaryFilesOnly = false
                showOtherFilesOnly = true
                currentCategoryFilter = null
                applyFilters()
                true
            }
            R.id.action_select_all -> {
                adapter.selectionMode = true
                adapter.selectedPaths.clear()
                adapter.selectedPaths.addAll(allEntries.map { it.path })
                adapter.notifyDataSetChanged()
                selectionBar.visibility = View.VISIBLE
                updateSelectionCount()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}
