package com.npsnelson.apkextractor

import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ImageButton
import android.widget.TextView
import java.io.File
import androidx.recyclerview.widget.RecyclerView

class FileAdapter(
    private val onClick: (ApkEntry) -> Unit,
    private val onLongClick: (ApkEntry) -> Unit,
    private val onToggleSelection: (ApkEntry) -> Unit,
    private val onPreview: (ApkEntry) -> Unit,
    private val onDownload: (ApkEntry) -> Unit,
    private val onShare: (ApkEntry) -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    private var items: List<ApkEntry> = emptyList()
    var selectionMode: Boolean = false
    val selectedPaths: MutableSet<String> = mutableSetOf()
    var apkFile: File? = null

    fun submitList(newItems: List<ApkEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun clearSelection() {
        selectedPaths.clear()
        selectionMode = false
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val imgIcon: ImageView = view.findViewById(R.id.imgIcon)
        val imgCheck: ImageView = view.findViewById(R.id.imgCheck)
        val txtName: TextView = view.findViewById(R.id.txtFileName)
        val txtPath: TextView = view.findViewById(R.id.txtFilePath)
        val txtSize: TextView = view.findViewById(R.id.txtFileSize)
        val btnDownload: ImageButton = view.findViewById(R.id.btnDownloadFile)
        val btnShare: ImageButton = view.findViewById(R.id.btnShareFile)
        val btnPreview: ImageButton = view.findViewById(R.id.btnPreviewFile)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        holder.txtName.text = entry.name
        holder.txtPath.text = entry.path
        holder.txtSize.text = formatSize(entry.size)

        val iconRes = when (entry.category) {
            ApkEntry.Category.ICON -> R.drawable.ic_app_icon
            ApkEntry.Category.SPLASH -> R.drawable.ic_splash
            ApkEntry.Category.HTML, ApkEntry.Category.JS, ApkEntry.Category.CSS,
            ApkEntry.Category.JSON_XML -> R.drawable.ic_file
            ApkEntry.Category.IMAGE -> R.drawable.ic_image_file
            ApkEntry.Category.OTHER -> R.drawable.ic_file
        }
        // Réinitialisation à chaque liaison : la vue est recyclée, il ne faut pas hériter du style de l'élément précédent.
        holder.imgIcon.imageTintList = ColorStateList.valueOf(0xFF9498A8.toInt())
        holder.imgIcon.scaleType = ImageView.ScaleType.FIT_CENTER
        holder.imgIcon.setPadding(6, 6, 6, 6)
        holder.imgIcon.setImageResource(iconRes)
        if (entry.category == ApkEntry.Category.IMAGE || entry.category == ApkEntry.Category.ICON || entry.category == ApkEntry.Category.SPLASH) {
            try {
                val bytes = apkFile?.let { ApkExtractor.readEntryBytes(it, entry.path) }
                val bitmap = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                if (bitmap != null) {
                    // C'est une vraie image : on retire le tint (sinon elle ressort en aplat gris) et on la cadre en plein carré.
                    holder.imgIcon.imageTintList = null
                    holder.imgIcon.scaleType = ImageView.ScaleType.CENTER_CROP
                    holder.imgIcon.setPadding(0, 0, 0, 0)
                    holder.imgIcon.setImageBitmap(bitmap)
                }
            } catch (_: Exception) {
                // L’icône de catégorie reste affichée si l’image n’est pas décodable.
            }
        }

        val isSelected = selectedPaths.contains(entry.path)
        holder.imgCheck.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.imgCheck.alpha = if (isSelected) 1f else 0.25f
        holder.imgIcon.visibility = if (selectionMode) View.GONE else View.VISIBLE
        holder.btnDownload.visibility = if (selectionMode) View.GONE else View.VISIBLE
        holder.btnShare.visibility = if (selectionMode) View.GONE else View.VISIBLE
        holder.btnPreview.visibility = if (selectionMode) View.GONE else View.VISIBLE

        holder.itemView.setOnClickListener {
            if (selectionMode) onToggleSelection(entry) else onClick(entry)
        }
        holder.itemView.setOnLongClickListener {
            onLongClick(entry)
            true
        }
        holder.btnDownload.setOnClickListener { onDownload(entry) }
        holder.btnShare.setOnClickListener { onShare(entry) }
        holder.btnPreview.setOnClickListener { onPreview(entry) }
    }

    override fun getItemCount(): Int = items.size

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 o"
        val units = arrayOf("o", "Ko", "Mo", "Go")
        var size = bytes.toDouble()
        var unitIndex = 0
        while (size >= 1024 && unitIndex < units.size - 1) {
            size /= 1024
            unitIndex++
        }
        return "%.1f %s".format(size, units[unitIndex])
    }
}
