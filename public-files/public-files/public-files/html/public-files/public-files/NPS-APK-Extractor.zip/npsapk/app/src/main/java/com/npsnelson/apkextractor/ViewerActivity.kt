package com.npsnelson.apkextractor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class ViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_APK_PATH = "extra_apk_path"
        const val EXTRA_ENTRY_PATH = "extra_entry_path"
        const val EXTRA_ENTRY_NAME = "extra_entry_name"
    }

    private lateinit var apkFile: File
    private lateinit var entryPath: String
    private lateinit var entryName: String
    private var isTextFile = true

    private val createFileLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri: Uri? -> uri?.let { saveEntryToUri(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)

        apkFile = File(intent.getStringExtra(EXTRA_APK_PATH)!!)
        entryPath = intent.getStringExtra(EXTRA_ENTRY_PATH)!!
        entryName = intent.getStringExtra(EXTRA_ENTRY_NAME) ?: entryPath

        val toolbar = findViewById<Toolbar>(R.id.toolbarViewer)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = entryName
        toolbar.setNavigationOnClickListener { finish() }

        val ext = entryName.substringAfterLast('.', "").lowercase()
        isTextFile = ext in ApkEntry.TEXT_EXTENSIONS

        val txtContent = findViewById<TextView>(R.id.txtContent)
        if (isTextFile) {
            try {
                txtContent.text = ApkExtractor.readEntryText(apkFile, entryPath)
            } catch (e: Exception) {
                txtContent.text = "Impossible de lire ce fichier : ${e.message}"
            }
        } else {
            txtContent.text = "Aperçu non disponible pour ce type de fichier.\nUtilisez « Enregistrer » ou « Partager » pour le récupérer."
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.viewer_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_share_file -> { shareEntry(); true }
            R.id.action_save_file -> { createFileLauncher.launch(entryName); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun shareEntry() {
        try {
            val bytes = ApkExtractor.readEntryBytes(apkFile, entryPath)
            val outFile = File(cacheDir, entryName)
            FileOutputStream(outFile).use { it.write(bytes) }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Partager $entryName"))
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveEntryToUri(uri: Uri) {
        try {
            val bytes = ApkExtractor.readEntryBytes(apkFile, entryPath)
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, "Fichier enregistré ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur d'enregistrement : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
