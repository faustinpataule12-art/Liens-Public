package com.npsnelson.apkextractor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FileAdapter(
    private val onClick: (ApkEntry) -> Unit,
    private val onLongClick: (ApkEntry) -> Unit,
    private val onToggleSelection: (ApkEntry) -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    private var items: List<ApkEntry> = emptyList()
    var selectionMode: Boolean = false
    val selectedPaths: MutableSet<String> = mutableSetOf()

    fun submitList(newItems: List<ApkEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun clearSelection() {
        selectedPaths.clear()
        selectionMode = false
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val imgIcon: ImageView = view.findViewById(R.id.imgIcon)
        val imgCheck: ImageView = view.findViewById(R.id.imgCheck)
        val txtName: TextView = view.findViewById(R.id.txtFileName)
        val txtPath: TextView = view.findViewById(R.id.txtFilePath)
        val txtSize: TextView = view.findViewById(R.id.txtFileSize)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        holder.txtName.text = entry.name
        holder.txtPath.text = entry.path
        holder.txtSize.text = formatSize(entry.size)

        val iconRes = when (entry.category) {
            ApkEntry.Category.HTML, ApkEntry.Category.JS, ApkEntry.Category.CSS,
            ApkEntry.Category.JSON_XML -> R.drawable.ic_file
            ApkEntry.Category.IMAGE -> R.drawable.ic_file
            ApkEntry.Category.OTHER -> R.drawable.ic_file
        }
        holder.imgIcon.setImageResource(iconRes)

        val isSelected = selectedPaths.contains(entry.path)
        holder.imgCheck.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.imgCheck.alpha = if (isSelected) 1f else 0.25f
        holder.imgIcon.visibility = if (selectionMode) View.GONE else View.VISIBLE

        holder.itemView.setOnClickListener {
            if (selectionMode) onToggleSelection(entry) else onClick(entry)
        }
        holder.itemView.setOnLongClickListener {
            onLongClick(entry)
            true
        }
    }

    override fun getItemCount(): Int = items.size

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 o"
        val units = arrayOf("o", "Ko", "Mo", "Go")
        var size = bytes.toDouble()
        var unitIndex = 0
        while (size >= 1024 && unitIndex < units.size - 1) {
            size /= 1024
            unitIndex++
        }
        return "%.1f %s".format(size, units[unitIndex])
    }
}
