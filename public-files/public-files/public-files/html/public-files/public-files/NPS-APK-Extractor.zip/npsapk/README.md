# NPS APK Extractor

Application Android permettant d'ouvrir un fichier `.apk`, de lister tous les fichiers sources qu'il contient (HTML, JS, CSS, JSON/XML, images, etc.) et de les extraire — individuellement ou en `.zip` — pour les réutiliser.

## Fonctionnalités
- Ouverture d'un `.apk` via le sélecteur de fichiers Android (aucun PC requis)
- Liste de tous les fichiers internes avec filtre par type (HTML / JS / CSS / JSON-XML / Images / Autres) et recherche par nom
- Aperçu du contenu texte d'un fichier
- Export d'un fichier seul : Enregistrer (SAF) ou Partager
- Sélection multiple (appui long) → export en `.zip` (Enregistrer ou Partager)
- Bouton "Tout télécharger (.zip)" pour récupérer l'intégralité des sources
- Thème sombre NPS

## Compilation
Projet Gradle standard (AGP 8.5.2, Kotlin 1.9.24, minSdk 26, targetSdk 34).
Prêt à être poussé sur un dépôt GitHub pour compilation via workflow (NPS APK Forge).

Créer par NPS.NELSON
