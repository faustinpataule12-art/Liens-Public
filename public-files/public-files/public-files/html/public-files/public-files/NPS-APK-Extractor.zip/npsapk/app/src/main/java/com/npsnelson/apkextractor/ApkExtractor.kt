package com.npsnelson.apkextractor

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Ouvre un APK (qui est un fichier ZIP standard), liste ses entrées
 * et permet de relire/exporter les fichiers sources qu'il contient.
 */
object ApkExtractor {

    /** Copie l'Uri choisi par l'utilisateur vers le cache local, puis retourne le File. */
    fun copyUriToCache(context: Context, uri: Uri, fileName: String = "source.apk"): File {
        val outFile = File(context.cacheDir, fileName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        }
        return outFile
    }

    /** Liste toutes les entrées (fichiers) contenues dans l'APK. */
    fun listEntries(apkFile: File): List<ApkEntry> {
        val entries = mutableListOf<ApkEntry>()
        ZipFile(apkFile).use { zip ->
            val zEntries = zip.entries()
            while (zEntries.hasMoreElements()) {
                val e = zEntries.nextElement()
                if (e.isDirectory) continue
                val name = e.name.substringAfterLast('/')
                val ext = name.substringAfterLast('.', "")
                entries.add(
                    ApkEntry(
                        path = e.name,
                        name = name,
                        extension = ext,
                        size = e.size,
                        category = ApkEntry.categorize(ext)
                    )
                )
            }
        }
        return entries.sortedBy { it.path }
    }

    /** Lit le contenu texte d'une entrée précise de l'APK. */
    fun readEntryText(apkFile: File, entryPath: String): String {
        ZipFile(apkFile).use { zip ->
            val entry = zip.getEntry(entryPath) ?: return "(Introuvable dans l'APK)"
            zip.getInputStream(entry).use { input ->
                return input.bufferedReader(Charsets.UTF_8).readText()
            }
        }
    }

    /** Lit les octets bruts d'une entrée (utile pour export/partage). */
    fun readEntryBytes(apkFile: File, entryPath: String): ByteArray {
        ZipFile(apkFile).use { zip ->
            val entry = zip.getEntry(entryPath) ?: return ByteArray(0)
            zip.getInputStream(entry).use { input ->
                return input.readBytes()
            }
        }
    }

    /** Recrée un fichier .zip contenant uniquement les entrées demandées. */
    fun buildZip(apkFile: File, entryPaths: List<String>, destFile: File) {
        ZipFile(apkFile).use { zip ->
            ZipOutputStream(FileOutputStream(destFile)).use { zos ->
                for (path in entryPaths) {
                    val entry = zip.getEntry(path) ?: continue
                    zip.getInputStream(entry).use { input ->
                        zos.putNextEntry(ZipEntry(path))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                }
            }
        }
    }

    /** Écrit le contenu d'un fichier zip déjà construit vers une destination (Uri SAF). */
    fun copyFileToUri(context: Context, source: File, destUri: Uri) {
        context.contentResolver.openOutputStream(destUri)?.use { output ->
            source.inputStream().use { input ->
                input.copyTo(output)
            }
        }
    }
}
