package com.npsnelson.apkextractor

data class ApkEntry(
    val path: String,
    val name: String,
    val extension: String,
    val size: Long,
    val category: Category
) {
    enum class Category { HTML, JS, CSS, JSON_XML, IMAGE, OTHER }

    companion object {
        fun categorize(ext: String): Category {
            return when (ext.lowercase()) {
                "html", "htm" -> Category.HTML
                "js", "mjs", "ts" -> Category.JS
                "css" -> Category.CSS
                "json", "xml" -> Category.JSON_XML
                "png", "jpg", "jpeg", "webp", "gif", "svg", "bmp" -> Category.IMAGE
                else -> Category.OTHER
            }
        }

        val TEXT_EXTENSIONS = setOf(
            "html", "htm", "js", "mjs", "ts", "css", "json", "xml",
            "txt", "md", "gradle", "properties", "yml", "yaml", "kt",
            "java", "py", "sh", "cfg", "conf", "ini", "manifest", "pro"
        )
    }
}
