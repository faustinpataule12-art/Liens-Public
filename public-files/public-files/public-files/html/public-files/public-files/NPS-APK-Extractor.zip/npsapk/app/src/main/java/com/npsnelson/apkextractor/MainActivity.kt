package com.npsnelson.apkextractor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: FileAdapter
    private lateinit var recycler: RecyclerView
    private lateinit var emptyState: LinearLayout
    private lateinit var selectionBar: LinearLayout
    private lateinit var txtSelectionCount: TextView

    private var currentApkFile: File? = null
    private var allEntries: List<ApkEntry> = emptyList()
    private var currentCategoryFilter: ApkEntry.Category? = null
    private var currentQuery: String = ""

    private val openApkLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { extractApk(it) } }

    private val createZipLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? -> uri?.let { finishZipExport(it) } }

    private var pendingZipFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))

        recycler = findViewById(R.id.recyclerFiles)
        emptyState = findViewById(R.id.emptyState)
        selectionBar = findViewById(R.id.selectionBar)
        txtSelectionCount = findViewById(R.id.txtSelectionCount)

        recycler.layoutManager = LinearLayoutManager(this)
        adapter = FileAdapter(
            onClick = { entry -> openViewer(entry) },
            onLongClick = { entry -> enterSelectionMode(entry) },
            onToggleSelection = { entry -> toggleSelection(entry) }
        )
        recycler.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fabOpen).setOnClickListener {
            openApkLauncher.launch(arrayOf("*/*"))
        }

        setupFilterChips()

        findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.editSearch)
            .addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    currentQuery = s?.toString().orEmpty()
                    applyFilters()
                }
                override fun afterTextChanged(s: Editable?) {}
            })

        findViewById<View>(R.id.btnZipSelection).setOnClickListener { zipSelection() }
        findViewById<View>(R.id.btnShareSelection).setOnClickListener { shareSelection() }
        findViewById<View>(R.id.btnCancelSelection).setOnClickListener { exitSelectionMode() }

        updateEmptyState()
    }

    private fun setupFilterChips() {
        val chipGroup = findViewById<ChipGroup>(R.id.chipGroupFilters)
        chipGroup.setOnCheckedStateChangeListener { group, checkedIds ->
            val id = checkedIds.firstOrNull() ?: R.id.chipAll
            currentCategoryFilter = when (id) {
                R.id.chipHtml -> ApkEntry.Category.HTML
                R.id.chipJs -> ApkEntry.Category.JS
                R.id.chipCss -> ApkEntry.Category.CSS
                R.id.chipJson -> ApkEntry.Category.JSON_XML
                R.id.chipImg -> ApkEntry.Category.IMAGE
                R.id.chipOther -> ApkEntry.Category.OTHER
                else -> null
            }
            applyFilters()
        }
    }

    // ---------- Extraction ----------

    private fun extractApk(uri: Uri) {
        Toast.makeText(this, "Extraction en cours…", Toast.LENGTH_SHORT).show()
        try {
            val file = ApkExtractor.copyUriToCache(this, uri, "current_${System.currentTimeMillis()}.apk")
            val entries = ApkExtractor.listEntries(file)
            currentApkFile = file
            allEntries = entries
            currentCategoryFilter = null
            currentQuery = ""
            findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.editSearch).setText("")
            findViewById<ChipGroup>(R.id.chipGroupFilters).check(R.id.chipAll)
            applyFilters()
            supportActionBar?.title = "${entries.size} fichiers trouvés"
            Toast.makeText(this, "APK ouvert : ${entries.size} fichiers", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun applyFilters() {
        var list = allEntries
        currentCategoryFilter?.let { cat -> list = list.filter { it.category == cat } }
        if (currentQuery.isNotBlank()) {
            list = list.filter { it.path.contains(currentQuery, ignoreCase = true) }
        }
        adapter.submitList(list)
        updateEmptyState()
    }

    private fun updateEmptyState() {
        val hasApk = currentApkFile != null
        emptyState.visibility = if (!hasApk) View.VISIBLE else View.GONE
        recycler.visibility = if (hasApk) View.VISIBLE else View.GONE
    }

    // ---------- Viewer ----------

    private fun openViewer(entry: ApkEntry) {
        val apk = currentApkFile ?: return
        val intent = Intent(this, ViewerActivity::class.java).apply {
            putExtra(ViewerActivity.EXTRA_APK_PATH, apk.absolutePath)
            putExtra(ViewerActivity.EXTRA_ENTRY_PATH, entry.path)
            putExtra(ViewerActivity.EXTRA_ENTRY_NAME, entry.name)
        }
        startActivity(intent)
    }

    // ---------- Sélection multiple ----------

    private fun enterSelectionMode(entry: ApkEntry) {
        adapter.selectionMode = true
        adapter.selectedPaths.add(entry.path)
        adapter.notifyDataSetChanged()
        selectionBar.visibility = View.VISIBLE
        updateSelectionCount()
    }

    private fun toggleSelection(entry: ApkEntry) {
        if (adapter.selectedPaths.contains(entry.path)) {
            adapter.selectedPaths.remove(entry.path)
        } else {
            adapter.selectedPaths.add(entry.path)
        }
        if (adapter.selectedPaths.isEmpty()) {
            exitSelectionMode()
        } else {
            adapter.notifyDataSetChanged()
            updateSelectionCount()
        }
    }

    private fun exitSelectionMode() {
        adapter.clearSelection()
        selectionBar.visibility = View.GONE
    }

    private fun updateSelectionCount() {
        txtSelectionCount.text = "${adapter.selectedPaths.size} sélectionné(s)"
    }

    // ---------- Export ZIP ----------

    private fun zipSelection() {
        val apk = currentApkFile ?: return
        val paths = adapter.selectedPaths.toList()
        if (paths.isEmpty()) return
        val zipFile = File(cacheDir, "export_${System.currentTimeMillis()}.zip")
        ApkExtractor.buildZip(apk, paths, zipFile)
        pendingZipFile = zipFile
        createZipLauncher.launch("extraction_nps.zip")
    }

    private fun zipAll() {
        val apk = currentApkFile ?: return
        if (allEntries.isEmpty()) return
        val zipFile = File(cacheDir, "export_all_${System.currentTimeMillis()}.zip")
        ApkExtractor.buildZip(apk, allEntries.map { it.path }, zipFile)
        pendingZipFile = zipFile
        createZipLauncher.launch("extraction_complete_nps.zip")
    }

    private fun finishZipExport(destUri: Uri) {
        val zip = pendingZipFile ?: return
        try {
            ApkExtractor.copyFileToUri(this, zip, destUri)
            Toast.makeText(this, "ZIP enregistré ✓", Toast.LENGTH_SHORT).show()
            exitSelectionMode()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur d'enregistrement : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareSelection() {
        val apk = currentApkFile ?: return
        val paths = adapter.selectedPaths.toList()
        if (paths.isEmpty()) return
        val zipFile = File(cacheDir, "share_${System.currentTimeMillis()}.zip")
        ApkExtractor.buildZip(apk, paths, zipFile)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zipFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Partager les fichiers"))
    }

    // ---------- Menu ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_zip_all -> { zipAll(); true }
            R.id.action_select_all -> {
                adapter.selectionMode = true
                adapter.selectedPaths.clear()
                adapter.selectedPaths.addAll(allEntries.map { it.path })
                adapter.notifyDataSetChanged()
                selectionBar.visibility = View.VISIBLE
                updateSelectionCount()
                true
            }
            R.id.action_about -> { showAboutDialog(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("NPS APK Extractor")
            .setMessage(
                "Ouvre un fichier APK, liste ses fichiers sources (HTML, JS, CSS, JSON, images...) " +
                "et permet de les exporter individuellement ou en ZIP.\n\nCréer par NPS.NELSON"
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
