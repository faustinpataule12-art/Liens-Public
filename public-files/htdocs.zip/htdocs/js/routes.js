(function(){
  function route(){
    var p=new URLSearchParams(location.search), v=p.get('view');
    if(!v) return;
    try {
      if(v==='library' && typeof window.ffLibOpen==='function'){ window.ffLibOpen(); return; }
      if(v==='storage' && typeof window.ffStoreOpen==='function'){ window.ffStoreOpen(); return; }
      if(v==='contact' && typeof window.ffContactOpen==='function'){ window.ffContactOpen(); return; }
      var labels={chat:'Agent Fable Fast',profile:'Profil',settings:'Paramètres'};
      if(typeof window.showView==='function' && document.getElementById('view-'+v)){
        window.showView(v);
        if(typeof window.setTitle==='function') window.setTitle(labels[v]||'');
      }
    } catch(e){ console.warn('Route Fable Fast:',e); }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',function(){setTimeout(route,0);});
  else setTimeout(route,0);
})();
