/* ================= PLANIFIÉES : tâches et rappels, façon ChatGPT ================= */
(function(){
var KEY='ff_tasks_v1',FKEY='ff_tasks_fired';
var DAYS=['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi','Dimanche'];
var PRE=[['Matin','07:45'],['Midi','12:30'],['Après-midi','15:00'],['Soir','18:30'],['Nuit','21:00']];
var REP=[['day','Chaque jour'],['week','Chaque semaine'],['month','Chaque mois'],['once','Une seule fois']];
var EMO=['🎬','💡','📊','🔥','🌙','🧠','💰','✂️','📅','🚀'];
var SUG=[
 {e:'🎬',t:'Publier ma vidéo du soir',m:'Rappelle-moi de publier ma vidéo. Propose-moi une accroche forte, une légende et des hashtags adaptés à ma niche.',r:'day',h:'18:30'},
 {e:'💡',t:'Idées de vidéos pour la semaine',m:'Chaque semaine, donne-moi 5 idées de vidéos courtes adaptées à mon profil, avec accroche, déroulé et appel à l’action.',r:'week',d:0,h:'07:45'},
 {e:'📊',t:'Analyser mes statistiques',m:'Analyse mes statistiques de la semaine et dis-moi simplement ce qui marche, ce qui bloque et quoi changer.',r:'week',d:6,h:'18:30'},
 {e:'🔥',t:'Vérifier les tendances de ma niche',m:'Cherche les tendances du moment dans ma niche et propose-moi une vidéo à tourner aujourd’hui.',r:'day',h:'07:45'},
 {e:'🧠',t:'Préparer l’épisode de ma série',m:'Aide-moi à préparer le prochain épisode de ma série : rappelle l’épisode précédent, garde les mêmes personnages et propose la suite.',r:'week',d:2,h:'15:00'},
 {e:'✂️',t:'Revoir mes vidéos qui stagnent',m:'Regarde mes vidéos qui stagnent autour de 200 vues et propose des corrections d’accroche, de rythme et de miniature.',r:'month',dom:1,h:'12:30'}];
var T=[],cur=null,isNew=false,depth=0,fired={};
function uid(){return 't'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function load(){
  try{var s=localStorage.getItem(KEY);if(s){T=JSON.parse(s)||[];return;}}catch(e){}
  T=[];
  try{var old=JSON.parse(localStorage.getItem('ff_user_schedule_v2')||'null');
    if(Array.isArray(old)&&old.length===7){var em=['🎬','✂️','🧠','📊','💰','🔥','🌙'];
      old.forEach(function(o,i){if(o&&o.active)T.push({id:uid(),e:em[i],title:'Publication du '+DAYS[i].toLowerCase(),msg:o.msg||'',rep:'week',day:i,dom:1,date:'',time:o.time||'18:30',active:true,notify:true});});}
  }catch(e){}
  save();
}
function save(){try{localStorage.setItem(KEY,JSON.stringify(T));}catch(e){}}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function sub(t){
  var h=t.time||'18:30';
  if(t.rep==='day')return 'Chaque jour · '+h;
  if(t.rep==='week')return 'Chaque semaine · le '+(DAYS[t.day||0]||'lundi').toLowerCase()+' · '+h;
  if(t.rep==='month')return 'Chaque mois · le '+(t.dom||1)+' · '+h;
  var d=t.date?new Date(t.date+'T00:00').toLocaleDateString('fr-FR'):'date à choisir';return 'Une fois · '+d+' · '+h;
}
function I(p,s){return '<svg width="'+(s||22)+'" height="'+(s||22)+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>';}
var IC={back:I('<path d="M15 6l-6 6 6 6"/>'),x:I('<path d="M18 6L6 18M6 6l12 12"/>'),plus:I('<path d="M12 5v14M5 12h14"/>'),more:'<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>',
 pause:'<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9.500"/><path d="M10 9v6M14 9v6" stroke-linecap="round"/></svg>',
 play:'<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><circle cx="12" cy="12" r="9.500"/><path d="M10.500 8.500l5 3.500-5 3.500z" fill="currentColor"/></svg>',
 chat:I('<path d="M21 12a8 8 0 0 1-11.600 7.100L4 20l1-4.600A8 8 0 1 1 21 12z"/><path d="M9 11h.01M12 11h.01M15 11h.01"/>'),
 trash:I('<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>'),
 list:I('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),chev:I('<path d="M6 9l6 6 6-6"/>',18)};
var host=document.createElement('div');host.id='pl-host';document.body.appendChild(host);
var css='#pl-host{position:fixed;inset:0;z-index:930;display:none;background:var(--bg);color:var(--text)}#pl-host.on{display:block}'+
'#pl-host .pl{position:absolute;inset:0;display:flex;flex-direction:column;max-width:760px;margin:0 auto;width:100%}'+
'#pl-host .hd{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:calc(12px + env(safe-area-inset-top)) 14px 10px;flex:none}'+
'#pl-host .hd h1{font-size:18px;font-weight:700;flex:1;text-align:center}'+
'#pl-host .rb{min-width:46px;height:46px;border-radius:23px;border:1px solid var(--border);background:var(--bg3);color:var(--text);display:grid;place-items:center;cursor:pointer;-webkit-tap-highlight-color:transparent;padding:0 12px}'+
'#pl-host .rbs{display:flex;gap:2px;border:1px solid var(--border);background:var(--bg3);border-radius:23px}#pl-host .rbs button{min-width:46px;height:44px;border:0;background:none;color:var(--text);display:grid;place-items:center;cursor:pointer;border-radius:22px}'+
'#pl-host .bd{flex:1;overflow-y:auto;padding:6px 16px 120px;-webkit-overflow-scrolling:touch}'+
'#pl-host h2{font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:var(--text2);font-weight:700;margin:18px 6px 10px}'+
'#pl-host .it{display:flex;align-items:center;gap:14px;width:100%;text-align:left;background:var(--bg2);border:1px solid var(--border);border-radius:22px;padding:16px 16px;margin-bottom:10px;color:var(--text);font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent}'+
'#pl-host .it:active{background:var(--bg3)}#pl-host .it .e{font-size:28px;width:34px;text-align:center;flex:none}#pl-host .it .x{flex:1;min-width:0}#pl-host .it b{display:block;font-size:16px;font-weight:600;line-height:1.3}#pl-host .it small{display:block;color:var(--text2);font-size:13px;margin-top:3px;line-height:1.35}'+
'#pl-host .it.off{opacity:.6}#pl-host .it .pl-p{color:var(--text2)}'+
'#pl-host .sw{position:relative;width:50px;height:30px;border-radius:16px;background:var(--bg3);border:2px solid var(--border);flex:none;cursor:pointer;transition:background .2s}#pl-host .sw i{position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:var(--text2);transition:transform .2s,background .2s}#pl-host .sw.on{background:#2f5be0;border-color:#2f5be0}#pl-host .sw.on i{transform:translateX(20px);background:#fff}'+
'#pl-host .ttl{display:flex;align-items:center;gap:12px;background:var(--bg2);border:1px solid var(--border);border-radius:22px;padding:6px 16px 6px 12px;margin-bottom:14px}#pl-host .ttl button{font-size:28px;border:0;background:none;cursor:pointer;width:42px;height:46px}#pl-host .ttl input{flex:1;min-width:0;background:none;border:0;outline:0;color:var(--text);font:inherit;font-size:17px;font-weight:600;padding:12px 0}'+
'#pl-host textarea{width:100%;min-height:170px;resize:vertical;background:var(--bg2);border:1px solid var(--border);border-radius:22px;padding:16px;color:var(--text);font:inherit;font-size:16px;line-height:1.5;outline:0;margin-bottom:14px}'+
'#pl-host .rw{position:relative;display:flex;align-items:center;justify-content:space-between;gap:12px;background:var(--bg2);border:1px solid var(--border);border-radius:22px;padding:0 18px;min-height:58px;margin-bottom:12px;font-size:16px}'+
'#pl-host .rw span.v{color:var(--text2);display:flex;align-items:center;gap:6px}#pl-host .rw select,#pl-host .rw input[type=time],#pl-host .rw input[type=date]{position:absolute;inset:0;width:100%;opacity:0;font-size:16px;cursor:pointer}'+
'#pl-host .rw.t{padding:0 18px}'+
'#pl-host .fl{position:absolute;right:16px;bottom:calc(18px + env(safe-area-inset-bottom));display:flex;gap:10px;align-items:center}'+
'#pl-host .pill{display:flex;align-items:center;gap:10px;height:52px;padding:0 20px;border-radius:26px;border:1px solid var(--border);background:var(--bg3);color:var(--text);font:inherit;font-weight:700;font-size:16px;cursor:pointer;box-shadow:0 10px 28px rgba(0,0,0,.4)}'+
'#pl-host .gh{display:block;width:100%;height:52px;border-radius:26px;border:1px solid var(--border);background:var(--bg2);color:var(--text);font:inherit;font-size:16px;cursor:pointer;margin:2px 0 12px}'+
'#pl-host .mn{position:absolute;right:14px;top:calc(66px + env(safe-area-inset-top));background:var(--bg2);border:1px solid var(--border);border-radius:22px;padding:8px;min-width:250px;box-shadow:0 16px 40px rgba(0,0,0,.5);z-index:5;display:none}#pl-host .mn.on{display:block}'+
'#pl-host .mn button{display:flex;align-items:center;gap:14px;width:100%;border:0;background:none;color:var(--text);font:inherit;font-size:16px;padding:14px;border-radius:14px;cursor:pointer;text-align:left}#pl-host .mn button.dg{color:#ff5470}#pl-host .mn hr{border:0;border-top:1px solid var(--border);margin:4px 10px}'+
'#pl-host .em{text-align:center;color:var(--text2);font-size:14.5px;line-height:1.5;padding:18px 14px 4px}'+
'#pl-rm{position:fixed;inset:0;z-index:960;display:none;align-items:center;justify-content:center;padding:18px;background:rgba(0,0,0,.6)}#pl-rm.on{display:flex}#pl-rm>div{width:100%;max-width:420px;background:var(--bg2);border:1px solid var(--border);border-radius:26px;padding:24px;color:var(--text)}#pl-rm .e{font-size:40px}#pl-rm h3{font-size:20px;margin:8px 0 6px}#pl-rm p{color:var(--text2);font-size:15px;line-height:1.5;margin-bottom:18px;white-space:pre-wrap}#pl-rm button{display:block;width:100%;height:50px;border-radius:25px;border:1px solid var(--border);background:var(--bg3);color:var(--text);font:inherit;font-size:16px;font-weight:600;margin-top:10px;cursor:pointer}#pl-rm button.pr{background:linear-gradient(90deg,#e86bb0,#5b8cf0,#a77bf0);border:0;color:#fff}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
var rm=document.createElement('div');rm.id='pl-rm';document.body.appendChild(rm);

function sw(on){return '<span class="sw'+(on?' on':'')+'"><i></i></span>';}
function drawList(){
  var h='<div class="pl"><div class="hd"><button class="rb" data-a="close" aria-label="Retour">'+IC.back+'</button><h1>Planifiées</h1><button class="rb" data-a="new" aria-label="Nouvelle tâche">'+IC.plus+'</button></div><div class="bd">';
  if(T.length){
    h+='<h2>Mes tâches</h2>'+T.map(function(t){return '<div class="it'+(t.active?'':' off')+'" role="button" tabindex="0" data-open="'+t.id+'"><span class="e">'+esc(t.e)+'</span><span class="x"><b>'+esc(t.title||'Sans titre')+'</b><small>'+(t.active?esc(sub(t)):'En pause · '+esc(sub(t)))+'</small></span><span data-tg="'+t.id+'">'+sw(t.active)+'</span></div>';}).join('');
  }else h+='<div class="em">Aucune tâche pour le moment. Choisis une suggestion ou touche + : Fable Fast te rappelle et t’aide à l’heure choisie.</div>';
  h+='<h2>Suggestions</h2>'+SUG.map(function(s,i){return '<button class="it" data-sg="'+i+'"><span class="e">'+s.e+'</span><span class="x"><b>'+esc(s.t)+'</b><small>'+esc(sub({rep:s.r,day:s.d,dom:s.dom,time:s.h}))+'</small></span><span class="pl-p">'+IC.plus+'</span></button>';}).join('');
  h+='</div></div>';
  host.innerHTML=h;
}
function selRow(label,val,opts,key,cls){return '<div class="rw"><span>'+label+'</span><span class="v">'+esc(val)+' '+IC.chev+'</span><select data-f="'+key+'">'+opts+'</select></div>';}
function drawDetail(){
  var t=cur,r=t.rep||'week';
  var repOpt=REP.map(function(x){return '<option value="'+x[0]+'"'+(x[0]===r?' selected':'')+'>'+x[1]+'</option>';}).join('');
  var repLabel=(REP.filter(function(x){return x[0]===r;})[0]||REP[1])[1];
  var preMatch=PRE.filter(function(p){return p[1]===t.time;})[0];
  var timeOpt=PRE.map(function(p){return '<option value="'+p[1]+'"'+(preMatch&&p[1]===t.time?' selected':'')+'>'+p[0]+' · '+p[1]+'</option>';}).join('')+'<option value="custom"'+(preMatch?'':' selected')+'>Heure précise…</option>';
  var planRow='';
  if(r==='week')planRow=selRow('Planification','Le '+(DAYS[t.day||0]||'Lundi').toLowerCase()+'s',DAYS.map(function(d,i){return '<option value="'+i+'"'+(i===(t.day||0)?' selected':'')+'>'+d+'</option>';}).join(''),'day');
  if(r==='month'){var o='';for(var i=1;i<=28;i++)o+='<option value="'+i+'"'+(i===(t.dom||1)?' selected':'')+'>Le '+i+'</option>';planRow=selRow('Planification','Le '+(t.dom||1),o,'dom');}
  if(r==='once')planRow='<div class="rw"><span>Planification</span><span class="v">'+esc(t.date?new Date(t.date+'T00:00').toLocaleDateString('fr-FR'):'Choisir une date')+' '+IC.chev+'</span><input type="date" data-f="date" value="'+esc(t.date||'')+'"></div>';
  var h='<div class="pl"><div class="hd"><button class="rb" data-a="list" aria-label="Fermer">'+IC.x+'</button><span style="flex:1"></span><div class="rbs"><button data-a="pause" aria-label="'+(t.active?'Mettre en pause':'Reprendre')+'">'+(t.active?IC.pause:IC.play)+'</button><button data-a="menu" aria-label="Plus">'+IC.more+'</button></div></div>'+
   '<div class="mn" id="pl-mn"><button data-a="share">'+IC.chat+'Copier la tâche</button><button class="dg" data-a="del">'+IC.trash+'Supprimer</button><hr><button data-a="list">'+IC.list+'Voir les tâches planifiées</button></div>'+
   '<div class="bd"><div class="ttl"><button data-a="emo" aria-label="Changer l’icône">'+esc(t.e)+'</button><input data-f="title" value="'+esc(t.title)+'" placeholder="Titre de la tâche" maxlength="80"></div>'+
   '<textarea data-f="msg" placeholder="Que doit faire Fable Fast à ce moment-là ? Exemple : donne-moi 3 idées de vidéos pour ma niche et rappelle-moi de publier.">'+esc(t.msg)+'</textarea>'+
   '<div class="rw" data-a="notif" style="cursor:pointer"><span>Me notifier à l’heure prévue</span>'+sw(t.notify!==false)+'</div>'+
   '<div style="height:10px"></div>'+selRow('Répétition',repLabel,repOpt,'rep')+planRow+selRow('Heure',preMatch?preMatch[0]:(t.time||'18:30'),timeOpt,'timeSel')+
   (preMatch?'':'<div class="rw"><span>Heure précise</span><span class="v">'+esc(t.time||'18:30')+' '+IC.chev+'</span><input type="time" data-f="time" value="'+esc(t.time||'18:30')+'"></div>')+
   '<button class="gh" data-a="now">Lancer maintenant</button></div>'+
   '<div class="fl"><button class="pill" data-a="agent">'+IC.chat+'Ouvrir dans l’agent</button></div></div>';
  host.innerHTML=h;
}
function commit(){
  if(isNew&&(cur.title.trim()||cur.msg.trim())){T.unshift(cur);isNew=false;}
  if(!isNew)save();
}
function open(id){cur=T.filter(function(t){return t.id===id;})[0];if(!cur)return;isNew=false;drawDetail();}
function blank(s){
  var t={id:uid(),e:'📅',title:'',msg:'',rep:'week',day:0,dom:1,date:'',time:'18:30',active:true,notify:true};
  if(s){t.e=s.e;t.title=s.t;t.msg=s.m;t.rep=s.r;t.day=s.d||0;t.dom=s.dom||1;t.time=s.h;}
  cur=t;isNew=true;if(s)commit();drawDetail();
}
function remind(t){
  rm.innerHTML='<div><div class="e">'+esc(t.e)+'</div><h3>'+esc(t.title||'Rappel')+'</h3><p>'+esc(t.msg||'C’est l’heure de ta tâche planifiée.')+'</p><button class="pr" data-r="ag">Ouvrir dans l’agent</button><button data-r="x">Fermer</button></div>';
  rm.classList.add('on');rm._t=t;
  try{if(window.Notification&&Notification.permission==='granted')new Notification('Fable Fast · '+(t.title||'Rappel'),{body:(t.msg||'').slice(0,160),tag:'ff-task-'+t.id});}catch(e){}
}
rm.addEventListener('click',function(e){var b=e.target.closest('[data-r]');if(e.target===rm||(b&&b.dataset.r==='x')){rm.classList.remove('on');return;}if(b&&b.dataset.r==='ag'){rm.classList.remove('on');var t=rm._t;if(window.agAsk)window.agAsk((t.title?t.title+' : ':'')+(t.msg||''));}});
host.addEventListener('click',function(e){
  var el;
  if((el=e.target.closest('[data-tg]'))){e.stopPropagation();var t=T.filter(function(x){return x.id===el.dataset.tg;})[0];if(t){t.active=!t.active;save();drawList();}return;}
  if((el=e.target.closest('[data-open]'))){open(el.dataset.open);return;}
  if((el=e.target.closest('[data-sg]'))){blank(SUG[+el.dataset.sg]);return;}
  var a=e.target.closest('[data-a]');
  var mn=host.querySelector('#pl-mn');if(mn&&!(a&&a.dataset.a==='menu'))mn.classList.remove('on');
  if(!a)return;var k=a.dataset.a;
  if(k==='close'){hist();}
  else if(k==='new'){blank();}
  else if(k==='list'){cur=null;drawList();}
  else if(k==='menu'){mn.classList.toggle('on');}
  else if(k==='pause'){cur.active=!cur.active;commit();drawDetail();}
  else if(k==='notif'){cur.notify=cur.notify===false;commit();drawDetail();}
  else if(k==='emo'){cur.e=EMO[(EMO.indexOf(cur.e)+1)%EMO.length];commit();drawDetail();}
  else if(k==='del'){T=T.filter(function(x){return x!==cur;});save();cur=null;drawList();}
  else if(k==='share'){var s=(cur.title||'Tâche')+'\n'+sub(cur)+'\n\n'+cur.msg;try{navigator.clipboard.writeText(s);}catch(x){}mn.classList.remove('on');}
  else if(k==='now'){remind(cur);}
  else if(k==='agent'){commit();var t2=cur;hist(true);setTimeout(function(){if(window.agAsk)window.agAsk((t2.title?t2.title+' : ':'')+t2.msg);},320);}
});
host.addEventListener('keydown',function(e){if((e.key==='Enter'||e.key===' ')&&e.target.dataset&&e.target.dataset.open){e.preventDefault();open(e.target.dataset.open);}});
host.addEventListener('input',function(e){var f=e.target.dataset&&e.target.dataset.f;if(!f||!cur)return;
  if(f==='title'||f==='msg'){cur[f]=e.target.value;commit();}});
host.addEventListener('change',function(e){var f=e.target.dataset&&e.target.dataset.f;if(!f||!cur)return;var v=e.target.value;
  if(f==='rep')cur.rep=v;else if(f==='day')cur.day=+v;else if(f==='dom')cur.dom=+v;else if(f==='date')cur.date=v;
  else if(f==='timeSel'){if(v==='custom'){cur.time=cur.time&&!PRE.some(function(p){return p[1]===cur.time;})?cur.time:'19:00';}else cur.time=v;}
  else if(f==='time'){cur.time=v||cur.time;}
  commit();drawDetail();});
function push(){try{history.pushState({pl:1},'');depth++;}catch(e){}}
function hide(){host.classList.remove('on');host.innerHTML='';cur=null;}
function hist(quick){if(depth>0){var d=depth;depth=0;hide();try{window.NAV&&(NAV.ignorePop=true);}catch(e){}try{history.go(-d);}catch(e){}}else hide();}
window.addEventListener('popstate',function(){if(!host.classList.contains('on'))return;depth=Math.max(0,depth-1);hide();});
window.ffPlanOpen=function(){load();if(!host.classList.contains('on')||depth===0){depth=0;push();}host.classList.add('on');cur=null;drawList();};
/* rappels */
function today(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
setInterval(function(){try{
  if(!T.length)load();
  var d=new Date(),hm=String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'),dw=(d.getDay()+6)%7,dm=d.getDate(),td=today();
  T.forEach(function(t){
    if(!t.active||t.notify===false||t.time!==hm)return;
    var ok=t.rep==='day'||(t.rep==='week'&&(t.day||0)===dw)||(t.rep==='month'&&(t.dom||1)===dm)||(t.rep==='once'&&t.date===td);
    var key=t.id+td+hm;if(!ok||fired[key])return;fired[key]=1;
    if(t.rep==='once'){t.active=false;save();}
    remind(t);
  });
}catch(e){}},20000);
load();
window.explainDiagCase=function(k){var q={'200vues':'Pourquoi mes vidéos bloquent autour de 200 vues ? Regarde mon profil et mes statistiques et dis-moi précisément quoi corriger.','abos':'Pourquoi ai-je des vues mais presque aucun nouvel abonné ? Appuie-toi sur mon profil et propose-moi un plan concret.','monet':'Comment débloquer et maximiser ma monétisation ? Tiens compte de mon profil, de ma niche et de mes statistiques.'}[k]||'Aide-moi à comprendre pourquoi mon compte stagne.';
  window.closeNotifModal();setTimeout(function(){if(window.agAsk)window.agAsk(q);},340);};
/* ancien centre : Programme -> Planifiées ; Diagnostic reste inchangé */
var _old=window.openNotifCenter;
window.openNotifCenter=function(tab){if(!tab||tab==='plans'||tab==='trends'){window.ffPlanOpen();return;}var r=_old.apply(this,arguments);var t=document.getElementById('ff-nm-title');if(t)t.textContent='Diagnostic & Monétisation';if(!dgDepth){try{history.pushState({dg:1},'');dgDepth=1;}catch(e){}}return r;};
var dgDepth=0,_cl=window.closeNotifModal;
window.closeNotifModal=function(){if(dgDepth){dgDepth=0;var m=document.getElementById('ff-notif-modal');if(m)m.style.display='none';try{window.NAV&&(NAV.ignorePop=true);}catch(e){}try{history.back();}catch(e){}}else if(_cl)_cl();};
window.addEventListener('popstate',function(){var m=document.getElementById('ff-notif-modal');if(dgDepth&&m&&m.style.display!=='none'){dgDepth=0;m.style.display='none';}});
})();
