/* ===== Fable Fast : historiques sauvegardés dans GitHub (dépôt Maker) =====
   rapports/<id>.json  = chaque rapport (profil, vidéo, stats, comparaison, liens)
   scripts/<ts>.json   = chaque script créé
   reglages/ff.json    = profil principal + objectif
   Le navigateur garde une copie ; GitHub fait foi. Rien n'est supprimé sans ton action. */
(function(){
const KR='ff_sync_rep',KS='ff_sync_scr',KC='ff_sync_cfg';
const gj=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?d:v;}catch(e){return d;}};
const sj=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}};
let owner=null,repoOk=false,chain=Promise.resolve(),firstDone=false,readyRes;
const ready=new Promise(r=>readyRes=r);
const tok=()=>(typeof S!=='undefined'&&S.tok)||'';
const fail=e=>{try{npsSyncFail(e);}catch(x){console.warn('sync',e);}};
async function own(){if(!owner)owner=await getGhLogin();return owner;}
async function ensureRepo(){
  if(repoOk)return;const o=await own();if(!o)throw new Error('GitHub injoignable ou token refusé');
  const r=await fetch('https://api.github.com/repos/'+o+'/'+NPS_MEM,{headers:npsGhH(),cache:'no-cache'});
  if(r.status===404){const c=await fetch('https://api.github.com/user/repos',{method:'POST',headers:{...npsGhH(),'Content-Type':'application/json'},body:JSON.stringify({name:NPS_MEM,private:true,auto_init:true,description:'Mémoire, historiques et rapports de Fable Fast'})});if(!c.ok&&c.status!==422)throw new Error('création du dépôt impossible (HTTP '+c.status+')');}
  else if(!r.ok)throw new Error('dépôt inaccessible (HTTP '+r.status+')');
  repoOk=true;}
const b64=s=>btoa(unescape(encodeURIComponent(s)));
function shrink(u){return new Promise(ok=>{if(typeof u!=='string'||u.slice(0,11)!=='data:image/'||u.length<60000)return ok(u);
  const im=new Image();im.onload=()=>{try{const k=Math.min(1,360/Math.max(im.naturalWidth,im.naturalHeight)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.naturalWidth*k));c.height=Math.max(1,Math.round(im.naturalHeight*k));c.getContext('2d').drawImage(im,0,0,c.width,c.height);ok(c.toDataURL('image/jpeg',.7));}catch(e){ok(u);}};im.onerror=()=>ok(u);im.src=u;});}
async function lean(o){
  if(typeof o==='string')return shrink(o);
  if(Array.isArray(o)){const r=[];for(const x of o)r.push(await lean(x));return r;}
  if(o&&typeof o==='object'){const r={};for(const k of Object.keys(o))r[k]=await lean(o[k]);return r;}
  return o;}
async function put(path,obj,msg){await npsGhPut(owner,path,b64(JSON.stringify(await lean(obj))),msg);}
async function list(dir){
  try{const r=await fetch('https://api.github.com/repos/'+owner+'/'+NPS_MEM+'/contents/'+dir+'?_='+Date.now(),{headers:npsGhH(),cache:'no-store'});
    if(r.status===404)return {ok:true,names:[]};if(!r.ok)return {ok:false,names:[]};
    const a=await r.json();return {ok:Array.isArray(a),names:(Array.isArray(a)?a:[]).filter(x=>x.type==='file'&&/\.json$/.test(x.name)).map(x=>x.name.replace(/\.json$/,''))};
  }catch(e){return {ok:false,names:[]};}}
async function getJ(path){const r=await npsGhRaw(owner,path);if(r.status!==200)return null;try{return JSON.parse(r.text);}catch(e){return null;}}
async function del(path){const sha=await npsGhFindSha(owner,path);if(!sha)return;
  const r=await fetch('https://api.github.com/repos/'+owner+'/'+NPS_MEM+'/contents/'+path,{method:'DELETE',headers:{...npsGhH(),'Content-Type':'application/json'},body:JSON.stringify({message:'Suppression '+path,sha})});
  if(!r.ok&&r.status!==404)throw new Error('suppression refusée (HTTP '+r.status+')');}
/* --- copie locale : IndexedDB des rapports --- */
function idb(){return new Promise((ok,ko)=>{try{const q=indexedDB.open('ff_reports',1);q.onupgradeneeded=()=>q.result.createObjectStore('r',{keyPath:'id'});q.onsuccess=()=>ok(q.result);q.onerror=()=>ko();}catch(e){ko();}});}
const idbAll=()=>idb().then(d=>new Promise(ok=>{const q=d.transaction('r').objectStore('r').getAll();q.onsuccess=()=>ok(q.result||[]);q.onerror=()=>ok([]);})).catch(()=>[]);
const idbPut=x=>idb().then(d=>new Promise(ok=>{const t=d.transaction('r','readwrite');t.objectStore('r').put(x);t.oncomplete=()=>ok();t.onerror=()=>ok();})).catch(()=>{});
const idbDel=id=>idb().then(d=>new Promise(ok=>{const t=d.transaction('r','readwrite');t.objectStore('r').delete(id);t.oncomplete=()=>ok();t.onerror=()=>ok();})).catch(()=>{});
const hist=()=>{const l=gj('ff_history',[]);return Array.isArray(l)?l:[];};
/* --- envoi : tout ce qui n'est pas encore dans GitHub --- */
async function pushAll(){
  if(!tok())return;await ensureRepo();
  let sy=new Set(gj(KR,[]));
  for(const x of await idbAll()){if(!x||!x.id||sy.has(x.id))continue;
    await put('rapports/'+x.id+'.json',x,'Rapport '+x.id);sy.add(x.id);sj(KR,[...sy]);}
  sy=new Set(gj(KS,[]));
  for(const h of hist()){const id=String(h.ts);if(sy.has(id))continue;
    await put('scripts/'+id+'.json',h,'Script '+id);sy.add(id);sj(KS,[...sy]);}
  const cfg=JSON.stringify({ff_main:localStorage.getItem('ff_main'),ff_goal:localStorage.getItem('ff_goal'),ff_accounts:localStorage.getItem('ff_accounts')});
  if((cfg!==JSON.stringify({ff_main:null,ff_goal:null,ff_accounts:null}))&&cfg!==localStorage.getItem(KC)){await put('reglages/ff.json',JSON.parse(cfg),'Réglages');try{localStorage.setItem(KC,cfg);}catch(e){}}
}
function flush(){chain=chain.then(pushAll).catch(fail);return chain;}
let tmr=null;const later=()=>{clearTimeout(tmr);tmr=setTimeout(flush,1500);};
/* --- réception : tout ce qui est dans GitHub et pas ici --- */
async function pull(){
  if(!tok()){readyRes();return;}
  try{
    await ensureRepo();
    const rl=await list('rapports');
    if(rl.ok){
      const local=await idbAll(),have=new Set(local.map(x=>x.id)),sy=new Set(gj(KR,[])),rem=new Set(rl.names),miss=rl.names.filter(n=>!have.has(n));
      for(let i=0;i<miss.length;i+=4)await Promise.all(miss.slice(i,i+4).map(async n=>{const x=await getJ('rapports/'+n+'.json');if(x&&x.id){await idbPut(x);sy.add(x.id);}}));
      if(rl.names.length>0&&rl.names.length<1000)for(const x of local){if(sy.has(x.id)&&!rem.has(x.id)){await idbDel(x.id);sy.delete(x.id);}}
      sj(KR,[...sy]);
    }
    const sl=await list('scripts');
    if(sl.ok){
      const l=hist(),have=new Set(l.map(h=>String(h.ts))),sy=new Set(gj(KS,[])),rem=new Set(sl.names),miss=sl.names.filter(n=>!have.has(n));let add=[];
      for(let i=0;i<miss.length;i+=4)await Promise.all(miss.slice(i,i+4).map(async n=>{const h=await getJ('scripts/'+n+'.json');if(h&&h.ts){add.push(h);sy.add(String(h.ts));}}));
      let all=l.concat(add);
      if(sl.names.length>0&&sl.names.length<1000)all=all.filter(h=>!(sy.has(String(h.ts))&&!rem.has(String(h.ts))));
      all.sort((a,b)=>b.ts-a.ts);sj('ff_history',all);sj(KS,[...sy].filter(id=>all.some(h=>String(h.ts)===id)));
    }
    const cfg=await getJ('reglages/ff.json');
    if(cfg){try{if(cfg.ff_main&&!localStorage.getItem('ff_main'))localStorage.setItem('ff_main',cfg.ff_main);if(cfg.ff_goal&&!localStorage.getItem('ff_goal'))localStorage.setItem('ff_goal',cfg.ff_goal);if(cfg.ff_accounts&&!localStorage.getItem('ff_accounts'))localStorage.setItem('ff_accounts',cfg.ff_accounts);}catch(e){}}
  }catch(e){fail(e);}
  finally{firstDone=true;readyRes();}
  flush();
}
let lastPull=0;const pullSoon=()=>{if(Date.now()-lastPull<30000)return;lastPull=Date.now();pull();};
window.ffSync={
  ready:()=>firstDone?Promise.resolve():Promise.race([ready,new Promise(r=>setTimeout(r,5000))]),
  rep:id=>{sj(KR,gj(KR,[]).filter(i=>i!==id));later();},
  script:ts=>{sj(KS,gj(KS,[]).filter(i=>i!==String(ts)));later();},
  repDel:id=>{sj(KR,gj(KR,[]).filter(i=>i!==id));chain=chain.then(async()=>{if(!tok())return;await ensureRepo();await del('rapports/'+id+'.json');}).catch(fail);},
  flush:flush,pull:pull};
setTimeout(pullSoon,2500);
setInterval(()=>{if(document.visibilityState==='visible')pullSoon();},45000);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')pullSoon();});
window.addEventListener('online',pullSoon);
})();
