/* ================= CONTACT : questions guidées puis e-mail pré-rempli ================= */
(function(){
const MAIL='fablefastaide@gmail.com';
const host=document.createElement('div');host.id='ct-host';
host.style.cssText='display:none;position:fixed;inset:0;z-index:9100;background:#0f1116';
document.body.appendChild(host);
const R=host.attachShadow({mode:'open'});
const I=(p,s)=>'<svg viewBox="0 0 24 24" width="'+(s||22)+'" height="'+(s||22)+'" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>';
const IC={back:I('<path d="M15 6l-6 6 6 6"/>'),chev:I('<path d="M9 6l6 6-6 6"/>',18),ok:I('<path d="M20 6L9 17l-5-5"/>',16),
 question:I('<circle cx="12" cy="12" r="9"/><path d="M9.500 9.500a2.500 2.500 0 1 1 3.500 2.300c-.7.4-1 .9-1 1.700M12 17h.01"/>'),
 bug:I('<rect x="8" y="7" width="8" height="12" rx="4"/><path d="M12 7V4M8 11H4M16 11h4M8 16H5M16 16h3M9 4l1.500 2M15 4l-1.500 2"/>'),
 idea:I('<path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.700c.6.500 1 1.300 1 2.300h6c0-1 .4-1.800 1-2.300A7 7 0 0 0 12 2z"/>'),
 collab:I('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.900M16 3.100a4 4 0 0 1 0 7.800"/>'),
 other:I('<path d="M21 12a8 8 0 0 1-11.600 7.100L4 20l1-4.600A8 8 0 1 1 21 12z"/>')};
const CATS=[
 {k:'question',t:'Poser une question',d:'Comprendre une fonction, un réglage',cas:['Comment utiliser une fonction','Idées créatives et séries','Clé API ou modèle IA','Mon profil ou mes statistiques','Une autre question'],ph:'Explique ce que tu veux savoir…'},
 {k:'bug',t:'Signaler un problème',d:'Quelque chose ne marche pas',cas:['L’application se bloque ou est lente','Une analyse échoue','Le téléchargement ne marche pas','Un écran s’affiche mal','Un autre problème'],ph:'Que s’est-il passé ? Sur quel écran ? Qu’as-tu fait juste avant ?'},
 {k:'idea',t:'Proposer une amélioration',d:'Une idée pour rendre l’outil meilleur',cas:['Une nouvelle fonction','Améliorer un écran','De meilleurs résultats de l’IA','Une nouvelle plateforme','Une autre idée'],ph:'Décris ton idée : à quoi ça servirait et comment tu l’imagines ?'},
 {k:'collab',t:'Collaboration',d:'Partenariat, presse, coaching',cas:['Partenariat','Presse et médias','Formation ou coaching','Autre collaboration'],ph:'Présente-toi et explique ce que tu proposes…'},
 {k:'other',t:'Autre sujet',d:'Un message libre',cas:[],ph:'Écris ton message…'}];
let st={step:0,cat:null,cas:'',msg:'',name:'',reply:'',tech:true},depth=0;
R.innerHTML='<style>:host{--bg:#0f1116;--card:#1b1c22;--line:#2a2b33;--mut:#9a9aa6;--grad:linear-gradient(90deg,#e86bb0,#5b8cf0,#a77bf0)}'+
'*{box-sizing:border-box;margin:0}button{font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent;color:inherit}'+
'.app{height:100%;display:flex;flex-direction:column;color:#fff;font-family:-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg)}'+
'header{display:flex;align-items:center;gap:8px;padding:10px 10px 10px 6px;border-bottom:1px solid var(--line);flex:none}header h1{flex:1;font-size:17px;font-weight:700;text-align:center}'+
'.ib{width:42px;height:42px;display:grid;place-items:center;background:none;border:0;color:#fff;border-radius:12px}.sp{width:42px}'+
'.bar{height:3px;background:var(--line)}.bar i{display:block;height:100%;background:var(--grad);transition:width .25s}'+
'.body{flex:1;overflow-y:auto;padding:20px 16px 28px}.body h2{font-size:21px;line-height:1.25;margin-bottom:6px}.body>p{color:var(--mut);font-size:14.5px;line-height:1.45;margin-bottom:18px}'+
'.opt{display:flex;align-items:center;gap:13px;width:100%;text-align:left;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:10px}.opt:active{border-color:#a77bf0}'+
'.opt .ic{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;background:rgba(167,123,240,.16);color:#cdb6ff;flex:none}.opt .tx{flex:1}.opt b{display:block;font-size:15.5px}.opt small{color:var(--mut);font-size:13px}.opt .ch{color:var(--mut)}'+
'.opt.s{padding:15px 16px;font-size:15.5px}.opt.s span:first-child{flex:1}'+
'label{display:block;font-size:13px;color:var(--mut);margin:16px 0 6px}textarea,input[type=text],input[type=email]{width:100%;background:var(--card);border:1.5px solid #3b3c47;border-radius:14px;color:#fff;font:inherit;font-size:16px;padding:12px 14px;outline:0}textarea{min-height:150px;resize:vertical;line-height:1.45}textarea:focus,input:focus{border-color:#a77bf0}'+
'.chk{display:flex;gap:10px;align-items:flex-start;color:#d5d6de;font-size:14px;line-height:1.4;margin-top:16px}.chk input{margin-top:3px;width:18px;height:18px;accent-color:#a77bf0}'+
'.cta{display:block;width:100%;margin-top:20px;padding:15px;border:0;border-radius:14px;background:var(--grad);color:#fff;font-weight:700;font-size:16px}.cta:disabled{opacity:.4}'+
'.sec{display:block;width:100%;margin-top:10px;padding:13px;border:1px solid var(--line);border-radius:14px;background:none;font-size:15px;color:#d5d6de;text-align:center;text-decoration:none}'+
'.to{display:flex;gap:8px;align-items:center;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px;font-size:14.5px;margin-bottom:12px}.to span{color:var(--mut)}'+
'.pre{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;line-height:1.5;white-space:pre-wrap;word-break:break-word;color:#e6e7ee;max-height:44vh;overflow:auto}'+
'.hint{color:var(--mut);font-size:12.5px;margin-top:10px;line-height:1.4}@media(min-width:900px){.app{max-width:860px;margin:0 auto;width:100%;border-left:1px solid var(--line,#2a2b33);border-right:1px solid var(--line,#2a2b33)}}</style>'+
'<div class="app"><header><button class="ib" id="bk" aria-label="Retour">'+IC.back+'</button><h1>Nous contacter</h1><span class="sp"></span></header><div class="bar"><i id="pg"></i></div><div class="body" id="bd"></div></div>';
const $=s=>R.querySelector(s);
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const cat=()=>CATS.find(c=>c.k===st.cat);
function tech(){var n=navigator,m=(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches)?'sombre':'clair';return 'Appareil : '+(n.userAgent||'?')+'\nÉcran : '+screen.width+'×'+screen.height+' · langue '+(n.language||'?')+' · thème '+m;}
function mainProfile(){try{var m=JSON.parse(localStorage.getItem('ff_main')||'null');return m&&m.u?m.p+' @'+m.u:'';}catch(e){return '';}}
function build(){
  var c=cat(),subj='[Fable Fast] '+c.t+(st.cas?' – '+st.cas:'');
  var b='Bonjour,\n\n'+st.msg.trim()+'\n\n';
  if(st.name.trim())b+='— '+st.name.trim()+'\n';
  b+='Sujet : '+c.t+(st.cas?' › '+st.cas:'')+'\n';
  if(st.reply.trim())b+='Me répondre à : '+st.reply.trim()+'\n';
  if(st.tech){var mp=mainProfile();if(mp)b+='Profil principal : '+mp+'\n';b+='\n'+tech()+'\n';}
  return {subj:subj,body:b};
}
function draw(){
  var bd=$('#bd'),c=cat(),h='';
  $('#pg').style.width=[8,34,64,100][st.step]+'%';
  if(st.step===0){
    h='<h2>Comment pouvons-nous t’aider ?</h2><p>Choisis un sujet : on prépare ton message pour qu’il arrive clair et complet.</p>'+CATS.map(function(x){return '<button class="opt" data-c="'+x.k+'"><span class="ic">'+IC[x.k]+'</span><span class="tx"><b>'+x.t+'</b><small>'+x.d+'</small></span><span class="ch">'+IC.chev+'</span></button>';}).join('');
  }else if(st.step===1){
    h='<h2>'+esc(c.t)+'</h2><p>Quel est le cas le plus proche ?</p>'+c.cas.map(function(x){return '<button class="opt s" data-s="'+esc(x)+'"><span>'+esc(x)+'</span><span class="ch">'+IC.chev+'</span></button>';}).join('');
  }else if(st.step===2){
    h='<h2>Ton message</h2><p>'+esc(c.t)+(st.cas?' › '+esc(st.cas):'')+'</p><textarea id="m" placeholder="'+esc(c.ph)+'">'+esc(st.msg)+'</textarea>'+
    '<label>Ton prénom ou pseudo (facultatif)</label><input type="text" id="nm" value="'+esc(st.name)+'" autocomplete="name">'+
    '<label>Ton e-mail pour la réponse (facultatif)</label><input type="email" id="rp" value="'+esc(st.reply)+'" placeholder="toi@exemple.com" autocomplete="email">'+
    '<label class="chk"><input type="checkbox" id="tc"'+(st.tech?' checked':'')+'><span>Joindre les infos techniques (appareil, navigateur) et mon profil principal : ça nous aide à comprendre plus vite.</span></label>'+
    '<button class="cta" id="nx">Continuer</button>';
  }else{
    var m=build();
    h='<h2>Prêt à envoyer</h2><p>Ton application e-mail va s’ouvrir avec le destinataire, l’objet et le message déjà remplis. Il ne te reste qu’à appuyer sur Envoyer.</p>'+
    '<div class="to"><span>À</span><b>'+MAIL+'</b></div><div class="pre"><b>'+esc(m.subj)+'</b>\n\n'+esc(m.body)+'</div>'+
    '<button class="cta" id="se">Ouvrir mon e-mail</button>'+
    '<a class="sec" target="_blank" rel="noopener" href="https://mail.google.com/mail/?view=cm&fs=1&to='+MAIL+'&su='+encodeURIComponent(m.subj)+'&body='+encodeURIComponent(m.body)+'">Ouvrir dans Gmail</a>'+
    '<button class="sec" id="cp">Copier le message</button><div class="hint">Si rien ne s’ouvre, copie le message et écris-nous à '+MAIL+'.</div>';
  }
  bd.innerHTML=h;bd.scrollTop=0;
  bd.querySelectorAll('[data-c]').forEach(function(b){b.onclick=function(){st.cat=b.dataset.c;st.cas='';st.step=cat().cas.length?1:2;draw();};});
  bd.querySelectorAll('[data-s]').forEach(function(b){b.onclick=function(){st.cas=b.dataset.s;st.step=2;draw();};});
  var nx=$('#nx');if(nx){var m=$('#m');var upd=function(){nx.disabled=m.value.trim().length<5;};m.oninput=upd;upd();
    nx.onclick=function(){st.msg=m.value;st.name=$('#nm').value;st.reply=$('#rp').value;st.tech=$('#tc').checked;st.step=3;draw();};}
  var se=$('#se');if(se)se.onclick=function(){var m=build();window.location.href='mailto:'+MAIL+'?subject='+encodeURIComponent(m.subj)+'&body='+encodeURIComponent(m.body);};
  var cp=$('#cp');if(cp)cp.onclick=function(){var m=build(),t='À : '+MAIL+'\nObjet : '+m.subj+'\n\n'+m.body;
    var fb=function(){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy');}catch(e){}a.remove();};
    if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).catch(fb);else fb();
    cp.textContent='Message copié ✓';};
}
function back(){
  if(st.step===0){hist();return;}
  if(st.step===2&&!(cat().cas.length))st.step=0;else st.step--;
  draw();
}
function push(){try{history.pushState({ct:1},'');depth++;}catch(e){}}
function close(){host.style.display='none';if(depth>0){var d=depth;depth=0;try{window.NAV&&(NAV.ignorePop=true);}catch(e){}try{history.go(-d);}catch(e){}}}
function hist(){if(depth>0)history.back();else close();}
$('#bk').onclick=back;
window.addEventListener('popstate',function(){if(host.style.display==='none')return;depth=Math.max(0,depth-1);host.style.display='none';});
window.ffContactOpen=function(){
  try{if(typeof closeSidebar==='function')closeSidebar();}catch(e){}
  st={step:0,cat:null,cas:'',msg:'',name:'',reply:'',tech:true};
  if(host.style.display==='none'||depth===0){depth=0;push();}
  host.style.display='block';draw();
};
})();
