/* ===== Stockage · Bibliothèque · Position ===== */
(function(){
var $=function(s,r){return (r||document).querySelector(s);};
var esc=function(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');};
function ic(p,s){return '<svg width="'+(s||22)+'" height="'+(s||22)+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>';}
var CH=ic('<path d="M9 6l6 6-6 6"/>',18);
var T={img:ic('<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.500" cy="8.500" r="1.500"/><path d="M21 15l-5-5L5 21"/>',22),
 vid:ic('<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 9h18M8 4l3 5M14 4l3 5"/>',22),
 doc:ic('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',22),
 web:ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',22),
 zip:ic('<path d="M21 8v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8"/><rect x="1" y="3" width="22" height="5" rx="1.500"/><path d="M10 12h4"/>',22)};
var IMG=/\.(png|jpe?g|gif|webp|bmp|svg|avif|heic)$/i,VID=/\.(mp4|mov|webm|mkv|avi|m4v)$/i,WEB=/\.(html?|css|js|json)$/i,ZIP=/\.(zip|apk|rar|7z|tar|gz)$/i;
function kind(p){return IMG.test(p)?'img':VID.test(p)?'vid':WEB.test(p)?'web':ZIP.test(p)?'zip':'doc';}
function fmt(b){b=+b||0;if(b>=1073741824)return (b/1073741824).toFixed(b>=1.07e10?0:1).replace('.',',')+' Go';if(b>=1048576)return (b/1048576).toFixed(b>=1.05e8?0:1).replace('.',',')+' Mo';if(b>=1024)return Math.round(b/1024)+' Ko';return b+' o';}
function mkView(id,html){var v=document.getElementById('view-'+id);if(!v){v=document.createElement('div');v.className='view';v.id='view-'+id;document.getElementById('view-chat').parentNode.appendChild(v);}v.innerHTML=html;return v;}
function go(id,title){try{if(typeof closeSidebar==='function')closeSidebar();}catch(e){}showView(id);setTitle(title);}
var ST={files:null,sizes:null,err:null,tab:'all',sel:{}};

/* ---------- GitHub ---------- */
function hdr(){return npsGhH?npsGhH():{'Authorization':'Bearer '+S.tok,'Accept':'application/vnd.github.v3+json'};}
async function loadGh(){
  if(!S.tok)throw new Error('notok');
  var owner=await getGhLogin();if(!owner)throw new Error('notok');
  var out=[],sizes={},H=hdr();
  for(var repo of ['Maker','MyBot']){
    try{
      var r=await fetch('https://api.github.com/repos/'+owner+'/'+repo,{headers:H,cache:'no-store'});
      if(!r.ok)continue;var j=await r.json();sizes[repo]=(j.size||0)*1024;
      var t=await fetch('https://api.github.com/repos/'+owner+'/'+repo+'/git/trees/'+(j.default_branch||'HEAD')+'?recursive=1',{headers:H,cache:'no-store'});
      if(!t.ok)continue;var tj=await t.json();
      (tj.tree||[]).forEach(function(e){if(e.type==='blob')out.push({repo:repo,owner:owner,path:e.path,sha:e.sha,size:e.size||0,name:e.path.split('/').pop(),k:kind(e.path)});});
    }catch(e){}
  }
  out.sort(function(a,b){return a.path<b.path?1:-1;});
  ST.files=out;ST.sizes=sizes;ST.owner=owner;return out;
}

/* ---------- Stockage ---------- */
function lsGroups(){
  var g={conv:0,idees:0,autres:0},tot=0;
  try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i),n=(k.length+(localStorage.getItem(k)||'').length)*2;tot+=n;
    if(/^(ff_history|ff_ix|ff_agent)/.test(k))g.idees+=n;else if(/conv|chat|msg/i.test(k))g.conv+=n;else g.autres+=n;}}catch(e){}
  g.tot=tot;return g;
}
function row(l,v,on){return '<button class="row"'+(on?' onclick="'+on+'"':'')+'><span class="l">'+l+'</span><span class="v">'+v+'</span>'+(on?'<span class="ch">'+CH+'</span>':'')+'</button>';}
async function renderStore(){
  var v=$('#xs-body');v.innerHTML='<div class="sk" style="width:60%"></div><div class="sk" style="height:14px"></div><div class="sk"></div><div class="sk" style="width:80%"></div>';
  var est={};try{if(navigator.storage&&navigator.storage.estimate)est=await navigator.storage.estimate();}catch(e){}
  var g=lsGroups(),h='';
  var gh='';
  try{
    var files=await loadGh();
    var used=0;for(var r in ST.sizes)used+=ST.sizes[r];
    var im=0,fl=0;files.forEach(function(f){if(f.k==='img')im+=f.size;else fl+=f.size;});
    var LIM=1073741824,pc=Math.min(100,Math.max(2,used/LIM*100));
    gh='<h3>GitHub · projet</h3><div class="big">'+fmt(used)+' sur 1 Go utilisés</div><div class="pbar"><i style="width:'+pc+'%"></i></div>'+
      '<div class="card">'+row('Fichiers',fmt(fl),"ffLibOpen('files')")+row('Images',fmt(im),"ffLibOpen('images')")+'</div>'+
      '<div class="sub">Dépôts du projet : '+Object.keys(ST.sizes).map(function(r){return esc(r)+' '+fmt(ST.sizes[r]);}).join(' · ')+'. Le total compte tout l’historique GitHub ; 1 Go est la taille recommandée par dépôt.</div>';
  }catch(e){
    gh='<h3>GitHub · projet</h3><div class="note">'+(e.message==='notok'?'GitHub n’est pas connecté. Ajoute ton token dans « Modèle & Clés API » pour voir l’espace utilisé par le projet et tes fichiers.':'Impossible de lire GitHub pour le moment ('+esc(e.message)+').')+'</div>'+
      '<button class="btn" onclick="showView(\'apikeys\');setTitle(\'Modèle &amp; Clés API\')">Ouvrir Modèle &amp; Clés API</button>';
  }
  var us=est.usage||g.tot,q=est.quota||0;
  var br='<h3>Navigateur</h3><div class="big">'+fmt(us)+(q?' sur '+fmt(q)+' utilisés':' utilisés')+'</div><div class="pbar"><i style="width:'+(q?Math.min(100,Math.max(2,us/q*100)):4)+'%"></i></div>'+
    '<div class="card">'+row('Conversations',fmt(g.conv))+row('Idées, séries et agent',fmt(g.idees))+row('Réglages et autres données',fmt(g.autres))+row('Cache et fichiers hors ligne',fmt(Math.max(0,us-g.tot)))+'</div>'+
    '<div class="sub">Espace occupé par Fable Fast dans ce navigateur, sur ton téléphone.</div>';
  v.innerHTML=gh+br+'<button class="btn" onclick="ffStoreOpen(true)">Actualiser</button>';
}
window.ffStoreOpen=function(refresh){
  if(!refresh||!$('#xs-body')){mkView('storage','<div class="xv" id="xs-body"></div>');go('storage','Stockage');}
  renderStore();
};

/* ---------- Bibliothèque ---------- */
var TITLES={all:'Bibliothèque'};
function selKeys(){return Object.keys(ST.sel);}
function renderLib(){
  var v=$('#xl-body');if(!v)return;
  var all=ST.files||[],list=all.filter(function(f){return ST.tab==='all'||(ST.tab==='images'?f.k==='img':f.k!=='img');});
  var n=selKeys().length;
  var tabs=[['all','Tous'],['images','Images'],['files','Fichiers']].map(function(t){return '<button data-t="'+t[0]+'" class="'+(ST.tab===t[0]?'on':'')+'">'+t[1]+'</button>';}).join('');
  var body=ST.err?'<div class="lb-empty">'+ST.err+'</div>':!ST.files?'<div class="sk"></div><div class="sk" style="width:70%"></div>':!list.length?'<div class="lb-empty">Aucun fichier ici pour le moment.</div>':
    '<div class="lb-grid">'+list.map(function(f){var id=f.repo+'/'+f.path;return '<div class="lb-c'+(ST.sel[id]?' on':'')+'" data-id="'+esc(id)+'"><div class="lb-n">'+esc(f.name)+'</div><span class="lb-k">'+(ST.sel[id]?ic('<path d="M20 6L9 17l-5-5"/>',15):'')+'</span><div class="lb-m"><span>'+fmt(f.size)+'</span>'+T[f.k]+'</div></div>';}).join('')+'</div>';
  v.innerHTML='<div class="lb-top'+(n?' show':'')+'"><button id="lb-x" aria-label="Annuler">'+ic('<path d="M18 6L6 18M6 6l12 12"/>',20)+'</button><span>'+n+' sélectionné'+(n>1?'s':'')+'</span></div><div class="lb-tabs">'+tabs+'</div>'+body;
  var pill=$('#lb-pill');if(pill)pill.classList.toggle('show',n>0);
  v.querySelectorAll('[data-t]').forEach(function(b){b.onclick=function(){ST.tab=b.dataset.t;renderLib();};});
  v.querySelectorAll('.lb-c').forEach(function(c){c.onclick=function(){var id=c.dataset.id;if(ST.sel[id])delete ST.sel[id];else ST.sel[id]=1;renderLib();};});
  var x=$('#lb-x');if(x)x.onclick=function(){ST.sel={};renderLib();};
}
function picked(){return (ST.files||[]).filter(function(f){return ST.sel[f.repo+'/'+f.path];});}
async function dl(f){
  var r=await fetch('https://api.github.com/repos/'+f.owner+'/'+f.repo+'/git/blobs/'+f.sha,{headers:hdr(),cache:'no-store'});
  if(!r.ok)throw new Error('GitHub '+r.status);var j=await r.json();
  var bin=atob((j.content||'').replace(/\s/g,'')),u=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
  var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([u]));a.download=f.name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},4000);
}
async function delAll(){
  var ps=picked(),ok=0;
  for(var f of ps){
    try{var r=await fetch('https://api.github.com/repos/'+f.owner+'/'+f.repo+'/contents/'+f.path.split('/').map(encodeURIComponent).join('/'),{method:'DELETE',headers:Object.assign({'Content-Type':'application/json'},hdr()),body:JSON.stringify({message:'Suppression : '+f.name,sha:f.sha})});
      if(r.ok){ok++;ST.files=ST.files.filter(function(x){return x!==f;});}}catch(e){}
  }
  ST.sel={};renderLib();
  try{toast(ok+' fichier'+(ok>1?'s':'')+' supprimé'+(ok>1?'s':'')+(ok<ps.length?' · '+(ps.length-ok)+' en échec':''));}catch(e){}
}
window.ffLibOpen=function(tab){
  ST.tab=tab||'all';ST.sel={};
  mkView('library','<div class="xv" id="xl-body"></div><div class="lb-pill" id="lb-pill"><button class="dn" id="lb-del" aria-label="Supprimer">'+ic('<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>')+'</button><button id="lb-dl" aria-label="Télécharger">'+ic('<path d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16"/>')+'</button></div>'+
    '<div class="lb-cf" id="lb-cf"><div><b id="lb-cft" style="font-size:18px"></b><p>Cette action est définitive : les fichiers seront supprimés de GitHub.</p><div class="b2"><button id="lb-no">Annuler</button><button class="dg" id="lb-yes">Supprimer</button></div></div></div>');
  go('library','Bibliothèque');
  $('#lb-dl').onclick=async function(){var ps=picked();for(var f of ps){try{await dl(f);}catch(e){try{toast('Échec : '+f.name,true);}catch(_){}}}};
  $('#lb-del').onclick=function(){var n=selKeys().length;$('#lb-cft').textContent='Supprimer '+n+' fichier'+(n>1?'s':'')+' ?';$('#lb-cf').classList.add('show');};
  $('#lb-no').onclick=function(){$('#lb-cf').classList.remove('show');};
  $('#lb-yes').onclick=function(){$('#lb-cf').classList.remove('show');delAll();};
  ST.err=null;renderLib();
  (ST.files?Promise.resolve():loadGh()).then(function(){renderLib();}).catch(function(e){ST.err=e.message==='notok'?'GitHub n’est pas connecté. Ajoute ton token dans « Modèle & Clés API » pour voir tous tes fichiers.':'Impossible de lire GitHub ('+esc(e.message)+').';renderLib();});
};

/* ---------- Position ---------- */
function geoGet(){try{return JSON.parse(localStorage.getItem('ff_geo')||'null');}catch(e){return null;}}
window.ffGeoLine=function(){var g=geoGet();return g&&g.on&&g.lat!=null?'\n\nPosition approximative de l’utilisateur (partagée volontairement, à n’utiliser que si utile : tendances locales, fuseau, langue) : lat '+g.lat+', lon '+g.lon+'.':'';};
function drawGeo(msg){
  var g=geoGet(),on=!!(g&&g.on);
  mkView('geo','<div class="xv"><div class="gp-card"><div class="gp-ic">'+ic('<path d="M12 21s7-6.200 7-11.500A7 7 0 0 0 5 9.500C5 14.800 12 21 12 21z"/><circle cx="12" cy="9.500" r="2.500"/>',28)+'</div><h2>Emplacement</h2><p>Partage ta position pour que l’agent et les idées tiennent compte de ta région (tendances locales, langue, fuseau). Elle reste sur ton appareil, arrondie à quelques kilomètres.</p></div>'+
   '<div class="gp-row"><span>Partager mon emplacement</span><div class="gp-sw'+(on?' on':'')+'" id="gp-sw" role="switch" aria-checked="'+on+'"><i></i></div></div>'+
   (on&&g.lat!=null?'<div class="sub">Position enregistrée : '+g.lat+', '+g.lon+(g.ts?' · '+new Date(g.ts).toLocaleDateString('fr-FR'):'')+'</div><button class="btn" id="gp-up">Actualiser ma position</button>':'')+
   (msg?'<div class="note">'+msg+'</div>':'')+'</div>');
  $('#gp-sw').onclick=function(){if(on){localStorage.setItem('ff_geo',JSON.stringify({on:false}));drawGeo();}else ask();};
  var u=$('#gp-up');if(u)u.onclick=ask;
}
function ask(){
  if(!navigator.geolocation){drawGeo('Ce navigateur ne permet pas de partager la position.');return;}
  navigator.geolocation.getCurrentPosition(function(p){
    var r=function(x){return Math.round(x*50)/50;};
    localStorage.setItem('ff_geo',JSON.stringify({on:true,lat:r(p.coords.latitude),lon:r(p.coords.longitude),acc:Math.round(p.coords.accuracy||0),ts:Date.now()}));
    drawGeo();try{toast('Position enregistrée');}catch(e){}
  },function(e){
    localStorage.setItem('ff_geo',JSON.stringify({on:false}));
    drawGeo(e&&e.code===1?'Autorisation refusée. Active la position pour ce site dans les réglages du navigateur, puis réessaie.':'Position introuvable pour le moment. Réessaie dans un instant.');
  },{enableHighAccuracy:false,timeout:15000,maximumAge:600000});
}
window.ffGeoOpen=function(){drawGeo();go('geo','Position');};
})();
