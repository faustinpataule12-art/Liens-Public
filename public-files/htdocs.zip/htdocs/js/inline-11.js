// ═══════ NOTIFICATIONS DE FIN DE TÂCHE ═══════
function npsNotifEnabled(){ return localStorage.getItem('nps_notify') === '1' && window.Notification && Notification.permission === 'granted'; }
function npsSyncNotifToggle(){ const t = document.getElementById('notif-toggle'); if (t) t.classList.toggle('on', npsNotifEnabled()); }
async function npsToggleNotif(el){
  if (npsNotifEnabled()) { safeSetItem('nps_notify', '0'); npsSyncNotifToggle(); toast('Notifications désactivées'); return; }
  if (!window.Notification) { toast('Notifications non disponibles dans ce navigateur ou cette version', true); npsSyncNotifToggle(); return; }
  let perm = Notification.permission;
  try { if (perm !== 'granted') perm = await Notification.requestPermission(); } catch (e) {}
  if (perm === 'granted') { safeSetItem('nps_notify', '1'); toast('Notifications activées'); }
  else { safeSetItem('nps_notify', '0'); toast('Autorisation refusée par le système', true); }
  npsSyncNotifToggle();
}
function npsNotifyDone(){
  try {
    if (!npsNotifEnabled() || !document.hidden) return;
    new Notification('Fable Fast', { body: 'La tâche est terminée.', tag: 'nps-done' });
  } catch (e) {}
}
window.addEventListener('load', () => { try { npsSyncNotifToggle(); npsSyncTtsEngineBtns(); } catch (e) {} });

function setTtsRate(rate){
  S.ttsRate = rate;
  safeSetItem('nps_tts_rate', rate);
  document.querySelectorAll('.tts-rate-btn').forEach(b => b.classList.toggle('active', parseFloat(b.dataset.rate) === rate));
  toast('Vitesse de lecture : ' + (rate===0.75?'Lent':rate===1?'Normal':rate===1.15?'Un peu vite':'Rapide'));
}

function toggleApi(inputId,eyeId){
  const i=document.getElementById(inputId);
  i.type=i.type==='password'?'text':'password';
}
function openProviderPicker(){
  document.getElementById('provider-popup-overlay').classList.add('show');
}
function closeProviderPicker(){
  document.getElementById('provider-popup-overlay').classList.remove('show');
}
function pickProvider(p){
  closeProviderPicker();
  pickProviderSilent(p);
  const target=document.getElementById(PROVIDER_FIELD_MAP[p]);
  if(target)target.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function pickProviderSilent(p){
  Object.values(PROVIDER_FIELD_MAP).forEach(id=>{const el=document.getElementById(id);if(el)el.style.display='none';});
  const target=document.getElementById(PROVIDER_FIELD_MAP[p]);
  if(target){target.style.display='block';}
}

/**
 * Un seul modèle actif à la fois : sauvegarder une clé efface les autres
 * (localStorage + état S), pour éviter toute confusion sur quel modèle répond.
 */
function clearOtherProviderKeys(keep){
  const all={gem:'nps_gem_tok',oai:'nps_oai_tok',ant:'nps_ant_tok'};
  Object.entries(all).forEach(([k,storageKey])=>{
    if(k!==keep){S[k]='';localStorage.removeItem(storageKey);const el=document.getElementById(k==='gem'?'gemtoken':k==='oai'?'oaitoken':'anttoken');if(el)el.value='';const st=document.getElementById(k+'-status');if(st){st.textContent='Non configuré';st.className='api-status';}}
  });
  if(keep!=='custom'){S.customModel=null;localStorage.removeItem('nps_custom_model');}
  updateActiveProviderLabel();
}

// Pastille d'état des clés : icône SVG, jamais d'emoji.
const NPS_SVG_OK='<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
const NPS_SVG_ERR='<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';
function setApiStatus(id, state, text){
  const el=document.getElementById(id); if(!el) return;
  if(state==='ok'){ el.innerHTML=NPS_SVG_OK+'<span>Configuré</span>'; el.className='api-status ok'; }
  else if(state==='err'){ el.innerHTML=NPS_SVG_ERR+'<span>'+esc(text||'Erreur')+'</span>'; el.className='api-status err'; }
  else if(state==='wait'){ el.innerHTML='<span>'+esc(text||'Vérification…')+'</span>'; el.className='api-status'; }
  else { el.textContent=text||'Non configuré'; el.className='api-status'; }
}
function updateActiveProviderLabel(){
  const el=document.getElementById('active-provider-label');
  if(!el)return;
  const dot=c=>'<span class="nps-dot" style="background:'+c+';width:9px;height:9px;margin-right:6px"></span>';
  if(S.gem) el.innerHTML=dot('#4285f4')+'Google Gemini';
  else if(S.ant) el.innerHTML=dot('#9b6cf0')+'Anthropic / Claude';
  else if(S.oai) el.innerHTML=dot('#4caf7d')+'OpenAI';
  else if(S.customModel) el.innerHTML=dot('#8b8fa3')+esc(S.customModel.name||'Modèle personnalisé');
  else el.textContent='Aucun configuré';
}

async function syncTokensToBackend(){
  // Backend Google Cloud Run désactivé : cette URL est protégée par un compte
  // Google et bloque toute requête (CORS). L'app reste 100% fonctionnelle en
  // local sans elle — les clés ne quittent jamais l'appareil de l'utilisateur.
  return;
}

async function saveApi(inputId,key){
  const v=document.getElementById(inputId).value.trim().replace(/\r?\n|\r/g, '');
  if(!v)return;
  if(key==='gh'){
    setApiStatus('gh-status','wait','Vérification…');
    try{
      const r=await fetch('https://api.github.com/user',{headers:{'Authorization':'Bearer '+v,'Accept':'application/vnd.github.v3+json'}});
      if(!r.ok) throw new Error(r.status===401?'Token invalide':'Erreur GitHub '+r.status);
      S.tok=v; S._ghLogin=null; S._ghLoginTokenFingerprint=null; safeSetItem('nps_gh_tok',v);
      setApiStatus('gh-status','ok');
      syncMemoryFromGitHub();
      syncTokensToBackend();
      toast('Token GitHub validé');
    }catch(e){
      setApiStatus('gh-status','err',e.message);
      toast('Token GitHub invalide',true);
    }
    return;
  }
  else if(key==='oai'){clearOtherProviderKeys('oai');S.oai=v;safeSetItem('nps_oai_tok',v);setApiStatus('oai-status','ok');S.model='custom-openai';updateActiveProviderLabel();}
  else if(key==='ant'){clearOtherProviderKeys('ant');S.ant=v;safeSetItem('nps_ant_tok',v);setApiStatus('ant-status','ok');S.model='claude-sonnet-4-6';updateActiveProviderLabel();}
  else if(key==='gem'){clearOtherProviderKeys('gem');S.gem=v;safeSetItem('nps_gem_tok',v);setApiStatus('gem-status','ok');S.model='gemini-3.5-flash-lite';updateActiveProviderLabel();}
  safeSetItem('nps_model',S.model);
  syncTokensToBackend();
  toast('Clé sauvegardée');
}

function saveGlobalKey() {
    const val = document.getElementById('global-key').value.trim();
    if (val) {
        const headers = { "Authorization": "Bearer " + val };
        S.globalHeaders = headers;
        safeSetItem('nps_global_headers', JSON.stringify(headers));
        safeSetItem('nps_global_key', val);
        toast('Clé universelle sauvegardée');
        setApiStatus('global-status','ok');
    } else {
        S.globalHeaders = {};
        localStorage.removeItem('nps_global_headers');
        localStorage.removeItem('nps_global_key');
        toast('Clé universelle effacée');
        document.getElementById('global-status').textContent = 'Non configuré';
        document.getElementById('global-status').className = 'api-status';
    }
}


function toggleCap(el,key){
  el.classList.toggle('on');
  S.caps[key]=el.classList.contains('on');
  safeSetItem('nps_caps',JSON.stringify(S.caps));
  const count=Object.values(S.caps).filter(Boolean).length;
  document.getElementById('cap-count-row').textContent=count+' activée'+(count>1?'s':'');
}

function fmtText(txt, msgCtx){
  if(!txt)return'';

  const hasMsgVideo = !!(msgCtx && (msgCtx.video || (msgCtx.codeBlocks && msgCtx.codeBlocks.some(b => b.isBinaryDataUrl && /\.(mp4|webm|mov|mkv)$/i.test(b.filename)))));

  // Extraction intelligente des balises <video> brutes éventuelles avant échappement HTML
  txt = txt.replace(/<video[^>]*>[\s\S]*?<source[^>]*src=["']([^"']+)["'][^>]*>[\s\S]*?<\/video>/gi, (m, src) => hasMsgVideo ? '' : `\n[🎬 Vidéo](${src})\n`);
  txt = txt.replace(/<video[^>]*src=["']([^"']+)["'][^>]*>[\s\S]*?<\/video>/gi, (m, src) => hasMsgVideo ? '' : `\n[🎬 Vidéo](${src})\n`);
  txt = txt.replace(/<video[^>]*src=["']([^"']+)["'][^>]*\/?>/gi, (m, src) => hasMsgVideo ? '' : `\n[🎬 Vidéo](${src})\n`);
  
  // Escape html tags first
  let safeTxt = esc(txt);

  const AUDIO_EXT = /\.(mp3|wav|ogg|m4a|aac)(\?|$)/i;
  const IMG_EXT = /\.(png|jpe?g|gif|webp|svg)(\?|$)/i;
  const VIDEO_EXT = /\.(mp4|webm|ogv|mov|mkv)(\?|$)/i;
  const isAudioUrl = url => AUDIO_EXT.test(url) || /translate_tts|texttospeech|\/api\/tts/i.test(url);
  const isImageUrl = url => IMG_EXT.test(url) || /picsum\.photos|placehold/i.test(url);
  const isVideoUrl = url => VIDEO_EXT.test(url) || /^data:video\//i.test(url);

  function renderLink(url, label){
    let safeUrl = url.replace(/'/g, '%27');
    // Convertir automatiquement les URL directes Google translate_tts vers /api/tts pour éliminer les blocages CORS et 180 chars
    if (/translate\.google\.com\/translate_tts/i.test(url)) {
      try {
        const parsed = new URL(url);
        const q = parsed.searchParams.get('q');
        const tl = parsed.searchParams.get('tl') || 'fr';
        if (q) {
          url = '/api/tts?tl=' + encodeURIComponent(tl) + '&q=' + encodeURIComponent(q);
          safeUrl = url.replace(/'/g, '%27');
        }
      } catch (e) {}
    }
    if (isVideoUrl(url)) {
      // Si la bulle possède déjà un lecteur vidéo dédié ou si l'URL est relative / expirée :
      // afficher un lien propre cliquable, JAMAIS une balise <video> vide affichant 0:00
      const isValidHttpOrData = /^https?:\/\//i.test(url) || /^data:video\//i.test(url);
      if (hasMsgVideo || !isValidHttpOrData) {
        return `<a href="${url}" onclick="event.preventDefault();openLink('${safeUrl}')" style="color:var(--accent);text-decoration:underline;word-break:break-all">${label||'Vidéo'}</a>`;
      }
      return npsVideoCard(url, label || 'video.mp4');
    }
    if (isAudioUrl(url) && /translate_tts|texttospeech|\/api\/tts/i.test(url)) {
      return `<audio controls preload="none" src="${url}" style="width:100%;max-width:320px;margin-top:6px;display:block"></audio>`;
    }
    if (isImageUrl(url)) {
      return `<img class="msg-img" src="${url}" onclick="event.stopPropagation();openLightbox(this.src)"/>`;
    }
    return `<a href="${url}" onclick="event.preventDefault();openLink('${safeUrl}')" style="color:var(--accent);text-decoration:underline;word-break:break-all">${label}</a>`;
  }

  // Fusionne une suite de liens TTS consécutifs (playlist générée par generate_mp3
  // pour un texte long) en UN SEUL lecteur enchaîné, au lieu de N lecteurs séparés
  // que l'utilisateur devrait cliquer un par un. Doit tourner AVANT le remplacement
  // générique des URLs brutes ci-dessous.
  const ttsRunRe = /((?:(?:https?:\/\/translate\.google\.com\/translate_tts|\/api\/tts)[^\s<>()'"]+\s*\n?){2,})/gi;
  safeTxt = safeTxt.replace(ttsRunRe, (block) => {
    const urls = block.match(/(?:https?:\/\/|\/api\/tts)[^\s<>()'"]+/g) || [];
    if (urls.length < 2) return block;
    const playlistAttr = JSON.stringify(urls).replace(/&/g,'&amp;').replace(/'/g,'&#39;');
    return `<div class="chained-audio-wrap" data-playlist='${playlistAttr}'>
      <div class="chained-audio-label">Segment <span class="seg-cur">1</span>/<span class="seg-total">${urls.length}</span></div>
      <audio controls class="chained-audio" data-idx="0" src="${urls[0]}" style="width:100%;max-width:320px;display:block"></audio>
    </div>`;
  });

  // Liens Markdown [texte](url)
  safeTxt = safeTxt.replace(/\[([^\]]+)\]\(((?:https?:\/\/|\/api\/)(?:[^\s()]|\([^\s()]*\))+)\)/g, (m, label, url) => renderLink(url, label));

  // URLs brutes restantes (pas déjà dans un lien créé ci-dessus)
  safeTxt = safeTxt.replace(/(^|[\s(])((?:https?:\/\/|\/api\/tts)[^\s<>()'"]+)/g, (m, pre, url) => `${pre}${renderLink(url, url)}`);

  return safeTxt
    .replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>')
    .replace(/\*(.*?)\*/g,'<em>$1</em>')
    .replace(/`([^`\n]+)`/g,'<code style="background:var(--bg3);padding:1px 4px;border-radius:3px;font-size:13.5px;font-family:monospace">$1</code>')
    .replace(/\n/g,'<br>');
}

function robustCopy(text) {
  // Synchrone d'abord (execCommand), pendant le geste utilisateur : indispensable
  // en contexte non sécurisé (content://, file://) où navigator.clipboard est absent.
  text = String(text == null ? '' : text);
  function legacyCopy() {
    let ta = null;
    try {
      ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;font-size:16px;';
      document.body.appendChild(ta);
      ta.focus({ preventScroll: true });
      ta.select();
      ta.setSelectionRange(0, text.length);
      const ok = document.execCommand('copy');
      return !!ok;
    } catch (e) {
      return false;
    } finally {
      if (ta && ta.parentNode) ta.parentNode.removeChild(ta);
    }
  }
  return new Promise((resolve, reject) => {
    if (legacyCopy()) return resolve();
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(resolve).catch(reject);
    } else {
      reject(new Error('Copie impossible dans ce contexte'));
    }
  });
}

// Dernier recours : affiche le texte dans une zone sélectionnable pour copie manuelle.
function showManualCopy(text, title) {
  const old = document.getElementById('nps-manual-copy');
  if (old) old.remove();
  const ov = document.createElement('div');
  ov.id = 'nps-manual-copy';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:100000;display:flex;align-items:center;justify-content:center;padding:12px;';
  const box = document.createElement('div');
  box.style.cssText = 'background:var(--bg2,#1e1e1e);color:var(--text,#eee);border:1px solid var(--border,#444);border-radius:12px;width:100%;max-width:560px;max-height:85vh;display:flex;flex-direction:column;gap:8px;padding:12px;';
  const h = document.createElement('div');
  h.style.cssText = 'font-size:15.5px;font-weight:600;';
  h.textContent = (title || 'Copie manuelle') + ' — appuyez longuement puis « Copier »';
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.readOnly = true;
  ta.style.cssText = 'flex:1;min-height:200px;width:100%;box-sizing:border-box;background:var(--bg3,#111);color:inherit;border:1px solid var(--border,#444);border-radius:8px;padding:8px;font-size:14.5px;font-family:monospace;';
  const row = document.createElement('div');
  row.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;';
  const mk = (label, fn) => { const b = document.createElement('button'); b.textContent = label; b.style.cssText = 'padding:8px 14px;border-radius:8px;border:1px solid var(--border,#444);background:var(--bg3,#222);color:inherit;font-size:15.5px;cursor:pointer;'; b.onclick = fn; return b; };
  row.appendChild(mk('Tout sélectionner', () => { ta.focus(); ta.select(); ta.setSelectionRange(0, ta.value.length); }));
  row.appendChild(mk('Fermer', () => ov.remove()));
  box.appendChild(h); box.appendChild(ta); box.appendChild(row);
  ov.appendChild(box);
  ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
  document.body.appendChild(ov);
  setTimeout(() => { try { ta.focus(); ta.select(); } catch (e) {} }, 50);
}

function copyCode(id){
  const el=document.getElementById(id);
  if(!el)return;
  robustCopy(el.textContent)
    .then(() => toast('Copié'))
    .catch(() => toast('Erreur de copie', true));
}

function sendQuick(txt){
  document.getElementById('comp-input').value=txt;
  sendMsg();
}

const IMG_RE=/(g[ée]n[èe]re|cr[ée]e|dessine|fabrique)\s+(une|des|l')?\s*(image|icone|icône|illustration|logo|photo)/i;

// Sources structurées (favicon/titre/url/extrait) captées lors du dernier appel
// à executeTool. Lues juste après l'appel par la boucle d'agent pour alimenter
// l'onglet "Sources" du message, sans changer la signature d'executeTool (qui
// doit continuer à renvoyer une simple string pour le modèle).
let lastToolSources = [];

// Parse le texte brut renvoyé par Jina Search (s.jina.ai) en résultats structurés.
// Format typique par résultat : "[n] Title: ...", "[n] URL Source: ...", "[n] Description: ...".
function parseJinaSearchResults(raw) {
  const out = [];
  const blocks = raw.split(/\n(?=\[\d+\]\s*Title:)/i);
  for (const block of blocks) {
    const titleM = block.match(/Title:\s*(.+)/i);
    const urlM = block.match(/URL Source:\s*(\S+)/i);
    const descM = block.match(/Description:\s*([\s\S]*?)(?:\n\[\d+\]|$)/i);
    if (titleM && urlM) {
      out.push({
        title: titleM[1].trim(),
        url: urlM[1].trim(),
        snippet: descM ? descM[1].replace(/\s+/g, ' ').trim().slice(0, 220) : ''
      });
    }
  }
  return out;
}

// Recherche partagée : backend same-origin d'abord (pas de CORS, aucune clé
// utilisateur requise), fallback Jina Search public sinon. Utilisée à la fois
// par l'outil `web_search` de l'IA et par la recherche intégrée de l'utilisateur
// (bouton 🔎 en haut), pour ne pas dupliquer la logique à deux endroits.
async function performWebSearch(query) {
  try {
    const res = await fetch('https://s.jina.ai/' + encodeURIComponent(query), {
      headers: { ...(S.globalHeaders || {}) }
    });
    if (!res.ok) throw new Error("Erreur HTTP " + res.status);
    const text = await res.text();
    return { source: 'jina', results: parseJinaSearchResults(text), raw: text };
  } catch (e) {
    throw e;
  }
}
