// ═══════ ÉTATS DE CHARGEMENT / VIDE (squelettes façon YouTube, illustrations SVG Fable Fast) ═══════
function npsHistorySkeleton(){
  const w=[78,62,88,54,72,66];
  return '<div class="nps-sk-list">'+w.map(x=>'<div class="nps-sk nps-sk-row" style="width:'+x+'%"></div>').join('')+'</div>';
}
function npsBubblesSvg(kind){
  const a='#9b6cf0', b='#cdb6ff';
  const dots=(x,y,c)=>'<circle cx="'+x+'" cy="'+y+'" r="3" fill="'+c+'"/><circle cx="'+(x+12)+'" cy="'+y+'" r="3" fill="'+c+'"/><circle cx="'+(x+24)+'" cy="'+y+'" r="3" fill="'+c+'"/>';
  const extra = kind==='fail'
    ? '<g stroke="'+a+'" stroke-width="3" stroke-linecap="round" fill="none"><path d="M118 20a14 14 0 1 0 6 12"/><polyline points="119 11 119 21 109 21"/></g>'
    : '<g fill="'+a+'" opacity=".9"><path d="M128 18l2.4 6.6L137 27l-6.6 2.4L128 36l-2.4-6.6L119 27l6.6-2.4z"/></g>';
  return '<svg viewBox="0 0 160 120" width="150" height="112" fill="none" aria-hidden="true">'
    +'<rect x="14" y="24" width="86" height="54" rx="15" fill="'+a+'" fill-opacity=".14" stroke="'+a+'" stroke-width="2.2"/>'
    +'<path d="M34 78l-3 17 19-17" fill="'+a+'" fill-opacity=".14" stroke="'+a+'" stroke-width="2.2" stroke-linejoin="round"/>'
    +dots(38,51,a)
    +'<rect x="60" y="52" width="86" height="54" rx="15" fill="'+b+'" fill-opacity=".14" stroke="'+b+'" stroke-width="2.2" stroke-dasharray="'+(kind==='fail'?'6 5':'0')+'"/>'
    +'<path d="M126 106l3 12-17-12" fill="'+b+'" fill-opacity=".14" stroke="'+b+'" stroke-width="2.2" stroke-linejoin="round"/>'
    +dots(84,79,b)+extra+'</svg>';
}
function npsHistoryEmpty(){
  return '<div class="nps-empty nps-empty-sm">'+npsBubblesSvg('empty')+'<div class="nps-empty-t">Aucune conversation</div><div class="nps-empty-s">Tes discussions apparaîtront ici.</div></div>';
}
function npsConvSkeleton(){
  return '<div class="nps-sk-conv">'
    +'<div class="nps-sk nps-sk-bub-u" style="width:46%"></div>'
    +'<div class="nps-sk-bot"><div class="nps-sk nps-sk-line" style="width:92%"></div><div class="nps-sk nps-sk-line" style="width:78%"></div><div class="nps-sk nps-sk-line" style="width:60%"></div></div>'
    +'<div class="nps-sk nps-sk-bub-u" style="width:62%"></div>'
    +'<div class="nps-sk-bot"><div class="nps-sk nps-sk-line" style="width:85%"></div><div class="nps-sk nps-sk-line" style="width:70%"></div></div>'
    +'</div>';
}
function npsConvFail(id){
  return '<div class="nps-empty">'+npsBubblesSvg('fail')
    +'<div class="nps-empty-t">Conversation non chargée</div>'
    +'<div class="nps-empty-s">Elle n\'a pas pu être synchronisée depuis GitHub' + (S._lastLoadErr ? ' : ' + esc(S._lastLoadErr) : '') + '.</div>'
    +'<div class="nps-yt-retry" style="margin-top:6px"><button class="nps-yt-retry-btn" onclick="npsRetryLoadConv(\''+id+'\',this)">RÉESSAYER</button><div class="nps-yt-spin"></div></div></div>';
}
function npsRetryLoadConv(id, btn){
  const wrap = btn && btn.closest('.nps-yt-retry');
  if (wrap) { if (wrap.classList.contains('loading')) return; wrap.classList.add('loading'); }
  setTimeout(() => loadConv(id), 350);
}
async function npsLoadConvWithRetry(id){
  for (let i = 0; i < 3; i++) {
    const r = await loadConvFromGitHub(id);
    if (r) return r;
    if (S.currentConv !== id) return null;
    await new Promise(res => setTimeout(res, 700 * (i + 1)));
  }
  return null;
}

// Résout les messages d'une conversation pour les actions du menu (renommer,
// partager, télécharger en .txt) : mémoire → cache local → GitHub en dernier
// recours. Sans ce repli, une conversation synchronisée depuis un autre
// appareil (donc absente du cache local nps_conv_*) était traitée comme
// vide par ces actions — et une sauvegarde déclenchée ensuite écrasait son
// vrai contenu sur GitHub avec un tableau de messages vide.
async function npsResolveConvMsgs(id){
  const c = S.convs.find(x => x.id === id);
  if (c && c.msgs && c.msgs.length) return c.msgs;
  const stored = localStorage.getItem('nps_conv_' + id);
  if (stored) {
    try { const parsed = JSON.parse(stored); if (parsed && parsed.length) return parsed; } catch (e) {}
  }
  if (S.tok) {
    try { const remote = await loadConvFromGitHub(id); if (remote && remote.length) return remote; } catch (e) {}
  }
  return [];
}

function renderRecents(){
  S.convs.forEach(v=>{ if(v.mode) _npsModeMemo[v.id]=v.mode; });
  const c=[...S.convs].filter(v=>!window.ffMode||!v.mode||v.mode===window.ffMode).sort((a,b)=>(b.pinned?1:0)-(a.pinned?1:0));
  document.getElementById('recent-list').innerHTML = c.length
    ? c.map(v=>`
      <div class="sb-recent${v.id===S.currentConv?' active':''}" style="display:flex;align-items:center;gap:2px;padding-right:2px;">
        <div style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;padding:0 4px;" onclick="loadConvAndClose('${v.id}', event)"><svg class="sb-chat-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/></svg>${v.pinned?(window.NPS_PIN_SVG||''):''}${v.projectId?(window.NPS_PROJECT_SVG||''):''}${v.titlePending?'<div class="nps-sk" style="height:14px;width:62%;margin:3px 4px"></div>':esc(v.title)}</div>
        <button onclick="event.stopPropagation();openConvMenu('${v.id}',this)" style="background:none;border:none;color:var(--text2);cursor:pointer;padding:4px 10px;flex-shrink:0;line-height:1;border-radius:8px;min-width:38px;display:flex;align-items:center;justify-content:center;" title="Options"><svg style="width:18px;height:18px;flex-shrink:0" viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg></button>
      </div>`).join('')
    : (S._convsLoading ? npsHistorySkeleton() : npsHistoryEmpty());
}

let _convMenuId = null;
function openConvMenu(id, btn) {
  document.querySelectorAll('.conv-inline-menu').forEach(m => m.remove());
  const conv = S.convs.find(c => c.id === id);
  if (!conv) { toast('Envoie un premier message pour ouvrir ce menu'); return; }
  _convMenuId = id;
  const ic = d => `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const item = (act, icon, label, style) => `<button class="conv-menu-item" ${style?`style="${style}"`:''} onclick="convMenuAction('${act}','${id}')">${icon}<span>${label}</span></button>`;
  const menu = document.createElement('div');
  menu.className = 'conv-inline-menu';
  menu.innerHTML =
    `<div class="conv-menu-title">${esc(conv.title||'Nouvelle conversation')}</div>` +
    item('rename', ic('<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/>'), 'Renommer') +
    item('github', ic('<path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/>'), 'Ouvrir dans GitHub') +
    item('zipshare', ic('<polyline points="15 14 20 9 15 4"/><path d="M4 20v-7a4 4 0 0 1 4-4h12"/>'), 'Partager l’historique (ZIP)') +
    item('zipexport', ic('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>'), 'Exporter l’historique (ZIP)');
  document.body.appendChild(menu);
  const r = btn.getBoundingClientRect();
  const mw = menu.offsetWidth, mh = menu.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
  const left = Math.max(8, Math.min(r.right - mw, vw - mw - 8));
  let top = r.bottom + 6;
  if (top + mh > vh - 8) top = Math.max(8, r.top - mh - 6);
  if (top + mh > vh - 8) top = Math.max(8, vh - mh - 8);
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  setTimeout(() => document.addEventListener('click', _closeConvMenu, {once:true}), 0);
}
function convMenuAction(act, id) {
  _closeConvMenu();
  if (act === 'zipshare') convZip(id, true);
  else if (act === 'zipexport') convZip(id, false);
  else if (act === 'github') convOpenGitHub(id);
  else if (act === 'share') shareConvMenu(id);
  else if (act === 'rename') openRenameSheet(id);
  else if (act === 'pin') togglePinConv(id);
  else if (act === 'project') openProjectSheet(id);
  else if (act === 'home') openHomeSheet(id);
  else if (act === 'txt') downloadConvTxt(id);
  else if (act === 'delete') confirmDeleteConv(id);
}
async function convZip(id, share) {
  try {
    const conv = S.convs.find(c => c.id === id); if (!conv) return;
    if (typeof JSZip === 'undefined') { toast('ZIP indisponible (hors ligne)', true); return; }
    const msgs = (await npsResolveConvMsgs(id)).filter(m => !m.hidden);
    const z = new JSZip();
    const name = String(conv.title || 'historique').replace(/[^\w\-]+/g, '_').slice(0, 40) || 'historique';
    z.file(name + '.txt', msgs.map(m => `[${m.role==='user'?'Vous':'Fable Fast'}] ${m.apiText||m.text||''}`).join('\n\n'));
    z.file(name + '.json', JSON.stringify({ id: conv.id, titre: conv.title, date: conv.ts, messages: msgs.map(m => ({ role: m.role, text: m.apiText || m.text || '' })) }, null, 2));
    const blob = await z.generateAsync({ type: 'blob' });
    const file = new File([blob], name + '.zip', { type: 'application/zip' });
    if (share && navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: conv.title }); return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name + '.zip';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast(share ? 'Partage indisponible : ZIP téléchargé' : 'Historique exporté en ZIP');
  } catch (e) { if (e && e.name !== 'AbortError') toast('Export impossible', true); }
}
async function convOpenGitHub(id) {
  try {
    const owner = await getGhLogin();
    if (!owner) { toast('Connecte GitHub dans les paramètres', true); return; }
    window.open('https://github.com/' + owner + '/Maker/blob/main/' + npsP(npsConvMode(id), 'historique/' + id + '.json'), '_blank');
  } catch (e) { toast('Ouverture impossible', true); }
}
function _closeConvMenu() {
  document.querySelectorAll('.conv-inline-menu').forEach(m => m.remove());
}
function renameConvMenu(id) {
  _closeConvMenu();
  const conv = S.convs.find(c => c.id === id);
  if (!conv) return;
  const newTitle = prompt('Renommer la conversation :', conv.title);
  if (!newTitle || !newTitle.trim()) return;
  conv.title = newTitle.trim(); conv.titlePending = false;
  safeSetItem('nps_convs', JSON.stringify(S.convs.map(c=>({...c,msgs:[]}))));
  renderRecents();
  if (S.currentConv === id) setTitle(conv.title);
  // Sync GitHub
  if (S.tok) {
    npsResolveConvMsgs(id).then(msgs => saveConvToGitHubNow(id, conv.title, conv.ts, msgs)).catch(()=>{});
  }
}
async function shareConvMenu(id) {
  _closeConvMenu();
  const conv = S.convs.find(c => c.id === id);
  const msgs = await npsResolveConvMsgs(id);
  const text = msgs.filter(m=>!m.hidden).map(m=>`[${m.role==='user'?'Vous':'Fable Fast'}] ${m.apiText||m.text||''}`).join('\n\n');
  if (navigator.share) {
    navigator.share({ title: conv?.title || 'Discussion Fable Fast', text }).catch(()=>{});
  } else {
    robustCopy(text).then(()=>toast('Copié')).catch(()=>toast('Copie impossible sur cet appareil', true));
  }
}
async function downloadConvTxt(id) {
  _closeConvMenu();
  const conv = S.convs.find(c => c.id === id);
  const msgs = await npsResolveConvMsgs(id);
  const lines = [];
  if (conv?.title) { lines.push(conv.title); lines.push('─'.repeat(40)); lines.push(''); }
  msgs.filter(m=>!m.hidden&&!m.thinking).forEach(m => {
    const who = m.role === 'user' ? 'Vous' : 'Fable Fast';
    const ts = m.ts ? new Date(m.ts).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}) : '';
    const rawText = (m.apiText || m.text || '').replace(/<think>[\s\S]*?<\/think>/gi,'').replace(/```json[\s\S]*?"action"[\s\S]*?```/gi,'').replace(/[*#_`]/g,'').trim();
    if (!rawText) return;
    lines.push(`[${who}${ts?' · '+ts:''}]`);
    lines.push(rawText);
    lines.push('');
  });
  const filename = (conv?.title || 'discussion').replace(/[^a-zA-Z0-9_\- ]/g,'_').slice(0,40) + '.txt';
  const fullText = lines.join('\n');

  // Méthode demandée : passer par un vrai fichier GitHub (encodage UTF-8
  // garanti fiable côté serveur, pas de bricolage navigateur), puis le
  // supprimer immédiatement une fois récupéré — rien ne reste derrière.
  // Nécessite un token GitHub ; sinon, repli sur le téléchargement local
  // (avec BOM UTF-8 ajouté, un signal standard que les visionneuses de
  // fichiers Android respectent mieux pour détecter l'encodage).
  if (S.tok) {
    try {
      toast('Préparation de l\'export…', 'info');
      const owner = await getGhLogin();
      const repoName = 'Maker';
      const path = `${npsMD()}exports/${id}-${Date.now()}.txt`;
      const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json', 'Content-Type': 'application/json' };
      const b64 = utob(fullText);
      const putRes = await fetch(`https://api.github.com/repos/${owner}/${repoName}/contents/${path}`, {
        method: 'PUT', headers,
        body: JSON.stringify({ message: `Export : ${filename}`, content: b64 })
      });
      if (!putRes.ok) throw new Error('Écriture GitHub échouée');
      const putData = await putRes.json();
      const rawUrl = putData.content?.download_url;
      if (!rawUrl) throw new Error('Pas de lien de téléchargement');
      const fileRes = await fetch(rawUrl);
      const realBytes = await fileRes.blob();
      const dlUrl = URL.createObjectURL(realBytes);
      const a = document.createElement('a');
      a.href = dlUrl; a.download = filename;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      URL.revokeObjectURL(dlUrl);
      // Nettoyage : supprime le fichier temporaire (déclenche la confirmation
      // de sécurité obligatoire, volontairement — même pour un fichier créé
      // par l'app elle-même).
      const delHeaders = { ...headers };
      await fetch(`https://api.github.com/repos/${owner}/${repoName}/contents/${path}`, {
        method: 'DELETE', headers: delHeaders,
        body: JSON.stringify({ message: 'Nettoyage export temporaire', sha: putData.content.sha })
      }).catch(()=>{});
      return;
    } catch (e) {
      console.warn('Export via GitHub échoué, repli local:', e.message);
    }
  }
  // Repli local : Blob avec BOM UTF-8 (aide les visionneuses de fichiers à
  // détecter le bon encodage même sans en-tête HTTP explicite).
  const blob = new Blob(['\ufeff' + fullText], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
function confirmDeleteConv(id) {
  _closeConvMenu();
  _convMenuId = id;
  document.getElementById('del-conv-modal').classList.add('show');
}
function closeDelConvModal() {
  document.getElementById('del-conv-modal').classList.remove('show');
  _convMenuId = null;
}
function confirmDeleteConvFinal() {
  const id = _convMenuId;
  if (!id) return;
  S.convs = S.convs.filter(c => c.id !== id);
  safeSetItem('nps_convs', JSON.stringify(S.convs.map(c=>({...c,msgs:[]}))));
  localStorage.removeItem('nps_conv_' + id);
  renderRecents();
  closeDelConvModal();
  if (S.currentConv === id) newConv();
}

// ═══════ VIEWS ═══════
function showView(id){
  const prevEl=document.querySelector('.view.active');
  const prev=prevEl?prevEl.id.replace('view-',''):null;
  const el=document.getElementById('view-'+id);
  const changed=prev!==id;
  // pile de navigation : chaque écran ouvert se retient pour le vrai bouton Retour
  if(changed && prev && NAV.mode!=='back'){
    NAV.stack.push({view:prev,title:document.getElementById('page-title').textContent});
    try{history.pushState({nps:NAV.stack.length},'');}catch(e){}
  }
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active','enter-fwd','enter-back'));
  if(el){
    el.classList.add('active');
    if(changed){
      const c=NAV.mode==='back'?'enter-back':'enter-fwd';
      el.classList.add(c);
      setTimeout(()=>el.classList.remove(c),420);
    }
  }
  if(changed && window.NPSLoader) NPSLoader.pulse(520);
  // sync header buttons
  const isChat=id==='chat';
  syncHeaderBtns(id);
}
// Les boutons + et ⋮ du haut n'existent que dans une conversation déjà commencée :
// jamais sur l'accueil vide, ni dans les paramètres ou les autres écrans.
function syncHeaderBtns(viewId){
  const v = viewId || currentViewId();
  const cur = S.currentConv && Array.isArray(S.convs) && S.convs.some(c=>c.id===S.currentConv);
  const inConv = v==='chat' && !(typeof sbOpen!=='undefined' && sbOpen) && cur;
  const home = v==='chat' && !cur;
  const set=(id,on)=>{const e=document.getElementById(id);if(e)e.style.display=on?'flex':'none';};
  // Le bouton de notification doit être STRICTEMENT et UNIQUEMENT à l'accueil (home):
  set('ff-header-notif', home);
  // Aucun doublon de bouton retour : new-chat-btn reste caché
  set('new-chat-btn', false);
  set('more-btn', inConv);
  const sb = document.getElementById('set-btn');
  const br = document.getElementById('hd-brand');
  const pt = document.getElementById('page-title');
  if(sb){ sb.style.display = home ? 'none' : 'flex'; if(!home && !sb.dataset.back){ sb.dataset.back='1'; sb.innerHTML='<svg class="nps-ic-header" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>'; } }
  if(br){ br.style.display = home ? 'flex' : 'none'; const lg=document.getElementById('hd-logo'); if(lg && !lg.src && window.FF_LOGO) lg.src = window.FF_LOGO; }
  if(pt) pt.style.display = home ? 'none' : '';
  const hm = document.getElementById('hd-menu'); if(hm) hm.style.display = 'flex';
}
function goBack(fromPop){
  if(typeof sbOpen!=='undefined'&&sbOpen){closeSidebar();return;}
  if(window.__ffBackRep&&window.ffReopenReport&&window.ffReopenReport()){window.__ffBackRep=false;try{NAV.stack.pop();}catch(_){}NAV.mode=null;return;}
  const e=NAV.stack.pop();
  NAV.mode='back';
  if(e){ showView(e.view); setTitle(e.title); }
  else{
    const cur=currentViewId();
    if(cur==='chat'){ NAV.mode=null; return; }
    if(cur!=='settings'){ showView('settings'); setTitle('Paramètres'); }
    else { showView('chat'); const c=S.convs.find(x=>x.id===S.currentConv); setTitle(c?c.title:'Fable Fast'); }
  }
  NAV.mode=null;
  if(e && !fromPop){ NAV.ignorePop=true; try{history.back();}catch(_){ NAV.ignorePop=false; } }
}
function setTitle(t){const el=document.getElementById('page-title');el.textContent=(t==='Fable Fast'?'':(t||''));el.classList.toggle('pending',!t)}
function currentViewId(){
  const el=document.querySelector('.view.active');
  return el?el.id.replace('view-',''):'chat';
}


function openExitModal(){document.getElementById('exit-modal').classList.add('show')}
function closeExitModal(){document.getElementById('exit-modal').classList.remove('show')}

function openLogoutModal(){document.getElementById('logout-modal').classList.add('show')}
function closeLogoutModal(){document.getElementById('logout-modal').classList.remove('show')}

/**
 * Retire toutes les cles API/tokens configures sur l'appareil (Gemini,
 * OpenAI, Anthropic, modele personnalise, GitHub), puis renvoie vers l'ecran
 * de connexion (Modele & Cles API) pour en reconfigurer une avant de
 * pouvoir reutiliser l'app.
 */
function confirmLogout(){
  ['nps_gem_tok','nps_oai_tok','nps_ant_tok','nps_custom_model','nps_gh_tok','nps_jina_key'].forEach(k => localStorage.removeItem(k));
  S.gem = ''; S.oai = ''; S.ant = ''; S.tok = ''; S.customModel = null;
  updateActiveProviderLabel();
  closeLogoutModal();
  try{ffsOpen('api');}catch(e){showView('apikeys');}
  toast('Déconnecté — reconfigure une clé API pour continuer');
}
function confirmExit(){
  closeExitModal();
  // Pont natif Android si l'app est compilée en WebView (à connecter côté Android : window.Android.exitApp())
  if(window.Android&&window.Android.exitApp){window.Android.exitApp();return;}
  if(window.navigator.app&&window.navigator.app.exitApp){window.navigator.app.exitApp();return;}
  window.close();
}

// ═══════ CHAT ═══════
function newConv(){
  S.msgs=[];
  S.currentConv = null;
  renderRecents();
  document.getElementById('feed').innerHTML='';
  document.getElementById('feed').appendChild(buildEmptyState());
  pickGreeting();
  showView('chat'); setTitle('Fable Fast');
  syncHeaderBtns('chat');
  document.getElementById('comp-input').focus();
}

/* ═══ Messages d'accueil : 41 messages, chacun avec sa propre icône SVG d'ambiance ═══ */
const _mi = p => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + p + '</svg>';
const NPS_ICONS = {
  coffee:   _mi('<path d="M17 8h1a4 4 0 0 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/>'),
  sunrise:  _mi('<path d="M17 18a5 5 0 0 0-10 0"/><line x1="12" y1="2" x2="12" y2="9"/><line x1="4.22" y1="10.22" x2="5.64" y2="11.64"/><line x1="1" y1="18" x2="3" y2="18"/><line x1="21" y1="18" x2="23" y2="18"/><line x1="18.36" y1="11.64" x2="19.78" y2="10.22"/><line x1="23" y1="22" x2="1" y2="22"/><polyline points="8 6 12 2 16 6"/>'),
  sunset:   _mi('<path d="M17 18a5 5 0 0 0-10 0"/><line x1="12" y1="9" x2="12" y2="2"/><line x1="4.22" y1="10.22" x2="5.64" y2="11.64"/><line x1="1" y1="18" x2="3" y2="18"/><line x1="21" y1="18" x2="23" y2="18"/><line x1="18.36" y1="11.64" x2="19.78" y2="10.22"/><line x1="23" y1="22" x2="1" y2="22"/><polyline points="16 5 12 9 8 5"/>'),
  sun:      _mi('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>'),
  moon:     _mi('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'),
  stars:    _mi('<path d="M12 3l1.9 4.6 4.6 1.9-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z"/>'),
  bed:      _mi('<path d="M2 4v16"/><path d="M2 8h18a2 2 0 0 1 2 2v10"/><path d="M2 17h20"/><path d="M6 8v9"/>'),
  bulb:     _mi('<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>'),
  wrench:   _mi('<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>'),
  sprout:   _mi('<path d="M7 20h10"/><path d="M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/>'),
  smile:    _mi('<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>'),
  rocket:   _mi('<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>'),
  target:   _mi('<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>'),
  compass:  _mi('<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>'),
  clock:    _mi('<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>'),
  food:     _mi('<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/>'),
  checks:   _mi('<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>'),
  zap:      _mi('<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'),
  battery:  _mi('<path d="M15 7h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-2"/><path d="M6 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h1"/><path d="m11 7-3 5h4l-3 5"/><line x1="22" y1="11" x2="22" y2="13"/>'),
  hourglass:_mi('<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>'),
  leaf:     _mi('<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>'),
  check:    _mi('<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>'),
  trophy:   _mi('<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>'),
  wind:     _mi('<path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/><path d="M9.6 4.6A2 2 0 1 1 11 8H2"/><path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>'),
  home:     _mi('<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>'),
  chat:     _mi('<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>'),
  code:     _mi('<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>'),
  eye:      _mi('<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>'),
  users:    _mi('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'),
  heart:    _mi('<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>')
};
const NPS_GREET_BANDS = [
  { from: 5,  to: 8,  msgs: [
    ["Un café avec Fable Fast ?", "coffee"],
    ["Le jour se lève. On démarre doucement ?", "sunrise"],
    ["Bien dormi ? On prépare la journée ensemble ?", "bed"],
    ["Premier café, première idée ?", "bulb"],
    ["Tôt debout. Qu'est-ce qu'on construit aujourd'hui ?", "wrench"],
    ["Le calme du matin, parfait pour bien commencer.", "sprout"]
  ]},
  { from: 8,  to: 12, msgs: [
    ["Bonne matinée ! Par quoi on commence ?", "sun"],
    ["Le matin, l'esprit est frais. Je t'écoute.", "smile"],
    ["Un projet à lancer avant midi ?", "rocket"],
    ["Allez, on avance sur du concret ?", "target"],
    ["Un deuxième café, et on s'y met ?", "coffee"],
    ["La journée est devant nous. Qu'est-ce qu'on fait ?", "compass"]
  ]},
  { from: 12, to: 14, msgs: [
    ["Pause de midi ? Un coup de main en attendant le repas ?", "clock"],
    ["Bon appétit ! Une question pendant la pause ?", "food"],
    ["Mi-journée : on fait le point ensemble ?", "checks"],
    ["Le temps d'un déjeuner, on règle un truc rapide ?", "zap"],
    ["Midi pile. Qu'est-ce qui t'occupe l'esprit ?", "sun"]
  ]},
  { from: 14, to: 18, msgs: [
    ["Bon après-midi ! On s'y remet ?", "sun"],
    ["Petit coup de mou ? On relance la machine.", "battery"],
    ["L'après-midi file vite. Sur quoi on avance ?", "hourglass"],
    ["Un thé et on s'y remet ?", "leaf"],
    ["Il reste du temps pour finir quelque chose. Quoi ?", "check"],
    ["Prêt quand tu veux.", "smile"]
  ]},
  { from: 18, to: 21, msgs: [
    ["Bonne soirée ! Comment s'est passée ta journée ?", "sunset"],
    ["La journée touche à sa fin. On boucle quoi ensemble ?", "check"],
    ["Le soir, on a le temps de bien faire les choses.", "clock"],
    ["On termine la journée en beauté ?", "trophy"],
    ["Une dernière idée avant de décompresser ?", "wind"],
    ["Soirée tranquille ? Raconte-moi ce que tu as en tête.", "home"]
  ]},
  { from: 21, to: 1,  msgs: [
    ["Encore debout ? Je t'accompagne.", "moon"],
    ["Le calme de la nuit, idéal pour réfléchir.", "stars"],
    ["Une dernière idée avant d'aller dormir ?", "bed"],
    ["La nuit porte conseil. On en parle ?", "chat"],
    ["Les meilleures idées arrivent tard. Dis-moi.", "bulb"],
    ["Soirée de code ? Je suis là.", "code"]
  ]},
  { from: 1,  to: 5,  msgs: [
    ["Il est tard, tu veilles ? Dis-moi ce qui t'occupe.", "eye"],
    ["Insomnie créative ? Allons-y.", "stars"],
    ["Tout dort, sauf nous. Qu'est-ce qu'on fait ?", "moon"],
    ["Les nuits blanches, c'est mieux à deux.", "users"],
    ["Une dernière chose, puis du repos ?", "bed"],
    ["Pense à te reposer aussi. Mais d'abord, je t'écoute.", "heart"]
  ]}
];
function npsBandForHour(h){
  return NPS_GREET_BANDS.find(b => b.from < b.to ? (h >= b.from && h < b.to) : (h >= b.from || h < b.to)) || NPS_GREET_BANDS[1];
}
let _greetBand = null;
function pickGreeting(){
  const el = document.getElementById('empty-greeting');
  if (!el) return;
  const band = npsBandForHour(new Date().getHours());
  let i = Math.floor(Math.random() * band.msgs.length), last = -1;
  try { last = parseInt(sessionStorage.getItem('nps_greet_last') || '-1', 10); } catch(e){}
  if (band.msgs.length > 1 && i === last) i = (i + 1) % band.msgs.length;
  try { sessionStorage.setItem('nps_greet_last', String(i)); } catch(e){}
  el.textContent = 'Que veux-tu faire ?';
  const mood = document.getElementById('empty-mood');
  if (mood) mood.innerHTML = NPS_ICONS[band.msgs[i][1]] || '';
  _greetBand = band;
}
// si on reste sur l'écran d'accueil quand l'ambiance change (ex. 11h59 → 12h), le message suit l'heure
setInterval(() => {
  const es = document.getElementById('empty-state');
  if (!es || es.style.display === 'none' || !es.offsetParent) return;
  if (npsBandForHour(new Date().getHours()) !== _greetBand) pickGreeting();
}, 60000);

// L'écran d'accueil vit DANS #feed : newConv() vide le feed (innerHTML=''), ce qui détruisait l'élément
// et laissait l'écran blanc dès la 2e nouvelle conversation. On garde donc un modèle pour le reconstruire.
const _EMPTY_TPL = (function(){ const e = document.getElementById('empty-state'); return e ? e.outerHTML : ''; })();
function buildEmptyState(){
  const live = document.getElementById('empty-state');
  if (live) { live.style.display = ''; return live; }
  const d = document.createElement('div');
  d.innerHTML = _EMPTY_TPL;
  return d.firstElementChild || d;
}

function loadConv(id){
  const c=S.convs.find(x=>x.id===id);
  if(!c)return;
  if(window.NPSLoader) NPSLoader.pulse(600);
  S.currentConv = id;
  if(!c.mode) c.mode='download';
  window.ffMode=c.mode; try{ffApplyModeUi(c.mode);}catch(e){}
  renderRecents();
  
  // Try memory first
  if (c.msgs && c.msgs.length > 0) {
      S.msgs=[...c.msgs];
  } else {
      // Try local storage
      const stored = localStorage.getItem('nps_conv_'+id);
      if (stored) {
          try {
              c.msgs = JSON.parse(stored);
              // fix Dates
              c.msgs.forEach(m => m.ts = new Date(m.ts));
              S.msgs=[...c.msgs];
          } catch(e) {}
      } else {
          S.msgs = [];
          // Dernier recours : GitHub (Maker). Async — dès que ça revient,
          // on ne réaffiche que si l'utilisateur est toujours sur cette conv.
          const feed=document.getElementById('feed');
          feed.innerHTML=npsConvSkeleton();
          npsLoadConvWithRetry(id).then(msgs => {
              if (!msgs || S.currentConv !== id) {
                if (!msgs && S.currentConv === id) {
                  feed.innerHTML=npsConvFail(id);
                }
                return;
              }
              msgs.forEach(m => m.ts = new Date(m.ts));
              c.msgs = msgs;
              S.msgs = [...msgs];
              safeSetItem('nps_conv_'+id, JSON.stringify(msgs));
              feed.innerHTML='';
              S.msgs.forEach(m=>appendMsgEl(m));
              feed.scrollTop=feed.scrollHeight;
              syncHeaderBtns('chat');
              toast('Historique restauré depuis GitHub');
          });
          return; // sortir tôt — le rendu se fera dans le .then()
      }
  }
  
  const feed=document.getElementById('feed');
  feed.innerHTML='';
  S.msgs.forEach(m=>{
      if (typeof m.ts === 'string') m.ts = new Date(m.ts);
      appendMsgEl(m);
  });
  feed.scrollTop=feed.scrollHeight;
  showView('chat'); setTitle(c.title);

  // GitHub reste la référence même quand le cache local a répondu instantanément :
  // on revérifie discrètement derrière (sans re-render brutal) pour ne jamais
  // laisser le local être la seule vérité — utile si la conv a été modifiée
  // depuis un autre appareil/session. Si le contenu diffère, on réaffiche.
  if (S.tok) npsRefreshCurrentConv(id);
}

function isFeedNearBottom(feed){
  // "Proche du bas" = à moins de 120px du fond. Si l'utilisateur a remonté
  // pour relire un message plus haut, on ne le fait plus redescendre de force
  // à chaque mise à jour (reflexion, streaming, etc.).
  return feed.scrollHeight - feed.scrollTop - feed.clientHeight < 120;
}

// Détecte si l'utilisateur a scrollé manuellement vers le haut
(function initScrollGuard(){
  const feed = document.getElementById('feed');
  if (!feed) return;
  feed.addEventListener('scroll', function(){
    window._userScrolledUp = !isFeedNearBottom(feed);
  }, { passive: true });
})();

function appendMsgEl(m){
  setTimeout(()=>syncHeaderBtns(),0);
  if (m.hidden) return;
  const feed=document.getElementById('feed');
  const empty=document.getElementById('empty-state');
  if(empty) empty.style.display='none';
  const wasNearBottom = isFeedNearBottom(feed);
  const el=document.createElement('div');
  el.className='msg-group'; el.id='msg-'+m.id;
  el.innerHTML=buildMsgHTML(m);
  feed.appendChild(el);
  if(wasNearBottom) feed.scrollTop=feed.scrollHeight;
}

// ═══ MISE À JOUR CIBLÉE (anti-clignotement) ═══
// Avant : el.innerHTML = buildMsgHTML(m) détruisait puis recréait TOUT le message à chaque
// tic (minuteur, progression terminal, nouvelle étape) -> clignotement, panneaux qui se
// referment, images/audio rechargés. Maintenant : on construit le nouveau HTML hors écran
// puis on ne modifie dans le DOM réel QUE ce qui a changé (texte, attributs, nœuds ajoutés).
function _npsKey(n, i){
  if (n.nodeType !== 1) return '#t';
  if (n.id) return '#' + n.id;
  const c = (n.getAttribute('class') || '').split(/\s+/)[0];
  return n.tagName + '.' + c;
}
function _npsPatchAttrs(o, n){
  const keep = o.tagName === 'DETAILS' ? ['open'] : [];
  // état purement visuel posé par le JS (menus ouverts, listes dépliées) : on le garde
  const isMenu = o.classList && o.classList.contains('nps-file-menu');
  for (const a of Array.from(o.attributes)) {
    if (keep.includes(a.name)) continue;
    if (isMenu && a.name === 'style') continue;
    if (!n.hasAttribute(a.name)) o.removeAttribute(a.name);
  }
  for (const a of Array.from(n.attributes)) {
    if (keep.includes(a.name)) continue;
    if (isMenu && a.name === 'style') continue;
    if (a.name === 'class') {
      const keepOpen = ['open','show','expanded'].filter(c => o.classList.contains(c));
      if (o.getAttribute('class') !== a.value) {
        o.setAttribute('class', a.value);
        keepOpen.forEach(c => o.classList.add(c));
      }
      continue;
    }
    if (o.getAttribute(a.name) !== a.value) o.setAttribute(a.name, a.value);
  }
}
function _npsMorph(o, n){
  if (o.nodeType === 3 || o.nodeType === 8) { if (o.nodeValue !== n.nodeValue) o.nodeValue = n.nodeValue; return; }
  _npsPatchAttrs(o, n);
  // médias en lecture : ne jamais les toucher tant que la source est identique
  if (/^(AUDIO|VIDEO|IFRAME|CANVAS)$/.test(o.tagName)) return;
  _npsMorphChildren(o, n);
}
function _npsMorphChildren(o, n){
  const oldKids = Array.from(o.childNodes);
  const newKids = Array.from(n.childNodes);
  const pool = new Map();
  oldKids.forEach(k => { const key = _npsKey(k); if (!pool.has(key)) pool.set(key, []); pool.get(key).push(k); });
  const used = new Set();
  let cursor = 0;
  newKids.forEach(nk => {
    const key = _npsKey(nk);
    const list = pool.get(key);
    let match = null;
    if (list) { while (list.length && !match) { const c = list.shift(); if (!used.has(c)) match = c; } }
    if (match) {
      used.add(match);
      if (match.nodeType === 1 && nk.nodeType === 1 && match.tagName === nk.tagName) _npsMorph(match, nk);
      else if (match.nodeType !== 1) { if (match.nodeValue !== nk.nodeValue) match.nodeValue = nk.nodeValue; }
      const ref = o.childNodes[cursor];
      if (ref !== match) o.insertBefore(match, ref || null);
    } else {
      const ref = o.childNodes[cursor];
      const adopted = document.importNode(nk, true);
      used.add(adopted);
      o.insertBefore(adopted, ref || null);
    }
    cursor++;
  });
  oldKids.forEach(k => { if (!used.has(k) && k.parentNode === o) o.removeChild(k); });
}

function updateMsgEl(m){
  const feed=document.getElementById('feed');
  const wasNearBottom = isFeedNearBottom(feed) && !window._userScrolledUp;
  const el=document.getElementById('msg-'+m.id);
  if(el){
    const tpl = document.createElement('div');
    tpl.innerHTML = buildMsgHTML(m);
    try { _npsMorphChildren(el, tpl); }   // enfants seulement : l'id/class du conteneur ne bougent jamais
    catch(e) { el.innerHTML = tpl.innerHTML; }   // filet de sécurité : ancien comportement
  }
  if(wasNearBottom) feed.scrollTop=feed.scrollHeight;
}

// Met à jour UNIQUEMENT le minuteur affiché d'un message en cours (aucun re-rendu).
function npsTickTimer(m){
  const el = document.getElementById('msg-' + m.id);
  if (!el) return;
  const t = el.querySelector('.nps-step-timer');
  if (!t) return;
  const _s = Math.max(0, Math.floor((Date.now() - (m.reflectionStartTs || Date.now())) / 1000));
  const txt = _s < 60 ? _s + 's' : Math.floor(_s / 60) + 'min ' + String(_s % 60).padStart(2, '0') + 's';
  if (t.textContent !== txt) t.textContent = txt;
  // minuteur de la carte "terminal en cours" : seulement le chiffre
  const lt = el.querySelector('.build-live-card .build-live-time');
  const liveStep = (m.steps || []).find(st => st.live && !st.live.done);
  if (lt && liveStep) {
    const e = Math.max(0, Math.floor((Date.now() - (liveStep.live._t0 || (liveStep.live._t0 = Date.now() - (liveStep.live.elapsed || 0) * 1000))) / 1000));
    const v = Math.floor(e / 60) + ':' + String(e % 60).padStart(2, '0');
    if (lt.textContent !== v) lt.textContent = v;
  }
}


function buildMsgHTML(m){
  const time=m.ts.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
  if(m.role==='user'){
    let attHtml='';
    if(m.attachments?.length){
      const isMed=a=>/^(image|video|audio)\//.test(a.type||'');
      const src=a=>a.dataUrl||'';
      const loading=m.attachments.filter(a=>!a.dataUrl&&isMed(a)&&a._hyd!=='fail');
      m.attachments.forEach(a=>{ if(!a.dataUrl&&!isMed(a)&&typeof a.text!=='string') npsHydrateAtt(a,m.id); });
      loading.forEach(a=>npsHydrateAtt(a,m.id));
      const imgAtts=m.attachments.filter(a=>src(a)&&a.type?.startsWith('image/'));
      const videoAtts=m.attachments.filter(a=>src(a)&&a.type?.startsWith('video/'));
      const audioAtts=m.attachments.filter(a=>src(a)&&a.type?.startsWith('audio/'));
      const fileAtts=m.attachments.filter(a=>!loading.includes(a)&&!(src(a)&&isMed(a)));
      const loadHtml=loading.map(a=>`<div style="margin-top:8px;padding:10px 12px;border-radius:10px;background:var(--bg2);font-size:14.5px;opacity:.8;text-align:left;">${esc(a.name||'Fichier')} — chargement…</div>`).join('');
      const imgsHtml=imgAtts.length?`<div class="img-row">${imgAtts.map(a=>`<img class="msg-img" src="${src(a)}" onclick="event.stopPropagation();openLightbox(this.src)" onerror="this.outerHTML='<div style=&quot;padding:10px 12px;border-radius:10px;background:var(--bg2);font-size:14.5px;opacity:.8&quot;>Image illisible</div>'"/>`).join('')}</div>`:'';
      const videoHtml=videoAtts.map(a=>npsVideoCard(src(a),a.name)).join('');
      const audioHtml=audioAtts.map(a=>`<audio controls src="${src(a)}" style="max-width:220px;margin-top:8px;display:block;" onclick="event.stopPropagation()"></audio>`).join('');
      const filesHtml=fileAtts.map((a,ai)=>`<div style="margin-top:8px;text-align:left" onclick="event.stopPropagation()">${buildUserFileCard(a,m.id,ai)}</div>`).join('');
      attHtml=imgsHtml+videoHtml+audioHtml+loadHtml+filesHtml;
    }
    return `<div class="msg-row user" style="flex-direction:row-reverse;">
      <div style="flex:1;min-width:0;display:flex;flex-direction:column;align-items:flex-end;">
        <div class="msg-bubble" style="position:relative;" onclick="toggleCopyButton(this, '${m.id}')">${fmtText(m.text)}${attHtml}</div>
        <div class="msg-time" style="margin-right:4px;">${time}</div>
      </div>
    </div>`;
  }
  
  let rawText = m.text || '';
  let thinkContent = m.accumulatedThink || '';
  let isThinkClosed = true;
  
  if (!m.accumulatedThink) {
      rawText = rawText.replace(/<think>([\s\S]*?)(<\/think>|$)/gi, function(match, p1, p2) {
        thinkContent += p1 + '\n';
        if (!p2) isThinkClosed = false;
        return '';
      });
  } else {
      rawText = rawText.replace(/<think>([\s\S]*?)(<\/think>|$)/gi, '');
      isThinkClosed = !m.thinking;
  }

  const cursor=m.typing?'<span class="typing-cursor"></span>':'';
  const imgHtml=(!m.image&&m.imageRef)?npsPendingMediaHtml(m,'image'):m.image?`<img class="msg-img" src="${m.image}" onclick="event.stopPropagation();openLightbox(this.src)" onerror="this.outerHTML=\'Image indisponible, réessaie.\'"/>`:'';
  const hasValidVideo = typeof m.video === 'string' && m.video.trim().length > 60 && !m.video.endsWith('base64,');
  const vidHtml = hasValidVideo ? npsVideoCard(m.video, (m.videoRef && m.videoRef.name) || 'video.mp4') : (m.videoRef ? npsPendingMediaHtml(m, 'video') : '');
  
  let thinkHtml = '';
  if (m.steps && m.steps.length > 0) {
     const isThinkClosed = !m.thinking;
     thinkHtml = buildReflectionBlock(m.id, isThinkClosed, m.steps, m.sources || [], m.reflectionStartTs);
  } else if (thinkContent.trim() || m.thinking) {
     const pseudoSteps = thinkContent.split('\n').filter(l=>l.trim().length>0).map((line,idx,arr)=>({
        id: 'pseudo-'+idx,
        name: 'Réflexion',
        summary: line.replace(/^[\d\.\-\s\*]+/, '').trim(),
        status: (!isThinkClosed && idx === arr.length-1) ? 'loading' : 'done'
     }));
     thinkHtml = buildReflectionBlock(m.id, isThinkClosed, pseudoSteps, m.sources || [], m.reflectionStartTs);
  }

  let zipButtonHtml = '';
  if (m.codeBlocks && m.codeBlocks.filter(b => b.lang !== 'plan' && !(b.lang === 'json' && b.content.includes('"action"'))).length > 1) {
      zipButtonHtml = `
      <div style="margin-top: 8px; margin-bottom: 4px;">
         <button onclick="downloadAllAsZip('${m.id}')" style="background: var(--bg3); border:1px solid var(--border); color: var(--accent); padding: 6px 12px; border-radius: 8px; font-size:14.5px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:6px;">
            <svg class="nps-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg> Télécharger tous les fichiers (.ZIP)
         </button>
      </div>`;
  }

  const finalResponseText = rawText.trim();
  const _introHtml = m.intro ? `<div class="nps-intro msg-content-final">${fmtText(m.intro)}</div>` : '';
  const _planList = []; // les plans ne sont plus affichés (message d'abord, puis travail)
  const _planHtml = _planList.map((b, i) => buildPlan(b, m.id, 'top' + i).replace('max-height:0;overflow:hidden', 'max-height:1200px;overflow:hidden').replace('id="chevron-plan-' + m.id + '-top' + i + '" style="', 'id="chevron-plan-' + m.id + '-top' + i + '" style="transform:rotate(180deg);')).join('');
  let finalBubbleHtml = '';
  if (finalResponseText || cursor || imgHtml) {
    finalBubbleHtml = `<div class="msg-content-final" style="width:100%; color:var(--text); line-height:1.6; padding:0; position:relative;" onclick="toggleCopyButton(this, '${m.id}')">${fmtText(finalResponseText, m)}${cursor}${imgHtml}</div>`;
  }

  // Message resté "en réflexion" mais dont aucune session active ne s'occupe
  // (coupure réseau / app fermée puis rouverte) : au lieu d'un spinner mort
  // pour toujours, on propose de reprendre — le contexte déjà acquis
  // (résultats d'outils déjà obtenus) reste disponible, donc Fable Fast repart de là
  // plutôt que de tout recommencer depuis zéro.
  let resumeHtml = '';
  if (m.thinking && m.id !== S.activeSendMsgId) {
    resumeHtml = `<div style="margin-top:8px;padding:10px 14px;border-radius:10px;background:var(--bg2);border:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:10px;">
      <span style="font-size:15px;opacity:.85;">Interrompu (connexion coupée ou app fermée pendant la tâche)</span>
      <button onclick="resumeInterrupted('${m.id}')" style="background:var(--accent);color:#ffffff;border:none;padding:6px 12px;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;white-space:nowrap;display:flex;align-items:center;gap:6px;"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><polygon points="6 4 20 12 6 20"/></svg>Reprendre</button>
    </div>`;
  }

  // Carte "réponse interrompue" quand l'utilisateur a lui-même appuyé sur Stop
  // en cours de génération — même logique que le bouton "Réessayer" de
  // l'interface Claude : le travail déjà fait reste affiché au-dessus, cette
  // carte propose juste de continuer.
  let interruptedCardHtml = '';
  if (m.interrupted) {
    interruptedCardHtml = `<div class="nps-stop-anim">
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:10px;background:var(--bg2);border:1px solid var(--border);">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;color:var(--text3)"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <span style="font-size:15.5px;color:var(--text2);">La réponse de Fable Fast n'a pas pu être entièrement générée.</span>
      </div>
      <div style="font-size:14px;color:var(--text3);margin-top:6px;">Fable Fast est une IA et peut faire des erreurs.</div>
      <div class="nps-yt-retry" style="margin-top:8px">
        <button class="nps-yt-retry-btn" onclick="retryInterrupted('${m.id}', this)">RÉESSAYER</button>
        <div class="nps-yt-spin"></div>
      </div>
    </div>`;
  }

  return `<div class="msg-row bot" style="width:100%;">
    <div style="flex:1;min-width:0;display:flex;flex-direction:column;width:100%;">
      ${_introHtml}
      ${_planHtml}
      ${thinkHtml}
      ${finalBubbleHtml}
      ${vidHtml}
      ${resumeHtml}
      ${interruptedCardHtml}
      ${zipButtonHtml}
      ${m.codeBlocks?.length ? m.codeBlocks.map((b,i)=> b.lang==='plan' ? '' : buildCode(b,m.id,i)).join('') : ''}
      <div class="msg-time" style="margin-top:8px">Fable Fast · ${time}</div>
    </div>
  </div>`;
}

function buildAlarmsBlock() { return ''; }
function toggleAlarmItem() {}

function resumeInterrupted(msgId) {
  const m = S.msgs.find(x => x.id === msgId);
  if (!m) return;
  // On ne relance pas un "nouveau" message : on marque l'ancien comme abandonné
  // (pour ne plus afficher son spinner mort) et on redémarre l'agent sur la
  // même conversation. Comme tout le contexte déjà obtenu (résultats d'outils
  // inclus) est encore dans l'historique de la conversation, le modèle repart
  // de là au lieu de recommencer la tâche depuis le début.
  m.thinking = false;
  if (!m.text || !m.text.trim()) m.text = '*(interrompu — reprise ci-dessous)*';
  updateMsgEl(m);
  sendMsg("[REPRISE APRÈS INTERRUPTION] Ta génération précédente s'est arrêtée en cours de route (connexion coupée ou app fermée). Avant toute chose, relis les DERNIERS résultats d'outils déjà présents dans cette conversation pour savoir précisément où tu en étais rendu. Ne reformule PAS la demande initiale et ne redemande AUCUNE information déjà donnée : continue directement l'exécution concrète de la tâche à partir du dernier état connu (prochain appel d'outil ou étape suivante), comme si tu n'avais jamais été interrompu. Si le dernier résultat d'outil visible montre que l'action a déjà réellement abouti, ne la refais pas : passe à l'étape suivante ou conclus.", [], true);
}

function retryInterrupted(msgId, btn) {
  const m = S.msgs.find(x => x.id === msgId);
  if (!m) return;
  // Le bouton devient un rond qui tourne (comme YouTube), puis la génération reprend.
  const wrap = btn && btn.closest ? btn.closest('.nps-yt-retry') : null;
  if (wrap) { if (wrap.classList.contains('loading')) return; wrap.classList.add('loading'); }
  setTimeout(() => {
    // Consomme le badge "interrompu" : le travail déjà affiché au-dessus reste intact.
    m.interrupted = false;
    updateMsgEl(m);
    // Dans le chat, l'utilisateur voit seulement « Veuillez continuer » ;
    // le modèle, lui, reçoit l'instruction interne complète (apiText).
    sendMsg("[REPRISE APRÈS INTERRUPTION VOLONTAIRE] Tu as été interrompu par l'utilisateur (bouton Stop) pendant ta génération précédente. Avant toute chose, relis les DERNIERS résultats d'outils déjà présents dans cette conversation pour savoir précisément où tu en étais rendu. Ne reformule PAS la demande initiale et ne redemande AUCUNE information déjà donnée : continue directement l'exécution concrète de la tâche à partir du dernier état connu (prochain appel d'outil ou étape suivante), comme si tu n'avais jamais été interrompu. Si le dernier résultat d'outil visible montre que l'action a déjà réellement abouti, ne la refais pas : passe à l'étape suivante ou conclus.", [], false, 'Veuillez continuer');
  }, 450);
}

function downloadAsPDF(id, filename) {
  const el = document.getElementById(id);
  if (!el) return;
  if (typeof window.jspdf === 'undefined') { toast('jsPDF non disponible (hors-ligne ?)', true); return; }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const text = el.textContent || '';
  const marginX = 40, marginY = 50, maxWidth = 515;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  const lines = doc.splitTextToSize(text, maxWidth);
  const lineHeight = 14;
  let y = marginY;
  const pageHeight = doc.internal.pageSize.getHeight();
  lines.forEach(line => {
    if (y > pageHeight - marginY) { doc.addPage(); y = marginY; }
    doc.text(line, marginX, y);
    y += lineHeight;
  });
  doc.save(filename.replace(/\.\w+$/, '') + '.pdf');
}

function toggleFileMenu(id, anchorBtn){
  const menu = document.getElementById('filemenu-'+id);
  if (!menu) return;
  const isOpen = menu.style.display === 'block';
  document.querySelectorAll('.nps-file-menu').forEach(m => m.style.display = 'none');
  if (isOpen) return;
  menu.style.display = 'block';
  positionFileMenu(menu, anchorBtn);
}

// Place le menu contextuel en position:fixed a partir de la position reelle
// du bouton ⋮ a l'ecran, en le retournant automatiquement si l'espace manque
// a droite ou en bas, pour qu'il reste toujours entierement visible.
function positionFileMenu(menu, anchor){
  if (!anchor) return;
  const margin = 8;
  const anchorRect = anchor.getBoundingClientRect();
  const menuRect = menu.getBoundingClientRect();
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  // Aligne par defaut le bord droit du menu sur le bord droit du bouton
  let left = anchorRect.right - menuRect.width;
  if (left < margin) left = margin;
  if (left + menuRect.width > vw - margin) left = vw - menuRect.width - margin;

  // Ouvre vers le bas par defaut, sinon retourne vers le haut si pas de place
  let top = anchorRect.bottom + margin;
  if (top + menuRect.height > vh - margin) {
    top = anchorRect.top - menuRect.height - margin;
  }
  if (top < margin) top = margin;

  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
}

document.addEventListener('click', (e) => {
  if (!e.target.closest('.nps-file-menu-wrap')) {
    document.querySelectorAll('.nps-file-menu').forEach(m => m.style.display = 'none');
  }
});
window.addEventListener('resize', () => {
  document.querySelectorAll('.nps-file-menu').forEach(m => m.style.display = 'none');
});
window.addEventListener('scroll', () => {
  document.querySelectorAll('.nps-file-menu').forEach(m => m.style.display = 'none');
}, true);

// Enchaînement automatique des playlists TTS (voir buildReflectionBlock /
// fmtText → .chained-audio-wrap). L'événement 'ended' des <audio> ne remonte
// pas (pas de bubbling sur les événements média), donc on écoute en phase de
// capture sur document : ça intercepte l'événement avant qu'il n'atteigne sa
// cible, ce qui marche même sans bubbling.
document.addEventListener('ended', (e) => {
  const audioEl = e.target;
  if (!audioEl.classList || !audioEl.classList.contains('chained-audio')) return;
  const wrap = audioEl.closest('.chained-audio-wrap');
  if (!wrap) return;
  let urls;
  try { urls = JSON.parse(wrap.dataset.playlist); } catch (err) { return; }
  let idx = parseInt(audioEl.dataset.idx || '0', 10) + 1;
  if (idx >= urls.length) return;
  audioEl.dataset.idx = idx;
  audioEl.src = urls[idx];
  const segCur = wrap.querySelector('.seg-cur');
  if (segCur) segCur.textContent = idx + 1;
  audioEl.play().catch(() => {});
}, true);

function deployToGhPages(id, fileName){
  // Le clic ne fait plus d'appel API en dur ni de prompt() natif du navigateur :
  // il envoie une vraie demande à Fable Fast, comme si l'utilisateur l'avait tapée. Fable Fast
  // planifie alors lui-même (dépôt cible, activation Pages, vérification), le fait
  // à travers son propre processus de réflexion visible, et l'utilisateur peut
  // toujours changer d'avis ou l'arrêter en cours de route, comme pour n'importe
  // quelle autre demande.
  sendMsg(`Déploie le fichier "${fileName}" que tu viens de créer sur GitHub Pages. Demande-moi le dépôt cible si tu ne le connais pas déjà, puis planifie et exécute toi-même les étapes.`);
}

// Ferme tous les apercus (autres cartes) et vide leur conteneur : ca detruit
// vraiment l'iframe (arrete tout JS/audio en cours dedans), pas juste la
// cacher. except: id de l'apercu a laisser tel quel (null = tout fermer).
function closeAllPreviews(exceptId){
  document.querySelectorAll('[id^="preview-"]').forEach(el => {
    if (exceptId && el.id === 'preview-' + exceptId) return;
    el.innerHTML = '';
    el.style.display = 'none';
  });
}
function closeAllCodeViews(exceptId){
  document.querySelectorAll('.code-block').forEach(el => {
    if (exceptId && el.id === exceptId) return;
    el.style.display = 'none';
  });
}

function toggleArtifactView(id, mode){
  const codeEl = document.getElementById(id);
  const previewEl = document.getElementById('preview-'+id);
  if(!codeEl) return;

  if(mode==='preview'){
    const wasOpen = previewEl && previewEl.style.display === 'block';
    // Toujours tout fermer d'abord : jamais deux apercus (ou apercu + code)
    // ouverts en meme temps, sur cette carte ou une autre.
    closeAllPreviews(null);
    closeAllCodeViews(null);

    if (!wasOpen && previewEl) {
      // Reconstruction complete de l'iframe a chaque ouverture : jamais de
      // reprise d'un etat precedent, toujours le contenu actuel du bloc.
      npsPreviewInto(previewEl, codeEl.textContent, codeEl.dataset.fname || '', codeEl.dataset.lang || '');
    }
  } else {
    const wasOpen = codeEl.style.display === 'block';
    closeAllPreviews(null);
    closeAllCodeViews(null);
    codeEl.style.display = wasOpen ? 'none' : 'block';
  }
}

function buildPlan(b, mid, i) {
  const id = 'plan-'+mid+'-'+i;
  const lines = b.content.split('\n').map(l=>l.trim()).filter(Boolean);
  const title = (lines[0] || 'Plan').replace(/^#+\s*/, '').replace(/^[\d\.\-\*\s]+/, '');
  return `<div style="margin-top:8px;border-radius:12px;background:linear-gradient(135deg, var(--bg2), var(--bg3));border:1px solid var(--accent);overflow:hidden;">
    <button onclick="togglePlan('${id}')" style="width:100%;display:flex;align-items:center;gap:10px;padding:12px 14px;background:none;border:none;cursor:pointer;text-align:left;">
      <div style="display:flex;color:var(--accent);"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 12h6M9 16h4"/></svg></div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:15.5px;font-weight:700;color:var(--accent);">Voici le plan</div>
        <div style="font-size:13.5px;color:var(--text2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(title)}</div>
      </div>
      <div id="chevron-${id}" style="font-size:15.5px;color:var(--text2);transition:transform .3s ease;">▾</div>
    </button>
    <div id="${id}" style="max-height:0;overflow:hidden;transition:max-height .4s ease;">
      <div style="padding:0 14px 14px 14px;border-top:1px solid var(--border);margin-top:0;">
        <div style="padding-top:12px;font-size:15.5px;line-height:1.8;color:var(--text);white-space:pre-wrap;">${esc(b.content)}</div>
      </div>
    </div>
  </div>`;
}
function togglePlan(id){
  const panel = document.getElementById(id);
  const chevron = document.getElementById('chevron-'+id);
  if(!panel) return;
  const isOpen = panel.style.maxHeight && panel.style.maxHeight !== '0px';
  panel.style.maxHeight = isOpen ? '0px' : (panel.scrollHeight + 'px');
  if(chevron) chevron.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
}

function inferArtifactName(b, ext) {
  const lang = (b.lang || '').toLowerCase();
  const content = b.content || '';
  if (lang === 'html' || /<!doctype html|<html[\s>]/i.test(content)) return 'index.html';
  if (lang === 'css' || /(^|\n)\s*[.#][\w-]+\s*\{/i.test(content)) return 'styles.css';
  if (lang === 'javascript' || lang === 'js' || /(^|\n)\s*(const|let|var|function)\s+/i.test(content)) return 'script.js';
  if (lang === 'typescript' || lang === 'ts') return 'main.ts';
  if (lang === 'python' || lang === 'py') return 'main.py';
  if (lang === 'json') return 'data.json';
  if (lang === 'markdown' || lang === 'md') return 'README.md';
  if (lang === 'java') return 'Main.java';
  if (lang === 'kotlin' || lang === 'kt') return 'Main.kt';
  if (lang === 'xml') return 'layout.xml';
  if (lang === 'sql') return 'query.sql';
  return `file.${ext || 'txt'}`;
}
