// ═══════ ICÔNES DE FICHIERS (SVG en couleurs par type — repli commun pour les types inconnus) ═══════
const NPS_FILE_ICONS = (function(){
  const P = {
    code:'<polyline points="8 8 4 12 8 16"/><polyline points="16 8 20 12 16 16"/><line x1="13.5" y1="6" x2="10.5" y2="18"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18z"/>',
    drop:'<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/><path d="M9.5 14.5a2.5 2.5 0 0 0 2.5 2.5"/>',
    lines:'<path d="M6 3h8l4 4v14H6z"/><polyline points="14 3 14 7 18 7"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="15.5" x2="15" y2="15.5"/><line x1="9" y1="19" x2="12.5" y2="19"/>',
    grid:'<rect x="4" y="4" width="16" height="16" rx="2.5"/><line x1="4" y1="10" x2="20" y2="10"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="4" x2="10" y2="20"/>',
    bars:'<rect x="3.5" y="4" width="17" height="12" rx="2"/><line x1="12" y1="16" x2="12" y2="20"/><line x1="8" y1="20" x2="16" y2="20"/><line x1="8" y1="12" x2="8" y2="9.5"/><line x1="12" y1="12" x2="12" y2="7.5"/><line x1="16" y1="12" x2="16" y2="10.5"/>',
    zip:'<path d="M4 7.5L12 3l8 4.5v9L12 21l-8-4.5z"/><polyline points="4 7.5 12 12 20 7.5"/><line x1="12" y1="12" x2="12" y2="21"/>',
    phone:'<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><line x1="10.5" y1="18.5" x2="13.5" y2="18.5"/><path d="M10 7.5l4 3-4 3" />',
    image:'<rect x="3.5" y="4" width="17" height="16" rx="3"/><circle cx="9" cy="9.5" r="1.7"/><path d="M4 17l5-5 4 4 2.5-2.5L20 17"/>',
    video:'<rect x="3" y="5.5" width="18" height="13" rx="3"/><polygon points="10.2 9.3 15.2 12 10.2 14.7" fill="currentColor"/>',
    audio:'<path d="M9 17.5V6l10-2v11.5"/><circle cx="6.5" cy="17.5" r="2.5"/><circle cx="16.5" cy="15.5" r="2.5"/>',
    db:'<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
    term:'<polyline points="5 8 10 12 5 16"/><line x1="12.5" y1="17" x2="19" y2="17"/>',
    gear:'<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
    file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/>',
    book:'<path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H19v17H7.5A2.5 2.5 0 0 0 5 21.5z"/><path d="M5 19.5A2.5 2.5 0 0 1 7.5 17H19"/>',
    cal:'<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><line x1="3.5" y1="10" x2="20.5" y2="10"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="16" y1="3" x2="16" y2="7"/>',
    contact:'<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="11" r="2.2"/><path d="M5.5 16.5c.6-1.6 1.9-2.3 3.5-2.3s2.9.7 3.5 2.3"/><line x1="15" y1="10" x2="18" y2="10"/><line x1="15" y1="13.5" x2="18" y2="13.5"/>',
    key:'<circle cx="8" cy="15" r="4"/><path d="M10.8 12.2L20 3"/><path d="M17 6l3 3"/><path d="M14.5 8.5l2 2"/>',
    pen:'<path d="M12 19l7-7-4-4-7 7z"/><path d="M8 15L4 20l5-1"/><path d="M15 8l1.5-1.5a1.8 1.8 0 0 1 2.6 0l.4.4a1.8 1.8 0 0 1 0 2.6L18 11"/>',
    cube:'<path d="M12 2.5l8 4.5v10l-8 4.5-8-4.5V7z"/><polyline points="4 7 12 11.5 20 7"/><line x1="12" y1="11.5" x2="12" y2="21.5"/>',
    sub:'<rect x="3" y="5" width="18" height="14" rx="3"/><line x1="7" y1="11" x2="11" y2="11"/><line x1="13" y1="11" x2="17" y2="11"/><line x1="7" y1="15" x2="9.5" y2="15"/><line x1="12" y1="15" x2="17" y2="15"/>'
  };
  const K = {
    html:{c:'#F0652F',p:P.globe}, css:{c:'#2D8CFF',p:P.drop}, js:{c:'#F7C23E',t:'JS'}, ts:{c:'#3B82F6',t:'TS'},
    json:{c:'#F59E0B',t:'{ }'}, py:{c:'#4B9CD3',t:'PY'}, md:{c:'#38BDF8',t:'MD'}, txt:{c:'#94A3B8',p:P.lines},
    pdf:{c:'#EF4444',t:'PDF'}, doc:{c:'#3B82F6',t:'DOC'}, sheet:{c:'#22C55E',p:P.grid}, slide:{c:'#F97316',p:P.bars},
    zip:{c:'#A855F7',p:P.zip}, apk:{c:'#3DDC84',p:P.phone}, img:{c:'#EC4899',p:P.image}, svg:{c:'#FFB13B',t:'SVG'},
    video:{c:'#F43F5E',p:P.video}, audio:{c:'#14B8A6',p:P.audio}, db:{c:'#06B6D4',p:P.db}, sh:{c:'#4ADE80',p:P.term},
    xml:{c:'#FB923C',p:P.code}, yml:{c:'#F472B6',t:'YML'}, java:{c:'#E76F51',t:'JV'}, kt:{c:'#A97BFF',t:'KT'},
    c:{c:'#5C9DFF',t:'C'}, cpp:{c:'#5C9DFF',t:'C+'}, php:{c:'#8892BF',t:'PHP'}, go:{c:'#00ADD8',t:'GO'},
    rs:{c:'#DEA584',t:'RS'}, rb:{c:'#E0473D',t:'RB'}, swift:{c:'#F05138',t:'SW'}, dart:{c:'#00B4AB',t:'DT'},
    font:{c:'#C084FC',t:'Aa'}, bin:{c:'#94A3B8',p:P.gear}, code:{c:'#60A5FA',p:P.code}, file:{c:'#94A3B8',p:P.file},
    ebook:{c:'#D97706',p:P.book}, cal:{c:'#EF4444',p:P.cal}, contact:{c:'#0EA5E9',p:P.contact}, key:{c:'#EAB308',p:P.key},
    design:{c:'#E879F9',p:P.pen}, model3d:{c:'#34D399',p:P.cube}, sub:{c:'#A3E635',p:P.sub}, tex:{c:'#10B981',t:'TEX'},
    docker:{c:'#2496ED',t:'DK'}, make:{c:'#94A3B8',p:P.gear}, git:{c:'#F05133',t:'GIT'}, lic:{c:'#94A3B8',p:P.lines}
  };
  const X = {};
  const add = (key, list) => list.split(' ').forEach(e => { X[e] = key; });
  add('html','html htm xhtml'); add('css','css scss sass less'); add('js','js mjs cjs jsx'); add('ts','ts tsx');
  add('json','json jsonc map'); add('py','py pyw ipynb python'); add('md','md markdown mdx'); add('txt','txt log text rtf');
  add('pdf','pdf'); add('doc','doc docx odt dotx'); add('sheet','xls xlsx xlsm csv tsv ods'); add('slide','ppt pptx odp key');
  add('zip','zip rar 7z tar gz tgz bz2 xz'); add('apk','apk aab xapk'); add('img','png jpg jpeg gif webp bmp ico heic avif');
  add('svg','svg'); add('video','mp4 webm mov mkv avi m4v'); add('audio','mp3 wav ogg m4a aac flac opus');
  add('db','sql db sqlite sqlite3'); add('sh','sh bash zsh bat cmd ps1'); add('xml','xml xsd plist');
  add('yml','yml yaml toml ini env conf cfg properties gradle'); add('java','java'); add('kt','kt kts kotlin');
  add('c','c h'); add('cpp','cpp cc cxx hpp'); add('php','php'); add('go','go'); add('rs','rs rust'); add('rb','rb ruby');
  add('swift','swift'); add('dart','dart'); add('font','ttf otf woff woff2'); add('bin','exe dll so bin dat jar');
  add('code','vue svelte lua r pl scala hs ex exs graphql gql proto wasm sol');
  add('ebook','epub mobi azw3 fb2'); add('cal','ics ical'); add('contact','vcf'); add('key','pem key crt cer pfx p12 pub jks keystore');
  add('design','psd ai fig sketch xd eps indd'); add('model3d','glb gltf obj fbx stl 3ds blend');
  add('sub','srt vtt ass sub'); add('tex','tex bib'); add('zip','iso dmg'); add('doc','pages'); add('sheet','numbers');
  add('img','tif tiff raw cr2 nef'); add('audio','wma mid midi amr'); add('video','wmv flv 3gp mpg mpeg');
  add('txt','nfo'); add('bin','apkm obb');
  // fichiers connus par leur nom complet (sans extension utile)
  const N = { 'dockerfile':'docker', 'makefile':'make', 'cmakelists.txt':'make', '.gitignore':'git', '.gitattributes':'git', '.gitmodules':'git',
              'license':'lic', 'licence':'lic', 'license.md':'lic', 'license.txt':'lic', 'readme':'md', 'package.json':'json', 'requirements.txt':'py',
              '.env':'yml', '.env.example':'yml', 'procfile':'sh', 'build.gradle':'yml', 'androidmanifest.xml':'xml' };
  return { K, X, N };
})();
function npsFileIcon(name, o){
  o = o || {};
  const ext = ((name || '').indexOf('.') >= 0 ? name.split('.').pop() : '').toLowerCase();
  let key = NPS_FILE_ICONS.N[String(name || '').split('/').pop().toLowerCase()] || NPS_FILE_ICONS.X[ext];
  if (!key && o.lang) key = NPS_FILE_ICONS.X[String(o.lang).toLowerCase()];
  if (!key && o.mime) {
    if (/^image\//.test(o.mime)) key = 'img';
    else if (/^video\//.test(o.mime)) key = 'video';
    else if (/^audio\//.test(o.mime)) key = 'audio';
    else if (/pdf/.test(o.mime)) key = 'pdf';
  }
  const d = NPS_FILE_ICONS.K[key] || NPS_FILE_ICONS.K.file;
  const size = o.size || 40, gl = Math.round(size * 0.62);
  const inner = d.t
    ? '<text x="12" y="16" text-anchor="middle" font-size="' + (d.t.length > 2 ? 8.5 : 11) + '" font-weight="800" font-family="system-ui,-apple-system,Roboto,sans-serif" fill="' + d.c + '" stroke="none">' + d.t + '</text>'
    : d.p;
  return '<div class="nps-ftile" style="width:' + size + 'px;height:' + size + 'px;background:' + d.c + '26;border-color:' + d.c + '59;color:' + d.c + '"><svg viewBox="0 0 24 24" width="' + gl + '" height="' + gl + '" fill="none" stroke="' + d.c + '" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' + inner + '</svg></div>';
}

// ═══════ COLORATION SYNTAXIQUE (légère, sans dépendance, façon Google AI Studio) ═══════
function highlightCode(raw, lang){
  raw = String(raw || '');
  lang = (lang || '').toLowerCase().trim();
  const wrap = (cls, s) => '<span class="tok-' + cls + '">' + esc(s) + '</span>';
  const run = (re, handler) => {
    let out = '', last = 0, m;
    while ((m = re.exec(raw))) {
      out += esc(raw.slice(last, m.index));
      out += handler(m);
      last = re.lastIndex;
      if (re.lastIndex === m.index) re.lastIndex++; // garde-fou anti-boucle sur un match vide
    }
    out += esc(raw.slice(last));
    return out;
  };
  if (['html', 'htm', 'xml', 'svg', 'vue'].includes(lang)) {
    const re = /(<!--[\s\S]*?-->)|(<\/?[a-zA-Z][\w:-]*)|(\s[a-zA-Z_:][\w:.-]*)(=)("[^"]*"|'[^']*')|(\/?>)/g;
    return run(re, m => {
      if (m[1]) return wrap('comment', m[1]);
      if (m[2]) return wrap('tag', m[2]);
      if (m[3]) return wrap('attr', m[3]) + esc(m[4]) + wrap('string', m[5]);
      return esc(m[6] || '');
    });
  }
  if (['js', 'javascript', 'jsx', 'ts', 'typescript', 'mjs'].includes(lang)) {
    const kw = 'const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|class|extends|new|try|catch|finally|throw|async|await|import|export|default|from|typeof|instanceof|in|of|null|undefined|true|false|this|super|void|yield|static|get|set';
    const re = new RegExp('(//[^\\n]*|/\\*[\\s\\S]*?\\*/)|("(?:[^"\\\\]|\\\\.)*"|\'(?:[^\'\\\\]|\\\\.)*\'|`(?:[^`\\\\]|\\\\.)*`)|(\\b\\d+\\.?\\d*\\b)|(\\b(?:' + kw + ')\\b)', 'g');
    return run(re, m => m[1] ? wrap('comment', m[1]) : m[2] ? wrap('string', m[2]) : m[3] ? wrap('number', m[3]) : wrap('keyword', m[4]));
  }
  if (['py', 'python'].includes(lang)) {
    const kw = 'def|return|if|elif|else|for|while|import|from|as|class|try|except|finally|with|lambda|None|True|False|and|or|not|in|is|pass|break|continue|yield|global|nonlocal|raise|async|await|self';
    const re = new RegExp('(#[^\\n]*)|("""[\\s\\S]*?"""|\'\'\'[\\s\\S]*?\'\'\'|"(?:[^"\\\\]|\\\\.)*"|\'(?:[^\'\\\\]|\\\\.)*\')|(\\b\\d+\\.?\\d*\\b)|(\\b(?:' + kw + ')\\b)', 'g');
    return run(re, m => m[1] ? wrap('comment', m[1]) : m[2] ? wrap('string', m[2]) : m[3] ? wrap('number', m[3]) : wrap('keyword', m[4]));
  }
  if (lang === 'json') {
    const re = /("(?:[^"\\]|\\.)*")(\s*:)?|(\b-?\d+\.?\d*\b)|(\btrue\b|\bfalse\b|\bnull\b)/g;
    return run(re, m => {
      if (m[1]) return wrap(m[2] ? 'attr' : 'string', m[1]) + esc(m[2] || '');
      if (m[3]) return wrap('number', m[3]);
      return wrap('keyword', m[4]);
    });
  }
  if (lang === 'css' || lang === 'scss') {
    const re = /(\/\*[\s\S]*?\*\/)|([.#]?[a-zA-Z][\w-]*)(\s*\{)|([a-zA-Z-]+)(\s*:)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g;
    return run(re, m => {
      if (m[1]) return wrap('comment', m[1]);
      if (m[2]) return wrap('tag', m[2]) + esc(m[3]);
      if (m[4]) return wrap('attr', m[4]) + esc(m[5]);
      return wrap('string', m[6]);
    });
  }
  if (['bash', 'sh', 'shell', 'zsh'].includes(lang)) {
    const kw = 'cd|ls|echo|cat|cp|mv|rm|mkdir|sudo|git|npm|pip|pip3|python|python3|curl|wget|export|if|then|else|fi|for|do|done|while|chmod|npx';
    const re = new RegExp('(#[^\\n]*)|("(?:[^"\\\\]|\\\\.)*"|\'[^\']*\')|(\\b(?:' + kw + ')\\b)', 'g');
    return run(re, m => m[1] ? wrap('comment', m[1]) : m[2] ? wrap('string', m[2]) : wrap('keyword', m[3]));
  }
  // Langage non reconnu : pas de couleur, mais toujours échappé correctement.
  return esc(raw);
}

// ═══════ APERÇUS DE FICHIERS (rendu réel selon le type) ═══════
function npsMdInline(t){
  t = esc(t);
  t = t.replace(/`([^`\n]+)`/g,'<code>$1</code>');
  t = t.replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>').replace(/__([^_\n]+)__/g,'<strong>$1</strong>');
  t = t.replace(/(^|[^*\w])\*([^*\n]+)\*/g,'$1<em>$2</em>').replace(/~~([^~\n]+)~~/g,'<del>$1</del>');
  t = t.replace(/!\[([^\]]*)\]\((https?:[^\s)]+)\)/g,'<img src="$2" alt="$1">');
  t = t.replace(/\[([^\]]+)\]\((https?:[^\s)]+)\)/g,'<a href="$2" onclick="event.preventDefault();event.stopPropagation();openLink(this.getAttribute(\'href\'))">$1</a>');
  return t;
}
function npsMd(src){
  const lines = String(src||'').replace(/\r/g,'').split('\n');
  const LI = /^\s*([-*+]|\d+[.)])\s+/;
  let out = '', i = 0, para = [];
  const flush = () => { if (para.length) { out += '<p>' + npsMdInline(para.join(' ')) + '</p>'; para = []; } };
  while (i < lines.length) {
    const l = lines[i]; let m;
    if ((m = /^\s*```(\w*)/.exec(l))) { flush(); const fenceLang = m[1] || ''; const buf = []; i++; while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]); i++; out += '<pre><code>' + highlightCode(buf.join('\n'), fenceLang) + '</code></pre>'; continue; }
    if (!l.trim()) { flush(); i++; continue; }
    if ((m = /^(#{1,6})\s+(.*)$/.exec(l))) { flush(); out += '<h' + m[1].length + '>' + npsMdInline(m[2].replace(/\s+#+\s*$/,'')) + '</h' + m[1].length + '>'; i++; continue; }
    if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(l)) { flush(); out += '<hr>'; i++; continue; }
    if (/^\s*>/.test(l)) { flush(); const buf = []; while (i < lines.length && /^\s*>/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/,'')); out += '<blockquote>' + npsMd(buf.join('\n')) + '</blockquote>'; continue; }
    if (LI.test(l)) {
      flush(); const ordered = /^\s*\d/.test(l); const items = [];
      while (i < lines.length && LI.test(lines[i])) { items.push(lines[i].replace(LI,'')); i++; }
      out += (ordered ? '<ol>' : '<ul>') + items.map(x => {
        const t = /^\[( |x|X)\]\s+/.exec(x);
        const cb = t ? '<span class="nps-cb' + (t[1] === ' ' ? '' : ' on') + '"></span>' : '';
        return '<li>' + cb + npsMdInline(t ? x.slice(t[0].length) : x) + '</li>';
      }).join('') + (ordered ? '</ol>' : '</ul>');
      continue;
    }
    if (/^\s*\|.*\|\s*$/.test(l) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[i+1])) {
      flush();
      const row = r => r.trim().replace(/^\||\|$/g,'').split('|').map(c => c.trim());
      const head = row(l); i += 2; const rows = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) rows.push(row(lines[i++]));
      out += '<div class="nps-pv-scroll"><table><thead><tr>' + head.map(c => '<th>' + npsMdInline(c) + '</th>').join('') + '</tr></thead><tbody>' +
        rows.map(r => '<tr>' + r.map(c => '<td>' + npsMdInline(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
      continue;
    }
    para.push(l.trim()); i++;
  }
  flush();
  return out;
}
function npsParseCsv(text, delim){
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i+1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
    else if (c === '"') q = true;
    else if (c === delim) { row.push(cur); cur = ''; }
    else if (c === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; if (rows.length > 400) break; }
    else if (c !== '\r') cur += c;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows;
}
function npsTableHtml(rows){
  if (!rows.length) return '<p>Fichier vide.</p>';
  const w = Math.max(...rows.map(r => r.length));
  const pad = r => { r = r.slice(); while (r.length < w) r.push(''); return r; };
  const head = pad(rows[0]);
  return '<div class="nps-pv-scroll"><table><thead><tr>' + head.map(c => '<th>' + esc(c) + '</th>').join('') + '</tr></thead><tbody>' +
    rows.slice(1).map(r => '<tr>' + pad(r).map(c => '<td>' + esc(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
}
// Types dont on peut afficher un vrai rendu (pas juste du texte brut)
function npsRenderKind(name, lang, text){
  const ext = ((name || '').indexOf('.') >= 0 ? name.split('.').pop() : '').toLowerCase();
  const l = String(lang || '').toLowerCase();
  const k = ext || l;
  const sniff = !k || /^(txt|text|log|html?|xhtml|svg|xml)$/.test(k); // on ne devine par le contenu que si le nom ne dit rien
  if (/^(html?|xhtml)$/.test(k) || (/^(html?)$/.test(l)) || (sniff && /<!doctype html|<html[\s>]/i.test((text || '').slice(0, 400)))) return 'html';
  if (k === 'svg' || (sniff && /^\s*<svg[\s>]/i.test((text || '').slice(0, 200)))) return 'svg';
  if (/^(md|markdown|mdx)$/.test(k) || /^(md|markdown)$/.test(l)) return 'md';
  if (/^(json|jsonc)$/.test(k) || l === 'json') return 'json';
  if (k === 'csv' || l === 'csv') return 'csv';
  if (k === 'tsv' || l === 'tsv') return 'tsv';
  return 'text';
}
function npsPreviewInto(box, text, name, lang){
  box.innerHTML = '';
  const kind = npsRenderKind(name, lang, text);
  const add = (html, cls) => { const d = document.createElement('div'); d.className = 'nps-pv ' + (cls || ''); d.innerHTML = html; box.appendChild(d); };
  if (kind === 'html' || kind === 'svg') {
    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'display:block;width:100%;height:340px;border:none;background:#fff;';
    iframe.setAttribute('sandbox', kind === 'svg' ? '' : 'allow-scripts allow-forms allow-popups allow-modals');
    iframe.srcdoc = kind === 'svg'
      ? '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><body style="margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#fff"><div style="max-width:100%;padding:12px;box-sizing:border-box">' + text + '</div>'
      : text;
    box.appendChild(iframe);
  } else if (kind === 'md') add(npsMd(text), 'md');
  else if (kind === 'json') {
    let pretty = text; try { pretty = JSON.stringify(JSON.parse(text), null, 2); } catch(e) {}
    add('<pre>' + esc(pretty) + '</pre>', 'code');
  }
  else if (kind === 'csv' || kind === 'tsv') add(npsTableHtml(npsParseCsv(text, kind === 'tsv' ? '\t' : (/;/.test((text.split('\n')[0] || '')) && !/,/.test(text.split('\n')[0] || '') ? ';' : ','))), 'table');
  else add('<pre>' + esc(text) + '</pre>', 'code');
  box.style.display = 'block';
}
function npsDataUrlToBlob(dataUrl){
  const [meta, b64] = String(dataUrl).split(',');
  const mime = (/data:(.*?)(;base64)?$/.exec(meta) || [,'application/octet-stream'])[1] || 'application/octet-stream';
  const bin = atob(b64 || ''); const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
// Aperçu d'un fichier binaire / structuré (Blob) : image, audio, vidéo, PDF, Word, Excel, ZIP, texte.
async function npsPreviewBlobInto(box, blob, name, mime){
  box.innerHTML = '<div class="nps-pv"><div class="nps-pv-note">Ouverture…</div></div>';
  box.style.display = 'block';
  const ext = ((name || '').indexOf('.') >= 0 ? name.split('.').pop() : '').toLowerCase();
  const note = t => { box.innerHTML = '<div class="nps-pv"><div class="nps-pv-note">' + esc(t) + '</div></div>'; };
  try {
    if (/^image\//.test(mime) || /^(png|jpe?g|gif|webp|bmp|ico|avif)$/.test(ext)) {
      const u = URL.createObjectURL(blob); box.innerHTML = '<div class="nps-pv"><img src="' + u + '" style="max-width:100%;border-radius:8px;display:block;margin:0 auto"></div>'; return;
    }
    if (/^video\//.test(mime) || /^(mp4|webm|mov|mkv)$/.test(ext)) { box.innerHTML = '<div class="nps-pv"><video controls playsinline src="' + URL.createObjectURL(blob) + '" style="width:100%;max-height:380px;border-radius:8px;background:#000"></video></div>'; return; }
    if (/^audio\//.test(mime) || /^(mp3|wav|ogg|m4a|aac|flac|opus)$/.test(ext)) { box.innerHTML = '<div class="nps-pv"><audio controls src="' + URL.createObjectURL(blob) + '" style="width:100%"></audio></div>'; return; }
    if (ext === 'pdf' || /pdf/.test(mime)) {
      const f = document.createElement('iframe'); f.style.cssText = 'display:block;width:100%;height:420px;border:none;background:#fff';
      f.src = URL.createObjectURL(new Blob([blob], { type: 'application/pdf' })); box.innerHTML = ''; box.appendChild(f); return;
    }
    if (/^(docx|dotx)$/.test(ext)) {
      if (!window.mammoth) return note('Lecteur Word indisponible (hors-ligne ?). Télécharge le fichier pour l\'ouvrir.');
      const r = await mammoth.convertToHtml({ arrayBuffer: await blob.arrayBuffer() });
      box.innerHTML = ''; const d = document.createElement('div'); d.className = 'nps-pv md'; d.innerHTML = r.value || '<p>Document vide.</p>'; box.appendChild(d); return;
    }
    if (/^(xlsx|xlsm|xls|ods)$/.test(ext)) {
      if (!window.XLSX) return note('Lecteur Excel indisponible (hors-ligne ?). Télécharge le fichier pour l\'ouvrir.');
      const wb = XLSX.read(await blob.arrayBuffer(), { type: 'array' });
      const html = wb.SheetNames.slice(0, 3).map(n => '<div class="nps-pv-sheet">' + esc(n) + '</div><div class="nps-pv-scroll">' + XLSX.utils.sheet_to_html(wb.Sheets[n], { header: '', footer: '' }).replace(/^[\s\S]*?<table/i, '<table').replace(/<\/table>[\s\S]*$/i, '</table>') + '</div>').join('');
      box.innerHTML = ''; const d = document.createElement('div'); d.className = 'nps-pv table'; d.innerHTML = html; box.appendChild(d); return;
    }
    if (/^(zip|apk|jar|aab|xapk)$/.test(ext) || /zip/.test(mime)) {
      if (!window.JSZip) return note('Lecteur ZIP indisponible (hors-ligne ?).');
      const z = await JSZip.loadAsync(blob); const names = Object.keys(z.files).filter(n => !z.files[n].dir);
      box.innerHTML = ''; const d = document.createElement('div'); d.className = 'nps-pv code';
      d.innerHTML = '<div class="nps-pv-note">' + names.length + ' fichier' + (names.length > 1 ? 's' : '') + ' dans l\'archive</div><pre>' + esc(names.slice(0, 300).join('\n')) + (names.length > 300 ? '\n…' : '') + '</pre>'; box.appendChild(d); return;
    }
    const textLike = /^text\//.test(mime) || /^(md|markdown|txt|log|json|csv|tsv|xml|html?|svg|css|js|mjs|ts|tsx|jsx|py|java|kt|c|h|cpp|sh|sql|ya?ml|toml|ini|env|conf|gradle|properties|php|go|rs|rb|swift|dart|vue|lua|srt|vtt|ics|vcf|tex|bib|gitignore)$/.test(ext);
    if (textLike) { npsPreviewInto(box, await blob.text(), name, ext); return; }
    note('Pas d\'aperçu pour ce type de fichier — utilise le téléchargement pour l\'ouvrir.');
  } catch (e) { note('Impossible d\'afficher ce fichier (' + (e.message || 'erreur') + ').'); }
}
// Carte d'un fichier binaire exporté : tap = aperçu sous la carte
function toggleBinaryPreview(id, name){
  const box = document.getElementById('preview-' + id); const src = document.getElementById(id);
  if (!box || !src) return;
  if (box.style.display === 'block') { box.innerHTML = ''; box.style.display = 'none'; return; }
  closeAllPreviews(null); closeAllCodeViews(null);
  try { const blob = npsDataUrlToBlob(src.textContent); npsPreviewBlobInto(box, blob, name, blob.type); }
  catch (e) { box.innerHTML = '<div class="nps-pv"><div class="nps-pv-note">Fichier illisible.</div></div>'; box.style.display = 'block'; }
}
const NPS_TYPE_LABEL = { html:'HTML', css:'CSS', js:'JavaScript', ts:'TypeScript', json:'JSON', py:'Python', md:'Markdown', txt:'Texte', pdf:'PDF', doc:'Document Word', sheet:'Tableur', slide:'Présentation', zip:'Archive', apk:'Application Android', img:'Image', svg:'Image SVG', video:'Vidéo', audio:'Audio', db:'Base de données', sh:'Script shell', xml:'XML', yml:'Configuration', java:'Java', kt:'Kotlin', c:'C', cpp:'C++', php:'PHP', go:'Go', rs:'Rust', rb:'Ruby', swift:'Swift', dart:'Dart', font:'Police', bin:'Fichier binaire', code:'Code', ebook:'Livre numérique', cal:'Calendrier', contact:'Contact', key:'Clé / certificat', design:'Design', model3d:'Modèle 3D', sub:'Sous-titres', tex:'LaTeX', docker:'Docker', make:'Makefile', git:'Git', lic:'Licence', file:'Fichier' };
function npsTypeLabel(name, lang){
  const ext = ((name || '').indexOf('.') >= 0 ? name.split('.').pop() : '').toLowerCase();
  const base = (name || '').split('/').pop().toLowerCase();
  const key = NPS_FILE_ICONS.N[base] || NPS_FILE_ICONS.X[ext] || NPS_FILE_ICONS.X[String(lang || '').toLowerCase()];
  return NPS_TYPE_LABEL[key] || (ext ? ext.toUpperCase() : (lang ? String(lang) : 'Fichier'));
}
// Carte d'un fichier envoyé par l'utilisateur : même carte que celles de Fable Fast
function buildUserFileCard(a, mid, i){
  const ext = ((a.name || '').indexOf('.') >= 0 ? a.name.split('.').pop() : '').toLowerCase();
  if (typeof a.text === 'string') return buildCode({ lang: ext || 'txt', content: a.text, filename: a.name, fromUser: true, size: a.size }, 'u' + mid, i);
  return `<div class="nps-fcard" onclick="event.stopPropagation();previewAttachment('${a.id}')">
    <div class="nps-fcard-row">${npsFileIcon(a.name, { mime: a.type })}
      <div class="nps-fcard-info"><div class="nps-fcard-name">${esc(a.name)}</div><div class="nps-fcard-meta">${esc(npsTypeLabel(a.name))} · ${formatBytes(a.size || 0)}</div></div>
    </div></div>`;
}

function buildCode(b, mid, i) {
  if(b.lang==='rapport') return ffRenderReport(b.content);
  const id='code-'+mid+'-'+i;
  if(!b.fromUser && b.lang === 'json' && b.content.includes('"action"')){
    return '';
  }
  if(b.lang === 'export_file'){
    return '';
  }
  if (b.evicted) {
    const _fn = b.filename || 'fichier';
    return `<div class="nps-fcard" style="cursor:default;margin-top:8px"><div class="nps-fcard-row">${npsFileIcon(_fn,{})}<div class="nps-fcard-info"><div class="nps-fcard-name">${esc(_fn)}</div><div class="nps-fcard-meta">${esc(npsTypeLabel(_fn, b.lang))} · ${formatBytes(b.evictedSize||0)} · non conservé après rechargement</div></div></div></div>`;
  }
  if (!b.fromUser && isNoiseCode(b.content, b.lang)) {
    return `<div style="margin-top:8px;border-radius:12px;background:var(--bg2);border:1px solid var(--border);padding:12px 14px;color:var(--text2);font-size:15.5px;">Un bloc de code généré semblait corrompu ou tronqué — bloqué, non affiché.</div>`;
  }

  const ext = getFileExtension(b.lang);
  const fileName = b.filename || inferArtifactName(b, ext);
  const isHtml = /html|svg/i.test(b.lang||'') || /<!DOCTYPE html|<html[\s>]/i.test(b.content);
  const rKind = npsRenderKind(fileName, b.lang, b.content);
  const renderable = rKind !== 'text'; // html, svg, markdown, json, csv, tsv : un vrai rendu existe
  // Conteneur vide : l'iframe reelle est creee/detruite dynamiquement par
  // toggleArtifactView, jamais reutilisee, pour eviter tout etat residuel
  // (navigation, JS, audio) d'un apercu precedent.
  const previewFrame = `<div id="preview-${id}" style="display:none;width:100%;"></div>`;

  // Bloc binaire réel (image/pdf/zip/apk... exporté depuis GitHub) : le
  // contenu est une Data URL intacte, pas du texte à afficher tel quel.
  // Téléchargement dédié qui reconvertit proprement le base64 en Blob —
  // jamais via un textContent, qui corromprait les octets.
  if (b.isRemoteFile && b.remote) return npsRemoteCardHtml(b);
  if (b.isBinaryDataUrl) {
    const isImg = /^data:image\//.test(b.content) || /\.(png|jpe?g|gif|webp|svg)$/i.test(fileName);
    const isVid = /^data:video\//.test(b.content) || /\.(mp4|webm|mov|mkv)$/i.test(fileName);
    const isAud = /^data:audio\//.test(b.content) || /\.(mp3|wav|ogg|m4a)$/i.test(fileName);
    const previewImg = isImg ? `<div style="padding:0 12px 12px;"><img src="${b.content}" style="max-width:100%;border-radius:8px;display:block;cursor:zoom-in;" onclick="event.stopPropagation();openLightbox(this.src)"/></div>` : '';
    const previewVid = isVid ? `<div style="padding:0 12px 12px;">${npsVideoCard(b.content, fileName)}</div>` : '';
    const previewAud = isAud ? `<div style="padding:0 12px 12px;"><audio controls src="${b.content}" style="width:100%;display:block;"></audio></div>` : '';
    const icon = npsFileIcon(fileName,{mime:((/^data:([^;,]+)/.exec(b.content)||[])[1]||'')});
    const label = isVid ? 'fichier vidéo' : (isImg ? 'image' : (isAud ? 'fichier audio' : 'fichier binaire'));
    const binTap = (!isImg && !isVid && !isAud) ? `onclick="toggleBinaryPreview('${id}','${esc(fileName)}')" style="cursor:pointer;padding:10px 12px;display:flex;align-items:center;gap:10px;"` : `style="padding:10px 12px;display:flex;align-items:center;gap:10px;"`;
    return `<div style="margin-top:8px;border-radius:12px;background:var(--bg2);border:1px solid var(--border);overflow:hidden">
      <div ${binTap}>
        <div style="display:flex;align-items:center;">${icon}</div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:15.5px;font-weight:600;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(fileName)}</div>
          <div style="font-size:13.5px;color:var(--text2);margin-top:2px;">${esc(npsTypeLabel(fileName, b.lang))} · ${(/^data:[^,]*,/.test(b.content) ? formatBytes(Math.round((b.content.length - b.content.indexOf(',') - 1) * 0.75)) : label)}</div>
        </div>
        <button onclick="event.stopPropagation();downloadBinaryDataUrl('${id}','${esc(fileName)}')" style="background:none;border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:14.5px;padding:6px 10px;cursor:pointer;display:flex;align-items:center;gap:6px;"><svg class="nps-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Télécharger</button>
      </div>
      ${previewImg}
      ${previewVid}
      ${previewAud}
      <div id="preview-${id}" style="display:none;width:100%;"></div>
      <span id="${id}" style="display:none">${esc(b.content)}</span>
    </div>`;
  }

  const menuItems = [
    renderable ? `<button onclick="toggleArtifactView('${id}','preview');toggleFileMenu('${id}')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;"><svg class="nps-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg> Aperçu</button>` : '',
    `<button onclick="toggleArtifactView('${id}','code');toggleFileMenu('${id}')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;">&lt;/&gt; Voir le code</button>`,
    `<button onclick="copyCode('${id}');toggleFileMenu('${id}')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;"><svg class="nps-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copier</button>`,
    `<button onclick="downloadCode('${id}','${fileName}');toggleFileMenu('${id}')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;"><svg class="nps-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Télécharger</button>`,
    `<button onclick="downloadAsPDF('${id}','${fileName}');toggleFileMenu('${id}')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;"><svg class="nps-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg> Télécharger en PDF</button>`,
    `<button onclick="shareArtifact('${id}','${esc(fileName)}');toggleFileMenu('${id}')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg> Partager</button>`,
    (isHtml && !b.fromUser) ? `<button onclick="deployToGhPages('${id}','${fileName}');toggleFileMenu('${id}')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--accent);font-size:15.5px;font-weight:600;text-align:left;cursor:pointer;border-top:1px solid var(--border);"><svg class="nps-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg> Déployer sur GitHub Pages</button>` : '',
  ].filter(Boolean).join('');

  return `<div style="margin-top:8px;border-radius:12px;background:var(--bg2);border:1px solid var(--border);overflow:hidden">
    <div onclick="primaryOpenArtifact('${id}',${renderable})" style="padding:10px 12px;display:flex;align-items:center;gap:10px;cursor:pointer;">
      <div style="display:flex;align-items:center;">${npsFileIcon(fileName,{lang:b.lang})}</div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:15.5px;font-weight:600;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(fileName)}</div>
        <div style="font-size:13.5px;color:var(--text2);margin-top:2px;">${esc(npsTypeLabel(fileName, b.lang))} · ${formatBytes(b.size || b.content.length)}</div>
      </div>
      <div class="nps-file-menu-wrap" style="position:relative;flex-shrink:0;">
        <button onclick="event.stopPropagation();toggleFileMenu('${id}', this)" style="background:none;border:none;color:var(--text2);cursor:pointer;padding:4px 8px;line-height:1;display:flex;align-items:center;justify-content:center;"><svg style="width:18px;height:18px;flex-shrink:0" viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg></button>
        <div id="filemenu-${id}" class="nps-file-menu" style="display:none;position:fixed;background:var(--bg3);border:1px solid var(--border);border-radius:10px;min-width:210px;max-width:calc(100vw - 16px);z-index:9999;overflow:hidden;box-shadow:0 6px 20px rgba(0,0,0,.5);" onclick="event.stopPropagation()">
          ${menuItems}
        </div>
      </div>
    </div>
    ${previewFrame}
    <div id="${id}" class="code-block" data-fname="${esc(fileName)}" data-lang="${esc(b.lang||'')}" style="display:none;padding:12px;font-family:var(--font-mono);font-size:14.5px;overflow-x:auto;white-space:pre-wrap;color:var(--text);border-top:1px solid var(--border);">${highlightCode(b.content, b.lang||'')}</div>
  </div>`;
}

// Reconvertit proprement une Data URL (base64) en Blob réel pour un
// téléchargement direct — jamais via un Blob([texte]), qui corromprait
// les octets d'un fichier binaire (image, pdf, zip, apk...).
function downloadBinaryDataUrl(id, filename) {
  const el = document.getElementById(id);
  if (!el) return;
  const dataUrl = el.textContent;
  try {
    const [meta, b64] = dataUrl.split(',');
    const mime = (/data:(.*?);base64/.exec(meta) || [,'application/octet-stream'])[1];
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    toast('Fichier téléchargé');
  } catch(e) {
    toast('Échec du téléchargement (fichier corrompu)', true);
  }
}

function primaryOpenArtifact(id, renderable){
  toggleArtifactView(id, renderable ? 'preview' : 'code');
}

function logoMiniSVG(){
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" style="width:26px;height:26px">
    <circle cx="100" cy="100" r="58" style="stroke:#9b6cf0;fill:none;stroke-width:5;stroke-dasharray:8 12"/>
    <circle cx="100" cy="100" r="46" style="fill:#0b0d12"/>
    <text x="100" y="103" style="font-family:sans-serif;font-size:38px;font-weight:900;fill:#9b6cf0;text-anchor:middle;dominant-baseline:central">N</text>
  </svg>`;
}

/**
 * Sauvegarde un contenu volumineux dans le dépôt de travail GitHub de
 * l'utilisateur, en public (minutes/stockage illimités côté GitHub),
 * et renvoie le chemin du fichier créé. Crée le dépôt s'il n'existe pas.
 */
async function saveOverflowToGitHub(filename, content) {
  const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' };
  const userRes = await fetch('https://api.github.com/user', { headers });
  if (!userRes.ok) throw new Error('Token GitHub invalide (' + userRes.status + ')');
  const owner = (await userRes.json()).login;
  const repo = 'MyBot';

  const repoCheck = await fetch(`https://api.github.com/repos/${owner}/${repo}`, { headers });
  if (repoCheck.status === 404) {
    await fetch('https://api.github.com/user/repos', {
      method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: repo, private: false, description: "Espace de travail de l'agent Fable Fast", auto_init: true })
    });
    await sleep(1500);
  }

  const safeName = filename.replace(/[^a-zA-Z0-9.\-_]/g, '_');
  const path = `${npsMD()}envoyes/${Date.now()}-${safeName}`;
  const putRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
    method: 'PUT', headers: { ...headers, 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: `Ajout de ${safeName} (fichier volumineux)`, content: utob(content) })
  });
  if (!putRes.ok) throw new Error('Échec de la sauvegarde GitHub (' + putRes.status + ')');
  return `${owner}/${repo}/${path}`;
}
