// ═══════ CONTRÔLE LOCAL DES API (avant toute action) ═══════
// L'application teste elle-même les API configurées (appels réels, réponses
// affichées) AVANT que l'agent ne les utilise : l'IA sait alors, avec certitude,
// si GitHub / Jina sont utilisables, au lieu de le deviner après un échec.
async function npsTestApisUI() {
  toast('Test des API en cours…');
  try {
    const chk = await npsApiCheck(true);
    showManualCopy(npsFormatApiCheck(chk), 'Contrôle des API');
  } catch (e) { toast('Test impossible : ' + e.message, true); }
}

async function npsTimedFetch(url, opts, ms) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms || 8000);
  try { return await fetch(url, { ...(opts || {}), signal: c.signal }); }
  finally { clearTimeout(t); }
}
async function npsCheckGithub() {
  if (!S.tok) return { id: 'github', label: 'GitHub', state: 'missing', http: 0, detail: 'aucun token configuré (Paramètres → GitHub)' };
  try {
    const r = await npsTimedFetch('https://api.github.com/user', { headers: { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' }, cache: 'no-store' }, 10000);
    if (r.status === 401) return { id: 'github', label: 'GitHub', state: 'invalid', http: 401, detail: 'token invalide, expiré ou révoqué' };
    if (r.status === 403 || r.status === 429) return { id: 'github', label: 'GitHub', state: 'forbidden', http: r.status, detail: 'accès refusé ou limite de requêtes GitHub atteinte' };
    if (!r.ok) return { id: 'github', label: 'GitHub', state: 'error', http: r.status, detail: 'réponse inattendue de GitHub' };
    const u = await r.json();
    const scopesHdr = r.headers.get('x-oauth-scopes');
    let detail = 'token valide, compte « ' + (u.login || '?') + ' »';
    let state = 'ok';
    if (scopesHdr !== null) {
      const sc = scopesHdr.split(',').map(x => x.trim()).filter(Boolean);
      const miss = ['repo', 'workflow'].filter(x => !sc.includes(x));
      detail += ' · permissions : ' + (sc.join(', ') || 'aucune');
      if (miss.length) { state = 'warn'; detail += ' · manque : ' + miss.join(', '); }
    }
    return { id: 'github', label: 'GitHub', state, http: 200, detail, login: u.login };
  } catch (e) {
    return { id: 'github', label: 'GitHub', state: 'unreachable', http: 0, detail: 'api.github.com injoignable depuis le navigateur (' + (e.name === 'AbortError' ? 'délai de 10 s' : e.message) + ')' };
  }
}
async function npsCheckJina() {
  try {
    const r = await npsTimedFetch('https://r.jina.ai/https://example.com', { headers: { 'X-Return-Format': 'text' }, cache: 'no-store' }, 10000);
    if (r.ok) return { id: 'jina', label: 'Jina Reader', state: 'ok', http: r.status, detail: 'lecture de pages disponible' };
    if (r.status === 429) return { id: 'jina', label: 'Jina Reader', state: 'forbidden', http: 429, detail: 'limite gratuite atteinte' };
    return { id: 'jina', label: 'Jina Reader', state: 'error', http: r.status, detail: 'réponse inattendue' };
  } catch (e) {
    return { id: 'jina', label: 'Jina Reader', state: 'unreachable', http: 0, detail: 'injoignable depuis le navigateur (' + (e.name === 'AbortError' ? 'délai de 10 s' : 'blocage CORS ou réseau') + ') — le terminal cloud peut encore lire les pages via curl' };
  }
}
async function npsApiCheck(force) {
  const key = S.tok || '';
  const c = S._apiCheckCache;
  if (!force && c && c.key === key && Date.now() - c.at < 60000) return { ...c, cached: true };
  const items = await Promise.all([npsCheckGithub(), npsCheckJina()]);
  S._apiCheckCache = { key, at: Date.now(), items };
  return { ...S._apiCheckCache, cached: false };
}
function npsApiStateMark(st) { return st === 'ok' ? '✓' : st === 'warn' ? '⚠' : '✗'; }
function npsFormatApiCheck(chk) {
  const t = new Date(chk.at).toLocaleTimeString('fr-FR');
  const lines = chk.items.map(it => `${npsApiStateMark(it.state)} ${it.label} — ${it.state === 'ok' || it.state === 'warn' ? 'OK' : 'ÉCHEC'}${it.http ? ' (HTTP ' + it.http + ')' : ''} : ${it.detail}`);
  return `[CONTRÔLE DES API — effectué par l'application à ${t}, appels réels]\n` + lines.join('\n');
}
// Détermine de quelles API l'action a besoin ; bloque UNIQUEMENT si une API
// indispensable est certainement inutilisable (token absent / invalide / refusé).
async function npsPreflightForTool(toolData, uiBMsg) {
  const a = toolData.action;
  const url = String((toolData.params && toolData.params.url) || '');
  const needsGithub = a === 'terminal_exec' || a === 'build_logs' || (a === 'api_call' && /github\.com/i.test(url));
  const touchesJina = a === 'web_fetch' || a === 'web_search';
  if (!needsGithub && !touchesJina) return { blocked: false };
  const _force = !!S._apiRecheck;
  if (_force) S._apiRecheck = false;
  else if ((S.turnLog || []).some(e => e.action === 'api_check' && e.ok)) return { blocked: false };
  const chk = await npsApiCheck(_force);
  const gh = chk.items.find(i => i.id === 'github');
  const jina = chk.items.find(i => i.id === 'jina');
  const ghDead = needsGithub && gh && ['missing', 'invalid', 'forbidden'].includes(gh.state);
  const text = npsFormatApiCheck(chk);
  if (!chk.cached || ghDead) {
    const allOk = chk.items.every(i => i.state === 'ok' || i.state === 'warn');
    const sum = chk.items.map(i => i.label + ' ' + npsApiStateMark(i.state)).join(' · ');
    uiBMsg.steps.push({
      id: 'step-check-' + uid(), name: 'Vérifié',
      summary: 'Contrôle des API : ' + sum,
      details: "Paramètres de l'action :\n" + JSON.stringify({ contrôle: 'api.check', api: chk.items.map(i => i.id) }, null, 2) + "\n\nRésultat de l'action :\n" + text,
      status: allOk ? 'done' : 'error'
    });
    updateMsgEl(uiBMsg);
  }
  (S.turnLog = S.turnLog || []).push({
    action: 'api_check', key: '', ok: !ghDead,
    label: 'Contrôle des API (' + chk.items.map(i => i.label + ' ' + npsApiStateMark(i.state)).join(' · ') + ')',
    summary: ghDead ? 'bloquant' : 'déjà vérifié, ne pas relancer'
  });
  if (ghDead) {
    const fix = gh.state === 'forbidden'
      ? "GitHub refuse l'accès ou la limite de requêtes est atteinte : attends un peu, ne relance pas en boucle."
      : "Le token GitHub n'est pas utilisable : l'utilisateur doit en saisir un valide dans Paramètres → GitHub (permissions repo + workflow).";
    return { blocked: true, result: `❌ ACTION NON LANCÉE : le contrôle des API fait par l'application avant l'exécution a échoué.\n\n${text}\n\n[DIAGNOSTIC CERTAIN] ${fix} Inutile de relancer ${a} tant que cela n'est pas réglé.${a === 'terminal_exec' && jina && jina.state === 'ok' ? " Pour simplement lire une page web, utilise web_fetch (ne dépend pas de GitHub)." : ''} Explique clairement le problème à l'utilisateur.` };
  }
  return { blocked: false, text };
}


async function executeTool(toolData, onProgress, uiBMsg) {
  const _r = await executeToolInner(toolData, onProgress, uiBMsg);
  try {
    if (window.ffMode && ['terminal_exec','web_fetch','api_call','web_search','extract_site'].includes(toolData && toolData.action)) {
      const t = typeof _r === 'string' ? _r : JSON.stringify(_r || '');
      (window.__ffTool = window.__ffTool || []).push(String(t).slice(0, 300000));
    }
  } catch (e) {}
  return _r;
}
async function executeToolInner(toolData, onProgress, uiBMsg) {
  lastToolSources = [];
  { const _g = npsModeGate(toolData); if (_g) return _g; }
  if (toolData.action === 'api_call') {
    try {
      let targetUrl = toolData.params.url || '';
      if (targetUrl.includes('api.github.com/users/') && targetUrl.endsWith('/repos')) {
         console.log("Redirecting GitHub repos list call for full multi-repository access...");
         targetUrl = 'https://api.github.com/user/repos?per_page=100&affiliation=owner,collaborator,organization_member';
      }
      const headers = { ...S.globalHeaders, ...(toolData.params.headers || {}) };
      if (targetUrl.includes('github.com') && S.tok) {
          headers['Authorization'] = 'Bearer ' + S.tok;
          headers['Accept'] = 'application/vnd.github.v3+json';
      }
      if (targetUrl.includes('api.github.com') && !targetUrl.includes('per_page=')) {
          if (targetUrl.includes('?')) targetUrl += '&per_page=100';
          else targetUrl += '?per_page=100';
      }
      // GARDE-FOU DUR — jamais contournable par le modèle : toute opération
      // destructrice (DELETE, ou PUT/PATCH qui écrase un fichier existant)
      // sur l'API GitHub doit être confirmée par un vrai humain, via une
      // vraie boîte de dialogue bloquante. Le prompt système ne suffit pas —
      // un modèle peut mal interpréter une demande ("cherche", "nettoie") et
      // agir quand même ; ceci est la seule protection qui ne dépend pas de
      // son interprétation.
      const methodUpper = (toolData.params.method || 'GET').toUpperCase();
      if (targetUrl.includes('api.github.com') && methodUpper === 'DELETE') {
        const confirmed = window.confirm(
          `⚠️ Fable Fast veut SUPPRIMER quelque chose sur GitHub, action définitive :\n\n${targetUrl}\n\nAutoriser cette suppression ?`
        );
        if (!confirmed) {
          return { error: "Suppression bloquée : l'utilisateur n'a PAS confirmé cette action destructrice. N'insiste pas et ne retente pas cette suppression — explique-le à l'utilisateur et attends une instruction explicite et non-ambiguë de sa part avant de reproposer quoi que ce soit de destructeur." };
        }
      }
let res = await fetch(targetUrl, {
        method: toolData.params.method || 'GET',
        headers: headers,
        body: toolData.params.body ? (typeof toolData.params.body === 'string' ? toolData.params.body : JSON.stringify(toolData.params.body)) : undefined
      });
      let text = await res.text();
      let allRepos = [];
      let status = res.status;
      
      try {
        if (targetUrl.includes('api.github.com/user/repos') && res.ok) {
            let parsed = JSON.parse(text);
            if (Array.isArray(parsed)) {
                allRepos = allRepos.concat(parsed);
                // Handle basic pagination for user repos (up to 3 pages)
                let linkHeader = res.headers.get('link');
                let pageCount = 1;
                while (linkHeader && linkHeader.includes('rel="next"') && pageCount < 3) {
                    const match = linkHeader.match(/<([^>]+)>;\s*rel="next"/);
                    if (match && match[1]) {
                        const nextUrl = match[1];
                        const nextRes = await fetch(nextUrl, { headers: headers });
                        if (nextRes.ok) {
                            const nextText = await nextRes.text();
                            const nextParsed = JSON.parse(nextText);
                            if (Array.isArray(nextParsed)) allRepos = allRepos.concat(nextParsed);
                        }
                        linkHeader = nextRes.headers.get('link');
                        pageCount++;
                    } else {
                        break;
                    }
                }
                const simplified = allRepos.map(r => ({name: r.name, private: r.private, url: r.html_url, desc: (r.description || '').substring(0, 30)}));
                text = JSON.stringify({
                  total_count: simplified.length,
                  note: pageCount >= 3 ? "List truncated to first 300 repos." : "All repos fetched.",
                  repos: simplified
                });
            }
        }
      } catch (e) {
         console.error("Pagination error", e);
      }
      // Gemini (et la plupart des modèles utilisés ici) ont un TRÈS grand
      // contexte — 20 000 caractères pour relire un résultat d'outil était
      // une limite arbitrairement basse qui empêchait de vérifier de vrais
      // gros fichiers, forçant le modèle à s'autolimiter par prudence.
      // Relevé à 150 000 caractères pour lui laisser une vraie marge de
      // vérification sur des fichiers volumineux.
      // Ni 20 000 ni un autre chiffre inventé par l'app n'a de sens ici :
      // Gemini (et les autres modèles) connaissent déjà leur propre limite
      // réelle de contexte — ce n'est pas à l'application de la deviner ou
      // de la fixer à sa place. Le seul filet de sécurité qui reste ici est
      // purement technique (éviter qu'une réponse absurdement énorme, ex:
      // plusieurs Mo, ne fasse planter le navigateur/la mémoire de l'app) —
      // fixé très haut, volontairement, pour ne quasiment jamais se
      // déclencher en usage réel. Si un modèle atteint un jour sa vraie
      // limite de contexte, c'est SON API qui renverra une vraie erreur
      // explicite (ex: "context length exceeded"), pas cette app qui doit
      // deviner un plafond à sa place.
      if (text.length > 2000000) text = text.slice(0, 2000000) + '\n\n[... coupé ici : réponse anormalement volumineuse (>2 Mo), protection mémoire du navigateur, pas une limite du modèle ...]';

      // VÉRIFICATION RÉELLE après une écriture de fichier GitHub (PUT/POST sur /contents/).
      // On ne se contente JAMAIS d'un statut 200 : on relit le fichier et on compare
      // le contenu décodé à ce qui a été envoyé, pour détecter toute corruption
      // (base64 mal formé, troncature, caractères parasites, etc.) avant de dire "réussi".
      let verificationNote = '';
      const isContentsWrite = (toolData.params.method === 'PUT' || toolData.params.method === 'POST') && targetUrl.includes('/contents/');
      if (isContentsWrite && res.ok) {
        try {
          const sentBody = typeof toolData.params.body === 'string' ? JSON.parse(toolData.params.body) : toolData.params.body;
          const sentB64 = sentBody && sentBody.content;
          if (sentB64) {
            const intendedContent = btou(sentB64.replace(/\s/g, ''));
            const readUrl = targetUrl.split('?')[0] + '?ref=' + (sentBody.branch || 'main') + '&_=' + Date.now();
            const verifyRes = await fetch(readUrl, { headers, cache: 'no-store' });
            if (verifyRes.ok) {
              const verifyJson = JSON.parse(await verifyRes.text());
              const storedContent = btou((verifyJson.content || '').replace(/\s/g, ''));
              if (storedContent === intendedContent) {
                verificationNote = `\n\n✅ VÉRIFICATION RÉELLE EFFECTUÉE : le fichier a été relu depuis GitHub après écriture, son contenu décodé correspond EXACTEMENT à ce qui devait être écrit (${storedContent.length} caractères). Aucune corruption.`;
              } else {
                verificationNote = `\n\n🚨 VÉRIFICATION ÉCHOUÉE : le contenu relu sur GitHub NE correspond PAS à ce qui a été envoyé (attendu ${intendedContent.length} caractères, trouvé ${storedContent.length} caractères). Le fichier est probablement corrompu ou tronqué. NE DÉCLARE PAS que cette écriture a réussi — ré-analyse le contenu décodé et recommence l'écriture avec un encodage correct avant de continuer.`;
              }
            } else {
              verificationNote = `\n\n⚠️ Impossible de relire le fichier pour vérification (statut ${verifyRes.status}). Ne suppose pas que l'écriture a réussi tant que tu n'as pas confirmé.`;
            }
          }
        } catch (verifyErr) {
          verificationNote = `\n\n⚠️ Vérification du contenu impossible (${verifyErr.message}). Ne déclare pas de succès sans confirmation.`;
        }
      }

      if (!res.ok) {
        let apiDiag = `[DIAGNOSTIC API HTTP ${res.status}] `;
        if (res.status === 401) apiDiag += "Token GitHub non autorisé ou expiré (401 Unauthorized).";
        else if (res.status === 403) apiDiag += "Accès interdit (403 Forbidden) : permissions de token insuffisantes ou quota atteint.";
        else if (res.status === 404) apiDiag += "Ressource introuvable (404 Not Found). Vérifie l'URL et le dépôt.";
        else if (res.status === 422) apiDiag += "Corps de requête invalide (422 Unprocessable Entity). Vérifie les champs du corps JSON.";
        else apiDiag += `Erreur HTTP ${res.status}.`;
        return `❌ ÉCHEC api_call (Status: ${res.status}) :\n\n${text}${verificationNote}\n\n${apiDiag}`;
      }

      return `Status: ${res.status}\n\n${text}${verificationNote}`;
    } catch (e) {
      // Le navigateur ne peut pas joindre certaines adresses (CORS / réseau). On ne lance plus de terminal en cachette :
      // c'est l'IA qui décide, avec une étape visible, en suivant la recette du prompt.
      return "❌ ERREUR api_call : " + e.message + "\n\n[DIAGNOSTIC] : le navigateur n'a pas pu joindre cette adresse (blocage CORS ou réseau). Pour lire une page web, utilise web_fetch ; s'il échoue aussi, utilise terminal_exec avec la recette curl exacte du prompt (https://r.jina.ai/ suivi de l'URL complète).";
    }
  }
  if (toolData.action === 'web_fetch') {
    // Le modèle ajoute parfois lui-même « r.jina.ai/ » devant l'URL : on l'enlève, l'app le fait déjà.
    let fetchUrl = String(toolData.params.url || '').trim();
    while (/^(?:https?:\/\/)?r\.jina\.ai\//i.test(fetchUrl)) fetchUrl = fetchUrl.replace(/^(?:https?:\/\/)?r\.jina\.ai\//i, '');
    if (!/^https?:\/\//i.test(fetchUrl)) fetchUrl = 'https://' + fetchUrl;
    toolData.params.url = fetchUrl;
    if (S._fetchCache && S._fetchCache[fetchUrl] && (parseInt(toolData.params.offset, 10) || 0) > 0) {
      return npsFetchChunkResult(fetchUrl, S._fetchCache[fetchUrl], toolData.params); // suite d'un document déjà chargé : pas de nouvelle requête
    }
    try {
      let res = null;
      for (let attempt = 0; attempt < 2; attempt++) {
        res = await fetch('https://r.jina.ai/' + toolData.params.url, { headers: { 'X-Return-Format': 'markdown' } });
        if (res.ok || ![429, 500, 502, 503, 504].includes(res.status)) break;
        await sleep(1500);
      }
      if (!res.ok) {
        const errBody = (await res.text().catch(() => '')).replace(/\s+/g, ' ').slice(0, 120);
        throw new Error('Jina HTTP ' + res.status + (errBody ? ' « ' + errBody + ' »' : ''));
      }
      let text = await res.text();
      lastToolSources.push({ title: toolData.params.url, url: toolData.params.url, snippet: text.replace(/\s+/g,' ').trim().slice(0, 220) });
      (S._fetchCache = S._fetchCache || {})[toolData.params.url] = text;
      return npsFetchChunkResult(toolData.params.url, text, toolData.params);
    } catch (e2) {
      try {
        const proxyUrl = 'https://api.allorigins.win/get?url=' + encodeURIComponent(toolData.params.url);
        const res = await fetch(proxyUrl);
        const rawProxy = await res.text();
        let data;
        try { data = JSON.parse(rawProxy); }
        catch (pe) { throw new Error('proxy de secours : réponse non JSON (HTTP ' + res.status + ') « ' + rawProxy.slice(0, 60).replace(/\s+/g, ' ') + ' »'); }
        if (!data.contents) throw new Error("Aucun contenu retourné");
        const doc = new DOMParser().parseFromString(data.contents, 'text/html');
        let text = doc.body.innerText.replace(/\s+/g, ' ').trim();
        if (text.length > 5000) text = text.slice(0, 5000) + '... (tronqué)';
        return `Contenu brut extrait de ${toolData.params.url} (mode fallback) :\n\n${text}`;
      } catch(e3) {
        return `❌ ÉCHEC web_fetch : Impossible d'accéder à l'URL "${toolData.params.url}" (Jina : ${e2.message} · ${e3.message}).\n\n[DIAGNOSTIC] : Le navigateur est bloqué (CORS ou réseau), mais pas le terminal cloud. Lance maintenant EXACTEMENT cette action, sans rien changer d'autre :\n{"action":"terminal_exec","status":"Lecture de la page via Jina","params":{"code":"curl -sL --max-time 30 'https://r.jina.ai/${String(toolData.params.url).replace(/'/g, "'\\\\''")}'","repo":"MyBot"}}\nSi cette commande échoue aussi, explique le blocage à l'utilisateur.`;
      }
    }
  }
  if (toolData.action === 'web_search') {
    try {
      const { results, raw } = await performWebSearch(toolData.params.query);
      lastToolSources = results;
      if (!results.length) throw new Error("Aucun résultat");
      let text = raw && raw.length > 8000 ? raw.slice(0, 8000) + '\n\n... (tronqué)' : raw;
      return `Résultats de la recherche pour "${toolData.params.query}" (via Jina Search) :\n\n${text}`;
    } catch (e1) {
      return `❌ ÉCHEC web_search : ${e1.message}.\n\n[DIAGNOSTIC AUTOMATIQUE] : La recherche n'a retourné aucun résultat ou le service est indisponible.`;
    }
  }
    if (toolData.action === 'generate_qr') {
    const text = encodeURIComponent(toolData.params.text || '');
    return 'Voici le QR Code généré:\n\n![QR Code](https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' + text + ')';
  }
  if (toolData.action === 'generate_mp3') {
    const fullText = (toolData.params.text || '').trim();
    const lang = toolData.params.lang || 'fr';
    if (!fullText) return "Erreur : aucun texte fourni à synthétiser.";
    const audioUrl = '/api/tts?tl=' + encodeURIComponent(lang) + '&q=' + encodeURIComponent(fullText.slice(0, 3000));
    return 'Audio généré avec succès. Donne simplement ce lien à l\'utilisateur dans ta réponse (texte brut, JAMAIS de balise HTML) :\n' + audioUrl + '\nL\'application affichera automatiquement un lecteur audio MP3 fluide et sans coupure.';
  }
  if (toolData.action === 'transcribe_audio') {
    if (!S.oai) {
      return "Erreur: Une clé API OpenAI valide (à configurer dans les paramètres) est requise pour utiliser la transcription audio Whisper.";
    }
    const audioFile = S.attachments.find(a => a.type && a.type.startsWith('audio/'));
    if (!audioFile || !audioFile.file) {
      return "Erreur: L'utilisateur n'a joint aucun fichier audio à transcrire. Demande-lui d'attacher un fichier audio (MP3, WAV, etc.).";
    }
    try {
      const formData = new FormData();
      formData.append("file", audioFile.file);
      formData.append("model", "whisper-1");
      const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
          method: "POST",
          headers: { "Authorization": "Bearer " + S.oai },
          body: formData
      });
      if (!res.ok) throw new Error("API Error " + res.status);
      const data = await res.json();
      return "Transcription réussie:\n" + data.text;
    } catch (e) {
      return "Erreur lors de la transcription: " + e.message;
    }
  }
  if (toolData.action === 'run_code') {
    try {
      const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
      const func = new AsyncFunction(toolData.params.code);
      const result = await func();
      return "Résultat de l'exécution JS :\n" + (typeof result === 'object' ? JSON.stringify(result, null, 2) : String(result));
    } catch(e) {
      return "Erreur d'exécution JS :\n" + e.message;
    }
  }
  if (toolData.action === 'search_conversations') {
    // Permet à Fable Fast de retrouver lui-même une conversation passée (dépôt
    // GitHub "Maker"), au lieu de dépendre de S.convs (qui ne
    // contient que ce qui a déjà été chargé côté app). On liste TOUS les
    // fichiers historique/*.json réels sur le dépôt, on filtre par mot-
    // clé sur le titre si fourni, et si un id précis est donné, on va
    // chercher son contenu complet réel.
    if (!S.tok) return "Erreur : la recherche de conversations nécessite un token GitHub configuré (Paramètres → GitHub).";
    try {
      const owner = await getGhLogin();
      if (!owner) return "Erreur : impossible de déterminer le compte GitHub (token invalide).";
      const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' };
      const id = (toolData.params && toolData.params.id || '').trim();

      if (id) {
        const msgs = await loadConvFromGitHub(id);
        if (!msgs) return `Aucune conversation trouvée avec l'id "${id}" sur le dépôt Maker.`;
        const text = msgs.map(m => `[${m.role}] ${(m.text||'').slice(0,1500)}`).join('\n\n');
        return `Contenu réel de la conversation "${id}" (${msgs.length} message(s)) :\n\n${text.slice(0, 7000)}`;
      }

      const query = (toolData.params && toolData.params.query || '').trim().toLowerCase();
      const listRes = await fetch(`https://api.github.com/repos/${owner}/Maker/contents/${npsP(window.ffMode || 'download', 'historique')}`, { headers });
      if (!listRes.ok) return "Aucune conversation trouvée (dépôt ou dossier historique/ inexistant).";
      const files = await listRes.json();
      if (!Array.isArray(files) || !files.length) return "Aucune conversation sauvegardée trouvée sur Maker.";

      // On récupère les métadonnées (titre) de chaque fichier pour permettre
      // une vraie recherche par mot-clé, pas juste lister les noms de fichiers.
      const chunks = [];
      for (let i = 0; i < files.length; i += 10) chunks.push(files.slice(i, i + 10));
      const results = [];
      for (const chunk of chunks) {
        await Promise.all(chunk.map(async (file) => {
          try {
            const fileRes = await fetch(file.url, { headers });
            if (!fileRes.ok) return;
            const fileData = await fileRes.json();
            const payload = JSON.parse(btou(fileData.content.replace(/\s/g, '')));
            const title = payload.title || 'Conversation';
            if (!query || title.toLowerCase().includes(query)) {
              results.push({ id: payload.id || file.name.replace('.json',''), title, ts: payload.ts || null, count: (payload.msgs||[]).length });
            }
          } catch(e) { /* fichier corrompu, ignoré */ }
        }));
      }
      if (!results.length) return `Aucune conversation ne correspond à "${query}".`;
      results.sort((a,b) => new Date(b.ts||0) - new Date(a.ts||0));
      const list = results.slice(0, 30).map(r => `- id="${r.id}" | "${r.title}" | ${r.count} message(s) | ${r.ts ? new Date(r.ts).toLocaleString() : 'date inconnue'}`).join('\n');
      return `${results.length} conversation(s) trouvée(s) :\n${list}\n\nPour lire le contenu complet réel d'une conversation précise, relance "search_conversations" avec son "id" exact ci-dessus.`;
    } catch(e) {
      return "Erreur lors de la recherche de conversations : " + e.message;
    }
  }
  
  if (toolData.action === 'export_file') {
    if (!S.tok) return "Erreur : export_file nécessite un token GitHub configuré (Paramètres → GitHub).";
    try {
      const owner = await getGhLogin();
      const repo = (toolData.params?.repo || 'MyBot').trim();
      const path = (toolData.params?.path || '').trim();
      if (!path) return "Erreur : paramètre 'path' manquant pour export_file.";
      
      const binInfo = binaryFileInfo(path);
      const isVid = binInfo && binInfo.isVideo;
      const isImg = binInfo && binInfo.isImage;

      // Archives et gros fichiers : carte dans le chat, téléchargement à la demande (jamais chargés en mémoire)
      if (binInfo && !isImg && !isVid) {
        let meta = null;
        try { meta = await npsGhMeta(repo, path); } catch (me) { return `❌ ÉCHEC export_file : ${me.message}\n\n[DIAGNOSTIC AUTOMATIQUE : FICHIER MANQUANT]\nLe fichier n'existe pas sur GitHub (${repo}/${path}). Ne confirme pas la réussite à l'utilisateur.`; }
        if (meta.size === 0) return `❌ ÉCHEC export_file : le fichier "${path}" fait 0 octet.\n\n[DIAGNOSTIC AUTOMATIQUE : CONTENU VIDE]`;
        if (NPS_ARCHIVE_RE.test(path) || meta.size > 20 * 1048576) {
          npsAddRemoteCard(uiBMsg, repo, path, meta);
          updateMsgEl(uiBMsg);
          return "Succès : le fichier \"" + path + "\" (" + formatBytes(meta.size) + ") est vérifié et livré dans le chat sous forme de carte avec bouton de téléchargement.";
        }
      }

      // 1. Récupération réelle du fichier avec vérification d'existence et de taille > 0
      let content;
      try {
        content = await fetchGitHubFileContent(repo, path, { binary: !!binInfo, mime: binInfo?.mime });
      } catch(fetchErr) {
        return `❌ ÉCHEC export_file : ${fetchErr.message}\n→ Le fichier n'existe pas ou fait 0 octet sur GitHub (${repo}/${path}).\n\n[DIAGNOSTIC AUTOMATIQUE : FICHIER MANQUANT OU VIDE]\nLe script ou la commande précédente n'a pas produit le fichier attendu. Vérifie avec "ls -lh ${path}" dans le terminal. Interdiction de prétendre que le fichier est disponible tant qu'il n'existe pas réellement.`;
      }

      if (!content) {
        return `❌ ÉCHEC export_file : Le contenu du fichier "${path}" est vide (0 octet).\n\n[DIAGNOSTIC AUTOMATIQUE : CONTENU VIDE]\nLe téléchargement ou la conversion a échoué silencieusement. Ne confirme pas la réussite à l'utilisateur.`;
      }

      // 2. Enregistrement direct et vérifié dans Maker (dans exports/ ET dans envoyes/)
      const saved = await saveExportToNpsMemory(path, content);
      if (!saved) {
        return `⚠️ Avertissement : Le fichier a été extrait mais n'a pas pu être dupliqué dans Maker. Vérifie les permissions d'écriture du token GitHub.`;
      }

      // 3. Affichage unique dans le chat (lecteur dédié, zéro doublon)
      if (isVid) {
        uiBMsg.video = content;
        uiBMsg.videoRef = { path: npsExportPath(path), mime: binInfo.mime, name: path.split('/').pop() };
      } else if (isImg) {
        uiBMsg.image = content;
        uiBMsg.imageRef = { path: npsExportPath(path), mime: binInfo.mime, name: path.split('/').pop() };
      } else if (binInfo) {
        uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
        const fname = path.split('/').pop();
        if (!uiBMsg.codeBlocks.some(b => b.filename === fname)) {
          uiBMsg.codeBlocks.push({ lang: binInfo.ext, content, filename: fname, isBinaryDataUrl: true });
        }
      } else {
        uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
        const fname = path.split('/').pop();
        const ext = path.split('.').pop() || 'txt';
        if (!uiBMsg.codeBlocks.some(b => b.filename === fname)) {
          uiBMsg.codeBlocks.push({ lang: ext, content, filename: fname });
        }
      }
      updateMsgEl(uiBMsg);

      return "Succès : le fichier \"" + path + "\" a été vérifié, exporté et sauvegardé dans Maker (dossiers exports/ et envoyes/)." + (isVid ? " Le lecteur vidéo est maintenant prêt dans l'interface." : " Le fichier est disponible et téléchargeable.");
    } catch(e) {
      return "Erreur lors de l'exportation du fichier : " + e.message;
    }
  }
  if (toolData.action === 'write_file') {
    // Écrit un contenu texte directement via l'API GitHub (Contents API), sans
    // passer par un terminal cloud : pas de shell, donc aucun risque de
    // guillemets cassés par une apostrophe, pas de runner à démarrer, pas
    // d'étape terminal_exec + ls/wc + export_file séparée. Réservé au contenu
    // que le modèle compose lui-même (HTML/CSS/JS/JSON/Markdown/texte) — pas
    // à une tâche qui nécessite une vraie exécution (calcul, traitement de
    // fichier binaire, téléchargement réel) : ça reste le rôle de terminal_exec.
    if (!S.tok) return "Erreur : write_file nécessite un token GitHub configuré (Paramètres → GitHub).";
    const path = (toolData.params?.path || '').trim();
    const content = toolData.params?.content;
    if (!path) return "Erreur : paramètre 'path' manquant pour write_file.";
    if (typeof content !== 'string' || !content.length) return "Erreur : paramètre 'content' manquant ou vide pour write_file. N'invente jamais un succès sans contenu réellement fourni.";
    try {
      const saved = await saveExportToNpsMemory(path, content);
      if (!saved) return `❌ ÉCHEC write_file : l'écriture dans Maker a échoué pour "${path}". Vérifie les permissions d'écriture du token GitHub (scope 'repo').`;

      const fname = path.split('/').pop();
      const ext = path.split('.').pop() || 'txt';
      uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
      if (!uiBMsg.codeBlocks.some(b => b.filename === fname)) {
        uiBMsg.codeBlocks.push({ lang: ext, content, filename: fname });
      }
      updateMsgEl(uiBMsg);
      return `Succès : le fichier "${path}" (${content.length} caractères) a été écrit directement via l'API et sauvegardé dans Maker (exports/ et envoyes/). Il est disponible et téléchargeable dans l'interface.`;
    } catch (e) {
      return "Erreur lors de l'écriture du fichier : " + e.message;
    }
  }
  if (toolData.action === 'set_alarm') {
    const promise = (toolData.params?.promise || toolData.params?.label || toolData.params?.task || '').trim();
    const status = (toolData.params?.status || 'active').trim().toLowerCase();
    if (!promise) return "Erreur : 'promise' ou 'label' requis.";
    const isCompleted = (status === 'completed' || status === 'done' || status === 'resolved');
    if (isCompleted) {
      return "✅ Engagement vérifié et validé pour : \"" + promise + "\". Tu peux maintenant certifier ce résultat à l'utilisateur.";
    } else {
      return "🔔 Engagement enregistré pour : \"" + promise + "\". Vérifie le résultat concret avant de clore.";
    }
  }

  if (toolData.action === 'terminal_exec') {
    if (!S.tok) return "Erreur : le terminal cloud nécessite un token GitHub configuré (Paramètres → GitHub).";
    try {
      const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' };
      const userRes = await fetch('https://api.github.com/user', { headers });
      if (!userRes.ok) throw new Error('Token GitHub invalide (' + userRes.status + ')');
      const owner = (await userRes.json()).login;
      const repo = toolData.params.repo || 'MyBot';

      const result = await runCloudTerminal(npsWithDeps(toolData.params.code), owner, repo, onProgress);
      const out = (result.output || '(aucune sortie)').slice(0, 8000);

      // Synchronisation automatique : si la commande écrit un fichier via
      // heredoc ("cat > x << 'EOF'" / "cat >> x << 'EOF'"), on retient ce
      // fichier pour aller le récupérer et l'afficher automatiquement dans
      // le chat une fois la tâche terminée — sans dépendre du modèle qui
      // doit se souvenir d'ajouter "export_file".
      // IMPORTANT : on ne conditionne plus ça à "exit_code === 0" — une
      // commande suivante dans la même chaine peut échouer (ex: un test ou
      // un push) alors que le fichier a bel et bien été écrit avant cet
      // échec. Le filtrer sur le code de sortie global perdait des fichiers
      // réellement présents sur le dépôt.
      {
        const code = toolData.params.code || '';
        const writeRe = /cat\s*>>?\s*['"]?([^\s'"<>]+)['"]?\s*<<-?\s*['"]?EOF['"]?/g;
        let m;
        S._pendingSync = S._pendingSync || [];
        while ((m = writeRe.exec(code))) {
          const path = m[1];
          const fname = path.split('/').pop().toLowerCase();
          if (fname === 'readme.md' || fname.startsWith('.git') || fname.endsWith('.part') || fname.endsWith('.tmp') || fname.endsWith('.ytdl')) continue;
          if (!S._pendingSync.some(p => p.repo === repo && p.path === path)) {
            S._pendingSync.push({ repo, path });
          }
        }
        // Fichiers produits par archivage / conversion (tar -czf x.tar.gz, zip x.zip, 7z a x.7z, mv a b, cp a b, > fichier)
        if (!/\b(unzip|tar\s+-?[a-z]*x|gunzip|7z\s+x)\b/.test(code)) {
          const outRe = /(?:^|[\s;&|>=])((?!https?:)[\w.\/-]+\.(?:tar\.gz|tgz|tar\.bz2|tar\.xz|tar|zip|7z|rar|apk|mp4|webm|mp3|wav|pdf|docx|xlsx|pptx))(?=[\s;&|'"]|$)/gi;
          let om;
          while ((om = outRe.exec(code))) {
            const path = om[1].replace(/^\.\//, '');
            const fname = path.split('/').pop().toLowerCase();
            if (fname.startsWith('.git')) continue;
            if (!S._pendingSync.some(p => p.repo === repo && p.path === path)) S._pendingSync.push({ repo, path });
          }
        }
        // Détection automatique des fichiers téléchargés ou générés (ex: yt-dlp -o video.mp4, curl -o out.mp4)
        const downloadRe = /(?:-o|-O|--output)\s+['"]?([^\s'"]+\.(?:mp4|webm|mp3|wav|png|jpe?g|gif|pdf|zip|tar\.gz|json|html|py|js|txt))['"]?/gi;
        while ((m = downloadRe.exec(code))) {
          const path = m[1].replace(/^\.\//, '');
          const fname = path.split('/').pop().toLowerCase();
          if (fname === 'readme.md' || fname.startsWith('.git') || fname.endsWith('.part') || fname.endsWith('.tmp') || fname.endsWith('.ytdl')) continue;
          if (!S._pendingSync.some(p => p.repo === repo && p.path === path)) {
            S._pendingSync.push({ repo, path });
          }
        }
      }

      if (result.exit_code !== 0 || !result.success) {
        const diag = diagnoseTerminalError(toolData.params.code, result.exit_code, out);
        return `❌ ÉCHEC DU TERMINAL CLOUD (Code de sortie: ${result.exit_code}) sur GitHub Actions (${owner}/${repo}) :\n\n${out}\n\n${diag}`;
      }

      if (/(^|\n)\s*(ERROR|Traceback|fatal:)|command not found|No such file or directory|Erreur de récupération|Unexpected response/i.test(String(out))) {
        return `⚠ COMMANDE TERMINÉE AVEC DES ERREURS (code 0 masqué par la commande) sur GitHub Actions (${owner}/${repo}) :\n\n${out}\n\n[DIAGNOSTIC AUTOMATIQUE] Cette commande a ÉCHOUÉ malgré le code 0. Corrige la cause (outil manquant → l'installer ; TikTok bloque → installer curl-cffi et utiliser --impersonate chrome, ou l'API oEmbed) et relance une seule fois avec une autre méthode, sans « || echo » qui masque l'erreur.`;
      }
      return `✓ SUCCÈS DU TERMINAL CLOUD (Code de sortie 0) sur GitHub Actions (${owner}/${repo}) :\n\n${out}`;
    } catch (e) {
      if (typeof onProgress === 'function') onProgress({ text: 'Exécution en erreur.', live: false, done: true, error: true });
      const isTimeout = /limite github atteinte|timed_out|timeout/i.test(e.message);
      if (isTimeout) {
        return `⏱️ ERREUR DE TIMEOUT DU TERMINAL CLOUD (limite GitHub) : ${e.message}\n\n[DIAGNOSTIC AUTOMATIQUE : TIMEOUT GITHUB]\nLa commande a dépassé la limite de GitHub Actions ou attendait une réponse interactive bloquante (ex: invite [y/N]).\n→ Action requise : Ne relance JAMAIS cette commande à l'identique. Si la tâche est trop lourde ou bloquée, informe l'utilisateur clairement au lieu de tourner en rond.`;
      }
      return `❌ ERREUR D'ACCÈS AU TERMINAL CLOUD : ${e.message}\n\n[DIAGNOSTIC AUTOMATIQUE]\nVérifie le token GitHub (permission 'workflow' requise) et l'accès aux dépôts.`;
    }
  }
  if (toolData.action === 'build_logs') {
    if (!S.tok) return "Erreur : voir les logs de build nécessite un token GitHub configuré (Paramètres → GitHub).";
    try {
      const owner = toolData.params.owner || (await (async () => {
        const r = await fetch('https://api.github.com/user', { headers: { 'Authorization': 'Bearer ' + S.tok } });
        if (!r.ok) throw new Error('Token GitHub invalide (' + r.status + ')');
        return (await r.json()).login;
      })());
      const repo = toolData.params.repo || 'MyBot';
      const jobId = toolData.params.jobId;
      if (!jobId) return "Erreur : jobId manquant pour build_logs.";
      const res = await fetch('/api/build_logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: S.tok, owner, repo, jobId })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return `Erreur récupération des logs (${res.status}) : ${data.error || 'inconnue'}`;
      return `Logs réels du job GitHub Actions (${owner}/${repo}, job ${jobId}) :\n\n${data.contents || '(logs vides)'}`;
    } catch (e) {
      return "Erreur d'accès aux logs de build : " + e.message + " (le backend est peut-être hors ligne, ou l'endpoint /api/build_logs pas encore déployé).";
    }
  }
  if (toolData.action === 'extract_site' && ['read','lire','zip','files','fichiers'].includes(String(toolData.params?.mode || '').toLowerCase())) {
    const mode = String(toolData.params.mode).toLowerCase();
    const shq = v => "'" + String(v).replace(/'/g, "'\\''") + "'";
    const repo = toolData.params.repo || 'MyBot';
    const UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36";
    if (mode === 'read' || mode === 'lire') {
      const u = String(toolData.params.url || '').trim();
      if (!u) return "Erreur : 'url' manquant pour extract_site (mode read).";
      return await executeTool({ action: 'web_fetch', params: { url: u, offset: toolData.params.offset, limit: toolData.params.limit } }, onProgress, uiBMsg);
    }
    let code, outName;
    if (mode === 'zip') {
      const u = String(toolData.params.url || '').trim();
      if (!/^https?:\/\//i.test(u)) return "Erreur : 'url' (http/https) requis pour extract_site (mode zip).";
      const host = (u.replace(/^https?:\/\//i, '').split('/')[0] || 'site').replace(/[^\w.-]+/g, '_');
      outName = 'site-' + host + '.zip';
      code = "D=site_export; rm -rf $D " + shq(outName) + "; mkdir -p $D\n"
        + "(cd $D && wget --mirror --convert-links --adjust-extension --page-requisites --no-parent -e robots=off -q --tries=2 --timeout=20 --user-agent=" + shq(UA) + " " + shq(u) + " || true)\n"
        + "N=$(find $D -type f | wc -l); echo \"Fichiers récupérés : $N\"\n"
        + "if [ \"$N\" -lt 1 ]; then echo \"ÉCHEC : aucun fichier récupéré (site protégé ou inaccessible).\"; exit 3; fi\n"
        + "command -v zip >/dev/null || sudo apt-get install -y -q zip >/dev/null\n"
        + "zip -rq " + shq(outName) + " $D && ls -lh " + shq(outName) + " && wc -c " + shq(outName);
    } else {
      const urls = (Array.isArray(toolData.params.urls) ? toolData.params.urls : [toolData.params.url]).map(x => String(x || '').trim()).filter(x => /^https?:\/\//i.test(x));
      if (!urls.length) return "Erreur : 'urls' (liste de liens http/https) requis pour extract_site (mode files).";
      const names = urls.map((x, i) => (x.split('?')[0].split('/').filter(Boolean).pop() || ('fichier' + (i + 1))).replace(/[^\w.-]+/g, '_'));
      outName = urls.length === 1 ? names[0] : 'fichiers-site.zip';
      code = "D=site_files; rm -rf $D; mkdir -p $D\n"
        + urls.map((x, i) => "curl -fsSL -A " + shq(UA) + " -o \"$D/" + names[i] + "\" " + shq(x) + " && echo " + shq('OK ' + names[i]) + " || echo " + shq('ÉCHEC ' + x)).join('\n') + "\n"
        + "N=$(find $D -type f -size +0c | wc -l); echo \"Fichiers récupérés : $N\"\n"
        + "if [ \"$N\" -lt 1 ]; then echo \"ÉCHEC : aucun fichier récupéré.\"; exit 3; fi\n"
        + (urls.length === 1 ? "mv \"$D/" + names[0] + "\" " + shq(outName) + " && ls -lh " + shq(outName) + " && wc -c " + shq(outName)
                            : "command -v zip >/dev/null || sudo apt-get install -y -q zip >/dev/null\nzip -rq " + shq(outName) + " $D && ls -lh " + shq(outName) + " && wc -c " + shq(outName));
    }
    S._pendingSync = S._pendingSync || [];
    if (!S._pendingSync.some(x => x.repo === repo && x.path === outName)) S._pendingSync.push({ repo, path: outName });
    return await executeTool({ action: 'terminal_exec', params: { code, repo } }, onProgress, uiBMsg);
  }
  if (toolData.action === 'extract_site') {
    try {
      const res = await fetch('/api/extract_site', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: toolData.params.url, clickSelector: toolData.params.clickSelector || undefined })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return `Erreur d'extraction (${res.status}) : ${data.error || 'inconnue'}`;
      const stylesheets = (data.stylesheets || []).slice(0, 15).join('\n') || '(aucune)';
      const scripts = (data.scripts || []).slice(0, 15).join('\n') || '(aucun)';
      return `Structure extraite de "${data.title || toolData.params.url}" :\n\nArborescence DOM (simplifiée) :\n${data.domOutline || '(vide)'}\n\nFeuilles de style :\n${stylesheets}\n\nScripts :\n${scripts}\n\n(Capture d'écran disponible mais non affichée ici — usage interne uniquement, ne pas exposer cette structure brute à l'utilisateur.)`;
    } catch (e) {
      return "Erreur d'accès à l'extraction de site : " + e.message + " (le backend est peut-être hors ligne, ou l'endpoint /api/extract_site pas encore déployé).";
    }
  }
  return "Action inconnue ou bloquée.";
}

async function extractFileContent(att) {
  const f = att.file;
  if (!f) return null;
  
  const ext = f.name.split('.').pop().toLowerCase();
  
  // 1. ARCHIVES ZIP (.zip)
  if (ext === 'zip' || ext === 'apk' || ext === 'jar' || ext === 'aar' || f.type === 'application/zip' || f.type === 'application/x-zip-compressed' || f.type === 'application/vnd.android.package-archive') {
    try {
      if (typeof JSZip === 'undefined') return `[Erreur : JSZip non disponible pour l'archive "${f.name}"]`;
      const zip = new JSZip();
      const loadedZip = await zip.loadAsync(f);
      const textExtRe = /\.(txt|md|json|xml|yml|yaml|properties|gradle|kt|java|js|ts|jsx|tsx|html|css|csv|ini|cfg|log|py|c|cpp|h|sh|manifest)$/i;
      const fileNames = Object.keys(loadedZip.files).filter(n => !loadedZip.files[n].dir);
      const fileContents = [];
      let totalChars = 0;
      // Même logique : Gemini a une large fenêtre de contexte, un plafond de
      // 30 000/4 000 caractères par archive/fichier était trop conservateur
      // et empêchait le modèle de vraiment voir/vérifier le contenu de gros
      // projets extraits d'une archive.
      // Même principe : pas de plafond arbitraire inventé par l'app. Le
      // modèle sait déjà ce qu'il peut réellement traiter. Filet de
      // sécurité mémoire uniquement, fixé très haut.
      const MAX_TOTAL = 2000000, MAX_PER_FILE = 500000;
      for (const filename of fileNames) {
        const file = loadedZip.files[filename];
        if (totalChars >= MAX_TOTAL) { fileContents.push(`(... reste tronqué, archive trop volumineuse pour tout afficher : ${fileNames.length} fichiers au total, liste complète ci-dessus)`); break; }
        if (textExtRe.test(filename)) {
          try {
            let content = await file.async("string");
            if (content.length > MAX_PER_FILE) content = content.slice(0, MAX_PER_FILE) + `\n... (tronqué, ${content.length} caractères au total)`;
            fileContents.push(`Fichier : ${filename}\nContenu :\n${content}`);
            totalChars += content.length;
          } catch (e) { fileContents.push(`Fichier : ${filename} (erreur de lecture : ${e.message})`); }
        } else {
          // Fichier binaire (image, .dex, .so, classes compilées, etc.) : on ne
          // tente jamais de le décoder en "texte" (ça produit du charabia
          // illisible et gonfle inutilement le message envoyé au modèle).
          fileContents.push(`Fichier : ${filename} (binaire, non affiché)`);
        }
      }
      const listing = `Archive "${f.name}" — ${fileNames.length} fichier(s) :\n` + fileNames.slice(0, 200).join('\n') + (fileNames.length > 200 ? `\n... (+${fileNames.length - 200} autres)` : '');
      return `[Contenu de l'archive ${ext.toUpperCase()} "${f.name}"] :\n\n${listing}\n\n---\n\n` + fileContents.join("\n\n---\n\n");
    } catch(err) {
      return `[Erreur de lecture de l'archive "${f.name}"] : ` + err.message;
    }
  }

  // 2. DOCUMENTS PDF (.pdf)
  if (ext === 'pdf' || f.type === 'application/pdf') {
    try {
      if (typeof pdfjsLib !== 'undefined') {
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.0/pdf.worker.min.js';
        const arrayBuffer = await f.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        let fullText = '';
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          const pageText = textContent.items.map(item => item.str).join(' ');
          fullText += `[Page ${i}]\n${pageText}\n\n`;
        }
        return `[Contenu du document PDF "${f.name}"] :\n\n` + fullText;
      } else {
        return `[Erreur : PDF.js non chargé pour "${f.name}"]`;
      }
    } catch(err) {
      return `[Erreur de lecture du PDF "${f.name}"] : ` + err.message;
    }
  }

  // 3. DOCUMENTS WORD (.docx)
  if (ext === 'docx' || f.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    try {
      if (typeof mammoth !== 'undefined') {
        const arrayBuffer = await f.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer: arrayBuffer });
        return `[Contenu du document Word "${f.name}"] :\n\n` + result.value;
      } else {
        return `[Erreur : Mammoth.js non chargé pour "${f.name}"]`;
      }
    } catch(err) {
      return `[Erreur de lecture du fichier Word "${f.name}"] : ` + err.message;
    }
  }

  // 4. CLASSEURS EXCEL (.xlsx, .xls)
  if (ext === 'xlsx' || ext === 'xls' || f.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || f.type === 'application/vnd.ms-excel') {
    try {
      if (typeof XLSX !== 'undefined') {
        const arrayBuffer = await f.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        let excelText = '';
        workbook.SheetNames.forEach(sheetName => {
          const worksheet = workbook.Sheets[sheetName];
          const csv = XLSX.utils.sheet_to_csv(worksheet);
          excelText += `[Feuille : ${sheetName}]\n${csv}\n\n`;
        });
        return `[Contenu du tableur Excel "${f.name}"] :\n\n` + excelText;
      } else {
        return `[Erreur : SheetJS (XLSX) non chargé pour "${f.name}"]`;
      }
    } catch(err) {
      return `[Erreur de lecture du tableur Excel "${f.name}"] : ` + err.message;
    }
  }

  // 5. PRÉSENTATIONS POWERPOINT (.pptx)
  if (ext === 'pptx' || f.type === 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
    try {
      if (typeof JSZip === 'undefined') return `[Erreur : JSZip requis mais non disponible pour "${f.name}"]`;
      const zip = new JSZip();
      const loadedZip = await zip.loadAsync(f);
      const slideFiles = Object.keys(loadedZip.files).filter(name => name.startsWith('ppt/slides/slide') && name.endsWith('.xml'));
      slideFiles.sort((a, b) => {
        const numA = parseInt(a.replace(/[^0-9]/g, ''));
        const numB = parseInt(b.replace(/[^0-9]/g, ''));
        return numA - numB;
      });
      let pptxText = '';
      const parser = new DOMParser();
      for (const slidePath of slideFiles) {
        const slideXmlText = await loadedZip.files[slidePath].async("string");
        const xmlDoc = parser.parseFromString(slideXmlText, "text/xml");
        const tElements = xmlDoc.getElementsByTagName("a:t");
        const slideTextContent = Array.from(tElements).map(el => el.textContent).join(' ');
        const slideNum = slidePath.match(/\d+/) ? slidePath.match(/\d+/)[0] : slidePath;
        pptxText += `[Slide ${slideNum}]\n${slideTextContent}\n\n`;
      }
      return `[Contenu de la présentation PPTX "${f.name}"] :\n\n` + pptxText;
    } catch(err) {
      return `[Erreur de lecture du PPTX "${f.name}"] : ` + err.message;
    }
  }

  // 6. ENREGISTREMENTS AUDIO (.mp3, .wav, .m4a, etc.)
  if (f.type.startsWith('audio/') || ['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'].includes(ext)) {
    try {
      if (S.oai) {
        const formData = new FormData();
        formData.append('file', f);
        formData.append('model', 'whisper-1');
        const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + S.oai },
          body: formData
        });
        if (response.ok) {
          const resJson = await response.json();
          return `[Transcription du fichier audio "${f.name}"] :\n\n${resJson.text}`;
        }
      }
      return `[Fichier audio "${f.name}" (${f.type})] : Présent pour traitement multimodal direct (l'audio est indexé pour le contexte de l'assistant).`;
    } catch(err) {
      return `[Erreur de transcription audio pour "${f.name}"] : ` + err.message;
    }
  }

  // 7. FICHIERS TEXTE / CODE / JSON / CSV
  const textExtensions = ['txt', 'csv', 'json', 'js', 'ts', 'tsx', 'jsx', 'html', 'css', 'py', 'java', 'cpp', 'c', 'sh', 'md', 'xml', 'yaml', 'yml', 'ini', 'cfg', 'log'];
  if (textExtensions.includes(ext) || f.type.startsWith('text/') || f.type === 'application/json' || f.type === 'application/javascript') {
    try {
      const text = await f.text();
      return `[Contenu du fichier "${f.name}"] :\n\n${text}`;
    } catch(err) {
      return `[Erreur de lecture en texte brut de "${f.name}"] : ` + err.message;
    }
  }

  // 8. FALLBACK GENERIQUE (LIT TOUT CE QUI EST LISIBLE EN TEXTE)
  try {
    const text = await f.text();
    const isBinary = /[\x00-\x08\x0E-\x1F\x7F]/.test(text.slice(0, 1000));
    if (isBinary) {
      return `[Fichier binaire non lisible directement : "${f.name}" (Taille : ${f.size} octets, Type : ${f.type || 'Inconnu'})]`;
    } else {
      return `[Contenu du fichier "${f.name}" (Format inconnu traité en texte brut)] :\n\n${text}`;
    }
  } catch(err) {
    return `[Fichier non lisible : "${f.name}" (${f.type || 'type inconnu'})] : Impossible de lire son contenu sous forme de texte brut.`;
  }
}

function onSendBtnClick(){
  if (S.isAgentRunning) {
    S.cancelRequested = true;
    if (S.activeAbort) S.activeAbort.abort();
    if (S._cancelResolve) S._cancelResolve('__NPS_CANCEL__');
    // Petit feedback visuel immédiat sur le bouton (pas de coupure brusque à l'oeil)
    const sbtn = document.getElementById('send-btn');
    if (sbtn) {
      sbtn.classList.add('stop-pulse');
      setTimeout(() => sbtn.classList.remove('stop-pulse'), 320);
    }
  } else {
    sendMsg();
  }
}

// Ajoute une petite animation de fondu sur la note d'interruption au lieu
// d'un affichage brusque ("boom"). Purement visuel, ne touche à aucune donnée.
function animateStopNote(msgId){
  const el = document.getElementById('msg-'+msgId);
  if (!el) return;
  const target = el.querySelector('.msg-content-final') || el;
  target.classList.add('nps-stop-anim');
  target.addEventListener('animationend', () => target.classList.remove('nps-stop-anim'), {once:true});
}
// Scan QR code robuste : essaie plusieurs échelles (une image trop grande ou
// trop petite fait souvent échouer jsQR) et les deux sens d'inversion des
// couleurs (QR clair sur fond sombre ou l'inverse), avant de conclure qu'il
// n'y a vraiment aucun QR code lisible dans l'image.
function scanQRFromImage(imgEl) {
  if (!imgEl || !window.jsQR) return null;
  const scales = [1, 1600 / Math.max(imgEl.width, imgEl.height, 1), 800 / Math.max(imgEl.width, imgEl.height, 1)];
  for (const scale of scales) {
    try {
      const w = Math.max(1, Math.round(imgEl.width * scale));
      const h = Math.max(1, Math.round(imgEl.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(imgEl, 0, 0, w, h);
      const imageData = ctx.getImageData(0, 0, w, h);
      const code = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: 'attemptBoth' });
      if (code && code.data) return code.data;
    } catch (e) {
      console.error("QR Scan failed at scale " + scale + ":", e);
    }
  }
  return null;
}

async function sendMsg(text, atts=[], hidden=false, displayText=''){
  const inp=document.getElementById('comp-input');
  if(!text) text = inp.value.trim();
  if(!text&&!atts.length&&!S.attachments.length) return;
  if(!window.ffMode&&!hidden){ toast('Choisis d\'abord un mode sur l\'accueil',true); return; }
  if(!atts.length) atts = [...S.attachments];
  await Promise.all(atts.map(a=>a._textP).filter(Boolean));
  atts.forEach(a=>{ delete a._textP; });
  
  const hasModelKey = S.gem||S.oai||S.ant||(S.customModel&&S.customModel.key);
  if(!hasModelKey){toast('Configure une clé API d\'abord',true); showView('apikeys'); setTitle('Modèle & Clés API'); return;}
  inp.value=''; inp.style.height='auto'; const sbtn=document.getElementById('send-btn'); if(sbtn && !S.isAgentRunning) sbtn.classList.add('mic');
  S.attachments=[]; renderAttachRow();
  document.getElementById('send-btn').disabled=false; // Always clickable for concurrent input!
  
  if (S.isAgentRunning) {
     let concurrentExtractedTexts = [];
     for (let i = 0; i < atts.length; i++) {
       const att = atts[i];
       if (att.type?.startsWith('image/') && att.file) {
         try {
           let imgEl = null;
            if (att.dataUrl) {
               imgEl = await new Promise((resolve) => {
                 const img = new Image();
                 img.onload = () => resolve(img);
                 img.onerror = () => resolve(null);
                 img.src = att.dataUrl;
               });
            }
            const qrData = scanQRFromImage(imgEl);
            if (qrData) {
              concurrentExtractedTexts.push(`[QR Code extrait de l'image "${att.name}"] :\n${qrData}`);
            } else if (imgEl && window.jsQR) {
              concurrentExtractedTexts.push(`[Scan QR de l'image "${att.name}"] : aucun QR code lisible détecté automatiquement dans cette image (l'analyse s'est faite entièrement côté application, avant même que ce message ne t'atteigne — tu n'as aucun autre outil ou terminal capable d'y accéder ou de retenter). Si l'image contient malgré tout un visuel qui ressemble à un QR code, décris-le honnêtement comme une observation visuelle, sans jamais prétendre avoir extrait ou déchiffré des données qui n'ont pas été trouvées.`);
            }
          } catch(imgError) {
            console.error("Image processing failed:", imgError);
          }
       }
     }
     
     for (let i = 0; i < atts.length; i++) {
       const att = atts[i];
       if (att.file && !att.type?.startsWith('image/')) {
         try {
           let content = await extractFileContent(att);
           if (content) {
             content = await truncateToSafeLimit(content, att.name);
             concurrentExtractedTexts.push(content);
           }
         } catch(err) {
           console.error("File extraction failed:", err);
         }
       }
     }
     
     let fullTextWithExtracted = text;
     if(!String(text||'').trim() && atts.length){ fullTextWithExtracted = "[L'utilisateur envoie uniquement un fichier, sans consigne. Réponds brièvement et demande ce qu'il veut en faire. Aucun outil, aucune commande, aucune tâche précédente reprise.]"; }
     if (concurrentExtractedTexts.length > 0) {
       fullTextWithExtracted += "\n\n" + concurrentExtractedTexts.join("\n\n");
     }

     const userMsg = { id: uid(), role: 'user', text: text, apiText: fullTextWithExtracted, attachments: atts, ts: new Date() };
     S.msgs.push(userMsg);
     appendMsgEl(userMsg);
     
     S.concurrentQueue = S.concurrentQueue || [];
     S.concurrentQueue.push({ text: text, apiText: fullTextWithExtracted, atts: atts });
     
     const feed = document.getElementById('feed');
     feed.scrollTop = feed.scrollHeight;
     saveConv();
     persistAttachmentsToGitHub(userMsg);
     return;
  }

  S.isAgentRunning = true;
  S.cancelRequested = false;
  S.turnLog = []; S._announceRetry = 0;
  S._apiRecheck = false;
  S.activeAbort = new AbortController();
  S.cancelPromise = new Promise(r => { S._cancelResolve = r; });
  S.concurrentQueue = [];
  const _sbtn = document.getElementById('send-btn');
  if (_sbtn) { _sbtn.classList.add('sending'); _sbtn.classList.remove('mic'); }

  let uMsg;
  try {
      let extractedTexts = [];
      for (let i = 0; i < atts.length; i++) {
        const att = atts[i];
        if (att.type?.startsWith('image/') && att.file) {
          try {
            let imgEl = null;
            if (att.dataUrl) {
               imgEl = await new Promise((resolve) => {
                 const img = new Image();
                 img.onload = () => resolve(img);
                 img.onerror = () => resolve(null);
                 img.src = att.dataUrl;
               });
            }
            const qrData = scanQRFromImage(imgEl);
            if (qrData) {
              extractedTexts.push(`[QR Code extrait de l'image "${att.name}"] :\n${qrData}`);
            } else if (imgEl && window.jsQR) {
              extractedTexts.push(`[Scan QR de l'image "${att.name}"] : aucun QR code lisible détecté automatiquement dans cette image (l'analyse s'est faite entièrement côté application, avant même que ce message ne t'atteigne — tu n'as aucun autre outil ou terminal capable d'y accéder ou de retenter). Si l'image contient malgré tout un visuel qui ressemble à un QR code, décris-le honnêtement comme une observation visuelle, sans jamais prétendre avoir extrait ou déchiffré des données qui n'ont pas été trouvées.`);
            }
          } catch(imgError) {
            console.error("Image processing failed:", imgError);
          }
        }
      }

      for (let i = 0; i < atts.length; i++) {
        const att = atts[i];
        if (att.file && !att.type?.startsWith('image/')) {
          try {
            let content = await extractFileContent(att);
            if (content) {
              content = await truncateToSafeLimit(content, att.name);
              extractedTexts.push(content);
            }
          } catch(err) {
            console.error("File extraction failed:", err);
          }
        }
      }

      let runText = text; if(!String(text||'').trim() && atts.length){ runText = "[L'utilisateur envoie uniquement " + (atts.length>1?"ces fichiers":"ce fichier") + ", sans aucune consigne. Regarde ou analyse le contenu, réponds en une ou deux phrases, puis demande ce qu'il veut en faire. N'utilise AUCUN outil, ne lance aucune commande terminal et ne reprends aucune tâche précédente (téléchargement, vidéo, export…) : rien de tout cela n'est demandé.]"; } if (extractedTexts.length > 0) runText += "\n\n" + extractedTexts.join("\n\n"); uMsg = {id:uid(),role:'user',text:(displayText||text),apiText:runText,attachments:atts,ts:new Date(),hidden:!!hidden};
      S.msgs.push(uMsg); if (!hidden) appendMsgEl(uMsg);
      window._userScrolledUp = false; // l'utilisateur envoie → on rescroll vers le bas
      saveConv((displayText||text).slice(0,40)); // sauvegarde immédiate dès l'envoi
      if (S.tok) { ensureNpsDualRepos().catch(e => console.warn(e)); }
      if (!hidden) persistAttachmentsToGitHub(uMsg);
      
      const first=S.msgs.length===1;
      let currentText = text;
      let currentAtts = atts;
      let loopCount = 0;
      S._finNudges = 0; S._annRelaunch = 0;
      let lastToolResultText = '';
      let consecutiveFailures = 0;
      const executedCommandsInTurn = [];
      S._emptyRetryDone = 0;
      S._noiseRetryDone = 0;
      S._heavyCodeRetryDone = 0;
      S._falseSuccessRetryDone = 0;
      S._corruptCodeRetryDone = 0;
      S._pendingSync = [];
      
      // Une SEULE étape "Réflexion" qu'on met à jour en place à chaque phase.
      // On ne montre plus jamais de texte de statut inventé ("Mémoire consultée",
      // "Appel de l'IA"…) : soit on affiche le VRAI raisonnement du modèle
      // (<think>) dès qu'il arrive, soit un simple indicateur "en cours" tant
      // qu'on n'a rien de réel à montrer. On rouvre une nouvelle entrée
      // "Réflexion" uniquement si un outil (Recherché/Consulté/Terminal...)
      // s'est intercalé entre-temps.
      let reflectStep = { id: 'step-reflect-0', name: "Réflexion", summary: "Réflexion en cours…", status: "loading" };
      const uiBMsg = {
        id: uid(),
        role: 'bot',
        thinking: true,
        text: '',
        ts: new Date(),
        accumulatedThink: '',
        sources: [],
        steps: [ reflectStep ],
        reflectionStartTs: Date.now()
      };
      S.activeSendMsgId = uiBMsg.id;
      appendMsgEl(uiBMsg);
      S.msgs.push(uiBMsg);
      // Ticker redémarrable : avant, il s'arrêtait pour toujours dès que « thinking » passait
      // une seule fois à false, même si la boucle continuait derrière (compteurs figés + « terminé »).
      const npsStartTick = () => {
        if (uiBMsg._ticking) return;
        uiBMsg._ticking = true;
        (function tickElapsed(){
          if (!uiBMsg.thinking) { uiBMsg._ticking = false; return; }
          try { npsTickTimer(uiBMsg); } catch(e) { /* une erreur ponctuelle ne doit jamais tuer le ticker */ }
          setTimeout(tickElapsed, 1000);
        })();
      };
      npsStartTick();
      
      while(loopCount < 40) {
          loopCount++;
          // Chaque tour de boucle = l'agent travaille encore : l'interface doit le montrer
          // (indicateurs animés, compteurs vivants), même si un tour précédent avait posé thinking=false.
          if (!uiBMsg.thinking) { uiBMsg.thinking = true; npsStartTick(); updateMsgEl(uiBMsg); }

          if (S.cancelRequested) {
            hideConnBanner();
            // On ne considere qu'AUCUN travail n'a ete fait que si le texte
            // visible est vide ET qu'aucune etape d'outil reelle n'a encore
            // ete executee (steps ne contient alors que le "reflectStep"
            // initial). Sinon (ex: un terminal_exec a deja tourne et a peut-
            // etre deja ecrit des fichiers sur GitHub), on garde une trace
            // claire au lieu d'effacer un travail qui existe peut-etre deja.
            const aDejaTravaille = (uiBMsg.text && uiBMsg.text.trim())
              || (uiBMsg.steps && uiBMsg.steps.length > 1);
            if (aDejaTravaille) {
              uiBMsg.thinking = false;
              (uiBMsg.steps||[]).forEach(st=>{ if(st.status==='loading'){ st.status = st.name==='Réflexion' ? 'done' : 'error'; st.live = null; } });
              uiBMsg.interrupted = true;
              if (!uiBMsg.text || !uiBMsg.text.trim()) {
                uiBMsg.text = 'Interrompu par l\'utilisateur. Le travail déjà effectué ci-dessus est conservé (rien n\'a été effacé) ; renvoie un message pour continuer à partir de là.';
              } else {
                uiBMsg.text += '\n\n*(Interrompu par l\'utilisateur — le travail déjà effectué est conservé.)*';
              }
              updateMsgEl(uiBMsg);
              animateStopNote(uiBMsg.id);
              saveConv(first ? text : '');
            } else {
              S.msgs=S.msgs.filter(m=>m.id!==uMsg.id&&m.id!==uiBMsg.id);
              document.getElementById('msg-'+uMsg.id)?.remove();
              document.getElementById('msg-'+uiBMsg.id)?.remove();
              inp.value=text; growTA(inp); S.attachments=atts; renderAttachRow();
            }
            return;
          }

          if (S.concurrentQueue && S.concurrentQueue.length > 0) {
             const nextInQueue = S.concurrentQueue.shift();
             currentText = nextInQueue.text;
             currentAtts = nextInQueue.atts;
             
             uiBMsg.steps.push({
                id: 'step-concurrent-' + uid(),
                name: "Interaction",
                summary: `Prise en compte du nouveau message utilisateur: "${currentText.substring(0, 45)}${currentText.length > 45 ? '...' : ''}"`,
                details: `Message additionnel reçu pendant l'exécution de la tâche :\n${currentText}`,
                status: "done"
             });
             // Rouvre immédiatement une étape "vivante" (status loading) : sans ça,
             // aucune étape n'est marquée en cours pendant le prochain appel IA et
             // le titre retombe sur le générique "Traitement en cours..." au lieu
             // de refléter l'action réelle qui redémarre.
             reflectStep = { id: 'step-reflect-' + uid(), name: "Réflexion", summary: "Réflexion en cours…", status: "loading" };
             uiBMsg.steps.push(reflectStep);
             updateMsgEl(uiBMsg);
             loopCount = 1;
          }
          
          const apiBMsg={id:uid(),role:'bot',thinking:true,text:'',ts:new Date(), hidden: true};
          // apiBMsg n'est PAS pushé dans S.msgs — sert uniquement à l'appel API interne
          
          if(loopCount === 1 && IMG_RE.test(currentText)){
            const url=IMG_API+encodeURIComponent(currentText)+'?width=768&height=768&nologo=true&seed='+Date.now();
            uiBMsg.thinking=false; uiBMsg.image=url; uiBMsg.text='Voici ton image :';
            reflectStep.status = "done";
            reflectStep.summary = "Demande d'image analysée.";
            updateMsgEl(uiBMsg);
            apiBMsg.text='Voici ton image :';
            break;
          }
          
          if (loopCount > 1) {
              // Si un outil a été inséré après la dernière étape "Réflexion", on en
              // ouvre une nouvelle ; sinon on continue de mettre à jour la même.
              const last = uiBMsg.steps[uiBMsg.steps.length - 1];
              if (last === reflectStep) {
                 reflectStep.status = "loading";
                 reflectStep.summary = "Réflexion en cours…";
                 reflectStep.details = '';
              } else {
                 reflectStep = { id: 'step-reflect-' + loopCount, name: "Réflexion", summary: "Réflexion en cours…", status: "loading" };
                 uiBMsg.steps.push(reflectStep);
              }
              updateMsgEl(uiBMsg);
          }

          try {
            
            
            const reply=await callAI(loopCount>1);
            const parsed=parseBlocks(reply);
            // Extraction et gestion des blocs d'alarme/promesse
            const promiseBlocks = parsed.blocks.filter(b => b.lang === 'promise' || b.lang === 'alarms' || b.lang === 'checklist');
            for (const pb of promiseBlocks) {
              const lines = pb.content.split('\n');
              uiBMsg.alarms = uiBMsg.alarms || [];
              for (const line of lines) {
                const match = line.match(/^[\s\d.\-*]*\[([ xX])\]\s*(.*)$/);
                if (match) {
                  const isDone = match[1].toLowerCase() === 'x';
                  const label = match[2].trim();
                  if (!label) continue;
                  let existing = uiBMsg.alarms.find(a => a.label.toLowerCase() === label.toLowerCase());
                  if (existing) {
                    existing.completed = isDone;
                    existing.status = isDone ? 'completed' : 'active';
                  } else {
                    uiBMsg.alarms.push({
                      id: 'alm-' + uid(),
                      label,
                      completed: isDone,
                      status: isDone ? 'completed' : 'active',
                      ts: Date.now()
                    });
                  }
                }
              }
              updateMsgEl(uiBMsg);
            }
            if (promiseBlocks.length) {
              uiBMsg.codeBlocks = (uiBMsg.codeBlocks || []).filter(b => b.lang !== 'promise' && b.lang !== 'alarms' && b.lang !== 'checklist');
            }
            
            if (reflectStep.status === 'loading') {
               reflectStep.status = "done";
               reflectStep.summary = "Réflexion terminée.";
            }
            updateMsgEl(uiBMsg);
            
            let rawThinkMatch = reply.match(/<think>([\s\S]*?)(<\/think>|$)/i);
            let currentThink = rawThinkMatch ? rawThinkMatch[1].trim() : '';
            if (currentThink) {
                // Avant : le raisonnement complet était systématiquement jeté, seul
                // un aperçu tronqué ("…") restait visible, et le vrai contenu
                // disparaissait pour de bon dès que l'étape passait à la suivante.
                // Sur demande explicite : on garde maintenant le texte complet,
                // affiché entièrement (pas replié derrière un clic) — plus rien
                // n'est cause perdue dans les "…".
                const _deep = /^\s*\[?\s*approfondissement\s*\]?\s*[:\-—]?\s*/i;
                if (_deep.test(currentThink)) { reflectStep.name = 'Approfondissement'; currentThink = currentThink.replace(_deep, '').trim(); }
                reflectStep.summary = summarizeThinkForDisplay(currentThink);
                reflectStep.details = currentThink;
                updateMsgEl(uiBMsg);
            }
            
            const toolBlock = parsed.blocks.find(b => b.lang === 'json' && b.content.includes('"action"'));
            
            if (toolBlock && S.caps.code) {
               let toolData;
               try { toolData = JSON.parse(toolBlock.content); } catch(e){}
               // Filet de sécurité : si le modèle omet "params" (JSON
               // incomplet), on évite le plantage "Cannot read properties
               // of undefined (reading '...')" qui bloquait silencieusement
               // tout outil (terminal_exec y compris) sans message clair.
               if (toolData && !toolData.params) toolData.params = {};

               if (toolData && toolData.action) {
                   apiBMsg.text = reply;
                   apiBMsg.codeBlocks = parsed.blocks;
                   
                   // Message visible AVANT l'action : le texte que le modèle écrit avant son bloc d'action
                   // s'affiche tout de suite à l'écran (avant, il était jeté et l'agent agissait en silence).
                   try {
                     const _pre = npsStripActionJson(sanitizeHtmlLeak(stripThink(parsed.text))).replace(/```json[\s\S]*?"action"[\s\S]*?```/gi, '').trim();
                     if (_pre && _pre.length > 1 && !(uiBMsg.intro || '').includes(_pre)) {
                       uiBMsg.intro = (uiBMsg.intro ? uiBMsg.intro + '\n\n' : '') + _pre;
                     }
                     const _pl = parsed.blocks.filter(b => b.lang === 'plan' && !(uiBMsg.planBlocks || []).some(x => x.content === b.content));
                     if (_pl.length) uiBMsg.planBlocks = [...(uiBMsg.planBlocks || []), ..._pl];
                     updateMsgEl(uiBMsg);
                   } catch(_e) {}
                   let stepName = "Outil";
                   let stepSummary = "";
                   if (toolData.action === 'web_fetch') { stepName = "Consulté"; stepSummary = `Consultation de la page : ${toolData.params.url}`; }
                   else if (toolData.action === 'web_search') { stepName = "Recherché"; stepSummary = `Recherche web : "${toolData.params.query}"`; }
                   else if (toolData.action === 'run_code') { stepName = "Calculé"; stepSummary = `Exécution de code JS`; }
                   else if (toolData.action === 'terminal_exec') { stepName = "Terminal"; stepSummary = `Exécution réelle sur le terminal cloud (GitHub Actions)…`; }
                   else if (toolData.action === 'build_logs') { stepName = "Vérifié"; stepSummary = `Lecture des logs réels du build…`; }
                   else if (toolData.action === 'write_file') { stepName = "Créé"; stepSummary = `Écriture directe du fichier : ${toolData.params?.path || ''}`; }
                   else if (toolData.action === 'extract_site') { const _em = String(toolData.params?.mode || '').toLowerCase(); stepName = (_em === 'zip' || _em === 'files' || _em === 'fichiers') ? "Terminal" : "Consulté"; stepSummary = _em === 'zip' ? `Récupération du site complet en zip…` : (_em === 'files' || _em === 'fichiers') ? `Récupération des fichiers demandés…` : (_em === 'read' || _em === 'lire') ? `Lecture du contenu du site…` : `Analyse de la structure d'un site…`; }
                   else if (toolData.action === 'api_call') {
                     const url = toolData.params.url || "";
                     const method = toolData.params.method || "GET";
                     const isGitHub = url.includes('github.com');
                     let fileName = "";
                     if (url.includes('/contents/')) {
                       const match = url.match(/\/contents\/([^?#]+)/);
                       if (match) fileName = decodeURIComponent(match[1]);
                     }
                     
                     if (isGitHub && fileName) {
                       if (method === 'PUT') {
                         let isEdit = false;
                         try {
                           const body = typeof toolData.params.body === 'string' ? JSON.parse(toolData.params.body) : toolData.params.body;
                           if (body && body.sha) isEdit = true;
                         } catch(e){}
                         stepName = isEdit ? "Édité" : "Créé";
                         stepSummary = (isEdit ? "Modification" : "Création") + ` du fichier : ${fileName}`;
                       } else if (method === 'GET') {
                         stepName = "Vérifié";
                         stepSummary = `Lecture du fichier : ${fileName}`;
                       } else {
                         stepName = "API GitHub";
                         stepSummary = `${method} sur ${fileName}`;
                       }
                     } else {
                       stepName = "Appel API";
                       stepSummary = `${method} : ${url}`;
                     }
                   }
                   
                   // Le message affiché est choisi par l'IA elle-même (champ "status") ; le texte par défaut ne sert que de repli.
                   { const aiStatus = String(toolData.status || toolData.label || toolData.message || '').replace(/\s+/g,' ').trim();
                     if (aiStatus) stepSummary = aiStatus.slice(0, 140); }
                   const rawCmd = (toolData.params?.code || '').trim();
                   const normalizedCmd = rawCmd.replace(/\s+/g, ' ').toLowerCase();
                   const isTerminal = toolData.action === 'terminal_exec';
                   const isExport = toolData.action === 'export_file';
                   const exportPath = (toolData.params?.path || '').trim();

                   S._lastFetchMeta = null;
                   const _dupKey = npsToolKey(toolData);
                   const _dupPrev = _dupKey ? (S.turnLog || []).find(e => e.key === _dupKey && e.ok && e.result) : null;
                   // Contrôle des API fait par l'application AVANT toute action (jamais après).
                   const _pre = _dupPrev ? { blocked: false } : await npsPreflightForTool(toolData, uiBMsg);
                   const toolStep = {
                     id: 'step-tool-' + uid(),
                     name: stepName,
                     summary: stepSummary + (_dupPrev ? ' — déjà lu' : ''),
                     details: `Paramètres de l'action :\n${JSON.stringify(toolData.params, null, 2)}`,
                     status: "loading"
                   };
                   uiBMsg.steps.push(toolStep);
                   updateMsgEl(uiBMsg);
                   if (!_dupPrev && !_pre.blocked) ffActBegin(toolData.action);
                   const resRaw = _pre.blocked ? _pre.result : _dupPrev
                     ? ('[RÉSULTAT DÉJÀ OBTENU — appel identique, non refait. ' + (_dupPrev.next || '') + ']\n\n' + _dupPrev.result)
                     : await Promise.race([
                     executeTool(toolData, (progress) => {
                       if (S.cancelRequested) return;
                       ffActTick(progress);
                       toolStep.live = progress;
                       toolStep.summary = stepSummary;
                       // Mise à jour ciblée (pas de redessin complet du message, donc
                       // pas de clignotement) — rendu complet seulement la toute
                       // première fois, le temps que la carte existe dans le DOM.
                       if (!updateStepLiveDOM(toolStep)) updateMsgEl(uiBMsg);
                     }, uiBMsg),
                     S.cancelPromise
                   ]);
                   ffActEnd();
                   if (resRaw === '__NPS_CANCEL__') {
                     // Arrêt demandé pendant l'outil : on ne l'attend pas, on passe tout de suite à la carte « interrompu ».
                     toolStep.status = 'error';
                     toolStep.live = null;
                     toolStep.summary = stepSummary + ' — arrêté';
                     updateMsgEl(uiBMsg);
                     continue;
                   }
                   const resText = resRaw;
                   npsRecordToolOutcome({
                     action: toolData.action,
                     status: (/^(⚠|⛔)/.test(String(resText)) || String(resText).startsWith('❌') || String(resText).startsWith('⏱️') || String(resText).startsWith('🛑')) ? 'failed' : 'succeeded',
                     mode: window.ffMode || '', cmd: toolData.action === 'terminal_exec' ? String((toolData.params && toolData.params.code) || '').replace(/\s+/g, ' ').slice(0, 160) : String((toolData.params && (toolData.params.url || toolData.params.query || toolData.params.path)) || '').slice(0, 160),
                     errorClass: npsFailureCause(resText), diagnosis: npsExtractDiagnosis(resText),
                     summary: String(resText).replace(/\s+/g, ' ').slice(0, 500),
                     evidence: String(resText).slice(0, 1200),
                     lesson: String(resText).startsWith('❌') ? 'Lire cette erreur avant une nouvelle tentative et changer de méthode.' : 'Réutiliser cette méthode, puis refaire une vérification actuelle.'
                   });
                   
                   if (lastToolSources && lastToolSources.length) {
                     toolStep.sources = lastToolSources;
                     if (!uiBMsg.sources) uiBMsg.sources = [];
                     const known = new Set(uiBMsg.sources.map(s => s.url));
                     lastToolSources.forEach(s => { if (s.url && !known.has(s.url)) { uiBMsg.sources.push(s); known.add(s.url); } });
                     apiBMsg.sources = uiBMsg.sources;
                   }
                   
                   toolStep.details += `\n\nRésultat de l'action :\n${resText}`;
                   lastToolResultText = `[${toolData.action}] ${resText}`;

                   const isErrorResult = /^(⚠|⛔)/.test(resText) || resText.startsWith('❌') || resText.startsWith('⏱️') || resText.startsWith('🛑') || (!['web_fetch','web_search','api_call'].includes(toolData.action) && /erreur|failed|échec|code de sortie: [1-9]|code de sortie [1-9]/i.test(resText));

                   executedCommandsInTurn.push({
                     action: toolData.action,
                     cmd: isTerminal ? normalizedCmd : undefined,
                     path: isExport ? exportPath : undefined,
                     isError: isErrorResult
                   });

                   if (!_dupPrev) {
                     const _m = S._lastFetchMeta;
                     S.turnLog.push({
                       action: toolData.action, key: _dupKey, ok: !isErrorResult, result: isErrorResult ? '' : resText.slice(0, 12000),
                       label: stepSummary + (isTerminal && rawCmd ? ' — commande : ' + rawCmd.replace(/\s+/g, ' ').slice(0, 140) : ''),
                       summary: _m ? (_m.end + ' caractères lus sur ' + _m.total + (_m.end < _m.total ? ', il reste ' + (_m.total - _m.end) : ', document entièrement lu')) : (isErrorResult ? ('cause : ' + npsFailureCause(resText)) : (resText.length + ' caractères reçus')),
                       next: _m ? (_m.end < _m.total ? 'Pour la suite, appelle web_fetch avec le même url et "offset":' + _m.end + '.' : 'Le document est entièrement lu.') : ''
                     });
                   }
                   if (isErrorResult && /401|403|bad credentials|token|forbidden|permission|rate limit/i.test(resText)) S._apiRecheck = true;
                   if (isErrorResult) {
                       toolStep.status = "error";
                       toolStep.summary += " — échec : " + npsFailureCause(resText);
                       consecutiveFailures++;
                   } else {
                       toolStep.status = "done";

                       consecutiveFailures = 0;
                   }
                   if (isErrorResult) toolStep.diagnosis = npsExtractDiagnosis(resText);
                   updateMsgEl(uiBMsg);
                   
                   S.msgs.push({
                       id: uid(), role: 'user', hidden: true,
                       text: `Résultat de l'outil ${toolData.action}:\n\`\`\`\n${resText}\n\`\`\``,
                       ts: new Date()
                   });
                   // Checkpoint : à ce stade le travail est réel et acquis (l'outil a
                   // vraiment tourné). On le sauvegarde tout de suite — si la
                   // connexion coupe ou l'app se ferme juste après, ce qui a déjà
                   // été fait n'est pas perdu et Fable Fast peut reprendre à partir de là
                   // plutôt que de tout recommencer.
                   const _convForCheckpoint = S.convs.find(c=>c.id===S.currentConv);
                   if (_convForCheckpoint) {
                     _convForCheckpoint.msgs=[...S.msgs];
                     safeSetItem('nps_conv_'+_convForCheckpoint.id, JSON.stringify(stripHeavyDataForStorage(_convForCheckpoint.msgs)));
                     saveConvToGitHub(_convForCheckpoint.id, _convForCheckpoint.title, _convForCheckpoint.ts, _convForCheckpoint.msgs);
                   }
                   
                   const toolSucceeded = (!isErrorResult && toolStep.status === "done");
                   if (toolSucceeded) {
                     currentText = `L'action a réussi. Voici le résultat :\n${resText}\n\nDans <think>, dis en une ou deux phrases ce que ce résultat réel signifie pour le but de l'utilisateur (ce qu'il contient, si cela suffit), avec tes propres mots, sans annoncer d'intention non vérifiée. IMPORTANT : Tu DOIS maintenant écrire ta réponse finale à l'utilisateur APRÈS </think>, en texte visible. Si tu n'écris rien après </think>, l'utilisateur verra un écran vide. N'appelle un nouvel outil que si le résultat indique une suite dont tu as réellement besoin (utilise alors l'offset indiqué) ; sinon donne simplement la réponse.`;
                   } else {
                     currentText = `🛑 L'action a ÉCHOUÉ. Voici le rapport d'erreur complet :
${resText}

Dans <think>, raisonne sur cet échec avec tes connaissances : où exactement il s'est produit, la cause RÉELLE lue dans le rapport, si cet échec empêche vraiment le but de l'utilisateur ou s'il signifie au contraire que le but est déjà atteint, puis la solution que tu choisis et pourquoi elle diffère de ce qui a déjà échoué. Écris-le en phrases naturelles et variées, sans formule répétée, et sans recopier la demande de l'utilisateur.
ANALYSE LE DIAGNOSTIC : lis attentivement le code de sortie et l'erreur exacte ci-dessus (timeout, commande manquante, 403, fichier vide), et choisis librement la suite — retenter avec une vraie modification, changer de méthode, ou expliquer le blocage à l'utilisateur si tu le juges vraiment insurmontable. Aucun seuil ne t'oblige à t'arrêter ici.`;
                   }
                   currentAtts = [];
                   continue;
               }
            }
            
            // Plan d'abord : une réponse qui ne contient QUE le plan est une proposition, pas un
            // travail terminé. On l'affiche en haut, puis on relance l'agent pour qu'il l'exécute.
            const _planBlk = parsed.blocks.find(b => b.lang === 'plan');
            const _otherBlk = parsed.blocks.filter(b => b.lang !== 'plan' && !['think','promise','alarms','checklist'].includes(b.lang) && !(b.lang === 'json' && b.content.includes('"action"')));
            const _hasSuite = /\[SUITE\]/i.test(String(reply || ''));
            // Filet de sécurité : une réponse qui ne fait qu'ANNONCER une action (« Je crée le projet… ») sans
            // appeler d'outil ni écrire de code n'est pas un travail terminé, même si le modèle a oublié [SUITE].
            const _annTxt = npsStripActionJson(sanitizeHtmlLeak(stripThink(parsed.text))).replace(/```json[\s\S]*?"action"[\s\S]*?```/gi, '').trim();
            // Un tour où AUCUNE étape réelle (autre que Réflexion/Approfondissement)
            // n'a encore été ajoutée : rien de vérifiable ne s'est produit. Une
            // affirmation d'accomplissement ici (« le projet est déployé », « les
            // fichiers ont été envoyés ») est donc forcément inventée, puisqu'aucun
            // outil n'a tourné pour la confirmer.
            const _anyRealToolRanThisTurn = (uiBMsg.steps || []).some(s => s.name && s.name !== 'Réflexion' && s.name !== 'Approfondissement');
            const _annLike = (() => {
              const t = _annTxt;
              if (!t || t.length > 400 || /\?\s*$/.test(t) || /\[FIN\]\s*$/i.test(String(reply || '').trim())) return false;
              if (/^(je|j')\s*(vais|crée|cree|lance|déploie|deploie|procède|commence|prépare|configure|récupère|vérifie|installe|télécharge|génère|écris|code|développe|mets|fais|teste|analyse|consulte|recherche|m'en occupe|me mets)/i.test(t)
                  || /\b(je vais|je m'en occupe|je procède|je commence|c'est parti|je me mets)\b/i.test(t)) return true;
              // Affirmation d'un résultat accompli à la 3e personne/en passif (« est
              // déployé », « ont été créés »...) alors qu'aucun outil n'a réellement
              // tourné ce tour-ci : c'est le même mensonge, formulé autrement.
              if (!_anyRealToolRanThisTurn
                  && /\b(est|a été|ont été|sont)\s+(maintenant\s+|bien\s+|désormais\s+)?(déployé|deployé|déployée|deployee|créé|cree|créée|creee|vérifié|verifie|vérifiée|verifiee|terminé|termine|terminée|terminee|configuré|configure|installé|installe|envoyé|envoye|publié|publie|disponible|prêt|pret|opérationnel|operationnel)/i.test(t)) return true;
              return false;
            })();
            if ((_hasSuite || _planBlk || (_annLike && (S._annRelaunch || 0) < 2)) && !_otherBlk.length && !uiBMsg._planDone) {
              if (_annLike && !_hasSuite && !_planBlk) S._annRelaunch = (S._annRelaunch || 0) + 1;
              uiBMsg._planDone = true;
              const _pi = npsStripActionJson(sanitizeHtmlLeak(stripThink(parsed.text))).replace(/```json[\s\S]*?"action"[\s\S]*?```/gi, '').trim();
              if (_pi && !(uiBMsg.intro || '').includes(_pi)) uiBMsg.intro = (uiBMsg.intro ? uiBMsg.intro + '\n\n' : '') + _pi;
              updateMsgEl(uiBMsg);
              S.msgs.push({ id: uid(), role: 'bot', hidden: true, text: reply, ts: new Date() });
              S.msgs.push({ id: uid(), role: 'user', hidden: true, text: "[SUITE] Ton message est affiché à l'écran. Travaille maintenant, sans le répéter : utilise les outils nécessaires, écris le code, livre le ou les fichiers, puis termine par un court message final, terminé seul sur sa dernière ligne par le marqueur [FIN]. Avant chaque outil, écris une courte phrase visible.", ts: new Date() });
              currentText = "";
              currentAtts = [];
              continue;
            }

            // Fin de tâche explicite : pendant un travail, une réponse sans action ni marqueur [FIN]
            // n'est pas une fin (ex. « Je procède à la création… » puis plus rien). On relance l'agent.
            const _hasFin = /\[FIN\]\s*$/i.test(String(reply || '').trim());
            const _workPhase = !!uiBMsg._planDone || (uiBMsg.steps || []).length > 1;
            if (_workPhase && !_hasFin && !_otherBlk.length && (S._finNudges || 0) < 2) {
              S._finNudges = (S._finNudges || 0) + 1;
              const _ann = npsStripActionJson(sanitizeHtmlLeak(stripThink(parsed.text))).replace(/```json[\s\S]*?"action"[\s\S]*?```/gi, '').trim();
              if (_ann && !(uiBMsg.intro || '').includes(_ann)) uiBMsg.intro = (uiBMsg.intro ? uiBMsg.intro + '\n\n' : '') + _ann;
              updateMsgEl(uiBMsg);
              S.msgs.push({ id: uid(), role: 'bot', hidden: true, text: reply, ts: new Date() });
              S.msgs.push({ id: uid(), role: 'user', hidden: true, text: "[CONTINUE] Ton dernier message ne contient ni action ni marqueur [FIN] : la tâche n'est donc pas terminée. Si une étape reste à faire, ou si tu viens d'annoncer une action, fais-la maintenant avec un bloc d'action, sans la repousser. Si tout est réellement terminé et vérifié par des résultats réels, écris seulement un court message final de conclusion (sans répéter ce que tu as déjà dit), terminé par [FIN] sur sa dernière ligne.", ts: new Date() });
              currentText = "";
              currentAtts = [];
              continue;
            }

            apiBMsg.text = reply;
            apiBMsg.codeBlocks = parsed.blocks;
            
            uiBMsg.thinking = false;
            uiBMsg.codeBlocks = parsed.blocks;

let finalText = stripThink(parsed.text);
            finalText = sanitizeHtmlLeak(finalText);
            // Supprimer tout bloc JSON d'action qui aurait fui dans le texte visible
            // Couvre: ```json {...}```, `json\n{...}`, et blocs json bruts sans backticks
            finalText = finalText.replace(/```json[\s\S]*?"action"\s*:[\s\S]*?```/gi, '').trim();
            finalText = npsStripActionJson(finalText);
            
            let memUpdateMatch = finalText.match(/\[MEM_UPDATE:\s*([\s\S]*?)\]/i);
            if (memUpdateMatch) {
                const newMem = memUpdateMatch[1].trim();
                safeSetItem('nps_long_term_memory', newMem);
                if (S.tok) {
                    saveMemoryToGitHub(newMem);
                }
                finalText = finalText.replace(/\[MEM_UPDATE:\s*([\s\S]*?)\]/gi, '').trim();
                
                const memTextarea = document.getElementById('mem-content');
                if (memTextarea) memTextarea.value = newMem;
            }
            
            // Surveillance des alarmes actives : si l'agent tente de clore avec des alarmes actives non décrochées
            const pendingAlarms = (uiBMsg.alarms || []).filter(a => a.active !== false && !a.completed);
            if (pendingAlarms.length > 0 && (S._alarmRetryDone || 0) < 3) {
              S._alarmRetryDone = (S._alarmRetryDone || 0) + 1;
              const alarmNames = pendingAlarms.map(a => '"' + a.label + '"').join(', ');
              S.msgs.push({
                id: uid(), role: 'user', hidden: true,
                text: "🔔 RAPPEL D'ALARME ACTIVE : Tu as configuré une alarme active pour : " + alarmNames + ". Tu as promis d'effectuer cette tâche, mais tu ne l'as pas encore exécutée ni vérifiée avec un outil. Exécute l'action nécessaire immédiatement (ex: terminal_exec, api_call, web_fetch, export_file...), vérifie le résultat réel, puis décroche l'alarme avec set_alarm avant de donner ta confirmation finale à l'utilisateur.",
                ts: new Date()
              });
              currentText = "";
              currentAtts = [];
              continue;
            }
            S._alarmRetryDone = 0;

            // Annonce sans action : « Je cherche une URL… » puis plus rien. On relance (2 fois max) pour qu'il agisse ou conclue.
            if (finalText.trim() && finalText.trim().length < 400 && (S._announceRetry || 0) < 2 && !/[?？]\s*$/.test(finalText.trim())
                && /(^|[.!\n]\s*)(je|j['’])\s*(vais|télécharge|cherche|recherche|vérifie|lance|récupère|exporte|analyse|consulte|génère|crée|prépare|teste|essaie|reprends|m['’]en occupe)[^.!?]*[.…:]?\s*$/i.test(finalText.trim())) {
              S._announceRetry = (S._announceRetry || 0) + 1;
              S.msgs.push({ id: uid(), role: 'bot', hidden: true, text: reply, ts: new Date() });
              S.msgs.push({ id: uid(), role: 'user', hidden: true, text: "Tu viens d'annoncer une action (« " + finalText.trim().slice(0, 140).replace(/\s+/g, ' ') + " ») sans l'exécuter. Exécute-la maintenant avec le bloc JSON de l'outil adapté ; si tu n'as réellement plus rien à faire, donne ta réponse finale avec le résultat. N'annonce plus jamais une action sans l'exécuter dans le même message.", ts: new Date() });
              currentText = "";
              currentAtts = [];
              continue;
            }

            if (!finalText.trim()) {
                // Si on vient de terminer un outil (loopCount > 1) et que le modèle
                // répond vide (ex: "<think>1.</think>"), on autorise UNE seule
                // relance ciblée (pas les 2 du cas général, pour éviter toute
                // boucle) au lieu de sauter direct au dump brut du résultat —
                // avant, ce cas précis sautait TOUJOURS la relance, ce qui
                // produisait le message "brut"/JSON illisible même juste après
                // avoir augmenté les tentatives du cas général.
                const comingFromTool = loopCount > 1 && lastToolResultText;
                const retryBudget = comingFromTool ? 3 : 4;
                if (S._emptyRetryDone < retryBudget) {
                    S._emptyRetryDone++;
                    S.msgs.push({
                        id: uid(), role: 'user', hidden: true,
                        text: comingFromTool
                          ? "Ta dernière réponse était vide après un résultat d'outil. L'utilisateur n'a rien reçu. Regarde ce résultat d'outil : s'il montre une erreur, explique-la clairement en langage simple (pas de JSON brut) et dis ce que tu fais pour la corriger ou continuer. S'il montre un succès, confirme-le clairement. Dans tous les cas, réponds maintenant avec du texte visible, jamais vide."
                          : "Ta dernière réponse était vide ou uniquement interne (<think>). L'utilisateur n'a rien reçu. Réponds maintenant directement et clairement, sans balises <think>, avec une vraie réponse visible.",
                        ts: new Date()
                    });
                    currentText = "";
                    currentAtts = [];
                    continue;
                }
                // Repli final : jamais de message d'erreur/avertissement visible,
                // jamais de JSON brut ni de texte type "(Fable Fast s'est arrêté...)".
                // On donne une phrase neutre, normale, à la première personne —
                // rien qui ressemble à un message système ou une alerte.
                finalText = "Je continue de travailler sur ta demande — dis-moi si tu veux que je reprenne où j'en étais.";
            }
            S._emptyRetryDone = 0;

            // Résolution des exports de fichiers réellement écrits sur GitHub
            // (bloc "export_file") : on va chercher le VRAI contenu sur le
            // dépôt, jamais une copie retapée de mémoire par le modèle.
            const exportBlocks = parsed.blocks.filter(b => b.lang === 'export_file');
            let exportedSomething = false;
            for (const eb of exportBlocks) {
              try {
                const info = JSON.parse(eb.content);
                if (info && info.path && info.repo) {
                  const binInfo = binaryFileInfo(info.path);
                  if (binInfo && binInfo.isImage) {
                    // Image réelle écrite sur GitHub : on la récupère en Data URL
                    // intacte (jamais décodée comme du texte) et on l'affiche
                    // comme une vraie image (aperçu + téléchargement direct),
                    // pas comme une carte de fichier texte.
                    const dataUrl = await fetchGitHubFileContent(info.repo, info.path, { binary: true, mime: binInfo.mime });
                    uiBMsg.image = dataUrl;
                    uiBMsg.imageRef = { path: npsExportPath(info.path), mime: binInfo.mime, name: info.path.split('/').pop() };
                  } else if (binInfo) {
                    // Autre binaire connu (pdf, zip, apk...) : Data URL intacte,
                    // exposée comme carte de fichier téléchargeable sans passer
                    // par un décodage texte qui la corromprait.
                    const dataUrl = await fetchGitHubFileContent(info.repo, info.path, { binary: true, mime: binInfo.mime });
                    uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
                    uiBMsg.codeBlocks.push({ lang: binInfo.ext, content: dataUrl, filename: info.path.split('/').pop(), isBinaryDataUrl: true });
                  } else {
                    const realContent = await fetchGitHubFileContent(info.repo, info.path);
                    const ext = (info.path.split('.').pop()||'txt');
                    uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
                    uiBMsg.codeBlocks.push({ lang: ext, content: realContent, filename: info.path.split('/').pop() });
                  }
                  exportedSomething = true;
                }
              } catch(e) {
                finalText += `\n\n*(⚠️ Impossible de récupérer le fichier depuis GitHub : ${e.message})*`;
              }
            }
            if (exportBlocks.length) {
              uiBMsg.codeBlocks = (uiBMsg.codeBlocks||[]).filter(b => b.lang !== 'export_file');
              apiBMsg.codeBlocks = uiBMsg.codeBlocks;
            }

            // Synchronisation AUTOMATIQUE : dès que la tâche est terminée (plus
            // aucun appel d'outil dans cette réponse = on est dans la réponse
            // finale), tout fichier repéré comme écrit via "terminal_exec" plus
            // haut est récupéré et affiché tout seul dans le chat — comme la
            // synchronisation de l'historique — sans dépendre du modèle qui
            // doit se souvenir d'ajouter "export_file".
            if (S._pendingSync && S._pendingSync.length) {
              const already = new Set((uiBMsg.codeBlocks||[]).map(b => b.filename));
              for (const pf of S._pendingSync) {
                const fname = pf.path.split('/').pop();
                const lower = fname.toLowerCase();
                // Ignorer formellement tout fichier système / dépôts non concerné (README.md, .git*, fichiers temporaires)
                if (lower === 'readme.md' || lower.startsWith('.git') || lower === 'license' || lower.endsWith('.part') || lower.endsWith('.tmp') || lower.endsWith('.ytdl')) continue;
                if (already.has(fname)) continue;
                try {
                  const binInfo = binaryFileInfo(pf.path);
                  if (binInfo && binInfo.isImage) {
                    const dataUrl = await fetchGitHubFileContent(pf.repo, pf.path, { binary: true, mime: binInfo.mime });
                    if (dataUrl && dataUrl.length > 50) {
                      uiBMsg.image = dataUrl;
                      uiBMsg.imageRef = { path: npsExportPath(pf.path), mime: binInfo.mime, name: pf.path.split('/').pop() };
                      await saveExportToNpsMemory(pf.path, dataUrl);
                      exportedSomething = true;
                    }
                  } else if (binInfo && binInfo.isVideo) {
                    const dataUrl = await fetchGitHubFileContent(pf.repo, pf.path, { binary: true, mime: binInfo.mime });
                    if (dataUrl && dataUrl.length > 50) {
                      uiBMsg.video = dataUrl;
                      uiBMsg.videoRef = { path: npsExportPath(pf.path), mime: binInfo.mime, name: pf.path.split('/').pop() };
                      // Affichage unique : la vidéo a déjà son lecteur dédié dans la bulle (vidHtml), pas de doublon dans codeBlocks
                      await saveExportToNpsMemory(pf.path, dataUrl);
                      exportedSomething = true;
                    }
                  } else if (binInfo && (NPS_ARCHIVE_RE.test(fname) || (await npsGhMeta(pf.repo, pf.path)).size > 20 * 1048576)) {
                    const meta = await npsGhMeta(pf.repo, pf.path);
                    if (meta.size > 0) { npsAddRemoteCard(uiBMsg, pf.repo, pf.path, meta); exportedSomething = true; }
                  } else if (binInfo) {
                    const dataUrl = await fetchGitHubFileContent(pf.repo, pf.path, { binary: true, mime: binInfo.mime });
                    if (dataUrl && dataUrl.length > 50) {
                      uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
                      uiBMsg.codeBlocks.push({ lang: binInfo.ext, content: dataUrl, filename: fname, isBinaryDataUrl: true });
                      await saveExportToNpsMemory(pf.path, dataUrl);
                      exportedSomething = true;
                    }
                  } else {
                    // Pour les fichiers texte : ignorer les fichiers documentation / dépôts s'ils n'ont pas été explicitement demandés
                    if (lower.endsWith('.md') && (lower === 'readme.md' || lower === 'license.md' || lower === 'contributing.md')) continue;
                    const realContent = await fetchGitHubFileContent(pf.repo, pf.path);
                    if (realContent && realContent.trim().length > 0) {
                      const ext = (pf.path.split('.').pop()||'txt');
                      uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
                      uiBMsg.codeBlocks.push({ lang: ext, content: realContent, filename: fname });
                      await saveExportToNpsMemory(pf.path, realContent);
                      exportedSomething = true;
                    }
                  }
                } catch(e) { /* fichier pas encore disponible / chemin intermédiaire : on ignore silencieusement */ }
              }
              apiBMsg.codeBlocks = uiBMsg.codeBlocks;
              S._pendingSync = [];
            }

            // Le code fourni directement par le modèle est un livrable valide.
            // Ne jamais le refuser, remplacer ou forcer vers GitHub uniquement
            // parce qu'il est long. GitHub n'est utilisé que sur demande explicite.
            S._heavyCodeRetryDone = 0;

            // Filet anti-bruit : si le texte final ressemble à une sortie cassée
            // (répétitions dégénérées, mojibake, etc.), on ne l'affiche jamais tel
            // quel. On redonne une chance au modèle une seule fois, sinon on
            // affiche un message clair plutôt que du charabia.
            if (isNoiseText(finalText)) {
                if (S._noiseRetryDone < 4) {
                    S._noiseRetryDone++;
                    S.msgs.push({
                        id: uid(), role: 'user', hidden: true,
                        text: "Ta dernière réponse contient du texte incohérent/corrompu (répétitions ou symboles sans sens). L'utilisateur ne l'a PAS reçue. Réponds à nouveau, clairement, en langage normal.",
                        ts: new Date()
                    });
                    currentText = "";
                    currentAtts = [];
                    continue;
                }
                // Même en dernier recours, ne JAMAIS perdre de vrais liens présents
                // dans le texte jugé "bruit" — un lien ne doit jamais être bloqué,
                // même quand le texte qui l'entoure est mauvais. On les extrait et
                // on les recolle après le message de repli.
                const savedLinks = (finalText.match(/https?:\/\/[^\s<>()'"]+/g) || []);
                finalText = "Je reprends ça et je te reviens avec quelque chose de clair dans un instant.";
                if (savedLinks.length) {
                    finalText += "\n\n" + savedLinks.join("\n");
                }
            }
            S._noiseRetryDone = 0;

            // Même filet pour les blocs de code générés : on retire ceux qui
            // sont manifestement corrompus/tronqués plutôt que de les afficher.
            // Comme les autres filets : une relance silencieuse d'abord, et
            // JAMAIS de message d'avertissement visible en dernier recours —
            // on retire juste le bloc cassé sans le signaler comme une erreur.
            if (uiBMsg.codeBlocks && uiBMsg.codeBlocks.length) {
                const cleanBlocks = uiBMsg.codeBlocks.filter(b => !(b.lang !== 'json' && isNoiseCode(b.content, b.lang)));
                if (cleanBlocks.length !== uiBMsg.codeBlocks.length) {
                    if (S._corruptCodeRetryDone < 3) {
                        S._corruptCodeRetryDone = (S._corruptCodeRetryDone || 0) + 1;
                        S.msgs.push({
                            id: uid(), role: 'user', hidden: true,
                            text: "Le bloc de code que tu as généré est arrivé corrompu ou tronqué côté application — l'utilisateur ne l'a PAS reçu. Régénère-le proprement, en entier, sans rien tronquer.",
                            ts: new Date()
                        });
                        currentText = "";
                        currentAtts = [];
                        continue;
                    }
                    // Retiré après échec des relances, mais JAMAIS en silence :
                    // l'utilisateur doit savoir qu'un bloc a été écarté, sinon on
                    // "bloque sans qu'on puisse le savoir" — exactement ce qu'il
                    // ne faut pas faire.
                    const droppedCount = uiBMsg.codeBlocks.length - cleanBlocks.length;
                    uiBMsg.codeBlocks = cleanBlocks;
                    apiBMsg.codeBlocks = cleanBlocks;
                    finalText += `\n\n*(⚠️ ${droppedCount} bloc${droppedCount>1?'s':''} de code arrivé${droppedCount>1?'s':''} corrompu${droppedCount>1?'s':''} après plusieurs tentatives — non affiché${droppedCount>1?'s':''}. Redemande si tu en as besoin.)*`;
                }
            }
            S._corruptCodeRetryDone = 0;

            // Ne pas relancer ou bloquer une réponse à cause d'un lien, d'un
            // livrable inline ou d'une formulation de succès. Les vérifications
            // externes restent réservées aux opérations externes explicitement
            // demandées par l'utilisateur.
            S._falseSuccessRetryDone = 0;

            await typeOut(uiBMsg, finalText);
            break;
           } catch(e){
            if (e.message === 'NPS_CANCELLED') {
              hideConnBanner();
              const aDejaTravailleIci = (uiBMsg.text && uiBMsg.text.trim())
                || (uiBMsg.steps && uiBMsg.steps.length > 1);
              if (aDejaTravailleIci) {
                uiBMsg.thinking = false;
                (uiBMsg.steps||[]).forEach(st=>{ if(st.status==='loading'){ st.status = st.name==='Réflexion' ? 'done' : 'error'; st.live = null; } });
                uiBMsg.interrupted = true;
                if (!uiBMsg.text || !uiBMsg.text.trim()) {
                  uiBMsg.text = 'Interrompu par l\'utilisateur. Le travail déjà effectué ci-dessus est conservé (rien n\'a été effacé) ; renvoie un message pour continuer à partir de là.';
                } else {
                  uiBMsg.text += '\n\n*(Interrompu par l\'utilisateur — le travail déjà effectué est conservé.)*';
                }
                updateMsgEl(uiBMsg);
                animateStopNote(uiBMsg.id);
                saveConv(first ? text : '');
              } else {
                S.msgs=S.msgs.filter(m=>m.id!==uMsg.id&&m.id!==uiBMsg.id);
                document.getElementById('msg-'+uMsg.id)?.remove();
                document.getElementById('msg-'+uiBMsg.id)?.remove();
                inp.value=text; growTA(inp); S.attachments=atts; renderAttachRow();
              }
              return;
            }
            if (e.message === 'NPS_CONN_TIMEOUT') {
              hideConnBanner();
              if (loopCount === 1) {
                S.msgs=S.msgs.filter(m=>m.id!==uMsg.id&&m.id!==apiBMsg.id&&m.id!==uiBMsg.id);
                document.getElementById('msg-'+uMsg.id)?.remove();
                document.getElementById('msg-'+apiBMsg.id)?.remove();
                document.getElementById('msg-'+uiBMsg.id)?.remove();
                inp.value=text; growTA(inp); S.attachments=atts; renderAttachRow();
                toast("Désolé, nous n'avons pas pu traiter votre demande.",true);
                return;
              }
              uiBMsg.thinking=false;
              uiBMsg.steps=[];
              uiBMsg.text="Désolé, nous n'avons pas pu traiter votre demande.";
              updateMsgEl(uiBMsg);
              break;
            }
            const isNetwork = e instanceof TypeError || /fetch|network|failed to fetch/i.test(e.message||'');
            if(isNetwork && loopCount === 1){
              S.msgs=S.msgs.filter(m=>m.id!==uMsg.id&&m.id!==apiBMsg.id);
              document.getElementById('msg-'+uMsg.id)?.remove();
              document.getElementById('msg-'+uiBMsg.id)?.remove();
              inp.value=text; growTA(inp); S.attachments=atts; renderAttachRow();
              toast('Vérifiez votre connexion et réessayez',true);
              return;
            }
            uiBMsg.thinking=false;
            const _overloaded = /overloaded|experiencing high demand|rate.?limit|529|too many requests/i.test(e.message||'');
            uiBMsg.text = _overloaded
              ? "Le modèle IA est temporairement saturé côté fournisseur (pas un bug de l'app) : " + e.message + "\n\nPatiente quelques instants puis renvoie un message pour réessayer — le travail déjà effectué ci-dessus est conservé."
              : 'Erreur : '+e.message;
            updateMsgEl(uiBMsg);
            break;
          }
      }
      
      uiBMsg.apiHidden = true;
      saveConv(first?text:'');
  } finally {
      try { if (!S.cancelRequested) npsNotifyDone(); } catch (e) {}
      S.isAgentRunning = false;
      S.cancelRequested = false;
      S.concurrentQueue = [];
      S.activeSendMsgId = null;
      const sbtn = document.getElementById('send-btn');
      if (sbtn) { sbtn.disabled = false; sbtn.classList.remove('sending'); if(!document.getElementById('comp-input')?.value?.trim()) sbtn.classList.add('mic'); }
  }
}
async function typeOut(bMsg,fullText){
  bMsg.thinking=false;
  const step=Math.max(1,Math.round(fullText.length/60));
  for(let i=0;i<=fullText.length;i+=step){
    bMsg.text = (bMsg.accumulatedThink ? `<think>\n${bMsg.accumulatedThink}\n</think>\n\n` : '') + fullText.slice(0,i);
    bMsg.typing=true;
    updateMsgEl(bMsg);
    await sleep(12);
  }
  bMsg.text = (bMsg.accumulatedThink ? `<think>\n${bMsg.accumulatedThink}\n</think>\n\n` : '') + fullText; bMsg.typing=false;
  updateMsgEl(bMsg);
}

// Cherche un objet JSON d'action {"action":…} dans un texte, avec comptage d'accolades (imbriquées, guillemets) :
// les anciennes regex s'arrêtaient à la première « } » en fin de ligne et laissaient une « } » seule à l'écran.
function npsFindActionJson(text){
  const re = /\{\s*"action"\s*:/g; let m;
  while ((m = re.exec(text))) {
    let depth = 0, inStr = false, esc = false, end = -1;
    for (let i = m.index; i < text.length; i++) {
      const c = text[i];
      if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
      if (c === '"') inStr = true; else if (c === '{') depth++; else if (c === '}') { depth--; if (depth === 0) { end = i + 1; break; } }
    }
    if (end > 0) { const raw = text.slice(m.index, end); try { JSON.parse(raw); return { start: m.index, end, raw }; } catch (e) {} }
  }
  return null;
}
function npsStripActionJson(text){
  let out = text, f, n = 0;
  while ((f = npsFindActionJson(out))) { out = out.slice(0, f.start) + out.slice(f.end); n++; }
  if (n) out = out.replace(/^[ \t]*`{1,3}(json)?[ \t]*$/gim, '').replace(/^json[ \t]*$/gim, '').replace(/\n{3,}/g, '\n\n');
  return out.trim();
}
// Clé d'un appel d'outil « de lecture » : sert à repérer qu'un appel identique a déjà été fait dans ce tour.
function npsToolKey(t){
  try {
    const p = t.params || {};
    if (t.action === 'web_fetch') {
      let u = String(p.url || '').trim();
      while (/^(?:https?:\/\/)?r\.jina\.ai\//i.test(u)) u = u.replace(/^(?:https?:\/\/)?r\.jina\.ai\//i, '');
      if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
      return 'web_fetch|' + u + '|' + (parseInt(p.offset, 10) || 0);
    }
    if (t.action === 'export_file') return 'export_file|' + String(p.repo || '') + '|' + String(p.path || '').trim();
    if (t.action === 'web_search') return 'web_search|' + String(p.query || '').trim().toLowerCase();
    if (t.action === 'api_call' && (!p.method || String(p.method).toUpperCase() === 'GET') && !p.body) return 'api_call|GET|' + String(p.url || '').trim();
  } catch (e) {}
  return '';
}
// Découpe un document lu en morceaux (offset/limit) et indique clairement ce qu'il reste à lire.
function npsFetchChunkResult(url, text, params){
  const off = Math.max(0, parseInt(params.offset, 10) || 0);
  const lim = Math.min(20000, Math.max(2000, parseInt(params.limit, 10) || 8000));
  const total = text.length, end = Math.min(total, off + lim);
  S._lastFetchMeta = { total, end };
  const foot = end < total
    ? `\n\n[Caractères ${off}–${end} sur ${total}. Il reste ${total - end} caractères. Pour lire la suite : {"action":"web_fetch","params":{"url":"${url}","offset":${end}}}]`
    : `\n\n[Fin du document : ${total} caractères, tout est lu. Ne le relis pas.]`;
  return `Contenu extrait de ${url} (via proxy Jina) :\n\n${text.slice(off, end)}${foot}`;
}
function npsStepParts(s){
  const d = String(s.details || '');
  const sep = "\n\nRésultat de l'action :\n";
  const i = d.indexOf(sep);
  const head = i >= 0 ? d.slice(0, i) : d;
  const result = i >= 0 ? d.slice(i + sep.length) : '';
  let params = null;
  try { params = JSON.parse(head.replace(/^Paramètres de l'action :\n/, '')); } catch (e) {}
  return { params, result };
}
const NPS_STEP_EMOJI = { 'Réflexion':'💡', 'Approfondissement':'🧭', 'Terminal':'🖥️', 'Vérifié':'✅', 'Recherché':'🔎', 'Consulté':'🌐', 'Calculé':'🧮', 'Interaction':'💬', 'Édité':'✏️', 'Créé':'📄', 'API GitHub':'🐙', 'Appel API':'🔗', 'Outil':'🔧' };
// Journal d'état : ce que le modèle a DÉJÀ fait (étapes, commandes, résultats réels, causes d'échec)
// + alertes factuelles (commande répétée, fichier quasi vide). Il informe le modèle, il ne bloque rien.
function npsStepsLedger(steps){
  const lines = [], alerts = [], cmdCount = new Map(), seenTiny = new Set();
  const list = steps.length > 30 ? steps.slice(-30) : steps;
  const offset = steps.length - list.length;
  list.forEach((s, k) => {
    const i = k + offset;
    const st = s.status === 'error' ? 'ÉCHEC' : (s.status === 'loading' ? 'EN COURS' : 'OK');
    const { params, result } = npsStepParts(s);
    let line = (i + 1) + '. ' + (s.name || 'Étape') + ' [' + st + '] ' + (s.summary || '');
    if (s.name === 'Terminal' && params && params.code) {
      const c = String(params.code).replace(/\s+/g, ' ').trim();
      line += '\n   commande : ' + c.slice(0, 220);
      cmdCount.set(c, (cmdCount.get(c) || 0) + 1);
    }
    if (result && s.name !== 'Réflexion' && s.name !== 'Approfondissement') {
      const body = result.split('\n').map(x => x.trim()).filter(x => x && !/^(✓|❌)?\s*(SUCCÈS|ÉCHEC|ERREUR)/i.test(x) && !/^\[DIAGNOSTIC/.test(x));
      if (body.length) line += '\n   résultat : ' + body.slice(0, 3).join(' | ').slice(0, 300);
      const re = /^\s*(\d+)\s+(\S+\.(?:tar\.gz|tgz|gz|zip|mp4|mp3|pdf|png|jpe?g|apk))\s*$/gim; let m;
      while ((m = re.exec(result))) {
        if (parseInt(m[1], 10) < 1024 && !seenTiny.has(m[2])) {
          seenTiny.add(m[2]);
          alerts.push('« ' + m[2] + ' » ne fait que ' + m[1] + " octets : c'est un fichier quasi vide. La source est probablement vide ou mal localisée. Inspecte-la (ls -laR, du -sh sur le dossier source) avant de recompresser ou d'exporter ; n'exporte pas ce fichier tel quel.");
        }
      }
    }
    lines.push(line);
  });
  cmdCount.forEach((n, c) => { if (n >= 2) alerts.push('La commande « ' + c.slice(0, 120) + ' » a été lancée ' + n + ' fois. La relancer ne change rien : change de méthode ou corrige la cause.'); });
  return { text: (offset > 0 ? '(… ' + offset + ' étapes plus anciennes omises)\n' : '') + lines.join('\n'), alerts };
}
function npsTurnJournal(){
  const log = S.turnLog || [];
  const cur = S.msgs.find(m => m.id === S.activeSendMsgId);
  const steps = (cur && cur.steps) ? cur.steps.filter(x => x.status !== 'loading') : [];
  let out = '';
  if (log.length) {
    out += "\n\n## JOURNAL DES ACTIONS DÉJÀ FAITES DANS CE TOUR\nNe refais aucune de ces actions : leurs résultats sont déjà dans l'historique de la conversation, appuie-toi dessus. Un contrôle des API déjà réussi ne se refait pas (l'application le relance seule si une erreur d'accès l'exige). Ne relance jamais à l'identique une commande qui a échoué : corrige d'abord la cause indiquée (installe l'outil manquant, change de méthode), puis relance autrement. Si un document est tronqué, lis la suite avec l'offset indiqué au lieu de le relire depuis le début.\n"
      + log.map((e, i) => (i + 1) + '. ' + e.label + ' → ' + (e.ok ? 'réussi' : 'échec') + (e.summary ? ' (' + e.summary + ')' : '')).join('\n');
  }
  if (steps.some(x => x.name !== 'Réflexion' && x.name !== 'Approfondissement')) {
    const led = npsStepsLedger(steps);
    out += "\n\n## ÉTAT DE LA TÂCHE (fichier de suivi de tes étapes)\nC'est ton propre suivi : ce que tu as déjà fait, ce que chaque commande a réellement renvoyé, et pourquoi ça a échoué. Lis-le avant chaque nouvelle action. Dans ton <think>, appuie-toi dessus : écris le résultat réel, la cause, puis ce que tu fais pour corriger. Ne refais jamais une étape réussie.\n" + led.text;
    if (led.alerts.length) out += "\n\n### ALERTES (faits constatés)\n" + led.alerts.map(x => '- ' + x).join('\n');
  } else if (cur) {
    // Début de tour : état de la tâche précédente, pour reprendre là où elle s'est arrêtée.
    const idx = S.msgs.indexOf(cur);
    for (let i = idx - 1; i >= 0; i--) {
      const pm = S.msgs[i];
      if (pm.role === 'bot' && pm.steps && pm.steps.some(x => x.name !== 'Réflexion' && x.name !== 'Approfondissement')) {
        const led = npsStepsLedger(pm.steps.filter(x => x.status !== 'loading'));
        out += "\n\n## ÉTAT DE LA TÂCHE PRÉCÉDENTE (avant ce message)\nVoici où tu en étais. Si l'utilisateur te demande de continuer, de réessayer ou de finir, pars de cet état : ne recommence pas depuis zéro et ne refais pas ce qui a réussi.\n" + led.text;
        if (led.alerts.length) out += "\n\n### ALERTES\n" + led.alerts.map(x => '- ' + x).join('\n');
        break;
      }
    }
  }
  return out;
}
// Cause réelle d'un échec, lue dans le rapport d'erreur (jamais inventée).
function npsFailureCause(resText) {
  const t = String(resText || '');
  const clean = x => x.replace(/^[^\p{L}\p{N}]+/u, '').replace(/\s+/g, ' ').trim();
  let cause = '';
  const d = t.match(/\[DIAGNOSTIC[^:\]]*:\s*([^\]]+)\]/);
  if (d) cause = d[1].trim().toLowerCase();
  if (!cause) {
    const body = t.split('[DIAGNOSTIC')[0].split('\n').map(clean).filter(x => x.length > 3);
    // première ligne d'erreur réelle (sortie du programme), sinon première ligne utile hors en-tête
    cause = body.find(x => /error|erreur|not found|introuvable|denied|refus|failed|échec|invalid|403|404|401|timeout/i.test(x) && !/^(ÉCHEC|ECHEC|ERREUR)\s+(DU|D')/i.test(x)) || body[1] || body[0] || 'erreur sans détail';
  }
  cause = cause.slice(0, 170);
  return cause + (/[.!?]$/.test(cause) ? '' : '.');
}
// Bloc « [DIAGNOSTIC …] » produit par l'application, affiché dans l'étape en échec.
function npsExtractDiagnosis(resText) {
  const m = String(resText || '').match(/\[DIAGNOSTIC[^\]]*\][\s\S]*$/);
  return m ? m[0].trim().slice(0, 900) : '';
}
// Téléchargement des étapes d'un message en Markdown (icônes et statuts comme dans l'interface).
function downloadStepsTxt(msgId) {
  const m = S.msgs.find(x => x.id === msgId);
  if (!m || !m.steps || !m.steps.length) { toast('Aucune étape à télécharger', true); return; }
  const mark = s => s.status === 'error' ? 'ÉCHEC' : (s.status === 'loading' ? 'EN COURS' : 'OK');
  const fence = t => '````\n' + String(t).replace(/````/g, '\u2032\u2032\u2032\u2032') + '\n````';
  const L = ['# Fable Fast — Étapes de la tâche', '', '- **Date** : ' + new Date().toLocaleString('fr-FR'), "- **Nombre d'étapes** : " + m.steps.length, '', '---', ''];
  m.steps.forEach((s, i) => {
    L.push('## Étape ' + (i + 1) + ' — ' + (s.name || 'Étape') + ' · ' + mark(s), '');
    if (s.summary) L.push('> ' + String(s.summary).replace(/\n+/g, ' '), '');
    if (s.live && typeof s.live.elapsed === 'number') L.push('**Durée** : ' + Math.floor(s.live.elapsed / 60) + ':' + String(s.live.elapsed % 60).padStart(2, '0'), '');
    if (s.diagnosis) L.push('**Diagnostic**', '', fence(s.diagnosis), '');
    if (s.sources && s.sources.length) L.push('**Sources**', '', s.sources.map(x => '- ' + (x.title || '') + ' ' + (x.url || '')).join('\n'), '');
    if (s.details) {
      if (s.name === 'Réflexion' || s.name === 'Approfondissement') L.push('**Raisonnement**', '', String(s.details).split('\n').map(x => '> ' + x).join('\n'), '');
      else {
        const { params, result } = npsStepParts(s);
        if (params) L.push('**Paramètres**', '', fence(JSON.stringify(params, null, 2)), '');
        if (result) L.push('**Résultat**', '', fence(result), '');
        if (!params && !result) L.push(fence(s.details), '');
      }
    }
    L.push('---', '');
  });
  const blob = new Blob(['\ufeff' + L.join('\n')], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'nps_etapes_' + msgId + '.md';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  toast('Étapes téléchargées');
}
function parseBlocks(raw){
  const blocks=[]; let text=raw;
  const re=/```(\w*)[ \t]*([^\n`]*)\n?([\s\S]*?)```/g; let m;
  while((m=re.exec(raw))!==null){
    const filename = (m[2]||'').trim();
    blocks.push({lang:m[1]||'text', filename: filename||null, content:m[3].trim()});
    text=text.replace(m[0],'[code]');
  }
  // Action JSON écrite sans les ``` : on la récupère quand même comme vraie action (sinon l'outil ne partait jamais
  // et il restait une « } » à l'écran).
  if (!blocks.some(b => b.lang === 'json' && b.content.includes('"action"'))) {
    const cut = text.lastIndexOf('</think>');
    const head = cut >= 0 ? text.slice(0, cut + 8) : '';
    let tail = cut >= 0 ? text.slice(cut + 8) : text;
    const f = npsFindActionJson(tail);
    if (f) { blocks.push({ lang: 'json', filename: null, content: f.raw }); tail = npsStripActionJson(tail); text = head + tail; }
  }
  return{text:text.replace(/\[code\]/g,'').trim(),blocks};
}

// Retire les données lourdes (base64 des images/fichiers) avant la sauvegarde en
// localStorage : c'est ça qui saturait les ~5 Mo de quota du navigateur et faisait
// planter l'enregistrement de l'historique après 2-3 images envoyées. Les données
// restent disponibles en mémoire (S.msgs) pour la session en cours ; seul ce qui
// est persisté est allégé. Le fichier lui-même (nom, type) reste visible dans
// l'historique rechargé, seul l'aperçu binaire disparaît.

// Chemin d'un fichier exporté dans Maker (même règle de nom que saveExportToNpsMemory).
function npsExportPath(name){ return npsMD() + 'exports/' + String(name || 'fichier').split('/').pop().replace(/[^\w.\-]+/g, '_'); }
// Média d'un message restauré depuis l'historique : l'historique ne garde qu'une RÉFÉRENCE, le fichier se recharge depuis GitHub.
const _msgMediaState = new Map();
function npsPendingMediaHtml(m, kind){
  const ref = m[kind + 'Ref']; if (!ref) return '';
  const st = _msgMediaState.get(m.id + kind);
  if (st !== 'fail') npsHydrateMsgMedia(m, kind);
  const nm = esc(ref.name || 'le fichier');
  return `<div ${st === 'fail' ? `onclick="npsRetryMsgMedia('${m.id}','${kind}')" ` : ''}style="margin:8px 0;padding:10px 12px;border-radius:10px;background:var(--bg2);border:1px solid var(--border);font-size:14.5px;opacity:.85;${st === 'fail' ? 'cursor:pointer;' : ''}">${st === 'fail' ? 'Impossible de charger ' + nm + ' depuis GitHub. Touche pour réessayer.' : 'Chargement de ' + nm + '…'}</div>`;
}
async function npsHydrateMsgMedia(m, kind){
  const ref = m[kind + 'Ref'];
  if (!ref || m[kind] || _msgMediaState.get(m.id + kind) === 'loading') return;
  _msgMediaState.set(m.id + kind, 'loading');
  try { m[kind] = await fetchGitHubFileContent(NPS_MEM, ref.path, { binary: true, mime: ref.mime }); _msgMediaState.set(m.id + kind, 'ok'); }
  catch (e) { _msgMediaState.set(m.id + kind, 'fail'); }
  updateMsgEl(m);
}
function npsRetryMsgMedia(id, kind){
  const m = S.msgs.find(x => x.id === id); if (!m) return;
  _msgMediaState.delete(id + kind);
  npsHydrateMsgMedia(m, kind);
}
function stripHeavyDataForStorage(msgs){
  const BIG = 300000;
  return msgs.map(m=>{
    let out = m;
    // Vidéo / image exportée : on garde la référence (chemin dans Maker), pas le base64 — sinon la conversation dépasse 1 Mo et ne se recharge plus.
    ['video', 'image'].forEach(k => { if (typeof m[k] === 'string' && m[k].length > BIG && /^data:/.test(m[k]) && m[k + 'Ref']) { const { [k]: _drop, ...rest } = out; out = rest; } });
    if (m.attachments && m.attachments.length) {
      out = { ...out, attachments: m.attachments.map(a=>{ const {dataUrl, file, _hyd, _hydErr, ...light} = a; return light; }) };
    }
    // Fichiers exportés (mp3, vidéos, archives…) : un seul mp3 de 8 Mo en base64 suffit à remplir tout le stockage local.
    if (Array.isArray(m.codeBlocks) && m.codeBlocks.some(b => b && typeof b.content === 'string' && b.content.length > BIG)) {
      out = { ...out, codeBlocks: m.codeBlocks.map(b => {
        if (!b || typeof b.content !== 'string' || b.content.length <= BIG) return b;
        const head = (/^data:[^,]*,/.exec(b.content) || [''])[0];
        return head ? { ...b, content: head, evicted: true, evictedSize: Math.round((b.content.length - head.length) * 0.75) }
                    : { ...b, content: b.content.slice(0, 20000) + '\n…[tronqué pour l\'enregistrement local]' };
      }) };
    }
    // Résultats d'outils et détails d'étapes : on garde le début, c'est suffisant pour reprendre la conversation.
    if (m.hidden && typeof m.text === 'string' && m.text.length > 8000) out = { ...out, text: m.text.slice(0, 8000) + '\n…[abrégé]' };
    if (typeof m.apiText === 'string' && m.apiText.length > 12000) out = { ...out, apiText: m.apiText.slice(0, 12000) + '\n…[abrégé]' };
    if (Array.isArray(m.steps) && m.steps.some(st => st && typeof st.details === 'string' && st.details.length > 6000)) {
      out = { ...out, steps: m.steps.map(st => (st && typeof st.details === 'string' && st.details.length > 6000) ? { ...st, details: st.details.slice(0, 6000) + '\n…[abrégé]' } : st) };
    }
    return out;
  });
}
