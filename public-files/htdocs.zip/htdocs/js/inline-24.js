(function(){
const root=document.getElementById('ffs');if(!root)return;
const PL=[['tiktok','TikTok'],['instagram','Instagram'],['youtube','YouTube'],['facebook','Facebook']];
const LOGO={
 tiktok:'<svg viewBox="0 0 56 56"><rect width="56" height="56" fill="#000"/><g transform="translate(12 11) scale(1.35)"><path d="M16.2 3c.3 2.3 1.7 3.9 3.8 4.1v3a7 7 0 0 1-3.8-1.2V15a6 6 0 1 1-6-6c.3 0 .6 0 .9.1v3.2a2.9 2.9 0 1 0 1.9 2.7V3z" fill="#25f4ee" transform="translate(-.7 -.5)" /><path d="M16.2 3c.3 2.3 1.7 3.9 3.8 4.1v3a7 7 0 0 1-3.8-1.2V15a6 6 0 1 1-6-6c.3 0 .6 0 .9.1v3.2a2.9 2.9 0 1 0 1.9 2.7V3z" fill="#fe2c55" transform="translate(.7 .5)"/><path d="M16.2 3c.3 2.3 1.7 3.9 3.8 4.1v3a7 7 0 0 1-3.8-1.2V15a6 6 0 1 1-6-6c.3 0 .6 0 .9.1v3.2a2.9 2.9 0 1 0 1.9 2.7V3z" fill="#fff"/></g></svg>',
 instagram:'<svg viewBox="0 0 56 56"><defs><linearGradient id="fsig" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#fdc468"/><stop offset=".45" stop-color="#f0377b"/><stop offset=".75" stop-color="#a135c9"/><stop offset="1" stop-color="#4f5bd5"/></linearGradient></defs><rect width="56" height="56" fill="url(#fsig)"/><g fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><rect x="15" y="15" width="26" height="26" rx="8"/><circle cx="28" cy="28" r="6.5"/></g><circle cx="35.4" cy="20.6" r="1.8" fill="#fff"/></svg>',
 youtube:'<svg viewBox="0 0 56 56"><rect width="56" height="56" fill="#fff"/><g transform="translate(6 6) scale(1.833)"><path fill="#f00" d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></g></svg>',
 facebook:'<svg viewBox="0 0 24 24"><rect width="24" height="24" fill="#1877f2"/><path fill="#fff" d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z"/></svg>'};
const CHEV='<svg class="fs-chev" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>';
const STAR='<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3 6.6 7.2.8-5.4 4.9 1.5 7.1L12 17.8 5.7 21.4l1.5-7.1L1.8 9.4l7.2-.8z"/></svg>';
const np=v=>window.ffNp?window.ffNp(v):String(v||'tiktok').toLowerCase();
const rd=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?d:v;}catch(e){return d;}};
const wr=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}};
const name=p=>(PL.find(x=>x[0]===p)||[0,p])[1];
const say=(m,bad)=>{try{toast(m,!!bad);}catch(e){}};
function clean(v){let u=String(v||'').trim();if(/\.(?:com|be)\//i.test(u))u=u.replace(/^.*?\.(?:com|be)\/(?:(?:c|user)\/)?@?/i,'').replace(/[\/?#&].*$/,'');return u.replace(/^@+/,'').replace(/\s+/g,'');}
function accts(){const a=Object.assign({},rd('ff_accounts',{})||{});const m=rd('ff_main',null);if(m&&m.u&&!a[np(m.p)])a[np(m.p)]=String(m.u).replace(/^@+/,'');return a;}
function mainP(){const m=rd('ff_main',null);return m&&m.u?np(m.p):null;}
function saveAll(a,main){
  wr('ff_accounts',a);
  if(main&&a[main])wr('ff_main',{p:main,u:a[main]});else{try{localStorage.removeItem('ff_main');}catch(e){}}
  try{window.ffSync&&window.ffSync.flush();}catch(e){}
  paint();
}
let cur='settings',pushed=false,swallow=false,edit=null;
const $=s=>root.querySelector(s);
function show(n){cur=n;root.querySelectorAll('.fs-screen').forEach(m=>m.hidden=(m.dataset.s!==n));root.scrollTop=0;if(n==='api'){$('#fs-msg').textContent='';fillApi();}paint();}
function paint(){
  const a=accts(),m=mainP(),n=PL.filter(p=>a[p[0]]).length;
  $('#fs-prof-sub').textContent=n?(n+' compte'+(n>1?'s':'')+' connecté'+(n>1?'s':'')+(m?' · '+name(m)+' principal':'')):'Aucun compte connecté';
  const order=PL.map(x=>x[0]).sort((x,y)=>(y===m)-(x===m));
  $('#fs-accts').innerHTML=order.map(p=>{const u=a[p],isM=p===m;
    return '<button class="fs-card'+(isM?' fs-main':'')+'" data-acc="'+p+'"><span class="fs-logo">'+LOGO[p]+'</span><span class="fs-txt"><b>'+name(p)+(isM?' <span class="fs-badge">'+STAR+'Principal</span>':'')+'</b><small>'+(u?(p==='facebook'?'':'@')+u.replace(/</g,'&lt;'):'Touche pour ajouter ton pseudo')+'</small></span>'+(u?'<span class="fs-pill"><i></i>Connecté</span>':'<span class="fs-pill fs-warn"><i></i>À renseigner</span>')+'</button>';}).join('');
}
function pill(id,ok,txtOk,txtNo){const e=$(id);e.className='fs-pill'+(ok?'':' fs-warn');e.innerHTML='<i></i>'+(ok?txtOk:txtNo);}
const PROV={gemini:'Google Gemini',anthropic:'Anthropic / Claude',openai:'OpenAI',universel:'Clé universelle'};
let prov='universel';
function activeProv(){if(S.gem)return 'gemini';if(S.ant)return 'anthropic';if(S.oai)return 'openai';if(S.customModel&&S.customModel.key)return 'universel';return null;}
function activeName(){const p=activeProv();return p==='universel'?((S.customModel&&S.customModel.name)||'Modèle personnalisé'):(p?PROV[p]:'Aucun configuré');}
function brainKey(){return S.gem||S.ant||S.oai||(S.customModel&&S.customModel.key)||'';}
function provUI(){
  $('#fs-mact').textContent=activeName();
  const ph={gemini:'Colle ta clé Gemini (AIza…)',anthropic:'Colle ta clé Claude (sk-ant-…)',openai:'Colle ta clé OpenAI (sk-…)',universel:'Colle n\'importe quelle clé API ici'}[prov];
  $('#fs-brain').placeholder=ph;
  $('#fs-msheet').querySelectorAll('[data-prov]').forEach(r=>r.classList.toggle('on',r.dataset.prov===prov));
  $('#fs-man').style.display=(prov==='universel'&&$('#fs-man').dataset.open==='1')?'block':'none';
  $('#fs-manl').style.display=prov==='universel'?'':'none';
}
function fillApi(){
  $('#fs-jina').value=localStorage.getItem('nps_jina_key')||'';$('#fs-gh').value=S.tok||'';$('#fs-brain').value=brainKey();prov=activeProv()||'universel';provUI();
  pill('#fs-p-jina',!!$('#fs-jina').value,'Enregistrée','Facultative');pill('#fs-p-gh',!!S.tok,'Enregistré','À renseigner');pill('#fs-p-brain',!!brainKey(),'Enregistrée','À renseigner');
}
async function saveKeys(){
  const j=$('#fs-jina').value.trim().replace(/\s+/g,''),g=$('#fs-gh').value.trim().replace(/\s+/g,''),b=$('#fs-brain').value.trim().replace(/\s+/g,'');
  try{if(j)localStorage.setItem('nps_jina_key',j);else localStorage.removeItem('nps_jina_key');}catch(e){}
  if(b&&b!==brainKey()||(b&&prov!==activeProv())){
    const msg=$('#fs-msg');msg.style.color='#a3a4ae';msg.textContent='';
    if(prov==='universel'){
      document.getElementById('cm-key').value=b;
      const mu=document.getElementById('cm-manual-url'),mn=document.getElementById('cm-name');
      if(mu)mu.value=$('#fs-man').dataset.open==='1'?$('#fs-murl').value.trim():'';if(mn)mn.value=$('#fs-mname').value.trim();
      msg.textContent='Test de la clé sur les fournisseurs connus…';
      await detectAndSaveCustomModel();
      const ok=!!(S.customModel&&S.customModel.key===b);
      msg.style.color=ok?'#4ade80':'#f87171';msg.textContent=ok?(S.customModel.name+' détecté et connecté'):(document.getElementById('cm-provider-label').textContent||'Clé non reconnue');
      if(!ok){$('#fs-man').dataset.open='1';}
    }else{
      const k={gemini:'gem',anthropic:'ant',openai:'oai'}[prov],id={gem:'gemtoken',ant:'anttoken',oai:'oaitoken'}[k];
      document.getElementById(id).value=b;await saveApi(id,k);
    }
  }
  if(g&&g!==S.tok){const el=document.getElementById('ghtoken');if(el){el.value=g;await saveApi('ghtoken','gh');}}
  if(!g&&S.tok){S.tok='';try{localStorage.removeItem('nps_gh_tok');}catch(e){}}
  fillApi();
}
function sheet(p){
  edit=p;const a=accts(),m=mainP(),u=a[p]||'';
  $('#fs-sh-t').innerHTML='<span class="fs-logo" style="width:44px;height:44px">'+LOGO[p]+'</span>'+name(p);
  $('#fs-sh-p').textContent=p==='facebook'?'Le nom de ta page, comme dans son adresse facebook.com/…':'Ton pseudo exact, comme sur '+name(p)+'.';
  $('#fs-sh-in').value=u;$('#fs-sh-main').style.display=(u&&p!==m)?'':'none';$('#fs-sh-del').style.display=u?'':'none';
  $('#fs-sheet').classList.add('on');setTimeout(()=>$('#fs-sh-in').focus(),80);
}
const shut=()=>{$('#fs-sheet').classList.remove('on');edit=null;};
function open(n){
  root.classList.add('on');show(n||'settings');
  if(!pushed){try{history.pushState({ffs:1},'');pushed=true;}catch(e){}}
}
function close(fromPop){
  shut();root.classList.remove('on');
  if(pushed&&!fromPop){swallow=true;try{history.back();}catch(e){swallow=false;}}
  pushed=false;
}
window.ffsOpen=open;window.ffsClose=close;
window.addEventListener('popstate',e=>{
  if(swallow){swallow=false;e.stopImmediatePropagation();return;}
  if(!root.classList.contains('on'))return;
  e.stopImmediatePropagation();pushed=false;
  if($('#fs-sheet').classList.contains('on')){shut();}
  if(cur!=='settings'){show('settings');}else{close(true);return;}
  try{history.pushState({ffs:1},'');pushed=true;}catch(x){}
},true);
root.addEventListener('click',async e=>{
  const t=e.target.closest('[data-go],[data-x],[data-acc],[data-eye],[data-prov],#fs-mbtn,#fs-msh-x,#fs-manl,#fs-save,#fs-sh-save,#fs-sh-main,#fs-sh-del,#fs-sh-x');if(!t)return;
  if(t.dataset.prov){prov=t.dataset.prov;$('#fs-msheet').classList.remove('on');provUI();return;}
  if(t.id==='fs-mbtn'){provUI();$('#fs-msheet').classList.add('on');return;}
  if(t.id==='fs-msh-x'){$('#fs-msheet').classList.remove('on');return;}
  if(t.id==='fs-manl'){e.preventDefault();const m=$('#fs-man');m.dataset.open=m.dataset.open==='1'?'0':'1';provUI();return;}
  if(t.dataset.go){show(t.dataset.go);return;}
  if(t.dataset.x==='close'){close();return;}
  if(t.dataset.x==='logout'){try{openLogoutModal();}catch(x){}return;}
  if(t.dataset.acc){sheet(t.dataset.acc);return;}
  if(t.dataset.eye){const i=document.getElementById(t.dataset.eye);i.type=i.type==='password'?'text':'password';return;}
  if(t.id==='fs-save'){t.disabled=true;try{await saveKeys();say('Enregistré');}finally{t.disabled=false;}return;}
  if(t.id==='fs-sh-x'){shut();return;}
  const a=accts();let m=mainP();
  if(t.id==='fs-sh-save'){const u=clean($('#fs-sh-in').value);if(!u){say('Entre un pseudo',true);return;}a[edit]=u;if(!m)m=edit;
    else if(m===edit){}saveAll(a,m);shut();say(name(edit||'')+' enregistré');return;}
  if(t.id==='fs-sh-main'){m=edit;saveAll(a,m);shut();say(name(m)+' est ton compte principal');return;}
  if(t.id==='fs-sh-del'){const was=edit;delete a[was];if(m===was)m=PL.map(x=>x[0]).find(p=>a[p])||null;saveAll(a,m);shut();say('Compte retiré');return;}
});
root.querySelector('#fs-sh-in').addEventListener('keydown',e=>{if(e.key==='Enter')root.querySelector('#fs-sh-save').click();});
/* aiguillage : tous les anciens accès aux paramètres ouvrent ces écrans */
const _sv=window.showView;
window.showView=function(id){if(id==='settings')return open('settings');if(id==='profile')return open('profil');if(id==='apikeys')return open('api');return _sv.apply(this,arguments);};
/* clé Jina : ajoutée automatiquement aux lectures r.jina.ai / s.jina.ai */
const _f=window.fetch;
window.fetch=function(u,o){try{const url=typeof u==='string'?u:(u&&u.url)||'';if(/^https:\/\/[rs]\.jina\.ai\//.test(url)){const k=localStorage.getItem('nps_jina_key');if(k){o=Object.assign({},o);const h=new Headers(o.headers||{});if(!h.has('Authorization'))h.set('Authorization','Bearer '+k);o.headers=h;}}}catch(e){}return _f.call(this,u,o);};

})();
