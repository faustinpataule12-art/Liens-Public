function ixC(p,img,k){
  const im=Array.isArray(img)?img.filter(Boolean):(img?[img]:[]);
  if(!im.length)return k==='g'?[{text:p}]:p;
  const pr=u=>{const m=/^data:([^;]+);base64,(.*)$/.exec(u)||[];return {mt:m[1]||'image/jpeg',b:m[2]||''};};
  if(k==='a')return [...im.map(u=>{const x=pr(u);return {type:'image',source:{type:'base64',media_type:x.mt,data:x.b}};}),{type:'text',text:p}];
  if(k==='g')return [...im.map(u=>{const x=pr(u);return {inlineData:{mimeType:x.mt,data:x.b}};}),{text:p}];
  return [{type:'text',text:p},...im.map(u=>({type:'image_url',image_url:{url:u}}))];
}
/* Appel IA ponctuel : utilise l'API configuree par l'utilisateur, quelle qu'elle soit.
   Les API disposant d'une cle sont essayees a tour de role : la premiere qui repond fait office de modele. */
async function ixAsk(sys, prompt, maxTok, img){
  const J={'Content-Type':'application/json'},tries=[],sel=String(S.model||'');
  const cm=(S.customModel&&S.customModel.key)?S.customModel:null;
  const jt=async(r)=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.json();};
  const callCustom=async(sig)=>{
    if(cm.provider==='anthropic'){const d=await jt(await fetch(cm.endpoint,{method:'POST',signal:sig,headers:{...J,'x-api-key':cm.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:cm.model,max_tokens:maxTok,system:sys,messages:[{role:'user',content:ixC(prompt,img,'a')}]})}));return (d.content||[]).map(c=>c.text||'').join('');}
    if(cm.provider==='gemini'){const d=await jt(await fetch(cm.endpoint+cm.model+':generateContent?key='+cm.key,{method:'POST',signal:sig,headers:J,body:JSON.stringify({system_instruction:{parts:[{text:sys}]},generationConfig:{maxOutputTokens:maxTok},contents:[{role:'user',parts:ixC(prompt,img,'g')}]})}));return (d.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('');}
    const d=await jt(await fetch(cm.endpoint,{method:'POST',signal:sig,headers:{...J,'Authorization':'Bearer '+cm.key},body:JSON.stringify({model:cm.model,max_tokens:maxTok,messages:[{role:'system',content:sys},{role:'user',content:ixC(prompt,img,'o')}]})}));return d.choices?.[0]?.message?.content||'';
  };
  const callGem=async(sig,model)=>{const d=await jt(await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent?key='+S.gem,{method:'POST',signal:sig,headers:J,body:JSON.stringify({system_instruction:{parts:[{text:sys}]},generationConfig:{maxOutputTokens:maxTok},contents:[{role:'user',parts:ixC(prompt,img,'g')}]})}));return (d.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('');};
  const callAnt=async(sig)=>{const d=await jt(await fetch('https://api.anthropic.com/v1/messages',{method:'POST',signal:sig,headers:{...J,'x-api-key':S.ant,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:sel,max_tokens:maxTok,system:sys,messages:[{role:'user',content:ixC(prompt,img,'a')}]})}));return (d.content||[]).map(c=>c.text||'').join('');};
  const callOai=async(sig)=>{const model=(sel==='custom-openai'||!sel)?'gpt-4o':sel;const d=await jt(await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',signal:sig,headers:{...J,'Authorization':'Bearer '+S.oai},body:JSON.stringify({model,max_tokens:maxTok,messages:[{role:'system',content:sys},{role:'user',content:ixC(prompt,img,'o')}]})}));return d.choices?.[0]?.message?.content||'';};
  const callProxy=async(sig)=>{if(img)throw new Error('Les images ne sont pas prises en charge par ce modèle');const d=await jt(await fetch('/api/gemini/generate',{method:'POST',signal:sig,headers:J,body:JSON.stringify({model:sel,prompt:prompt,system_instruction:sys})}));return d.text||'';};
  const add=(id,fn)=>{if(!tries.some(t=>t.id===id))tries.push({id,fn});};
  /* une seule API est configuree a la fois : on utilise exactement celle-la, avec le modele qui y est enregistre (aucun modele impose) */
  if(sel==='custom'&&cm)add('custom',callCustom);
  else if(S.gem)add('gem',s=>callGem(s,sel));
  else if(S.ant)add('ant',callAnt);
  else if(S.oai)add('oai',callOai);
  else if(cm)add('custom',callCustom);
  else if(sel.startsWith('gemini'))add('proxy',callProxy);
  if(!tries.length)throw new Error('Aucune API IA configurée. Ajoute une clé dans les paramètres.');
  let last=null;
  for(const t of tries){
    const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),90000);
    try{const out=await t.fn(ctl.signal);if(String(out||'').trim())return out;last=new Error('Réponse vide');}
    catch(e){last=e;}finally{clearTimeout(to);}
  }
  const lm=String(last&&last.message||'erreur');
  if(img&&/HTTP 4(00|15|22)/.test(lm))throw new Error('Le modèle configuré ne lit pas les images. Choisis une IA avec vision dans Modèle & Clés API.');
  throw new Error('L\'API configurée n\'a pas répondu ('+lm+').');
}
/* ===== FABLE FAST : flux "Creer un script" (ideas -> accroches -> style -> script) ===== */
(function(){
const host=document.createElement('div');host.id='ix-host';
host.style.cssText='display:none;position:fixed;inset:0;z-index:9000;overflow-y:auto;background:#0f1116';
document.body.appendChild(host);
const R=host.attachShadow({mode:'open'});
R.innerHTML="<style>\n:host{--bg:#0f1116;--card:#1b1c22;--line:#2a2b33;--mut:#9a9aa6;--lil:#c9a0f5;--grad:linear-gradient(90deg,#e86bb0,#5b8cf0,#a77bf0)}\n*{box-sizing:border-box;margin:0}\n.app{color:#fff;font-family:system-ui,sans-serif;padding-top:env(safe-area-inset-top)}\n.app{max-width:480px;margin:0 auto;min-height:100vh;display:flex;flex-direction:column;\n  background:linear-gradient(to bottom,rgba(15,17,22,0) 130px,var(--bg) 360px),linear-gradient(115deg,#5560b8,#6a3fa0 55%,#a35cbf)}\nheader{display:flex;align-items:center;justify-content:space-between;padding:14px 12px}\nheader h2{font-size:26px}\n.ico{width:42px;height:42px;background:none;border:none;color:#fff;display:flex;align-items:center;justify-content:center}\n.ico svg{width:26px;height:26px}\n.s{display:none;flex:1;flex-direction:column;padding:0 20px 24px;animation:in .35s}\n.s.on{display:flex}\n@keyframes in{from{opacity:0;transform:translateY(10px)}}\nh1{font-size:27px;line-height:1.2;margin-bottom:10px}\n.sub{color:#c5bfd8;font-size:15.5px;line-height:1.45}\n.c{text-align:center}\ntextarea{margin:36px 0 auto;min-height:190px;width:100%;padding:18px;font-size:18px;color:#fff;background:#1d1e24;\n  border:2px solid #b9a2f5;border-radius:26px;box-shadow:0 0 0 4px rgba(185,162,245,.25);outline:none;resize:none;font-family:inherit}\n.foot{position:sticky;bottom:0;margin:auto -20px -24px;padding:26px 20px 24px;background:linear-gradient(to bottom,rgba(15,17,22,0),var(--bg) 40%);display:flex;flex-direction:column}\n.foot .go{margin-top:0}.foot .go+.go,.foot .go+.lien{margin-top:12px}\n.go{width:100%;margin-top:16px;padding:18px;font-size:18px;font-weight:700;color:#fff;border:2px solid transparent;border-radius:34px;font-family:inherit;\n  background:linear-gradient(var(--bg),var(--bg)) padding-box,var(--grad) border-box}\n.go:disabled{opacity:.4}\n.lien{background:none;border:none;color:var(--mut);text-decoration:underline;margin-top:14px;font-size:15px;align-self:center}\n/* écran 0 : les 4 entrées */\n.big{width:64px;height:64px;margin:34px auto 18px;border-radius:16px;background:#23242b;display:flex;align-items:center;justify-content:center;color:#cfc4ee;padding:16px}\n.opt{display:flex;align-items:center;gap:14px;width:100%;padding:17px 16px;margin-top:12px;border-radius:16px;background:var(--card);\n  border:1px solid var(--line);color:#fff;font-size:16px;font-weight:600;text-align:left;font-family:inherit}\n.opt span{width:24px;height:24px;color:var(--mut)}.opt span svg,.big svg{width:100%;height:100%}\n.hint{color:var(--mut);font-size:13px;text-align:center;margin-top:30px}\n/* chargement : vague décorative + carte + 3 lignes + stepper */\n.lcard{margin:6px 0 20px;padding:18px;border-radius:24px;background:#16171c;border:1px solid var(--line)}\n#lt{font-size:17px;font-weight:700;text-align:center;margin:6px 0 20px;background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}\n.stp{position:relative;display:flex;justify-content:space-between;padding:0 6%}\n.trk{position:absolute;top:10px;left:14%;right:14%;height:3px;background:var(--line);border-radius:3px;overflow:hidden}\n.trk i{display:block;height:100%;width:0;background:var(--grad);transition:width .6s;position:relative;overflow:hidden}\n.trk i::after{content:'';position:absolute;top:0;bottom:0;left:0;width:45%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.85),transparent);transform:translateX(-120%);animation:sweep 1.25s ease-in-out infinite}\n@keyframes sweep{to{transform:translateX(260%)}}\n.n{position:relative;text-align:center;font-size:11px;color:var(--mut);width:70px}\n.n b{position:relative;display:block;width:22px;height:22px;margin:0 auto 6px;border-radius:50%;background:#0f1116;border:2px solid #fff;color:#fff;font-size:13px;line-height:18px}\n.n.act{color:#fff}.n.act b{border-color:#e86bb0;background:linear-gradient(135deg,#e86bb0,#a77bf0);animation:pl 1s infinite alternate}\n.n.act b::after{content:'';position:absolute;inset:-6px;border-radius:50%;border:2px solid #e86bb0;animation:ripple 1.3s ease-out infinite}\n.n.ok{color:#fff}.n.ok b{background:linear-gradient(135deg,#1fb77a,#2fd396);border-color:#1fb77a}\n@keyframes pl{to{transform:scale(1.15)}}\n@keyframes ripple{0%{opacity:.8;transform:scale(.7)}100%{opacity:0;transform:scale(1.5)}}\n/* petite animation de chargement (sans texte) */\n.ldf{--a:#a78bfa;--b:#4cc3ff;--c:#e56fd0;display:grid;place-items:center;margin:30px 0 6px;padding:24px 18px;overflow:hidden;border-radius:28px;background:#15161c;border:1px solid #ffffff18;box-shadow:0 20px 60px #0000004d}\n.ldq{width:min(100%,440px);display:flex;flex-direction:column;gap:10px;position:relative}\n.ldq b{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:18px;background:#171926;border:1px solid #ffffff12;opacity:0;animation:ldBi 6s ease infinite;animation-delay:calc(var(--i) * .5s)}\n.ldq b::before{content:'';width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--c),var(--b));flex:none}\n.ldq b::after{content:'';flex:1;height:21px;background:linear-gradient(#ffffff2e,#ffffff2e) 0 0/100% 7px no-repeat,linear-gradient(#ffffff1f,#ffffff1f) 0 14px/60% 7px no-repeat}\n.ldq b span{width:10px;height:10px;border-radius:50%;background:#34d399;flex:none}\n.ldq b:nth-child(2) span{background:#fbbf24}\n.ldq b:nth-child(4) span{background:#fb7185}\n.ldq i{position:absolute;left:-8px;right:-8px;height:50px;border-radius:18px;border:1.5px solid var(--a);box-shadow:0 0 24px color-mix(in srgb,var(--a) 55%,transparent);animation:ldSc 3s ease-in-out infinite alternate}\n@keyframes ldBi{0%{opacity:0;transform:translateY(14px)}12%,80%{opacity:1;transform:none}92%,100%{opacity:0}}\n@keyframes ldSc{from{top:0}to{top:calc(100% - 50px)}}\n@media (prefers-reduced-motion:reduce){.ldq b,.ldq i{animation-duration:14s!important}.trk i::after,.n.act b::after{animation:none!important}}\n/* idées + styles */\n.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:20px 0 auto}\n.card{display:flex;flex-direction:column;gap:7px;text-align:left;color:#fff;padding:14px;border-radius:18px;background:var(--card);border:1.5px solid var(--line);font-family:inherit}\n.card.on{border-color:transparent;background:linear-gradient(var(--card),var(--card)) padding-box,var(--grad) border-box}\n.tag{font-size:12px;font-weight:700;color:var(--lil);text-transform:uppercase;letter-spacing:.4px}\n.card b{font-size:16px;line-height:1.25}\n.card small{font-size:12.5px;color:var(--mut);line-height:1.35}\n.bar{height:5px;background:#2d2e36;border-radius:3px;margin-top:auto}\n.bar i{display:block;height:100%;background:var(--grad);border-radius:3px}\n.card em{font-size:11px;color:var(--mut);font-style:normal}\n.stl .tag{text-transform:none;font-size:14px}\n.stl{align-items:center;text-align:center}.rec{color:#fff!important;background:var(--grad);border-radius:8px;padding:2px 8px;font-weight:700}\n.hook{text-align:left;margin:14px 0 0;padding:16px;font-size:15.5px;line-height:1.4;font-weight:500;color:var(--lil)}\n.hook small{display:block;margin-top:6px;font-size:11.5px;color:var(--mut)}\n/* script */\n.box{margin:14px 0;padding:18px;border-radius:18px;background:#16171c;border:1px solid var(--line);font-size:15px;line-height:1.55;white-space:pre-wrap;outline:none}\n.box[contenteditable=true]{border-color:#a77bf0}\n.tools{display:flex;justify-content:flex-end;gap:18px;margin-top:10px}\n.tools button{background:#1d1e24;border:1px solid var(--line);border-radius:14px;color:#ddd;font-size:13.5px;padding:7px 14px;font-family:inherit}\n.thumbs{display:flex;gap:12px;margin:6px 0}\n.thumbs button svg{width:22px;height:22px}.thumbs button{flex:1;display:flex;justify-content:center;color:#ddd;padding:12px;border-radius:14px;background:var(--card);border:1px solid var(--line)}\n.thumbs button.on{border-color:#a77bf0;background:#2a2140}\n/* prompteur */\n#pr{padding-bottom:20px}\n.pbox{flex:1;min-height:360px;max-height:60vh;overflow:hidden;position:relative;border-radius:22px;background:#0b0c10;border:1px solid var(--line);\n  -webkit-mask-image:linear-gradient(transparent,#000 14%,#000 86%,transparent);mask-image:linear-gradient(transparent,#000 14%,#000 86%,transparent)}\n#ptxt{padding:46% 22px 46%;font-size:26px;line-height:1.5;font-weight:600;text-align:center;will-change:transform}\n.pctl{display:flex;align-items:center;justify-content:center;gap:26px;margin:18px 0 8px}\n.pctl button{background:#1d1e24;border:1px solid var(--line);color:#fff;border-radius:50%;width:56px;height:56px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:inherit}\n.pctl button svg{width:22px;height:22px}.pctl small{font-size:9px;color:var(--mut);margin-top:1px}\n.pctl .main{width:74px;height:74px;background:var(--grad);border:none}.pctl .main svg{width:30px;height:30px}\n.pctl2{display:flex;align-items:center;justify-content:center;gap:18px;color:var(--mut);font-size:14px}\n.pctl2 button{background:#1d1e24;border:1px solid var(--line);color:#fff;border-radius:12px;padding:8px 14px;font-family:inherit;font-size:15px}\n\n#err{margin:30px 0;padding:22px;border-radius:24px;background:#16171c;border:1px solid var(--line);text-align:center}\n#err p{font-size:16px;line-height:1.45;margin-bottom:6px}\n.tabs{display:flex;gap:8px;margin-top:10px}\n.tabs button{flex:1;padding:10px 6px;border-radius:14px;background:var(--card);border:1px solid var(--line);color:#ddd;font:inherit;font-size:14px}\n.tabs button.on{border-color:#a77bf0;background:#2a2140;color:#fff}\n.hg{margin-bottom:16px}.hg .row{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}\n.hg em{font-style:normal;font-size:13.5px;color:#cfc4ee;background:#23242b;border:1px solid var(--line);border-radius:12px;padding:5px 11px}\n.mini{margin-top:10px;background:#1d1e24;border:1px solid var(--line);border-radius:14px;color:#ddd;font:inherit;font-size:13.5px;padding:8px 14px}\n.fld{margin-top:16px}.fld>label{display:block;font-size:13px;color:#c5bfd8;margin-bottom:6px;font-weight:600}.fld>label small{color:var(--mut);font-weight:400}\n.fld input.num,.fld textarea.num,textarea.num{width:100%;color:#fff;background:#1d1e24;border:2px solid #3b3c47;border-radius:16px;outline:none;font-family:inherit;font-size:16px;padding:14px;line-height:1.4;margin-top:0;min-height:0;box-shadow:none}\ntextarea.num{min-height:84px;resize:vertical}\n.fld input.num:focus,textarea.num:focus{border-color:#b9a2f5}\n.chips{display:flex;flex-wrap:wrap;gap:8px}\n.chip{padding:11px 16px;border-radius:22px;background:var(--card);border:1.5px solid var(--line);color:#ddd;font:inherit;font-size:15px}\n.chip.on{border-color:transparent;background:linear-gradient(#2a2140,#2a2140) padding-box,var(--grad) border-box;color:#fff}\n.pc{margin-top:14px;padding:14px;border-radius:18px;background:#16171c;border:1px solid var(--line)}\n.pc h3{display:flex;justify-content:space-between;align-items:center;font-size:13px;letter-spacing:.5px;text-transform:uppercase;color:var(--lil);margin-bottom:4px}\n.pc h3 button{background:none;border:none;color:var(--mut);text-decoration:underline;font-size:13px;text-transform:none;letter-spacing:0}\n.ob{margin-top:12px;padding:14px;border-radius:16px;background:#16171c;border:1px solid var(--line);font-size:14.5px;line-height:1.5}\n.ob .tag{display:block;margin-bottom:6px}\n.ob p{font-size:14.5px;line-height:1.5;white-space:pre-wrap;word-break:break-word}\n.ob p[contenteditable=true]{outline:none;border:1px dashed #a77bf0;border-radius:8px;padding:6px}\n.ob .bt{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}\n.ob .bt button{background:#1d1e24;border:1px solid var(--line);border-radius:12px;color:#ddd;font-size:13px;padding:8px 14px;font-family:inherit}\n.hrow{display:flex;align-items:flex-start;gap:12px}.hrow .sub{flex:1}\n.wand{flex:none;width:46px;height:46px;border-radius:50%;border:2px solid transparent;color:#fff;display:grid;place-items:center;background:linear-gradient(var(--card),var(--card)) padding-box,var(--grad) border-box}\n.wand svg{width:22px;height:22px}.wand.spin svg{animation:rot .8s linear infinite}.wand:disabled{opacity:.75}\n@keyframes rot{to{transform:rotate(360deg)}}\n.sg{margin-top:8px}.mini:disabled{opacity:.6}\n.rsb{margin-top:18px;display:flex;flex-direction:column}.rsb .two{display:flex;gap:8px;margin-top:12px}.rsb .two .mini{flex:1;margin-top:0}.rsb .go+.two+.go{margin-top:14px}\n#tst{position:fixed;left:50%;bottom:24px;transform:translateX(-50%) translateY(30px);opacity:0;pointer-events:none;background:#2a2140;border:1px solid #a77bf0;color:#fff;border-radius:14px;padding:11px 16px;font-size:14px;max-width:90%;text-align:center;transition:.25s;z-index:5}\n#tst.show{opacity:1;transform:translateX(-50%)}\n.grid{grid-template-columns:1fr}.why{font-size:12.5px;color:#b9b4cc;line-height:1.4}\n.s.hw{position:relative}.wand.fl{position:absolute;right:16px;top:4px;z-index:2}.s.hw>h1{padding:0 54px}.s.hw>.sub.c{padding:0 54px}\n\n.foot{gap:8px;padding:18px 20px 16px}.foot .go,.foot .go+.go{margin-top:0;padding:14px;font-size:16.5px;border-radius:28px}\n.go.sec{border-color:#3b3c47;background:linear-gradient(var(--bg),var(--bg)) padding-box,#3b3c47 border-box;color:#d6d2e4;font-weight:600;font-size:15px!important;padding:11px!important}\n.row2{display:flex;gap:8px}.row2 .go{flex:1;margin-top:0}\n.dt{margin-top:16px;border:1px solid var(--line);border-radius:16px;padding:12px 14px;background:#16171c}.dt summary{font-size:14.5px;color:#cfc4ee;cursor:pointer}.dt .fld:first-of-type{margin-top:10px}\n.grid{margin-bottom:12px}\n\n#sv_c,#ss_c{display:grid;grid-template-columns:1fr 1fr;gap:8px}\n.chip.sty{border-radius:16px;text-align:left;padding:11px 12px;display:flex;flex-direction:column;gap:2px;line-height:1.25}\n.chip.sty b{font-size:15px;color:#fff}.chip.sty small{font-size:12px;color:#aaa6bd}\n<\/style><div class=\"app\">\n<header>\n  <button class=\"ico\" id=\"back\" aria-label=\"Retour\" style=\"visibility:visible\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M15 5l-7 7 7 7\"/><\/svg><\/button>\n  <h2>Fable Fast<\/h2>\n  <button class=\"ico\" id=\"histBtn\" aria-label=\"Historique\"><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z\"/><\/svg><\/button>\n<\/header>\n\n<!-- 0 : Idées créatives -->\n<section class=\"s on\" data-n=\"0\">\n  <div class=\"big\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z\"/><\/svg><\/div>\n  <h1 class=\"c\">Idées créatives<\/h1>\n  <p class=\"sub c\">Des prompts vidéo prêts à copier<\/p>\n  <div style=\"margin-top:34px\">\n    <button class=\"opt\" data-m=\"idee\"><span><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.5 1 2.5h6c0-1 .3-1.8 1-2.5A6 6 0 0 0 12 3z\"/><\/svg><\/span>J'ai déjà une idée<\/button>\n    <button class=\"opt\" data-m=\"lien\"><span><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1\"/><path d=\"M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1\"/><\/svg><\/span>Depuis un lien<\/button>\n    <button class=\"opt\" data-m=\"sugg\"><span><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z\"/><\/svg><\/span>Suggère-moi une idée<\/button>\n  <\/div>\n  <p class=\"hint\">Tu as déjà un script ?<\/p>\n  <button class=\"opt\" data-m=\"coller\" style=\"margin-top:12px\"><span><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><rect x=\"9\" y=\"3\" width=\"6\" height=\"11\" rx=\"3\"/><path d=\"M5 11a7 7 0 0 0 14 0M12 18v3\"/><\/svg><\/span>Coller &amp; Enregistrer<\/button>\n<\/section>\n\n<!-- 1 : saisie (sujet / lien / script / accroche) -->\n<section class=\"s\" data-n=\"1\">\n  <h1 id=\"it\"><\/h1>\n  <p class=\"sub\" id=\"is\"><\/p>\n  <textarea id=\"txt\"><\/textarea>\n  <button class=\"go\" id=\"ok\" disabled>Continuer<\/button>\n<\/section>\n\n<!-- 2 : chargement en 3 étapes -->\n<section class=\"s\" data-n=\"2\">\n  <div class=\"ldf\"><div class=\"ldq\" aria-hidden=\"true\"><b style=\"--i:0\"><span><\/span><\/b><b style=\"--i:1\"><span><\/span><\/b><b style=\"--i:2\"><span><\/span><\/b><b style=\"--i:3\"><span><\/span><\/b><b style=\"--i:4\"><span><\/span><\/b><i><\/i><\/div><\/div>\n  <div id=\"err\" style=\"display:none\"><p id=\"errt\"><\/p><button class=\"go\" id=\"errR\">Réessayer<\/button><button class=\"lien\" id=\"errB\">Retour<\/button><\/div><div class=\"lcard\">\n    <p id=\"lt\"><\/p>\n    <div class=\"stp\"><div class=\"trk\"><i id=\"fill\"><\/i><\/div>\n      <div class=\"n\"><b><\/b><u><\/u><\/div><div class=\"n\"><b><\/b><u><\/u><\/div><div class=\"n\"><b><\/b><u><\/u><\/div><\/div>\n  <\/div>\n<\/section>\n\n<!-- 6 : le script -->\n<section class=\"s\" data-n=\"6\">\n  <h1 class=\"c\" style=\"font-size:22px\">Ton Script<\/h1>\n  <div class=\"tabs\" id=\"tabs\"><button data-t=\"p\" class=\"on\">Paroles<\/button><button data-t=\"d\">Déroulement<\/button><button data-t=\"h\">Publication<\/button><\/div><div class=\"tools\"><button id=\"copy\">Copier<\/button><button id=\"edit\">Modifier<\/button><\/div>\n  <div class=\"box\" id=\"script\"><\/div><div class=\"box\" id=\"pub\" style=\"display:none\"><\/div>\n  <p class=\"sub c\" style=\"margin:10px 0\">Que penses-tu de ce script ?<\/p>\n  <div class=\"thumbs\"><button aria-label=\"J'aime\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M7 11v9H4v-9zM7 11l4-8a2 2 0 0 1 2 2v4h6a2 2 0 0 1 2 2l-1.5 7a2 2 0 0 1-2 1.5H7\"/><\/svg><\/button><button aria-label=\"Je n'aime pas\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M7 13V4H4v9zM7 13l4 8a2 2 0 0 0 2-2v-4h6a2 2 0 0 0 2-2l-1.5-7A2 2 0 0 0 17.5 4H7\"/><\/svg><\/button><\/div>\n  <button class=\"go\" id=\"prompt\" style=\"margin-top:auto\">Enregistrer avec le prompteur<\/button>\n<\/section>\n\n<!-- 7 : prompteur (texte qui défile, test sans caméra) -->\n<section class=\"s\" id=\"pr\" data-n=\"7\">\n  <div class=\"pbox\" id=\"pbox\"><div id=\"ptxt\"><\/div><\/div>\n  <div class=\"pctl\">\n    <button id=\"pslow\" aria-label=\"Plus lent\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M5 12h14\"/><\/svg><small>Vitesse<\/small><\/button>\n    <button id=\"pplay\" class=\"main\" aria-label=\"Lecture\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M7 4l13 8-13 8z\"/><\/svg><\/button>\n    <button id=\"pfast\" aria-label=\"Plus rapide\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 5v14M5 12h14\"/><\/svg><small>Vitesse<\/small><\/button>\n  <\/div>\n  <div class=\"pctl2\"><button id=\"psm\">A−<\/button><span id=\"pspd\">Vitesse 3<\/span><button id=\"pbg\">A+<\/button><\/div>\n  <button class=\"go\" id=\"pdone\" style=\"margin-top:14px\">Terminer<\/button>\n<\/section>\n\n<!-- 8 : historique des scripts déjà générés -->\n<section class=\"s\" data-n=\"8\">\n  <h1 class=\"c\" style=\"font-size:22px\">Historique<\/h1>\n  <p class=\"sub c\">Tes scripts et prompts déjà générés, enregistrés sur cet appareil<\/p>\n  <div id=\"histList\" style=\"margin-top:18px;display:flex;flex-direction:column;gap:10px\"><\/div>\n  <p class=\"hint\" id=\"histEmpty\" style=\"display:none\">Aucun script dans l'historique pour l'instant.<\/p>\n<\/section>\n\n<\/div>";
const $=s=>R.querySelector(s),$$=s=>[...R.querySelectorAll(s)];
const CHECK="<svg viewBox=\"0 0 24 24\" width=\"12\" height=\"12\" fill=\"none\" stroke=\"#fff\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"display:block;margin:2px auto\"><path d=\"M5 12l5 5 9-10\"/></svg>",PLAY="<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M7 4l13 8-13 8z\"/></svg>",PAUSE="<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M8 5v14M16 5v14\"/></svg>";
const HIST_KEY='ff_history';
let lastRep=null,busy=false,dur=45;
let step=0,hist=[],idea='',mode='',runId=0,tmr=null,sc=null,tab='p';
function parseJ(t){t=String(t||'').replace(/```json|```/g,'');const a=t.indexOf('{'),b=t.lastIndexOf('}');if(a<0||b<a)throw new Error('x');return JSON.parse(t.slice(a,b+1));}
function repairJ(t){t=String(t||'').replace(/```json|```/g,'');const a=t.indexOf('{');if(a<0)throw new Error('x');t=t.slice(a);
  try{return JSON.parse(t.slice(0,t.lastIndexOf('}')+1));}catch(e){}
  let o='',st=[],inS=false,esc=false;for(const ch of t){o+=ch;if(inS){if(esc)esc=false;else if(ch==='\\')esc=true;else if(ch==='"')inS=false;continue;}
    if(ch==='"')inS=true;else if(ch==='{'||ch==='[')st.push(ch);else if(ch==='}'||ch===']')st.pop();}
  if(inS)o+='"';o=o.replace(/[,:\s]+$/,'');while(st.length)o+=(st.pop()==='{'?'}':']');
  o=o.replace(/,\s*([}\]])/g,'$1');return JSON.parse(o);}
const cl=(s,n)=>String(s==null?'':s).trim().slice(0,n);
function mainProf(){try{const m=JSON.parse(localStorage.getItem('ff_main')||'null');if(m&&m.u)return {p:window.ffNp(m.p),u:String(m.u).replace(/^@+/,'').trim()};}catch(e){}return null;}
const _nm=v=>String(v||'').replace(/^@+/,'').trim().toLowerCase();
/* ---- analyse locale (calcul exact, aucune donnee inventee) ---- */
function num(v){if(v==null||v==='')return null;if(typeof v==='number')return isFinite(v)?v:null;
  let t=String(v).toLowerCase().replace(/\s|\u00a0/g,'').replace(',','.');const m=t.match(/^([\d.]+)([kmb]?)/);if(!m)return null;let n=parseFloat(m[1]);if(isNaN(n))return null;
  n*=({k:1e3,m:1e6,b:1e9})[m[2]]||1;return Math.round(n);}
function med(a){if(!a.length)return null;const b=a.slice().sort((x,y)=>x-y),h=b.length>>1;return b.length%2?b[h]:Math.round((b[h-1]+b[h])/2);}
function fmtN(n){if(n==null)return '?';return n>=1e6?(n/1e6).toFixed(1).replace('.',',')+' M':n>=1e4?Math.round(n/1e3)+' k':n>=1e3?(n/1e3).toFixed(1).replace('.',',')+' k':String(n);}
function vidList(r){const vs=(r&&r.videos||[]).map(v=>({t:cl(v&&(v.titre||v.description),110)||'(sans titre)',views:num(v&&v.vues),likes:num(v&&v.jaime),com:num(v&&v.commentaires),sh:num(v&&v.partages),tags:(v&&v.hashtags||[]).map(h=>String(h).replace(/^#/,'').toLowerCase()).filter(Boolean),date:v&&v.date,cover:v&&v.couverture}));
  const m=med(vs.map(v=>v.views).filter(n=>n!=null));vs.forEach(v=>{v.x=(m&&v.views!=null)?+(v.views/m).toFixed(1):null;v.er=(v.views&&v.likes!=null)?v.likes/v.views*100:null;});return vs;}
function insights(r){const vs=vidList(r),w=vs.filter(v=>v.views!=null);if(w.length<3)return null;
  const m=med(w.map(v=>v.views)),by=w.slice().sort((a,b)=>b.views-a.views),H={};
  w.forEach(v=>[...new Set(v.tags)].forEach(t=>(H[t]=H[t]||[]).push(v.views)));
  let hs=Object.keys(H).filter(k=>H[k].length>=2).map(k=>({t:k,n:H[k].length,avg:med(H[k])})).sort((a,b)=>b.avg-a.avg).slice(0,5);
  const ers=w.map(v=>v.er).filter(x=>x!=null);
  return {n:vs.length,nv:w.length,med:m,best:by[0],worst:by[by.length-1],above:w.filter(v=>v.views>m).length,tags:hs,er:ers.length?+(ers.slice().sort((a,b)=>a-b)[ers.length>>1]).toFixed(1):null,all:vs};}
async function profCtx(noAnalyze){
  try{
    const a=(await (window.ffRepAll?window.ffRepAll('profile'):[]))||[],mp=window.__ixForced||mainProf();let x=null;
    if(window.__ixNoProf&&!window.__ixForced)return '';
    if(mp){
      x=a.find(z=>{const r=(z.res&&z.res[z.res.length-1])||{};return _nm(r.pseudo)===_nm(mp.u)&&(!r.plateforme||String(r.plateforme).toLowerCase()===mp.p);});
      if(!x&&!noAnalyze&&window.ffAnalyzeMain){host.style.display='none';window.ffAnalyzeMain(mp.p,mp.u);return null;}
    }
    if(!x&&window.__ixForced)return '';
    if(!x)x=a[0];
    if(!x)return '';
    const r=(x.res&&x.res[x.res.length-1])||{};lastRep=r;
    return JSON.stringify({pseudo:r.pseudo,plateforme:r.plateforme,niche:r.niche,bio:r.bio,resume:cl(r.resume,300),stats:(r.stats||[]).map(s=>s.label+' : '+s.value),videos:vidList(r).slice(0,30).map(v=>({titre:v.t,vues:v.views,jaime:v.likes,vs_mediane:v.x?('x'+v.x):undefined,hashtags:v.tags.slice(0,5)})),hashtags:(r.hashtags||[]).slice(0,12),points_forts:(r.points_forts||[]).slice(0,3),points_faibles:(r.points_faibles||[]).slice(0,4),recommandations:(r.recommandations||[]).slice(0,4)}).slice(0,6500);
  }catch(e){return '';}
}
window.ffProfCtx=function(){return profCtx(true);};
async function readLink(url){
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),20000);
  try{const h={Accept:'text/plain'};const k="";if(k)h.Authorization='Bearer '+k;
    const r=await fetch('https://r.jina.ai/'+url,{signal:ctl.signal,headers:h});if(!r.ok)throw 0;
    const t=(await r.text()).trim();if(t.length<60)throw 0;return t.slice(0,4000);
  }catch(e){throw new Error('Impossible de lire ce lien. Colle plutôt le sujet de la vidéo.');}finally{clearTimeout(to);}
}
/* ---------- navigation ---------- */
let ixDepth=0;function ixPush(){try{history.pushState({ix:1},'');ixDepth++;}catch(e){}}
function go(n,back){if(!back&&step!==n&&step!==2){hist.push(step);ixPush();}step=n;$$('.s').forEach(e=>e.classList.toggle('on',e.dataset.n===String(n)));host.scrollTop=0;sync();}
function sync(){$('#histBtn').style.visibility=(step===0)?'visible':'hidden';}
function close(){runId++;clearTimeout(tmr);pStop();host.style.display='none';if(ixDepth>0){const d=ixDepth;ixDepth=0;try{NAV.ignorePop=true;}catch(e){}try{history.go(-d);}catch(e){}}}
function ixBackCore(){
  if(step===0&&!hist.length){close();return;}
  runId++;clearTimeout(tmr);pStop();
  if(hist.length)go(hist.pop(),true);else go(0,true);
}
function ixBack(){
  if(step===0&&!hist.length){close();return;}
  if(ixDepth>0)history.back();else ixBackCore();
}
window.addEventListener('popstate',()=>{if(host.style.display==='none')return;ixDepth=Math.max(0,ixDepth-1);ixBackCore();});
window.ixIsOpen=function(){return host.style.display!=='none';};
$('#back').onclick=ixBack;
function reset(){hist=[];step=-1;idea='';sc=null;W={};P=null;anaCtx='';go(0,true);}
window.ixOpen=function(){reset();if(host.style.display==='none'||ixDepth===0){ixDepth=0;ixPush();}host.style.display='block';};
window.ixOpenWithAnalysis=function(teachings,report){reset();if(host.style.display==='none'||ixDepth===0){ixDepth=0;ixPush();}host.style.display='block';anaCtx=String(teachings||'');newW('sugg');go(14);};
window.ixRunIdeas=function(){histId=0;newW('sugg');go(14);};
const _gb=window.goBack;
window.goBack=function(){if(host.style.display!=='none'){ixBack();return;}return _gb&&_gb.apply(this,arguments);};
$('#txt').oninput=e=>$('#ok').disabled=!e.target.value.trim();
$('#ok').onclick=()=>{const v=$('#txt').value.trim();if(!v)return;showScript({paroles:v,dtxt:'',description:'',tags:[],pasted:1});};
/* ---------- chargement reel ---------- */
function showErr(msg,retry){$('#err').style.display='block';$('.lcard').style.display='none';$('.ldf').style.display='none';$('#errt').textContent=msg;$('#errR').onclick=retry;}
function run(k,work,next){
  const my=++runId;go(2);$('#err').style.display='none';$('.lcard').style.display='';$('.ldf').style.display='';
  const S=STAGES[k],ns=$$('.n');let i=0,done=false;
  ns.forEach((n,j)=>{n.className='n';n.querySelector('b').textContent='';n.querySelector('u').textContent=S.l[j];n.querySelector('u').style.textDecoration='none';});
  $('#fill').style.width='0';
  (function tick(){if(my!==runId||done)return;
    if(i>0){ns[i-1].className='n ok';ns[i-1].querySelector('b').innerHTML=CHECK;}
    if(i===3)return;
    ns[i].className='n act';$('#lt').textContent=S.m[i];$('#fill').style.width=i*50+'%';i++;tmr=setTimeout(tick,1800);})();
  work().then(res=>{if(my!==runId)return;done=true;clearTimeout(tmr);
    ns.forEach(n=>{n.className='n ok';n.querySelector('b').innerHTML=CHECK;});$('#fill').style.width='100%';
    setTimeout(()=>{if(my===runId)next(res);},450);
  }).catch(e=>{if(my!==runId)return;done=true;clearTimeout(tmr);if(e&&e.message==='__main__')return;showErr(String(e&&e.message||'Une erreur est survenue.'),()=>run(k,work,next));});
}
$('#errB').onclick=ixBack;
/* ---------- script : paroles / deroulement / publication ---------- */
function groups5(t){const o=[];for(let i=0;i<t.length;i+=5)o.push(t.slice(i,i+5));return o;}
function copyTxt(t,btn,lbl){
  const ok=()=>{if(btn){btn.textContent='Copié';setTimeout(()=>btn.textContent=lbl,1500);}};
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(ok,()=>fb());}else fb();
  function fb(){try{const ta=document.createElement('textarea');ta.value=t;ta.style.cssText='position:fixed;opacity:0';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();ok();}catch(e){}}
}
function pubHTML(){
  let h='';
  if(sc.description)h+='<div class="hg"><div class="tag">Description</div><p style="margin:6px 0">'+esc(sc.description)+'</p><button class="mini" data-c="d">Copier la description</button></div>';
  const gs=groups5(sc.tags||[]);
  if(gs.length)h+='<p class="hint" style="margin:6px 0 12px;text-align:left">TikTok accepte 5 hashtags par vidéo : choisis un groupe.</p>'+gs.map((g,i)=>'<div class="hg"><div class="tag">Groupe '+(i+1)+'</div><div class="row">'+g.map(t=>'<em>'+esc(t)+'</em>').join('')+'</div><button class="mini" data-g="'+i+'">Copier ces '+g.length+'</button></div>').join('');
  return h||'<p class="hint">Aucune description ni hashtag pour ce script.</p>';
}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function curText(){return tab==='p'?sc.paroles:tab==='d'?sc.dtxt:(sc.description?sc.description+'\n\n':'')+groups5(sc.tags||[]).map(g=>g.join(' ')).join('\n');}
function showTab(t){
  if(editing())endEdit();
  tab=t;$$('#tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));
  const s=$('#script'),p=$('#pub');
  if(t==='h'){s.style.display='none';p.style.display='';p.innerHTML=pubHTML();$('#edit').style.display='none';
    p.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>copyTxt(groups5(sc.tags)[+b.dataset.g].join(' '),b,b.textContent));
    p.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>copyTxt(sc.description,b,b.textContent));}
  else{p.style.display='none';s.style.display='';s.textContent=t==='p'?sc.paroles:(sc.dtxt||'Aucun déroulement pour ce script.');$('#edit').style.display='';}
}
function editing(){return $('#script').contentEditable==='true';}
function endEdit(){const b=$('#script');b.contentEditable=false;$('#edit').textContent='Modifier';if(tab==='p')sc.paroles=b.textContent;else if(tab==='d')sc.dtxt=b.textContent;saveHist();}
function showScript(o,fromHist){
  sc=o;tab='p';$('#tabs').style.display=sc.pasted?'none':'flex';$('#script').contentEditable=false;$('#edit').textContent='Modifier';
  $$('.thumbs button').forEach(x=>x.classList.remove('on'));showTab('p');if(!fromHist)saveHist(true);go(6);}
/* ---------- historique ---------- */
function loadHist(){try{return JSON.parse(localStorage.getItem(HIST_KEY)||'[]');}catch(e){return [];}}
let histId=0;
function saveHist(isNew){
  const l=loadHist();
  if(isNew||!histId){histId=Date.now();l.unshift({ts:histId,idea:idea||(sc.pasted?'(script collé)':'(sans idée)'),sc:sc});}
  else{const x=l.find(y=>y.ts===histId);if(x)x.sc=sc;}
  if(l.length>1000)l.length=1000;try{localStorage.setItem(HIST_KEY,JSON.stringify(l));}catch(e){}
  try{window.ffSync&&window.ffSync.script(histId);}catch(e){}
}
function renderHist(){
  const l=loadHist(),box=$('#histList');box.innerHTML='';{const ns=loadSer().length;if(ns){const sb=document.createElement('button');sb.className='card';sb.style.width='100%';sb.innerHTML='<span class="tag">Séries</span><b>Mes séries ('+ns+')</b>';sb.onclick=()=>{renderSeries();go(29);};box.appendChild(sb);}}$('#histEmpty').style.display=l.length?'none':'block';
  l.forEach(it=>{const b=document.createElement('button');b.className='card';b.style.width='100%';
    const d=new Date(it.ts),when=d.toLocaleDateString()+' · '+d.toLocaleTimeString().slice(0,5),txt=(it.sc&&it.sc.paroles)||it.text||'';
    b.innerHTML='<span class="tag"></span><b></b><small></small>';b.querySelector('.tag').textContent=when+(it.sc&&it.sc.ia?' · Prompt vidéo':'');b.querySelector('b').textContent=it.idea;
    b.querySelector('small').textContent=txt.slice(0,90)+(txt.length>90?'...':'');
    b.onclick=()=>{if(it.sc&&it.sc.ia){openIa(it);return;}histId=it.ts;idea=it.idea;showScript(it.sc||{paroles:it.text||'',dtxt:'',description:'',tags:[],pasted:1},true);};box.appendChild(b);});
}
$('#histBtn').onclick=()=>{renderHist();go(8);};
/* ================= NOUVEAUX PARCOURS : Idées créatives ================= */
const THEMES=['Post-apocalyptique','Mystère / Thriller','Humour','Motivation / Mindset','Horreur','Science-fiction','Romance','Action','Fantastique','Autre'];
const TONS=['Sombre','Drôle','Épique','Inspirant','Mystérieux','Émouvant'];
const PUBS=['Général','Ado','Adulte'];
const DURS=['15 s','30 s','45 s','60 s'];
const OBJS=['S’inspirer du concept','Reproduire un style similaire','Améliorer / transformer l’idée','Faire une version différente'];
const NBEP=['3 épisodes','5 épisodes','8 épisodes','10 épisodes','Je ne sais pas encore'];
const STYD={'Cinématique':'Look film, lumière travaillée','Dark & Moody':'Sombre, contrasté, ambiance lourde','Réaliste':'Rendu photo, naturel','Cartoon':'Dessin animé coloré, formes simples','3D':'Rendu 3D type film d’animation','Anime':'Style japonais, lignes nettes','Rétro VHS':'Grain, couleurs passées, années 90','Minimaliste':'Décor épuré, peu d’éléments'};
const VSTY=Object.keys(STYD);
const RULES=['Pas de vrais visages','Pas de logos de marques','Pas de sang / violence excessive','Rester dans un univers sombre'];
const SER_KEY='ff_ix_series';
const WAND='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 4V2M15 16v-2M8 9h2M20 9h2M17.8 11.8L19 13M17.8 6.2L19 5M12.2 6.2L11 5M3 21l9-9"/></svg>';
const STAGES={
 idees:{l:['Brief','Recherche','Idées'],m:['Lecture de ton brief','Recherche d’idées originales','Rédaction des idées']},
 lien:{l:['Lien','Analyse','Variations'],m:['Lecture de la vidéo','Analyse du concept','Rédaction des variations']},
 gen:{l:['Brief','Scènes','Prompts'],m:['Lecture du brief complet','Construction scène par scène','Écriture des prompts']}};
let W={},P=null,anaCtx='',curOut=null,curMeta=null,editOut=false,vState=null;
const el=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;};
const val=id=>(($(id)||{}).value||'').trim();
const foot=h=>'<div class="foot">'+h+'</div>';
function sec(n,h){const s=el('section','s',h);s.dataset.n=n;$('.app').appendChild(s);return s;}
function toast(t){let e=$('#tst');if(!e){e=el('div','');e.id='tst';R.appendChild(e);}e.textContent=t;e.className='show';clearTimeout(e._t);e._t=setTimeout(()=>e.className='',3800);}
function chips(id,items,multi,sel,cb){const b=$(id);b.innerHTML='';items.forEach(x=>{const e=el('button','chip'+((sel||[]).includes(x)?' on':''));e.type='button';if(STYD[x]){e.className+=' sty';e.innerHTML='<b></b><small></small>';e.firstChild.textContent=x;e.lastChild.textContent=STYD[x];}else e.textContent=x;e.dataset.v=x;
  e.onclick=()=>{if(multi)e.classList.toggle('on');else{const was=e.classList.contains('on');[...b.children].forEach(c=>c.classList.remove('on'));if(!was)e.classList.add('on');}if(cb)cb(cv(id,multi));};b.appendChild(e);});}
function cv(id,multi){const a=[...$(id).children].filter(c=>c.classList.contains('on')).map(c=>c.dataset.v);return multi?a:(a[0]||'');}
function setChips(id,vals){const a=[].concat(vals||[]);[...$(id).children].forEach(c=>c.classList.toggle('on',a.includes(c.dataset.v)));}
const durNum=s=>parseInt(String(s||'').replace(/\D/g,''),10)||0;
function fld(label,inner,opt){return '<div class="fld"><label>'+label+(opt?' <small>(optionnel)</small>':'')+'</label>'+inner+'</div>';}
const inp=(id,ph,max)=>'<input class="num" id="'+id+'" type="text" autocomplete="off" maxlength="'+(max||160)+'" placeholder="'+(ph||'')+'">';
const tar=(id,ph,max,h)=>'<textarea class="num" id="'+id+'" maxlength="'+(max||600)+'" placeholder="'+(ph||'')+'"'+(h?' style="min-height:'+h+'px"':'')+'></textarea>';
const head=(t,s)=>'<h1 class="c">'+t+'</h1><p class="sub c">'+s+'</p>';
const wandBtn=id=>'<button type="button" class="wand" id="'+id+'" aria-label="Suggérer">'+WAND+'</button>';

/* ---------- appels IA ---------- */
const RULES_SYS='Règles de qualité : (1) Tu respectes à la lettre les CHOIX DE L\u2019UTILISATEUR (univers, ton, public, durée, style, structure) : ils priment sur tout le reste. (2) Idées concrètes et spécifiques, jamais génériques : un personnage ou un sujet précis, un lieu précis, un événement précis. (3) Tout doit pouvoir être filmé par un générateur de vidéo IA dans la durée donnée : peu de personnages, peu de décors, une action visuelle claire. (4) Une accroche forte dès les 2 premières secondes. (5) Tu n\u2019inventes aucun fait sur le créateur : tu utilises son profil uniquement s\u2019il t\u2019est fourni. (6) Tu écris en français naturel, sauf les prompts de scène qui sont en anglais.';
const JS_SYS='Tu es un expert des vidéos courtes (TikTok, Reels, Shorts), en création de concepts, de séries et de prompts pour générateurs de vidéo IA. '+RULES_SYS+' Tu réponds uniquement par un objet JSON valide, sans texte autour, sans balises markdown.';
const TX_SYS='Tu es un expert des vidéos courtes (TikTok, Reels, Shorts), en création de concepts, de structure et de prompts pour les générateurs de vidéo IA (Kling, Runway, Luma, Pika). '+RULES_SYS+' Tu suis exactement le format demandé, sans introduction ni conclusion.';
async function askJ(p,tok){const t=await ixAsk(JS_SYS,p,tok||2500);try{return parseJ(t);}catch(e){try{return repairJ(t);}catch(e2){throw new Error('La réponse de l’IA est illisible. Réessaie.');}}}
async function askT(p,tok){const t=String(await ixAsk(TX_SYS,p,tok||3000)||'').trim();if(!t)throw new Error('Réponse vide de l’IA. Réessaie.');return t;}
async function creatorCtx(fresh){if(!fresh)return W.prof?(W.profCtx||''):'';try{const c=await profCtx(true);return c?String(c).slice(0,6500):'';}catch(e){return '';}}
function ctxLine(c){return (c?'\n\nPROFIL DU CRÉATEUR (résumé validé par lui, données réelles) :\n'+c+'\n\nCe que tu dois faire avec ce profil : 1) rester dans sa niche et parler à son audience ; 2) reprendre les formats, angles et hashtags qui ont le mieux marché chez lui ; 3) ne pas répéter les sujets déjà traités ; 4) garder son ton habituel, sauf si le ton demandé est différent (le ton demandé prime) ; 5) si l\u2019univers choisi sort de sa niche, garde l\u2019univers choisi mais adapte l\u2019angle à son audience. N\u2019invente rien sur lui.':'')+(anaCtx?'\n\nEnseignements d\u2019une analyse récente de sa vidéo :\n'+String(anaCtx).slice(0,1800):'');}

/* ---------- lecture des réponses « Idée n : Titre / Résumé / Pourquoi » ---------- */
function fieldOf(b,lab){const m=new RegExp('(?:^|\\n)[ \\t]*(?:'+lab+')[^\\S\\n]*(?:\\([^)\\n]*\\))?[^\\S\\n]*:[ \\t]*([\\s\\S]*?)(?=\\n[ \\t]*(?:Titre|R[ée]sum[ée]|Concept|Pourquoi|Adapt[ée]|Ce qui change|Id[ée]e am[ée]lior[ée]e|Variation|Version|Id[ée]e\\s*\\d)|$)','i').exec(b);return m?m[1].trim():'';}
function parseBlocks(t){
  t=String(t).replace(/\*\*|__/g,'').replace(/^[ \t]*#+[ \t]*/gm,'');
  const re=/(?:^|\n)[ \t]*(?:Id[ée]e|Version|Variation)\s*\d+\s*[:.\-–]?[ \t]*/gi,ix=[];let m;while((m=re.exec(t)))ix.push([m.index,re.lastIndex]);
  return ix.map((p,i)=>t.slice(p[1],i+1<ix.length?ix[i+1][0]:t.length)).map(b=>({t:fieldOf(b,'Titre(?: de la s[ée]rie)?'),r:fieldOf(b,'R[ée]sum[ée]|Concept|Id[ée]e am[ée]lior[ée]e'),w:fieldOf(b,'Pourquoi[^:\\n]*|Ce qui change'),p:fieldOf(b,'Adapt[ée][^:\\n]*')})).filter(x=>x.t||x.r);
}
function block(t,lab,stop){const m=new RegExp(lab+'[^\\S\\n]*:[ \\t]*([\\s\\S]*?)(?=\\n[ \\t]*(?:'+stop+')|$)','i').exec(String(t).replace(/\*\*|__/g,''));return m?m[1].trim():'';}

/* ---------- écrans ---------- */
function build(){
 /* 10 : j'ai déjà une idée */
 sec(10,head('J’ai déjà une idée','Décrivez votre idée')+
  fld('Quelle est votre idée ?',tar('a_txt','Ex. : un astronaute retrouve une vieille cassette sur Mars…',900,130))+
  fld('Durée souhaitée','<div class="chips" id="a_dur"></div>',1)+fld('Ton souhaité',inp('a_ton','Ex. : mystérieux, drôle…',80),1)+
  foot('<button class="go" id="a_ok" disabled>Continuer</button><button class="lien" id="a_imp" disabled>Suggérer des améliorations</button>'));
 /* 11 : améliorer ? */
 sec(11,head('Améliorer l’idée','Voulez-vous que l’IA améliore ou enrichisse votre idée ?')+
  '<div style="margin-top:34px"><button class="opt" id="b_yes">Oui, améliorer mon idée</button><button class="opt" id="b_no">Non, garder mon idée telle quelle</button></div>');
 /* 12 : sélection (idées / variations / améliorations) */
 sec(12,'<h1 class="c" id="pk_t"></h1><p class="sub c" id="pk_s"></p><div id="pk_orig"></div><div class="grid" id="pk_list" style="margin-top:14px"></div>'+
  '<div class="pc" id="pk_edit" style="display:none"><h3><span>Modifier l’idée</span></h3>'+fld('Titre',inp('pk_et','',120))+fld('Résumé',tar('pk_er','',500,90))+'<button class="go" id="pk_es" style="margin-top:12px">Enregistrer</button></div>'+
  foot('<button class="go" id="pk_pick" disabled>Choisir cette idée</button><div class="row2"><button class="go sec" id="pk_more"></button><button class="go sec" id="pk_mod" disabled>Modifier</button></div>'));
 /* 13 : confirmation */
 sec(13,'<h1 class="c" id="cf_t"></h1><p class="sub c" id="cf_s"></p><div class="ob" style="margin-top:24px"><span class="tag" id="cf_k"></span><p id="cf_ti" style="font-weight:700;font-size:17px;margin-bottom:6px"></p><p id="cf_r"></p></div>'+foot('<button class="go" id="cf_ok"></button>'));
 /* 14 : suggérer → vidéo ou série */
 sec(14,head('Suggérer une idée','Voulez-vous une idée pour une seule vidéo ou pour une série ?')+
  '<div style="margin-top:34px"><button class="opt" data-k="video">Une seule vidéo</button><button class="opt" data-k="serie">Une série (plusieurs épisodes)</button></div>');
 sec(30,head('Adapté à ton profil ?','Veux-tu que les idées s\u2019appuient sur ton profil et tes vidéos ?')+'<div style="margin-top:30px"><button class="opt" data-p="1">Oui, adapté à mon profil</button><button class="opt" data-p="0">Non, une idée libre</button></div>');
 /* 31 : résumé du profil */
 sec(31,head('Ce que l’IA retient de ton profil','Vérifie et corrige : c’est la base des idées')+'<div class="fld"><textarea class="num" id="pf_t" style="min-height:270px"></textarea></div><p class="hint" style="text-align:left;margin-top:10px">L’IA va rester dans ta niche, parler à ton audience, reprendre ce qui a le mieux marché chez toi, éviter les sujets déjà traités et garder ton ton habituel.</p>'+foot('<button class="go" id="pf_ok">Continuer</button>'));
 /* 15 : thème */
 sec(15,head('Suggérer une idée','<span id="th_q"></span>')+fld('Univers','<div class="chips" id="th_c"></div>')+
  '<div id="th_oo" style="display:none">'+fld('Votre univers',inp('th_o','Ex. : cuisine, sport, histoire…',80))+'</div>'+
  fld('Précisez un peu plus votre envie',tar('th_p','Ex. : un héros solitaire, une ambiance de fin du monde…',400,84),1)+foot('<button class="go" id="th_ok" disabled>Continuer</button>'));
 /* 16 : affinage */
 sec(16,head('Affiner la suggestion','Voulez-vous préciser quelques éléments ? (optionnel)')+fld('Ton souhaité','<div class="chips" id="af_t"></div>',1)+fld('Public cible','<div class="chips" id="af_p"></div>',1)+
  fld('<span id="af_dl">Durée de la vidéo</span>','<div class="chips" id="af_d"></div>',1)+foot('<button class="go" id="af_ok">Continuer</button><button class="lien" id="af_skip">Passer cette étape</button>'));
 /* 17 : lien */
 sec(17,head('Partir d’un lien','Collez le lien de la vidéo TikTok, Reels ou Shorts')+fld('Lien de la vidéo','<input class="num" id="l_url" type="url" autocomplete="off" placeholder="https://…">')+
  fld('Que voulez-vous faire avec cette vidéo ?','<div class="chips" id="l_obj"></div>')+
  fld('Décrivez la vidéo en une phrase',tar('l_desc','Sert d’aide si la page du lien ne peut pas être lue.',300,64),1)+foot('<button class="go" id="l_ok" disabled>Analyser le lien</button>'));
 /* 18 : structure */
 sec(18,'<h1 class="c">Structure de la vidéo</h1><p class="sub c" id="st_s"></p>'+fld('Durée','<div class="chips" id="st_d"></div>')+
  '<div class="fld" id="st_sw" style="display:none"><label>Structure proposée (modifiable)</label><textarea class="num" id="st_sc" style="min-height:190px"></textarea></div>'+
  '<details class="dt"><summary>Écrire ma propre structure</summary>'+fld('Hook (les 3 premières secondes)',tar('st_h','',300,64),1)+fld('Développement',tar('st_v','',400,72),1)+fld('Twist / Moment fort',tar('st_t','',300,64),1)+fld('Call-to-action',tar('st_c','',200,56),1)+'</details>'+
  foot('<button class="go" id="st_ai">Laisser l\u2019IA proposer la structure</button><button class="go sec" id="st_ok">Continuer avec ma structure</button>'));
 /* 19 : style vidéo */
 sec(19,'<div class="hrow"><p class="sub" style="font-size:15px">Quel style visuel voulez-vous pour cette vidéo ?</p>'+wandBtn('sv_w')+'</div><h1 style="margin-top:6px">Style de la vidéo</h1>'+
  fld('Style visuel','<div class="chips" id="sv_c"></div>')+fld('Ton / Ambiance',inp('sv_a','Ex. : tendu, lumineux…',100),1)+'<details class="dt"><summary>Options : caméra et effets</summary>'+fld('Mouvements de caméra',inp('sv_m','Ex. : travelling lent, caméra à l’épaule…',140),1)+fld('Effets spéciaux',inp('sv_e','Ex. : poussière, lueurs, glitch…',140),1)+'</details>'+
  foot('<button class="go" id="sv_ok">Continuer</button>'));
 /* 20 : nombre d'épisodes */
 sec(20,head('Combien d’épisodes aura cette série ?','Choisissez le nombre d’épisodes prévus')+'<div class="chips" id="ne_c" style="margin-top:28px"></div>'+foot('<button class="go" id="ne_ok" disabled>Continuer</button>'));
 /* 21 : style série */
 sec(21,'<div class="hrow"><p class="sub" style="font-size:15px">Définissez l’univers visuel de toute la série</p>'+wandBtn('ss_w')+'</div><h1 style="margin-top:6px">Style et ambiance de la série</h1>'+
  fld('Style visuel','<div class="chips" id="ss_c"></div>')+fld('Palette de couleurs',inp('ss_p','Ex. : bleu nuit, orange rouille…',120))+fld('Ton / Émotion dominante',inp('ss_t','Ex. : sombre et mélancolique…',100))+foot('<button class="go" id="ss_ok">Continuer</button>'));
 /* 22 : personnages */
 sec(22,'<div class="hrow"><p class="sub" style="font-size:15px">Ajoutez les personnages qui reviendront dans plusieurs épisodes</p>'+wandBtn('pc_w')+'</div><h1 style="margin-top:6px">Personnages de la série</h1><div id="pc_l"></div>'+
  '<button class="mini" id="pc_add" style="width:100%;margin-top:14px">+ Ajouter un personnage</button>'+foot('<button class="go" id="pc_ok">Continuer</button>'));
 /* 23 : règles */
 sec(23,head('Règles de la série','Y a-t-il des choses à éviter absolument dans cette série ?')+'<div class="chips" id="ru_c" style="margin-top:24px"></div>'+fld('Autre',tar('ru_o','',300,64),1)+foot('<button class="go" id="ru_ok">Continuer</button>'));
 /* 24 : épisode */
 sec(24,'<h1 class="c">Créer un épisode</h1><p class="sub c">Créons un épisode de la série</p><p class="ob" id="ep_n" style="margin-top:18px;font-weight:700;text-align:center"></p>'+
  fld('Titre de l’épisode',inp('ep_t','',120))+'<div class="sg"><button class="mini" data-s="titre">Suggérer un titre</button></div>'+
  fld('Résumé de l’épisode',tar('ep_r','',700,90))+'<div class="sg"><button class="mini" data-s="resume">Suggérer un résumé</button></div>'+
  fld('Objectif de cet épisode',tar('ep_o','',400,64))+'<div class="sg"><button class="mini" data-s="objectif">Suggérer un objectif</button></div>'+
  '<div class="fld" id="ep_cw"><label>Continuité</label><textarea class="num" id="ep_c" maxlength="900" style="min-height:90px"></textarea></div>'+foot('<button class="go" id="ep_ok" disabled>Continuer</button>'));
 /* 25 : direction artistique de l'épisode */
 sec(25,head('Ambiance de cet épisode','Souhaitez-vous garder le style de la série ou l’ajuster ?')+'<p class="ob" id="di_r" style="margin-top:18px"></p><div class="chips" id="di_c" style="margin-top:16px"></div>'+
  '<div id="di_a" style="display:none">'+fld('Mouvements de caméra',inp('di_m','',140),1)+fld('Intensité',inp('di_i','Ex. : montée progressive, très calme…',140),1)+fld('Éclairage',inp('di_l','',140),1)+fld('Effets',inp('di_e','',140),1)+'</div>'+
  foot('<button class="go" id="di_ok">Générer les prompts</button>'));
 /* 26 : résultat */
 sec(26,'<h1 class="c" style="font-size:24px">Vos prompts sont prêts</h1><p class="sub c" id="rs_s"></p><div class="tabs" id="rs_tabs"><button data-t="p" class="on">Prompt</button><button data-t="i">Infos</button></div><div id="rs_b"></div>'+
  '<div class="rsb"><button class="go" id="rs_var">Générer des variantes d’une scène</button><div class="two"><button class="mini" id="rs_mod">Modifier</button><button class="mini" id="rs_exp">Exporter</button><button class="mini" id="rs_cp">Tout copier</button></div>'+
  '<button class="go" id="rs_nxt"></button><button class="lien" id="rs_all" style="display:none">Voir tous les épisodes de la série</button></div>');
 /* 27 : variantes */
 sec(27,head('Variantes d’une scène','Choisissez la scène à décliner')+'<div class="chips" id="va_c" style="margin-top:22px"></div><div id="va_l"></div>');
 /* 28 : une série */
 sec(28,'<h1 class="c" id="sr_t"></h1><p class="sub c" id="sr_s"></p><div id="sr_l" style="margin-top:16px;display:flex;flex-direction:column;gap:10px"></div>'+foot('<button class="go" id="sr_nx">Créer l’épisode suivant</button>'));
 /* 29 : mes séries */
 sec(29,head('Mes séries','Tes séries enregistrées sur cet appareil')+'<div id="ml_l" style="margin-top:16px;display:flex;flex-direction:column;gap:10px"></div><p class="hint" id="ml_e" style="display:none">Aucune série pour l’instant.</p>');
}

/* ================= LOGIQUE DES PARCOURS ================= */
build();
async function wandRun(btn,fn){if(btn.disabled)return;btn.disabled=true;btn.classList.add('spin');try{await fn();}catch(e){toast(String(e&&e.message||'Erreur'));}finally{btn.disabled=false;btn.classList.remove('spin');}}
function newW(flow,kind){W={flow,kind:kind||'video'};}
const ideaTxt=()=>W.titre?('Titre : '+W.titre+'\nRésumé : '+W.resume):(W.resume||W.idee||'');
const nz=(v,d)=>v&&String(v).trim()?String(v).trim():(d||'non précisé');

/* ---------- séries (stockage) ---------- */
function loadSer(){try{return JSON.parse(localStorage.getItem(SER_KEY)||'[]');}catch(e){return [];}}
function saveSer(s){const l=loadSer(),i=l.findIndex(x=>x.id===s.id);s.ts=Date.now();if(i>=0)l[i]=s;else l.unshift(s);try{localStorage.setItem(SER_KEY,JSON.stringify(l));}catch(e){toast('Enregistrement impossible sur cet appareil.');}}
function histPut(ts,label,scx){const l=loadHist();const x=ts&&l.find(y=>y.ts===ts);if(x){x.idea=label;x.sc=scx;}else{ts=Date.now();l.unshift({ts,idea:label,sc:scx});}
  if(l.length>1000)l.length=1000;try{localStorage.setItem(HIST_KEY,JSON.stringify(l));}catch(e){}try{window.ffSync&&window.ffSync.script(ts);}catch(e){}return ts;}
function serBlock(s){return 'Série : '+s.name+'\nConcept : '+s.concept+'\nDurée des épisodes : '+(s.duree||30)+' secondes'+(s.nbEp?'\nNombre d’épisodes prévus : '+s.nbEp:'')+(s.style&&s.style.length?'\nStyle visuel : '+s.style.join(', '):'')+(s.palette?'\nPalette de couleurs : '+s.palette:'')+(s.tone?'\nTon / émotion dominante : '+s.tone:'')+(s.pub?'\nPublic : '+s.pub:'')+(s.theme?'\nUnivers : '+s.theme:'')+(s.profile?'\nAdaptation au profil du créateur (données réelles) : '+s.profile:'');}
function charsTxt(s){return (s.chars||[]).map((c,i)=>(i+1)+'. '+(c.name||'(sans nom)')+(c.desc?' — Physique : '+c.desc:'')+(c.perso?' | Personnalité : '+c.perso:'')+(c.role?' | Rôle : '+c.role:'')+(c.voice?' | Voix : '+c.voice:'')).join('\n')||'(aucun personnage fixe défini)';}
function rulesTxt(s){const a=[].concat(s.rules||[]);if(s.rulesText)a.push(s.rulesText);return a.length?a.map(x=>'- '+x).join('\n'):'(aucune règle particulière)';}
function prevEps(s,n){return (s.eps||[]).filter(e=>e.num<n).sort((a,b)=>a.num-b.num);}
function prevTxt(s,n){const p=prevEps(s,n);if(!p.length)return 'Aucun : c’est l’épisode 1. N’invente aucune continuité.';
  let t=p.map(e=>'Épisode '+e.num+(e.titre?' « '+e.titre+' »':'')+' : '+(e.resume||'')+(e.objectif?' (objectif : '+e.objectif+')':'')).join('\n');
  const l=p[p.length-1],sc=l.out&&l.out.scenes&&l.out.scenes[l.out.scenes.length-1];if(sc)t+='\nDernière scène de l’épisode '+l.num+' (pour la continuité visuelle) :\n'+String(sc.p).slice(0,700);return t;}
function epBlock(e){return 'Épisode '+e.num+'\nTitre : '+nz(e.titre,'(à définir)')+'\nRésumé : '+nz(e.resume,'(à définir)')+(e.objectif?'\nObjectif : '+e.objectif:'')+(e.continuite?'\nContinuité : '+e.continuite:'');}
function serieCtx(){const s=W.ser,e=W.ep;return serBlock(s)+'\n\nPersonnages :\n'+charsTxt(s)+'\n\nRègles :\n'+rulesTxt(s)+'\n\nÉpisodes précédents :\n'+prevTxt(s,e.num)+'\n\n'+epBlock(e);}

/* ---------- entrées ---------- */
function startIdee(){newW('idee');$('#a_txt').value='';$('#a_ton').value='';chips('#a_dur',DURS,false,[]);$('#a_ok').disabled=$('#a_imp').disabled=true;go(10);}
function startLien(){newW('lien');$('#l_url').value='';$('#l_desc').value='';chips('#l_obj',OBJS,false,[OBJS[0]]);$('#l_ok').disabled=true;go(17);}
function startSugg(){newW('sugg');go(14);}
/* ---- J'ai déjà une idée ---- */
$('#a_txt').oninput=()=>{$('#a_ok').disabled=$('#a_imp').disabled=!val('#a_txt');};
function readIdee(){W.idee=val('#a_txt');W.resume=W.idee;W.titre='';W.duree=durNum(cv('#a_dur'));W.ton=val('#a_ton');}
$('#a_ok').onclick=()=>{readIdee();go(11);};
$('#a_imp').onclick=()=>{readIdee();improve();};
$('#b_yes').onclick=improve;
$('#b_no').onclick=()=>{W.titre='';W.resume=W.idee;showConfirm();};
function improve(){const prev=[];
  const work=async()=>{const c=await creatorCtx();
    const t=await askT('Tu es un expert en création de concepts pour vidéos courtes (TikTok, Reels, Shorts).\n\nIdée de l’utilisateur : '+W.idee+'\nTon : '+nz(W.ton)+'\nDurée : '+(W.duree?W.duree+' secondes':'non précisée')+
      (prev.length?'\nVersions déjà proposées (ne les répète pas) : '+prev.join(' | '):'')+ctxLine(c)+'\n\nPropose 3 versions améliorées et enrichies de cette idée (garde son intention, rends-la plus accrocheuse).\n\nFormat obligatoire pour chaque version :\n\nVersion 1 :\nTitre :\nIdée améliorée : (2 à 3 phrases)\nCe qui change : (1 phrase)\n\nVersion 2 :\n...',2200);
    const a=parseBlocks(t);if(!a.length)throw new Error('L’IA n’a pas proposé de versions lisibles. Réessaie.');a.forEach(x=>prev.push(x.t));return a.slice(0,3);};
  const show=a=>showPicker({items:[{t:'Mon idée d’origine',r:W.idee,w:'',orig:1}].concat(a),title:'Versions de votre idée',sub:'Choisissez une version ou gardez l’originale',more:'Proposer d’autres versions',regen:()=>run('idees',work,a2=>{P.items=P.items.concat(a2);drawPick();go(12);})});
  run('idees',work,show);}
/* ---- Depuis un lien ---- */
$('#l_url').oninput=()=>{$('#l_ok').disabled=val('#l_url').length<8;};
$('#l_ok').onclick=()=>{W.url=val('#l_url');W.objectif=cv('#l_obj')||OBJS[0];W.ldesc=val('#l_desc');const prev=[];
  const work=async()=>{let page='';try{page=await readLink(W.url);}catch(e){}
    if(!page&&!W.ldesc)throw new Error('Impossible de lire ce lien. Décris la vidéo en une phrase (champ prévu sur l’écran précédent) pour que l’IA puisse t’aider.');
    const t=await askT('Tu es un expert en analyse de vidéos courtes (TikTok, Reels, Shorts).\n\nVoici le lien : '+W.url+'\nObjectif de l’utilisateur : '+W.objectif+'\n'+
      (page?'\nTexte lu sur la page de la vidéo (peut contenir du bruit) :\n<<<'+page+'>>>\n':'\nLa page de la vidéo n’a pas pu être lue.\n')+(W.ldesc?'Description donnée par l’utilisateur : '+W.ldesc+'\n':'')+
      '\nImportant : tu ne peux pas regarder la vidéo. Base-toi uniquement sur ces éléments et sur le lien, et n’invente aucun détail que tu ne peux pas en déduire ; si c’est insuffisant, dis-le dans le résumé.'+
      (prev.length?'\nVariations déjà proposées (ne les répète pas) : '+prev.join(' | '):'')+
      '\n\nTa mission :\n1. Résume le concept principal de la vidéo en 2 phrases\n2. Identifie le ton et le style\n3. Propose 4 variations d’idées différentes basées sur cette vidéo\n\nFormat de réponse :\n\nRésumé de la vidéo originale :\n...\n\nTon & Style :\n...\n\nVariations proposées :\n\nVariation 1 :\nTitre :\nRésumé : (2 phrases)\n\nVariation 2 :\n...',2600);
    const a=parseBlocks(t);if(!a.length)throw new Error('L’IA n’a pas proposé de variations lisibles. Réessaie.');
    W.lienSum=block(t,'R[ée]sum[ée] de la vid[ée]o originale','Ton\\s*&|Variations?')||'';W.lienTon=block(t,'Ton\\s*&\\s*Style','Variations?|Variation\\s*1')||'';a.forEach(x=>prev.push(x.t));return a.slice(0,4);};
  const orig=()=>(W.lienSum?'<b>Résumé de la vidéo originale</b><br>'+esc(W.lienSum):'')+(W.lienTon?'<br><br><b>Ton &amp; style</b><br>'+esc(W.lienTon):'');
  run('lien',work,a=>showPicker({items:a,title:'Idées proposées à partir du lien',sub:'Voici des idées inspirées de la vidéo',orig:orig(),more:'Demander d’autres variations',regen:()=>run('lien',work,a2=>{P.items=P.items.concat(a2);drawPick();go(12);})}));};
/* ---- Suggère-moi une idée ---- */
R.querySelectorAll('section[data-n="14"] .opt').forEach(b=>b.onclick=()=>{W.kind=b.dataset.k;go(30);});
function profTxt(d){const j=x=>[].concat(x||[]).filter(Boolean).join(' ; ')||'non déterminé';return 'Niche : '+(d.niche||'non déterminé')+'\nAudience : '+(d.audience||'non déterminé')+'\nTon habituel : '+(d.ton||'non déterminé')+'\nCe qui marche chez toi : '+j(d.ce_qui_marche)+'\nHashtags performants : '+j(d.hashtags)+'\nDéjà traité (à ne pas répéter) : '+j(d.deja_traite)+'\nÀ éviter : '+j(d.a_eviter);}
function localProf(raw){try{const r=JSON.parse(raw);return profTxt({niche:r.niche||r.resume,audience:'',ton:'',ce_qui_marche:r.points_forts,hashtags:(r.hashtags||[]).slice(0,6).map(h=>'#'+String(h).replace(/^#/,'')),deja_traite:(r.videos||[]).slice(0,8).map(v=>v.titre),a_eviter:r.points_faibles});}catch(e){return '';}}
R.querySelectorAll('section[data-n="30"] .opt').forEach(b=>b.onclick=()=>wandRun(b,async()=>{W.prof=b.dataset.p==='1';W.profCtx='';
  if(!W.prof){toTheme();return;}
  const raw=await creatorCtx(true);
  if(!raw){W.prof=!!anaCtx;if(!anaCtx)toast('Aucun profil analysé : idée libre.');toTheme();return;}
  let txt='';
  try{const d=await askJ('Voici les données réelles du profil d\u2019un créateur de vidéos courtes (JSON) :\n'+raw+'\n\nRésume-les pour guider la création d\u2019idées. Base-toi UNIQUEMENT sur ces données, n\u2019invente rien ; écris « non déterminé » si une information manque. « ce_qui_marche » = formats, sujets ou accroches des vidéos qui dépassent la médiane (vs_mediane au-dessus de x1) ; « deja_traite » = sujets des vidéos déjà publiées ; « audience » = déduite de la niche et des vidéos. Format : {"niche":"","audience":"","ton":"","ce_qui_marche":["",""],"hashtags":["",""],"deja_traite":["",""],"a_eviter":["",""]}',1500);txt=profTxt(d);}catch(e){}
  if(!txt)txt=localProf(raw);if(!txt){W.prof=false;toast('Profil illisible : idée libre.');toTheme();return;}
  $('#pf_t').value=txt;go(31);}));
$('#pf_ok').onclick=()=>{W.profCtx=val('#pf_t').slice(0,1500);if(!W.profCtx)W.prof=false;toTheme();};
function adl(){return W.prof&&W.profCtx?'\nAdapté à ton profil : (1 phrase : le lien concret avec ta niche, ton audience ou ce qui a marché chez toi)':'';}
function toTheme(){$('#th_q').textContent=W.kind==='serie'?'Dans quel univers voulez-vous une idée de série ?':'Dans quel univers voulez-vous une idée ?';
  chips('#th_c',THEMES,false,[],v=>{$('#th_oo').style.display=v==='Autre'?'':'none';thOk();});$('#th_o').value='';$('#th_p').value='';$('#th_oo').style.display='none';$('#th_ok').disabled=true;go(15);}
function thOk(){const t=cv('#th_c');$('#th_ok').disabled=!t||(t==='Autre'&&!val('#th_o'));}
$('#th_o').oninput=thOk;
$('#th_ok').onclick=()=>{const t=cv('#th_c');W.theme=t==='Autre'?val('#th_o'):t;W.precision=val('#th_p');
  chips('#af_t',TONS,false,[]);chips('#af_p',PUBS,false,[]);chips('#af_d',DURS,false,[]);$('#af_dl').textContent=W.kind==='serie'?'Durée des épisodes':'Durée de la vidéo';go(16);};
function afterAf(skip){W.ton=skip?'':cv('#af_t');W.pub=skip?'':cv('#af_p');W.duree=skip?0:durNum(cv('#af_d'));startSuggest();}
$('#af_ok').onclick=()=>afterAf(false);$('#af_skip').onclick=()=>afterAf(true);
function startSuggest(){const prev=[],serie=W.kind==='serie';
  const work=async()=>{const c=await creatorCtx();
    const info='CHOIX DE L’UTILISATEUR (à respecter strictement) :\n- Type : '+(serie?'série (plusieurs épisodes)':'une seule vidéo')+'\n- Adaptation au profil : '+(W.prof?'oui (voir le profil ci-dessous)':'non, idée libre, ne suppose rien sur le créateur')+'\nInformations'+(serie?' reçues':'')+' :\n- Thème : '+W.theme+'\n- Précision : '+nz(W.precision)+'\n- Ton : '+nz(W.ton)+'\n- Public : '+nz(W.pub)+'\n- Durée'+(serie?' par épisode':'')+' : '+(W.duree?W.duree+' secondes':'non précisée');
    const p=serie?'Tu es un expert en création de concepts de séries pour vidéos courtes (TikTok, Reels, Shorts).\n\n'+info+(prev.length?'\n\nIdées déjà proposées (ne les répète pas) : '+prev.join(' | '):'')+ctxLine(c)+'\n\nTa mission :\nPropose 5 idées originales de séries.\n\nLes 5 idées doivent toutes respecter le thème, le ton, le public et la durée ci-dessus, et être très différentes entre elles (personnages, décor, angle). Chaque épisode doit pouvoir être filmé par un générateur de vidéo IA.\n\nPour chaque idée, utilise exactement ce format :\n\nIdée 1 :\nTitre de la série :\nConcept : (2 phrases maximum)\nPourquoi ça peut marcher : (1 phrase)'+adl()+'\n\nIdée 2 :\n...'
     :'Tu es un expert en création de concepts pour vidéos courtes (TikTok, Reels, Shorts).\n\n'+info+(prev.length?'\n\nIdées déjà proposées (ne les répète pas) : '+prev.join(' | '):'')+ctxLine(c)+'\n\nPropose 5 idées originales et accrocheuses.\n\nLes 5 idées doivent toutes respecter le thème, le ton, le public et la durée ci-dessus, et être très différentes entre elles (sujet, décor, angle). Chaque idée doit pouvoir être filmée par un générateur de vidéo IA dans la durée donnée.\n\nFormat obligatoire pour chaque idée :\n\nIdée 1 :\nTitre : \nRésumé : (2 phrases maximum)\nPourquoi ça peut marcher : (1 phrase)'+adl()+'\n\nIdée 2 :\n...';
    const a=parseBlocks(await askT(p,2600));if(!a.length)throw new Error('L’IA n’a pas proposé d’idées lisibles. Réessaie.');a.forEach(x=>prev.push(x.t));return a.slice(0,5);};
  run('idees',work,a=>showPicker({serie,items:a,title:serie?'Voici des idées de séries':'Voici des idées pour vous',sub:'Choisissez une idée ou demandez-en d’autres',more:serie?'Me proposer d’autres idées':'Demander d’autres idées',
    regen:()=>run('idees',work,a2=>{P.items=P.items.concat(a2);drawPick();go(12);})}));}

/* ---------- sélection d'une idée ---------- */
function showPicker(c){P=c;P.sel=-1;$('#pk_t').textContent=c.title;$('#pk_s').textContent=c.sub;const o=$('#pk_orig');o.innerHTML='';
  if(c.orig){const d=el('div','ob',c.orig);d.style.marginTop='14px';o.appendChild(d);}
  $('#pk_more').textContent=c.more;$('#pk_edit').style.display='none';$('#pk_pick').disabled=true;$('#pk_mod').disabled=true;drawPick();go(12);}
function drawPick(){const g=$('#pk_list');g.innerHTML='';
  P.items.forEach((it,i)=>{const b=el('button','card'+(i===P.sel?' on':''),'<span class="tag"></span><b></b><small></small><p class="why"></p>');
    b.querySelector('.tag').textContent=it.orig?'Votre idée':(P.serie?'Série ':'Idée ')+(it.orig?'':(i+(P.items[0]&&P.items[0].orig?0:1)));
    b.querySelector('b').textContent=it.t||'(sans titre)';b.querySelector('small').textContent=it.r||'';
    const w=b.querySelector('.why');w.textContent=(it.w?'Pourquoi : '+it.w:'')+(it.p?(it.w?'\n':'')+'Adapté à ton profil : '+it.p:'');w.style.whiteSpace='pre-line';if(!w.textContent)w.remove();
    b.onclick=()=>{P.sel=i;drawPick();$('#pk_pick').disabled=false;$('#pk_mod').disabled=false;};g.appendChild(b);});}
$('#pk_pick').onclick=()=>{const it=P.items[P.sel];if(!it)return;W.titre=it.orig?'':it.t;W.resume=it.r;W.adapt=it.p||'';showConfirm();};
$('#pk_more').onclick=()=>P.regen();
$('#pk_mod').onclick=()=>{const it=P.items[P.sel];if(!it)return;$('#pk_et').value=it.t||'';$('#pk_er').value=it.r||'';$('#pk_edit').style.display='';$('#pk_edit').scrollIntoView&&$('#pk_edit').scrollIntoView({block:'center'});};
$('#pk_es').onclick=()=>{const it=P.items[P.sel];if(!it)return;it.t=val('#pk_et');it.r=val('#pk_er');if(it.orig){W.idee=it.r;}$('#pk_edit').style.display='none';drawPick();};
function showConfirm(){const s=W.kind==='serie';
  $('#cf_t').textContent=W.flow==='idee'?'Votre idée':'Idée sélectionnée';
  $('#cf_s').textContent=W.flow==='idee'||W.flow==='lien'?'Voici l’idée avec laquelle nous allons travailler':(s?'Voici l’idée de série que vous avez choisie':'Voici l’idée que vous avez choisie');
  $('#cf_k').textContent=s?'Série':'Idée';$('#cf_ti').textContent=W.titre||'';$('#cf_ti').style.display=W.titre?'':'none';$('#cf_r').textContent=W.resume||'';
  $('#cf_ok').textContent=s?'Créer une nouvelle série avec cette idée':'Continuer avec cette idée';go(13);}
$('#cf_ok').onclick=()=>{if(W.kind==='serie'){W.ser={id:'s'+Date.now(),name:W.titre||'Ma série',concept:W.resume||'',duree:W.duree||30,pub:W.pub||'',theme:W.theme||'',profile:(W.prof&&W.profCtx||'').slice(0,1200),eps:[],chars:[],rules:[]};
    chips('#ne_c',NBEP,false,[]);$('#ne_ok').disabled=true;go(20);}else openStruct();};

/* ---------- série : réglages ---------- */
chips('#ne_c',NBEP,false,[],()=>{});
$('#ne_c').addEventListener('click',()=>{$('#ne_ok').disabled=!cv('#ne_c');});
$('#ne_ok').onclick=()=>{const v=cv('#ne_c');W.ser.nbEp=v.startsWith('Je ne')?'':parseInt(v,10);chips('#ss_c',VSTY,true,W.ser.style||[]);$('#ss_p').value='';$('#ss_t').value=W.ton||'';go(21);};
function fillStyle(d,c,fields){if(!d)return;if(!cv(c,true).length&&Array.isArray(d.style)){const a=d.style.filter(x=>VSTY.includes(x));if(a.length)setChips(c,a);}
  fields.forEach(([id,k])=>{if(!val(id)&&d[k])$(id).value=cl(d[k],140);});}
$('#ss_w').onclick=()=>wandRun($('#ss_w'),async()=>{const s=W.ser;
  const d=await askJ('Série pour vidéos courtes :\nTitre : '+s.name+'\nConcept : '+s.concept+'\nDurée par épisode : '+(s.duree||30)+' secondes\n\nPropose l’univers visuel de toute la série. Format : {"style":["1 ou 2 parmi : '+VSTY.join(', ')+'"],"palette":"max 100 caractères","ton":"max 80 caractères"}',700);
  fillStyle(d,'#ss_c',[['#ss_p','palette'],['#ss_t','ton']]);});
$('#ss_ok').onclick=()=>{const s=W.ser;s.style=cv('#ss_c',true);s.palette=val('#ss_p');s.tone=val('#ss_t');if(!s.chars.length)s.chars=[{}];drawChars();go(22);};
function drawChars(){const l=$('#pc_l');l.innerHTML='';
  W.ser.chars.forEach((c,i)=>{const d=el('div','pc','<h3><span>Personnage '+(i+1)+'</span>'+(W.ser.chars.length>1?'<button type="button">Retirer</button>':'')+'</h3>'+
    fld('Nom','<input class="num cn" type="text" maxlength="40" autocomplete="off">')+fld('Description physique détaillée','<textarea class="num cd" maxlength="400"></textarea>')+
    fld('Personnalité','<input class="num cp" type="text" maxlength="160" autocomplete="off">',1)+fld('Rôle','<input class="num cr" type="text" maxlength="80" autocomplete="off">')+
    fld('Voix (genre, âge, grain, accent, ton, rythme)','<textarea class="num cv" maxlength="300" style="min-height:64px"></textarea>',1));
    d.querySelector('.cn').value=c.name||'';d.querySelector('.cd').value=c.desc||'';d.querySelector('.cp').value=c.perso||'';d.querySelector('.cr').value=c.role||'';d.querySelector('.cv').value=c.voice||'';
    const rm=d.querySelector('h3 button');if(rm)rm.onclick=()=>{readChars();W.ser.chars.splice(i,1);drawChars();};l.appendChild(d);});}
function readChars(){W.ser.chars=$$('#pc_l .pc').map(d=>{const g=q=>d.querySelector(q).value.trim();return {name:g('.cn'),desc:g('.cd'),perso:g('.cp'),role:g('.cr'),voice:g('.cv')};});}
$('#pc_add').onclick=()=>{readChars();W.ser.chars.push({});drawChars();const n=$$('#pc_l .cn');n[n.length-1].focus();};
$('#pc_w').onclick=()=>wandRun($('#pc_w'),async()=>{readChars();const s=W.ser;
  const d=await askJ('Série pour vidéos courtes :\nTitre : '+s.name+'\nConcept : '+s.concept+'\nStyle visuel : '+nz((s.style||[]).join(', '))+'\nPersonnages déjà saisis :\n'+charsTxt(s)+
    '\n\nPropose 2 personnages principaux qui reviendront dans plusieurs épisodes (respecte ceux déjà saisis, ne les remplace pas). Format : {"personnages":[{"nom":"","physique":"description physique détaillée (âge, visage, cheveux, tenue, signes distinctifs)","personnalite":"","role":"","voix":"genre, âge, grain, accent, ton, rythme"}]}',1800);
  const a=(d.personnages||[]).slice(0,3);a.forEach((p,i)=>{let c=s.chars[i];if(!c){c={};s.chars.push(c);}
    if(!c.name)c.name=cl(p.nom,40);if(!c.desc)c.desc=cl(p.physique,400);if(!c.perso)c.perso=cl(p.personnalite,160);if(!c.role)c.role=cl(p.role,80);if(!c.voice)c.voice=cl(p.voix,300);});drawChars();});
$('#pc_ok').onclick=()=>{readChars();const s=W.ser;s.chars=s.chars.filter(c=>c.name||c.desc||c.perso||c.role||c.voice);chips('#ru_c',RULES,true,s.rules||[]);$('#ru_o').value=s.rulesText||'';go(23);};
$('#ru_ok').onclick=()=>{const s=W.ser;s.rules=cv('#ru_c',true);s.rulesText=val('#ru_o');saveSer(s);openEp();};

/* ---------- série : épisode ---------- */
function openEp(){const s=W.ser,n=(s.eps.reduce((m,e)=>Math.max(m,e.num),0))+1;W.kind='serie';W.hts=0;W.ep={num:n};
  $('#ep_n').textContent='Épisode '+n;['#ep_t','#ep_r','#ep_o','#ep_c'].forEach(i=>$(i).value='');
  const p=prevEps(s,n);$('#ep_cw').style.display=n>1?'':'none';if(p.length){const l=p[p.length-1];$('#ep_c').value='Épisode '+l.num+(l.titre?' « '+l.titre+' »':'')+' : '+(l.resume||'');}
  $('#ep_ok').disabled=true;go(24);}
const epChk=()=>{$('#ep_ok').disabled=!(val('#ep_t')||val('#ep_r'));};
['#ep_t','#ep_r'].forEach(i=>$(i).addEventListener('input',epChk));
R.querySelectorAll('.sg .mini').forEach(b=>b.onclick=()=>wandRun(b,async()=>{const f=b.dataset.s,s=W.ser,n=W.ep.num;
  const lab={titre:'un titre court et accrocheur (max 60 caractères)',resume:'un résumé de l’épisode en 2 à 3 phrases',objectif:'l’objectif de cet épisode en une phrase (ce qui doit avancer ou être révélé)'}[f];
  const cur={num:n,titre:val('#ep_t'),resume:val('#ep_r'),objectif:val('#ep_o'),continuite:n>1?val('#ep_c'):''};
  const d=await askJ('Série pour vidéos courtes :\n'+serBlock(s)+'\n\nPersonnages :\n'+charsTxt(s)+'\n\nÉpisodes précédents :\n'+prevTxt(s,n)+'\n\nÉpisode en cours de préparation :\n'+epBlock(cur)+
    '\n\nPropose '+lab+'. Reste cohérent avec la série et les épisodes précédents, n’invente aucune continuité qui n’existe pas. Format : {"valeur":""}',700);
  const v=cl(d.valeur,f==='titre'?100:700);if(!v)throw new Error('Aucune suggestion reçue. Réessaie.');$({titre:'#ep_t',resume:'#ep_r',objectif:'#ep_o'}[f]).value=v;epChk();}));
$('#ep_ok').onclick=()=>{const e=W.ep;e.titre=val('#ep_t');e.resume=val('#ep_r');e.objectif=val('#ep_o');e.continuite=W.ep.num>1?val('#ep_c'):'';W.duree=W.ser.duree||30;openStruct();};

/* ---------- structure (commune) ---------- */
function openStruct(){const serie=W.kind==='serie';
  $('#st_s').textContent=serie?'Comment doit être construit cet épisode ?':'Comment doit être construite la vidéo ?';
  const d=(serie?W.ser.duree:W.duree)||30;chips('#st_d',DURS,false,[DURS.includes(d+' s')?d+' s':'30 s']);
  ['#st_h','#st_v','#st_t','#st_c','#st_sc'].forEach(i=>$(i).value='');$('#st_sw').style.display='none';go(18);}
const stDur=()=>durNum(cv('#st_d'))||30;
function structPrompt(){const serie=W.kind==='serie',d=stDur();
  const mine=[['Hook (3 premières secondes)','#st_h'],['Développement','#st_v'],['Twist / moment fort','#st_t'],['Call-to-action','#st_c']].filter(x=>val(x[1])).map(x=>x[0]+' : '+val(x[1]));
  const m=mine.length?'\nÉléments déjà définis par l’utilisateur (à respecter) :\n'+mine.join('\n')+'\n':'';
  if(serie)return 'Tu es un expert en structure de vidéos courtes (épisodes de série).\n\n'+serieCtx()+'\nDurée : '+d+' secondes\n'+m+'\nPropose une structure optimisée en 3 à 6 scènes, cohérente avec la série.\nRéponds uniquement au format :\n\nScène 1 (0-Xs) : description\nScène 2 (X-Ys) : description\n...';
  return 'Tu es un expert en structure de vidéos courtes.\n\nIdée :\n'+(W.flow==='idee'&&!W.titre?W.resume:'Titre : '+nz(W.titre,'(à définir)')+'\nRésumé : '+nz(W.resume))+'\nTon : '+nz(W.ton)+'\nDurée : '+d+' secondes\n'+m+'\nPropose une structure optimisée en 3 à 6 scènes.\nRéponds uniquement au format :\n\nScène 1 (0-Xs) : description\nScène 2 (X-Ys) : description\n...';}
$('#st_ai').onclick=async()=>{const b=$('#st_ai'),o=b.textContent;b.disabled=true;b.textContent='L’IA construit la structure…';
  try{let t=await askT(structPrompt(),1800);t=t.replace(/\*\*|__/g,'');const i=t.search(/Sc[èe]ne\s*1/i);if(i>0)t=t.slice(i);$('#st_sc').value=t.trim();$('#st_sw').style.display='';$('#st_sw').scrollIntoView&&$('#st_sw').scrollIntoView({block:'center'});}
  catch(e){toast(String(e&&e.message||'Erreur'));}finally{b.disabled=false;b.textContent=o;}};
$('#st_ok').onclick=()=>{const parts=[],sc1=val('#st_sc');if(sc1)parts.push(sc1);
  [['Hook','#st_h'],['Développement','#st_v'],['Twist / Moment fort','#st_t'],['Call-to-action','#st_c']].forEach(x=>{const v=val(x[1]);if(v)parts.push(x[0]+' : '+v);});
  if(!parts.length){toast('Renseigne la structure ou laisse l’IA la proposer.');return;}
  const st=parts.join('\n'),d=stDur();
  if(W.kind==='serie'){W.ep.struct=st;W.ep.dur=d;openDir();}else{W.struct=st;W.duree=d;openVStyle();}};

/* ---------- style : vidéo unique ---------- */
function openVStyle(){chips('#sv_c',VSTY,true,['Cinématique']);$('#sv_a').value=W.ton||'';$('#sv_m').value='';$('#sv_e').value='';go(19);}
$('#sv_w').onclick=()=>wandRun($('#sv_w'),async()=>{const d=await askJ('Vidéo courte à illustrer :\n'+ideaTxt()+'\n\nStructure :\n'+(W.struct||'')+'\nTon : '+nz(W.ton)+
  '\n\nPropose la direction visuelle. Format : {"style":["1 ou 2 parmi : '+VSTY.join(', ')+'"],"ambiance":"max 80 caractères","camera":"max 120 caractères","effets":"max 120 caractères"}',800);
  fillStyle(d,'#sv_c',[['#sv_a','ambiance'],['#sv_m','camera'],['#sv_e','effets']]);});
$('#sv_ok').onclick=()=>{const st=cv('#sv_c',true);if(!st.length&&!val('#sv_a')){toast('Choisis au moins un style visuel.');return;}
  W.style=st.join(', ')||'à définir selon l’idée';W.ambiance=val('#sv_a');
  W.direction='Style visuel : '+W.style+(W.ambiance?'\nAmbiance : '+W.ambiance:'')+(val('#sv_m')?'\nMouvements de caméra : '+val('#sv_m'):'')+(val('#sv_e')?'\nEffets spéciaux : '+val('#sv_e'):'');generate();};

/* ---------- direction artistique : épisode ---------- */
const DI=['Garder le style de la série','Ajuster (mouvements de caméra, intensité, éclairage, effets)'];
function openDir(){chips('#di_c',DI,false,[DI[0]],v=>{$('#di_a').style.display=v===DI[1]?'':'none';});$('#di_a').style.display='none';['#di_m','#di_i','#di_l','#di_e'].forEach(i=>$(i).value='');$('#di_r').textContent='Style de la série : '+nz((W.ser.style||[]).join(', '),'non défini')+(W.ser.palette?' · Palette : '+W.ser.palette:'')+(W.ser.tone?' · Ton : '+W.ser.tone:'');go(25);}
$('#di_ok').onclick=()=>{const s=W.ser,adj=cv('#di_c')===DI[1];
  W.ep.direction='Garder le style de la série : '+nz((s.style||[]).join(', '),'défini dans la fiche série')+(s.palette?' | palette : '+s.palette:'')+(s.tone?' | ton : '+s.tone:'')+
   (adj?'\nAjustements pour cet épisode :'+(val('#di_m')?'\n- Mouvements de caméra : '+val('#di_m'):'')+(val('#di_i')?'\n- Intensité : '+val('#di_i'):'')+(val('#di_l')?'\n- Éclairage : '+val('#di_l'):'')+(val('#di_e')?'\n- Effets : '+val('#di_e'):''):'');
  generate();};

/* ---------- génération des prompts ---------- */
function briefText(){
  if(W.kind==='serie'){const s=W.ser,e=W.ep;return '=== SÉRIE ===\n'+serBlock(s)+'\n\n=== PERSONNAGES (à décrire de façon identique dans chaque prompt où ils apparaissent) ===\n'+charsTxt(s)+'\n\n=== RÈGLES / À ÉVITER ===\n'+rulesTxt(s)+
    '\n\n=== ÉPISODES PRÉCÉDENTS ===\n'+prevTxt(s,e.num)+'\n\n=== ÉPISODE '+e.num+' ===\n'+epBlock(e).replace(/^Épisode \d+\n/,'')+'\nDurée : '+(e.dur||s.duree||30)+' secondes\n\n=== STRUCTURE VALIDÉE ===\n'+e.struct+'\n\n=== DIRECTION ARTISTIQUE ===\n'+e.direction;}
  return '=== IDÉE ===\n'+(W.titre?'Titre : '+W.titre+'\nRésumé : '+W.resume:W.resume)+'\n\n=== INFORMATIONS ===\nTon : '+nz(W.ton||W.ambiance,'à définir selon l’idée')+'\nStyle visuel : '+W.style+'\nDurée : '+W.duree+' secondes'+(W.theme?'\nUnivers : '+W.theme:'')+(W.pub?'\nPublic : '+W.pub:'')+(W.flow==='lien'?'\nInspiration originale : Vidéo analysée via lien'+(W.objectif?'\nObjectif de l’utilisateur : '+W.objectif:'')+(W.lienSum?'\nRésumé de la vidéo d’origine : '+W.lienSum:''):'')+(W.prof&&W.profCtx?'\nAdaptation au profil du créateur (données réelles) : '+String(W.profCtx).slice(0,1200)+(W.adapt?'\nAdaptation retenue pour cette idée : '+W.adapt:''):'')+
    '\n\n=== STRUCTURE VALIDÉE ===\n'+W.struct+'\n\n=== DIRECTION ARTISTIQUE ===\n'+W.direction;}
const MARKS='\nFORMAT OBLIGATOIRE : écris chaque partie sous un titre placé seul sur sa ligne, exactement comme ci-dessous, sans rien d’autre sur cette ligne ni avant/après le contenu :\n=== ANALYSE ===\n=== STRUCTURE ===\n=== SCÈNE 1 (0-5s) ===   (un titre de ce type pour chaque scène, suivi du prompt en anglais)\n=== TEXTES À L’ÉCRAN ===\n=== AMBIANCE SONORE ===\n=== TITRE ===\n=== DESCRIPTION ===   (sans hashtags)\n=== HASHTAGS ===   (séparés par des espaces)\n=== HEURE DE PUBLICATION ===   (un conseil d’horaire avec une raison courte, sans inventer de statistiques)\n=== COMMENTAIRE ÉPINGLÉ ===\n=== COUVERTURE ===   (texte à mettre sur la couverture + idée d’image)';
function genPrompt(brief){const serie=W.kind==='serie';
  return 'Tu es un expert senior en ingénierie de prompts vidéo pour Kling, Runway, Luma, Pika, etc.\n\nVoici le brief complet de '+(serie?'l’épisode':'la vidéo')+' :\n\n'+brief+
   '\n\nTa mission :\n1. Fais une très courte analyse\n2. Confirme la structure finale avec timestamps\n3. Écris un prompt vidéo ultra-détaillé en anglais pour chaque scène\n4. Ajoute les textes à l’écran\n5. Propose l’ambiance sonore recommandée\n6. Prépare les informations de publication (titre, description, hashtags, heure de publication, commentaire épinglé, couverture)\n\n'+
   'Chaque prompt doit contenir : sujet, action, émotion, éclairage, mouvement de caméra, style, ratio 9:16.'+
   (serie?'\nDans chaque prompt de scène, redécris le physique exact de chaque personnage présent avec les mêmes mots que sa fiche, indique ce qu’il dit et avec quelle voix (selon sa fiche), respecte les règles de la série et reste cohérent avec l’épisode précédent.':'')+
   (/Adaptation au profil/.test(brief)?'\nAdaptation au profil du créateur : le titre, la description, les hashtags (reprends ceux qui marchent chez lui s’ils sont pertinents), le commentaire épinglé, les textes à l’écran et le ton doivent coller à son audience et à son style habituel ; ne répète pas les sujets déjà traités.':'')+'\nRègles pour les prompts de scène : chaque prompt est autonome (le générateur ne se souvient d’aucune autre scène) : redécris le sujet, le décor et la lumière à chaque fois ; une seule action claire et filmable ; précise l’échelle de plan et un seul mouvement de caméra ; répète les mêmes mots-clés de style dans toutes les scènes ; aucun texte ni logo dans l’image générée (les textes s’ajoutent au montage) ; chaque scène dure 3 à 8 secondes et leur somme égale la durée totale ; termine chaque prompt par « vertical 9:16 ». Respecte à la lettre la structure validée, le ton, le style et la direction artistique.\nLes prompts de scène sont en anglais ; les textes à l’écran et les informations de publication sont en français.\n'+MARKS;}
function normK(s){return String(s).toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^A-Z0-9 ]/g,' ').replace(/\s+/g,' ').trim();}
function parseOut(t,brief){t=String(t).replace(/\*\*|__/g,'');const o={scenes:[],brief:brief};
  const re=/^[ \t]*(?:={2,}|#{2,})[ \t]*(.+?)[ \t]*(?:={2,}|#{2,})?[ \t]*$/gm,hs=[];let m;while((m=re.exec(t)))hs.push({h:m[1].trim(),a:m.index,b:re.lastIndex});
  const K={ANALYSE:'analyse',STRUCTURE:'structure',TEXTES:'textes',AMBIANCE:'ambiance',TITRE:'titre',DESCRIPTION:'description',HASHTAGS:'tags',HEURE:'heure',COMMENTAIRE:'comm',COUVERTURE:'couv'};
  hs.forEach((x,i)=>{const body=t.slice(x.b,i+1<hs.length?hs[i+1].a:t.length).trim(),k=normK(x.h);
    if(/^SCENE\b/.test(k)){o.scenes.push({h:x.h.replace(/^SC[ÈE]NE/i,'Scène'),p:body});return;}
    const f=Object.keys(K).find(z=>k.startsWith(z));if(f)o[K[f]]=body;});
  if(!o.scenes.length)o.scenes=[{h:'Prompt',p:t.trim()}];return o;}
async function askGen(){const brief=briefText(),t=await ixAsk(TX_SYS,genPrompt(brief),7000);if(!String(t||'').trim())throw new Error('Réponse vide de l’IA. Réessaie.');return parseOut(t,brief);}
function generate(){run('gen',askGen,showResult);}

/* ---------- résultat ---------- */
function outText(o,k){const j=a=>a.filter(Boolean).join('\n\n');
  if(k==='p')return j(o.scenes.map(s=>s.h+'\n'+s.p).concat([o.textes&&'TEXTES À L’ÉCRAN\n'+o.textes,o.ambiance&&'AMBIANCE SONORE\n'+o.ambiance]));
  return j([['TITRE',o.titre],['DESCRIPTION',o.description],['HASHTAGS',o.tags],['HEURE DE PUBLICATION',o.heure],['COMMENTAIRE ÉPINGLÉ',o.comm],['COUVERTURE',o.couv]].filter(x=>x[1]).map(x=>x[0]+'\n'+x[1]));}
function fullText(o){const s=W.kind==='serie'&&W.ser?'Série « '+W.ser.name+' » — Épisode '+(W.ep&&W.ep.num)+(W.ep&&W.ep.titre?' : '+W.ep.titre:''):(W.titre||W.resume||'Vidéo');
  return [s,o.analyse&&'ANALYSE\n'+o.analyse,o.structure&&'STRUCTURE\n'+o.structure,'=== PROMPTS ===\n'+outText(o,'p'),'=== INFOS ===\n'+outText(o,'i')].filter(Boolean).join('\n\n');}
function persist(){const o=curOut;if(!o)return;
  const mk=m=>({paroles:outText(o,'p'),dtxt:outText(o,'i'),description:o.description||'',tags:String(o.tags||'').split(/\s+/).filter(x=>x[0]==='#'),ia:Object.assign({out:o},m)});
  if(W.kind==='serie'&&W.ser){const s=W.ser,e=W.ep;let r=s.eps.find(x=>x.num===e.num);if(!r){r={num:e.num};s.eps.push(r);}
    Object.assign(r,{titre:e.titre,resume:e.resume,objectif:e.objectif,continuite:e.continuite,dur:e.dur,struct:e.struct,direction:e.direction,out:o,ts:Date.now()});
    r.hts=histPut(r.hts,'Série « '+s.name+' » — Épisode '+e.num+(e.titre?' : '+e.titre:''),mk({serie:s.id,ep:e.num}));saveSer(s);}
  else W.hts=histPut(W.hts,(W.titre||W.resume||'Vidéo').slice(0,90),mk({flow:W.flow}));}
function showResult(o){curOut=o;editOut=false;persist();showResultView();}
function showResultView(){const o=curOut,serie=W.kind==='serie';
  $('#rs_s').textContent=serie&&W.ser?'Série « '+W.ser.name+' » — Épisode '+(W.ep&&W.ep.num):(W.titre||'');
  $('#rs_mod').textContent='Modifier';editOut=false;
  const nx=$('#rs_nxt');nx.style.display='';nx.textContent=serie?'Créer l’épisode suivant':(W.flow==='lien'?'Partir d’un nouveau lien':'Créer une nouvelle idée');
  if(serie&&!W.ser)nx.style.display='none';$('#rs_all').style.display=serie&&W.ser?'':'none';
  $$('#rs_tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t==='p'));drawOut('p');go(26);}
let rsTab='p';
function obk(label,text,path,extra){const d=el('div','ob','<span class="tag"></span><p class="tx"></p><div class="bt"><button data-a="c">Copier</button></div>');d.querySelector('.tag').textContent=label;
  const p=d.querySelector('.tx');p.textContent=text;p.dataset.path=path;p.contentEditable=editOut?'true':'false';
  d.querySelector('[data-a=c]').onclick=e=>copyTxt(p.textContent,e.target,'Copier');if(extra)extra(d.querySelector('.bt'));return d;}
function drawOut(t){rsTab=t;const b=$('#rs_b'),o=curOut;b.innerHTML='';
  if(t==='p'){if(o.analyse)b.appendChild(obk('Analyse',o.analyse,'analyse'));if(o.structure)b.appendChild(obk('Structure',o.structure,'structure'));
    o.scenes.forEach((s,i)=>b.appendChild(obk(s.h,s.p,'scene:'+i,bt=>{const v=el('button','',' Variantes');v.textContent='Variantes';v.onclick=()=>openVar(i);bt.appendChild(v);})));
    if(o.textes)b.appendChild(obk('Textes à l’écran',o.textes,'textes'));if(o.ambiance)b.appendChild(obk('Ambiance sonore recommandée',o.ambiance,'ambiance'));}
  else{[['Titre','titre'],['Description','description'],['Hashtags','tags'],['Heure de publication','heure'],['Commentaire épinglé','comm'],['Couverture','couv']].forEach(x=>{if(o[x[1]])b.appendChild(obk(x[0],o[x[1]],x[1]));});
    if(!b.children.length)b.appendChild(el('p','hint','Aucune information de publication reçue. Régénère les prompts pour les obtenir.'));}}
function readEdits(){const o=curOut;$$('#rs_b .tx').forEach(p=>{const k=p.dataset.path,v=p.textContent.trim();if(k.startsWith('scene:'))o.scenes[+k.slice(6)].p=v;else o[k]=v;});}
$$('#rs_tabs button').forEach(b=>b.onclick=()=>{if(editOut)finishEdit();$$('#rs_tabs button').forEach(x=>x.classList.toggle('on',x===b));drawOut(b.dataset.t);});
function finishEdit(){readEdits();editOut=false;$('#rs_mod').textContent='Modifier';persist();}
$('#rs_mod').onclick=()=>{if(editOut){finishEdit();drawOut(rsTab);}else{editOut=true;$('#rs_mod').textContent='Terminé';$$('#rs_b .tx').forEach(p=>p.contentEditable='true');}};
$('#rs_cp').onclick=()=>{if(editOut)finishEdit();copyTxt(rsTab==='p'?outText(curOut,'p'):outText(curOut,'i'),$('#rs_cp'),'Tout copier');};
$('#rs_exp').onclick=()=>{if(editOut)finishEdit();const txt=fullText(curOut);
  try{const nm=String((W.kind==='serie'&&W.ser?W.ser.name+' ep'+(W.ep&&W.ep.num):(W.titre||W.resume||'video'))).normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-zA-Z0-9]+/g,'-').toLowerCase().slice(0,40)||'video';
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'text/plain;charset=utf-8'}));a.download='prompts-'+nm+'.txt';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},500);toast('Fichier exporté.');}
  catch(e){copyTxt(txt,null,'');toast('Export impossible ici : texte copié.');}};
$('#rs_nxt').onclick=()=>{if(editOut)finishEdit();if(W.kind==='serie'){const s=loadSer().find(x=>x.id===W.ser.id)||W.ser;W.ser=s;openEp();}else if(W.flow==='lien')startLien();else if(W.flow==='idee')startIdee();else startSugg();};
$('#rs_all').onclick=()=>{if(editOut)finishEdit();openSerie(W.ser.id);};
/* ---- variantes d'une scène ---- */
$('#rs_var').onclick=()=>{if(editOut)finishEdit();openVar(-1);};
function openVar(i){const sc=curOut.scenes,labs=sc.map((s,k)=>'Scène '+(k+1));$('#va_l').innerHTML='';
  chips('#va_c',labs,false,i>=0?[labs[i]]:[],v=>{if(v)genVar(labs.indexOf(v));else $('#va_l').innerHTML='';});go(27);if(i>=0)genVar(i);}
async function genVar(k){const o=curOut,s=o.scenes[k],box=$('#va_l');box.innerHTML='<p class="hint">L’IA écrit 3 variantes…</p>';
  try{const brief=o.brief||ideaTxt();
    const t=await askT('Tu es un expert senior en ingénierie de prompts vidéo pour Kling, Runway, Luma, Pika, etc.\n\nVoici le brief complet :\n\n'+brief+'\n\nPrompt actuel de la scène « '+s.h+' » :\n'+s.p+
      '\n\nÉcris 3 variantes différentes de ce prompt (en anglais) : même durée, même continuité avec les autres scènes et les personnages, mais une mise en scène, un cadrage ou un mouvement de caméra différent. Chaque prompt doit contenir : sujet, action, émotion, éclairage, mouvement de caméra, style, ratio 9:16.\n\nFormat obligatoire :\n\nVariante 1 :\n...\n\nVariante 2 :\n...\n\nVariante 3 :\n...',3000);
    const parts=t.replace(/\*\*|__/g,'').split(/(?:^|\n)[ \t]*Variante\s*\d+\s*:?[ \t]*/i).map(x=>x.trim()).filter(Boolean).slice(0,3);if(!parts.length)throw new Error('Variantes illisibles. Réessaie.');
    box.innerHTML='';parts.forEach((p,n)=>{const d=obk('Variante '+(n+1),p,'v'+n,bt=>{const u=el('button','');u.textContent='Utiliser cette variante';u.onclick=()=>{o.scenes[k].p=p;persist();toast('Scène '+(k+1)+' remplacée.');};bt.appendChild(u);});box.appendChild(d);});}
  catch(e){box.innerHTML='';box.appendChild(el('p','hint',esc(String(e&&e.message||'Erreur')))); }}

/* ---------- séries enregistrées ---------- */
function renderSeries(){const l=loadSer(),b=$('#ml_l');b.innerHTML='';$('#ml_e').style.display=l.length?'none':'block';
  l.forEach(s=>{const x=el('button','card','<span class="tag"></span><b></b><small></small>');x.style.width='100%';x.querySelector('.tag').textContent=(s.eps||[]).length+' épisode'+((s.eps||[]).length>1?'s':'')+(s.nbEp?' / '+s.nbEp:'');x.querySelector('b').textContent=s.name;x.querySelector('small').textContent=String(s.concept||'').slice(0,100);x.onclick=()=>openSerie(s.id);b.appendChild(x);});}
function openSerie(id){const s=loadSer().find(x=>x.id===id);if(!s)return;W={flow:'sugg',kind:'serie',ser:s};
  $('#sr_t').textContent=s.name;$('#sr_s').textContent=(s.concept||'')+((s.eps||[]).length?'':' — aucun épisode pour l’instant');const l=$('#sr_l');l.innerHTML='';
  (s.eps||[]).slice().sort((a,b)=>a.num-b.num).forEach(e=>{const x=el('button','card','<span class="tag"></span><b></b><small></small>');x.style.width='100%';x.querySelector('.tag').textContent='Épisode '+e.num;x.querySelector('b').textContent=e.titre||'(sans titre)';x.querySelector('small').textContent=String(e.resume||'').slice(0,110);
    x.onclick=()=>{W.ser=s;W.ep=Object.assign({},e);curOut=e.out;showResultView();};l.appendChild(x);});go(28);}
$('#sr_nx').onclick=()=>{const s=loadSer().find(x=>x.id===W.ser.id)||W.ser;W.ser=s;openEp();};
function openIa(it){const ia=it.sc.ia;
  if(ia.serie){const s=loadSer().find(x=>x.id===ia.serie),r=s&&s.eps.find(e=>e.num===ia.ep);W={flow:'sugg',kind:'serie',ser:s||null,ep:r?Object.assign({},r):{num:ia.ep}};curOut=(r&&r.out)||ia.out;}
  else{W={flow:ia.flow||'sugg',kind:'video',hts:it.ts,titre:it.idea};curOut=ia.out;}
  showResultView();}

/* ================= BAGUETTE MAGIQUE : un bouton « suggérer » sur chaque écran à remplir ================= */
function addWand(n,fn){const s=R.querySelector('section[data-n="'+n+'"]');const b=el('button','wand fl',WAND);b.type='button';b.setAttribute('aria-label','Suggérer avec l’IA');b.onclick=()=>wandRun(b,fn);s.insertBefore(b,s.firstChild);s.classList.add('hw');}
function pick1(id,v,items){if(cv(id)||v==null)return false;const t=String(v).toLowerCase().trim();const f=items.find(x=>x.toLowerCase()===t)||items.find(x=>x.toLowerCase().startsWith(t.slice(0,6))&&t.length>2);if(f){setChips(id,[f]);return true;}return false;}
function put1(id,v,max){if(!val(id)&&v){$(id).value=cl(v,max||400);$(id).dispatchEvent(new Event('input'));}}
const ctxBrief=()=>W.kind==='serie'&&W.ser&&W.ep?serieCtx():'Idée :\n'+ideaTxt()+'\nTon : '+nz(W.ton)+'\nDurée : '+(W.duree?W.duree+' secondes':'non précisée');
/* 10 : J'ai déjà une idée */
addWand(10,async()=>{const c=await creatorCtx();const d=await askJ('Tu aides un créateur de vidéos courtes à trouver une idée de vidéo.'+ctxLine(c)+'\nDéjà saisi : idée « '+val('#a_txt')+' », ton « '+val('#a_ton')+' », durée « '+cv('#a_dur')+' ».\n\nComplète l’écran : si l’idée est vide, propose-en une originale en 2 phrases ; propose un ton et une durée si absents. Format : {"idee":"","ton":"max 40 caractères","duree":30}',900);
  put1('#a_txt',d.idee,900);put1('#a_ton',d.ton,80);pick1('#a_dur',(d.duree||'')+' s',DURS);});
/* 15 : thème */
addWand(15,async()=>{const c=await creatorCtx();const d=await askJ('Tu aides à choisir l’univers d’une idée de '+(W.kind==='serie'?'série':'vidéo')+' pour vidéos courtes.'+ctxLine(c)+'\nDéjà saisi : univers « '+(cv('#th_c')||val('#th_o'))+' », précision « '+val('#th_p')+' ».\n\nChoisis un univers parmi : '+THEMES.slice(0,9).join(', ')+' et écris une précision d’envie en une phrase. Format : {"theme":"","precision":""}',600);
  pick1('#th_c',d.theme,THEMES);thOk();put1('#th_p',d.precision,400);});
/* 16 : affinage */
addWand(16,async()=>{const d=await askJ('Idée recherchée : univers « '+W.theme+' », précision « '+nz(W.precision)+' », pour '+(W.kind==='serie'?'une série':'une vidéo')+' courte.\nChoisis le ton parmi : '+TONS.join(', ')+' ; le public parmi : '+PUBS.join(', ')+' ; la durée parmi : 15, 30, 45, 60 (secondes). Format : {"ton":"","public":"","duree":30}',400);
  pick1('#af_t',d.ton,TONS);pick1('#af_p',d.public,PUBS);pick1('#af_d',(d.duree||'')+' s',DURS);});
/* 17 : lien — l'IA ne peut pas deviner le contenu, elle propose seulement l'objectif */
/* 18 : structure */
addWand(18,async()=>{const d=await askJ('Vidéo courte de '+stDur()+' secondes à structurer :\n'+ctxBrief()+'\n\nÉcris : le hook (les 3 premières secondes), le développement, le twist / moment fort et le call-to-action, chacun en 1 à 2 phrases. Format : {"hook":"","developpement":"","twist":"","cta":""}',1100);
  put1('#st_h',d.hook,300);put1('#st_v',d.developpement,400);put1('#st_t',d.twist,300);put1('#st_c',d.cta,200);});
/* 20 : nombre d'épisodes */
addWand(20,async()=>{const d=await askJ('Série pour vidéos courtes :\n'+W.ser.name+' — '+W.ser.concept+'\nChoisis le nombre d’épisodes le plus adapté parmi 3, 5, 8, 10. Format : {"nb":5}',200);
  if(pick1('#ne_c',(d.nb||'')+' épisodes',NBEP))$('#ne_ok').disabled=false;});
/* 23 : règles */
addWand(23,async()=>{const s=W.ser;const d=await askJ('Série pour vidéos courtes :\n'+serBlock(s)+'\nPersonnages :\n'+charsTxt(s)+'\n\nChoisis les règles utiles parmi : '+RULES.join(' ; ')+' et ajoute au besoin une règle personnalisée courte. Format : {"regles":["",""],"autre":""}',500);
  if(!cv('#ru_c',true).length)setChips('#ru_c',(d.regles||[]).filter(x=>RULES.includes(x)));put1('#ru_o',d.autre,300);});
/* 24 : épisode complet */
addWand(24,async()=>{const s=W.ser,n=W.ep.num;const cur={num:n,titre:val('#ep_t'),resume:val('#ep_r'),objectif:val('#ep_o'),continuite:n>1?val('#ep_c'):''};
  const d=await askJ('Série pour vidéos courtes :\n'+serBlock(s)+'\n\nPersonnages :\n'+charsTxt(s)+'\n\nÉpisodes précédents :\n'+prevTxt(s,n)+'\n\nÉpisode en préparation :\n'+epBlock(cur)+'\n\nComplète les champs vides : titre (max 60 caractères), résumé (2 à 3 phrases), objectif (1 phrase). Reste cohérent, n’invente aucune continuité inexistante. Format : {"titre":"","resume":"","objectif":""}',900);
  put1('#ep_t',d.titre,100);put1('#ep_r',d.resume,700);put1('#ep_o',d.objectif,400);epChk();});
/* 25 : direction de l'épisode */
addWand(25,async()=>{const s=W.ser,e=W.ep;const d=await askJ('Épisode de série :\n'+serBlock(s)+'\n'+epBlock(e)+'\nStructure :\n'+(e.struct||'')+'\n\nPropose des ajustements de direction pour cet épisode. Format : {"camera":"max 100 caractères","intensite":"max 100 caractères","eclairage":"max 100 caractères","effets":"max 100 caractères"}',600);
  setChips('#di_c',[DI[1]]);$('#di_a').style.display='';put1('#di_m',d.camera,140);put1('#di_i',d.intensite,140);put1('#di_l',d.eclairage,140);put1('#di_e',d.effets,140);});

/* ---- structure : l'IA complète si on laisse vide ---- */
$('#st_ok').textContent='Continuer';
async function genStruct(){let t=await askT(structPrompt(),1800);t=t.replace(/\*\*|__/g,'');const i=t.search(/Sc[èe]ne\s*1/i);if(i>0)t=t.slice(i);$('#st_sc').value=t.trim();$('#st_sw').style.display='';}
async function stBusy(b,fn){const o=b.textContent;b.disabled=true;b.textContent='L’IA construit la structure…';try{await fn();return true;}catch(e){toast(String(e&&e.message||'Erreur'));return false;}finally{b.disabled=false;b.textContent=o;}}
$('#st_ai').onclick=async()=>{if(await stBusy($('#st_ai'),genStruct)&&$('#st_sw').scrollIntoView)$('#st_sw').scrollIntoView({block:'center'});};
const stOk0=$('#st_ok').onclick;
$('#st_ok').onclick=async()=>{if(!val('#st_sc')&&!val('#st_h')&&!val('#st_v')&&!val('#st_t')&&!val('#st_c')){if(!(await stBusy($('#st_ok'),genStruct)))return;}stOk0();};

/* ---- mise en page homogène : titre centré + baguette en haut à droite sur tous les écrans ---- */
[19,21,22].forEach(n=>{const s=R.querySelector('section[data-n="'+n+'"]'),h=s.querySelector('.hrow'),w=h.querySelector('.wand'),sub=h.querySelector('.sub'),t=s.querySelector('h1');
  t.className='c';t.removeAttribute('style');sub.className='sub c';sub.removeAttribute('style');w.classList.add('fl');s.insertBefore(w,s.firstChild);s.insertBefore(t,h);s.insertBefore(sub,h);h.remove();s.classList.add('hw');});

$$('.opt[data-m]').forEach(b=>b.onclick=()=>{const m=b.dataset.m;histId=0;
  if(m==='idee')startIdee();else if(m==='lien')startLien();else if(m==='sugg')startSugg();
  else{mode='coller';$('#it').textContent='Colle ton script';$('#is').textContent='Tu pourras ensuite l\'enregistrer avec le prompteur.';$('#txt').placeholder='Colle ton texte ici...';$('#txt').value='';$('#ok').disabled=true;go(1);}});
$('#copy').onclick=()=>{if(editing())endEdit();copyTxt(curText(),$('#copy'),'Copier');};
$('#edit').onclick=()=>{const b=$('#script');if(editing()){endEdit();}else{b.contentEditable=true;$('#edit').textContent='Terminé';b.focus();}};
$$('#tabs button').forEach(b=>b.onclick=()=>showTab(b.dataset.t));
$$('.thumbs button').forEach(b=>b.onclick=()=>{$$('.thumbs button').forEach(x=>x.classList.remove('on'));b.classList.add('on');});
/* ---------- prompteur ---------- */
let pOn=false,pPos=0,pSpd=3,pSize=26,pRaf=0,pLast=0;
function pStop(){pOn=false;cancelAnimationFrame(pRaf);const p=$('#pplay');if(p)p.innerHTML=PLAY;}
function pTick(t){if(!pOn)return;const dt=(t-pLast)/1000;pLast=t;const max=Math.max(0,$('#ptxt').offsetHeight-$('#pbox').offsetHeight);
  pPos=Math.min(max,pPos+pSpd*14*dt);$('#ptxt').style.transform='translateY('+(-pPos)+'px)';if(pPos>=max){pStop();return;}pRaf=requestAnimationFrame(pTick);}
function pStart(){pOn=true;pLast=performance.now();$('#pplay').innerHTML=PAUSE;pRaf=requestAnimationFrame(pTick);}
$('#pplay').onclick=()=>pOn?pStop():pStart();
$('#pslow').onclick=()=>{pSpd=Math.max(1,pSpd-1);$('#pspd').textContent='Vitesse '+pSpd;};
$('#pfast').onclick=()=>{pSpd=Math.min(8,pSpd+1);$('#pspd').textContent='Vitesse '+pSpd;};
$('#psm').onclick=()=>{pSize=Math.max(18,pSize-3);$('#ptxt').style.fontSize=pSize+'px';};
$('#pbg').onclick=()=>{pSize=Math.min(44,pSize+3);$('#ptxt').style.fontSize=pSize+'px';};
$('#pdone').onclick=()=>{pStop();go(6,true);if(hist.length&&hist[hist.length-1]===6)hist.pop();};
$('#prompt').onclick=()=>{if(editing())endEdit();$('#ptxt').textContent=sc.paroles;pPos=0;$('#ptxt').style.transform='none';pStop();go(7);};
})();
