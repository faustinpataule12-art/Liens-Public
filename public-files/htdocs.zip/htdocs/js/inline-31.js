/* ═══ FABLE FAST — diagnostic API et demande de clés ═══ */
(function(){
  'use strict';
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const labels={github:'GitHub',jina:'Jina',model:'modèle IA'};
  let modal=null, pending=null, busy=false;
  function modelName(){
    try { if(typeof activeName==='function') return activeName(); } catch(e){}
    try { return (S.customModel&&S.customModel.name)||S.model||'modèle IA'; } catch(e){return 'modèle IA';}
  }
  function serviceFromError(err){
    const s=String(err&&err.message||err||'');
    if(/github|api\.github\.com|gh token|token github/i.test(s)) return 'github';
    if(/jina|r\.jina\.ai|s\.jina\.ai|jina reader/i.test(s)) return 'jina';
    return 'model';
  }
  function reason(err,svc){
    const s=String(err&&err.message||err||'');
    if(!s || /aucune (api|clé)|aucun modèle|no api|no key|clé configurée/i.test(s)) return 'Aucun token utilisable n’est configuré.';
    if(/401|unauthori[sz]ed|invalid.*key|token invalide|révoqu|expir/i.test(s)) return 'Le token est invalide, expiré ou révoqué.';
    if(/403|forbidden|permission|quota|429|rate.?limit|limite/i.test(s)) return 'Accès refusé ou quota atteint par ce service.';
    if(/abort|timeout|délai/i.test(s)) return 'Le service n’a pas répondu dans le délai prévu.';
    if(/fetch|network|réseau|cors|injoign/i.test(s)) return 'Le service est injoignable depuis le navigateur.';
    return 'Le service a renvoyé une erreur ou une réponse vide.';
  }
  function add(svc,err,rerun){
    svc=svc||serviceFromError(err); const item={id:svc,label:labels[svc]||svc,why:reason(err,svc)};
    if(pending){ if(!pending.items.some(x=>x.id===svc)) pending.items.push(item); if(rerun) pending.rerun=rerun; render(); return; }
    pending={items:[item],rerun:rerun||null}; render();
    // Complète le diagnostic en arrière-plan : si plusieurs services sont en
    // panne, le même popup demande exactement les clés concernées.
    try{
      if(typeof npsApiCheck==='function') npsApiCheck(true).then(chk=>{
        (chk.items||[]).filter(x=>x.state!=='ok'&&x.state!=='warn').forEach(x=>{
          if(pending&&!pending.items.some(y=>y.id===x.id)) pending.items.push({id:x.id,label:x.id==='github'?'GitHub':x.id==='jina'?'Jina':'modèle IA',why:x.detail||'service indisponible'});
        });
        if(pending)render();
      }).catch(()=>{});
    }catch(e){}
  }
  function failureText(text){
    const s=String(text||'');
    if(!/❌|échec|erreur|aucune api|aucun modèle|injoignable|api .*n'a pas répondu/i.test(s)) return null;
    return {svc:serviceFromError(s),text:s};
  }
  function field(item){
    const id=item.id==='github'?'ff-api-gh':item.id==='jina'?'ff-api-jina':'ff-api-model';
    const ph=item.id==='github'?'Token GitHub (ghp_… ou github_pat_…)':item.id==='jina'?'Token Jina (facultatif selon ton compte)':'Clé du modèle IA utilisé';
    return `<label class="ff-api-field"><span>${esc(item.label)}</span><input id="${id}" data-api="${item.id}" type="password" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="${esc(ph)}"></label>`;
  }
  function render(){
    if(!pending)return;
    if(!modal){modal=document.createElement('div');modal.id='ff-api-modal';document.body.appendChild(modal);}
    const names=pending.items.map(x=>x.label).join(' et ');
    modal.innerHTML=`<div class="ff-modal-backdrop ff-api-backdrop" role="dialog" aria-modal="true" aria-labelledby="ff-api-title"><div class="ff-modal-sheet ff-api-sheet"><div class="ff-modal-head"><div class="ff-modal-head-title"><span class="ff-badge notif-badge">Connexion requise</span><h3 id="ff-api-title">${esc(names)} ne répond pas</h3></div><button class="ff-modal-close" data-api-close aria-label="Fermer">×</button></div><div class="ff-modal-body"><p class="ff-api-intro">${pending.items.length===1?'Cette API':'Ces API'} n’a pas pu être utilisée. Vérifie le token ci-dessous, puis réessaie. Les tentatives automatiques de Fable Fast restent conservées.</p><div class="ff-api-fields">${pending.items.map(field).join('')}</div><div id="ff-api-status" class="ff-api-status" aria-live="polite"></div><div class="ff-api-actions"><button class="ff-api-secondary" data-api-open>Ouvrir les clés API</button><button class="ff-api-primary" data-api-save>Enregistrer et réessayer</button></div></div></div></div>`;
    modal.querySelector('[data-api-close]').onclick=()=>{modal.remove();modal=null;pending=null;};
    modal.querySelector('[data-api-open]').onclick=()=>{try{showView('apikeys');}catch(e){};};
    modal.querySelector('[data-api-save]').onclick=saveAndRetry;
    modal.querySelector('.ff-api-backdrop').onclick=e=>{if(e.target===e.currentTarget){modal.remove();modal=null;pending=null;}};
  }
  async function saveAndRetry(){
    if(busy||!pending)return; busy=true;
    const st=modal&&modal.querySelector('#ff-api-status'), btn=modal&&modal.querySelector('[data-api-save]');
    if(st)st.textContent='Enregistrement et vérification…'; if(btn)btn.disabled=true;
    try{
      const vals={}; pending.items.forEach(x=>{const el=modal.querySelector('[data-api="'+x.id+'"]');vals[x.id]=el&&el.value.trim();});
      if(vals.github){const e=document.getElementById('fs-gh');if(e)e.value=vals.github;}
      if(vals.jina){const e=document.getElementById('fs-jina');if(e)e.value=vals.jina;}
      if(vals.model){const e=document.getElementById('fs-brain');if(e)e.value=vals.model;}
      if(typeof saveKeys==='function') await saveKeys();
      const retry=pending.rerun; pending=null; if(modal){modal.remove();modal=null;}
      busy=false;
      if(retry) setTimeout(()=>{try{retry();}catch(e){add(serviceFromError(e),e,retry);}},80);
    }catch(e){busy=false;if(st)st.textContent='Impossible d’enregistrer ce token. Vérifie la valeur puis réessaie.';if(btn)btn.disabled=false;}
  }
  window.ffApiFailure=function(service,err,rerun){add(service||serviceFromError(err),err,rerun);};
  window.ffApiFailureFromText=function(text,rerun){const f=failureText(text);if(f)add(f.svc,f.text,rerun);};
  // Enveloppe les appels IA : elle n’interrompt pas les retries internes de callAI.
  try{
    const original=window.callAI;
    if(typeof original==='function') window.callAI=async function(){try{return await original.apply(this,arguments);}catch(e){add('model',e,()=>window.callAI.apply(this,arguments));throw e;}};
  }catch(e){}
  // Enveloppe les outils : elle observe les résultats d’échec sans modifier leur contenu ni leurs retries.
  try{
    const original=window.executeTool;
    if(typeof original==='function') window.executeTool=async function(tool,onProgress,msg){
      const result=await original.apply(this,arguments); const f=failureText(typeof result==='string'?result:'');
      if(f)add(f.svc,result,()=>window.executeTool(tool,onProgress,msg)); return result;
    };
  }catch(e){}
})();
