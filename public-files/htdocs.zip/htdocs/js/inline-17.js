/* Fable Fast : cartes d'accueil + captures de video (10 max) */
function npsFill(t){const i=document.getElementById('comp-input');if(!i)return;i.value=t;try{growTA(i)}catch(e){}i.focus();try{i.setSelectionRange(t.length,t.length)}catch(e){}}
/* Une vidéo reçue par l'IA = UNE image : une mosaïque de captures régulières, chacune avec sa seconde (mm:ss) en bas à gauche.
   Lecture : ordre chronologique, de gauche à droite puis de haut en bas. 24 vignettes au maximum. */
function npsFmtT(s,dec){s=Math.max(0,s);const w=Math.floor(s),r=dec?(Math.round((s-w)*10)/10):0,t=r>=1?w+1:w,d=r>=1?0:Math.round(r*10);return String(Math.floor(t/60)).padStart(2,'0')+':'+String(t%60).padStart(2,'0')+(dec?'.'+d:'');}
function npsMosaic(tiles,portrait){
  const n=tiles.length;if(!n)return null;
  const cols=Math.min(n,portrait?(n>12?6:5):(n>12?5:4)),rows=Math.ceil(n/cols),gap=6,tw=tiles[0].c.width,th=tiles[0].c.height;
  const W=cols*tw+(cols+1)*gap,H=rows*th+(rows+1)*gap;
  const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');
  x.fillStyle='#0b0d12';x.fillRect(0,0,W,H);
  let labels=tiles.map(t=>npsFmtT(t.t));
  if(new Set(labels).size<labels.length)labels=tiles.map(t=>npsFmtT(t.t,1)); /* vidéo courte : un dixième de seconde pour que deux vignettes n'aient jamais la même heure */
  tiles.forEach((t,i)=>{
    const px=gap+(i%cols)*(tw+gap),py=gap+Math.floor(i/cols)*(th+gap);
    x.drawImage(t.c,px,py,tw,th);
    const lab=labels[i],fs=Math.max(14,Math.round(tw/16)),lh=Math.round(fs*1.6);
    x.font='bold '+fs+'px system-ui,sans-serif';x.textBaseline='middle';
    const lw=Math.round(x.measureText(lab).width)+fs;
    x.fillStyle='rgba(0,0,0,.72)';x.fillRect(px,py+th-lh,lw,lh);
    x.fillStyle='#fff';x.fillText(lab,px+fs/2,py+th-lh/2);
  });
  const k=Math.min(1,2600/Math.max(W,H));let o=c;
  if(k<1){o=document.createElement('canvas');o.width=Math.round(W*k);o.height=Math.round(H*k);const ox=o.getContext('2d');ox.imageSmoothingQuality='high';ox.drawImage(c,0,0,o.width,o.height);}
  return {url:o.toDataURL('image/jpeg',0.82),cols:cols,rows:rows};
}
function npsVideoFrames(file,max){max=Math.max(1,Math.min(24,max||12));return new Promise(resolve=>{
  const url=URL.createObjectURL(file),v=document.createElement('video'),out=[];out.times=[];out.meta=null;out.mosaic=null;out.cols=0;let done=false;
  const fin=()=>{if(done)return;done=true;clearTimeout(g);URL.revokeObjectURL(url);resolve(out);};
  const g=setTimeout(fin,120000);
  v.muted=true;v.playsInline=true;v.preload='auto';v.onerror=fin;
  v.onloadedmetadata=async()=>{
    const d=v.duration;if(!isFinite(d)||d<=0){fin();return;}
    const n=Math.min(max,Math.max(1,Math.round(d>=2?max:Math.ceil(d*10))));
    const vw=v.videoWidth||768,vh=v.videoHeight||432,portrait=vh>vw,tw=Math.min(portrait?360:480,vw),th=Math.round(tw*vh/vw),tiles=[];
    out.meta={duration:d,width:v.videoWidth||null,height:v.videoHeight||null};
    for(let i=0;i<n;i++){
      await new Promise(r=>{const f=()=>{v.removeEventListener('seeked',f);r();};v.addEventListener('seeked',f);v.currentTime=Math.min(d-0.05,(i+0.5)*d/n);setTimeout(r,4000);});
      try{const c=document.createElement('canvas');c.width=tw;c.height=th;c.getContext('2d').drawImage(v,0,0,tw,th);
        tiles.push({c:c,t:v.currentTime});out.push(c.toDataURL('image/jpeg',0.7));out.times.push(Math.round(v.currentTime*10)/10);}catch(e){}
    }
    try{const m=npsMosaic(tiles,portrait);if(m){out.mosaic=m.url;out.cols=m.cols;}}catch(e){}
    fin();
  };
  v.src=url;
});}
/* ===== Analyse vidéo : mesures LOCALES (aucune API, la vidéo ne quitte pas l'appareil) -> rapport brut "media_evidence"
   Règle : un champ ne vaut jamais "absent" par défaut. status "analyzed" = mesuré ; "not_analyzed" = inconnu (pas "aucun"). */
function ffAudioEvidence(file){
  const NA=why=>({status:'not_analyzed',reason:why});
  return new Promise(resolve=>{
    const AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)return resolve(NA('Web Audio indisponible sur ce navigateur'));
    if(file.size>150*1048576)return resolve(NA('fichier trop lourd pour être décodé sans risque (plus de 150 Mo)'));
    let fin=false;const done=v=>{if(!fin){fin=true;clearTimeout(g);resolve(v);}};
    const g=setTimeout(()=>done(NA('délai dépassé (25 s)')),25000);
    let ctx;try{ctx=new AC();}catch(e){return done(NA('contexte audio impossible'));}
    file.arrayBuffer().then(buf=>new Promise((ok,ko)=>{const r=ctx.decodeAudioData(buf,ok,ko);if(r&&r.then)r.then(ok,ko);})).then(ab=>{
      try{ctx.close();}catch(e){}
      const dur=ab.duration;
      if(!(dur>0))return done(NA('piste audio vide'));
      if(dur>300)return done(NA('vidéo de plus de 5 min : mesure audio non faite pour protéger la mémoire'));
      const ch=ab.numberOfChannels,n=ab.length,sr=ab.sampleRate,win=Math.max(1,Math.round(sr*0.1));
      const data=[];for(let c=0;c<ch;c++)data.push(ab.getChannelData(c));
      let sumSq=0,peak=0,clip=0;const rms=[];
      for(let w=0;w<n;w+=win){
        const e=Math.min(n,w+win);let s2=0;
        for(let i=w;i<e;i++){let v=0;for(let c=0;c<ch;c++)v+=data[c][i];v/=ch;const a=Math.abs(v);if(a>peak)peak=a;if(a>=0.99)clip++;s2+=v*v;}
        sumSq+=s2;rms.push(10*Math.log10(Math.max(s2/(e-w),1e-10)));
      }
      const r1=x=>Math.round(x*10)/10,avg=10*Math.log10(Math.max(sumSq/n,1e-10)),pk=20*Math.log10(Math.max(peak,1e-6));
      // silences : au moins 0,5 s sous -50 dBFS
      const sil=[];let st0=null;
      rms.forEach((d,i)=>{if(d<-50){if(st0===null)st0=i;}else{if(st0!==null&&(i-st0)>=5)sil.push({start:r1(st0*0.1),end:r1(i*0.1)});st0=null;}});
      if(st0!==null&&(rms.length-st0)>=5)sil.push({start:r1(st0*0.1),end:r1(rms.length*0.1)});
      const silT=sil.reduce((a,x)=>a+(x.end-x.start),0);
      // profil du volume : une valeur toutes les 2 s (max 30 points)
      const step=Math.max(20,Math.ceil(rms.length/30)),prof=[];
      for(let i=0;i<rms.length;i+=step){const sl=rms.slice(i,i+step);prof.push({t:r1(i*0.1),dbfs:r1(sl.reduce((a,b)=>a+b,0)/sl.length)});}
      const out={status:'analyzed',duration_s:r1(dur),channels:ch,average_dbfs:r1(avg),peak_dbfs:r1(pk),
        clipping:clip/(n*ch)>0.001,silence_segments:sil.slice(0,20),silence_ratio:r1(silT/dur*100)/100,volume_profile:prof,
        all_silent:avg<-60};
      Object.defineProperty(out,'__ab',{value:ab,enumerable:false});done(out);
    }).catch(()=>{try{ctx.close();}catch(e){}done(NA('piste audio absente ou format non décodable par ce navigateur'));});
  });
}

function ffWavBase64(ab){
  return new Promise((ok,ko)=>{
    try{
      const sr=16000,len=Math.max(1,Math.ceil(ab.duration*sr)),oc=new (window.OfflineAudioContext||window.webkitOfflineAudioContext)(1,len,sr),src=oc.createBufferSource();
      src.buffer=ab;src.connect(oc.destination);src.start();
      const p=oc.startRendering(),use=r=>{
        const d=r.getChannelData(0),n=d.length,buf=new ArrayBuffer(44+n*2),v=new DataView(buf),w=(o,t)=>{for(let i=0;i<t.length;i++)v.setUint8(o+i,t.charCodeAt(i));};
        w(0,'RIFF');v.setUint32(4,36+n*2,true);w(8,'WAVE');w(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,sr,true);v.setUint32(28,sr*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);w(36,'data');v.setUint32(40,n*2,true);
        for(let i=0;i<n;i++){const x=Math.max(-1,Math.min(1,d[i]));v.setInt16(44+i*2,x<0?x*0x8000:x*0x7fff,true);}
        const u=new Uint8Array(buf);let bin='';for(let i=0;i<u.length;i+=0x8000)bin+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));
        ok(btoa(bin));};
      if(p&&p.then)p.then(use,ko);else oc.oncomplete=e=>use(e.renderedBuffer);
    }catch(e){ko(e);}
  });
}

async function ffTranscribe(ab){
  const NA=why=>({status:'not_analyzed',reason:why});
  let url=null;
  try{
    const cm=S.model==='custom'?S.customModel:null;
    if(cm&&cm.provider==='gemini'&&cm.key)url=cm.endpoint+cm.model+':generateContent?key='+cm.key;
    else if(S.model&&S.model.startsWith('gemini')&&S.gem)url='https://generativelanguage.googleapis.com/v1beta/models/'+S.model+':generateContent?key='+S.gem;
  }catch(e){}
  if(!url)return {speech:NA('le modèle utilisé ne reçoit pas l\'audio : paroles inconnues'),events:NA('non analysé')};
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),70000);
  try{
    const b64=await ffWavBase64(ab);
    const prompt='Écoute cet audio. 1) Transcris fidèlement ce qui est dit, dans la langue parlée, segment par segment, avec le début et la fin de chaque segment en secondes. Écris [inaudible] pour ce que tu ne comprends pas : n\'invente jamais un mot. '+
      '2) Liste seulement les événements sonores non parlés clairement audibles (musique de fond, effet sonore, rires, applaudissements) avec début, fin et confiance de 0 à 1 ; ne mets rien si tu n\'es pas sûr. '+
      'Réponds en JSON strict : {"langue":"","segments":[{"start":0,"end":0,"text":""}],"evenements":[{"type":"","start":0,"end":0,"confiance":0}]}';
    const r=await fetch(url,{method:'POST',signal:ctl.signal,headers:{'Content-Type':'application/json'},
      body:JSON.stringify({generationConfig:{maxOutputTokens:6000,temperature:0,responseMimeType:'application/json'},contents:[{role:'user',parts:[{text:prompt},{inlineData:{mimeType:'audio/wav',data:b64}}]}]})});
    if(!r.ok)throw new Error('HTTP '+r.status);
    const d=await r.json(),t=(d.candidates&&d.candidates[0]&&d.candidates[0].content&&d.candidates[0].content.parts||[]).map(x=>x.text||'').join('');
    const a=t.indexOf('{'),b=t.lastIndexOf('}'),j=JSON.parse(t.slice(a,b+1));
    const seg=(j.segments||[]).filter(x=>x&&String(x.text||'').trim()).slice(0,200).map(x=>({start:Math.round((+x.start||0)*10)/10,end:Math.round((+x.end||0)*10)/10,text:String(x.text).trim().slice(0,300)}));
    const ev=(j.evenements||[]).filter(x=>x&&x.type).slice(0,30).map(x=>({type:String(x.type).slice(0,40),start:Math.round((+x.start||0)*10)/10,end:Math.round((+x.end||0)*10)/10,confiance:Math.max(0,Math.min(1,+x.confiance||0))}));
    return {
      speech:seg.length?{status:'analyzed_by_model',language:String(j.langue||'').slice(0,20)||null,segments:seg,note:'transcription faite par le modèle sur l\'audio : peut contenir des erreurs ; [inaudible] = non compris'}
        :{status:'analyzed_by_model',language:null,segments:[],note:'aucune parole reconnue par le modèle (cela ne prouve pas qu\'il n\'y en a pas)'},
      events:{status:'analyzed_by_model',events:ev,note:'liste des événements sûrs seulement : une liste vide ne prouve pas leur absence'}};
  }catch(e){return {speech:NA('transcription impossible (réseau, clé ou modèle)'),events:NA('non analysé')};}
  finally{clearTimeout(to);}
}

async function ffMediaEvidence(file,fr){
  const NA=why=>({status:'not_analyzed',reason:why});
  const ev={version:1,source:'mesures locales sur l\'appareil, sans interprétation',
    file:null,video:NA('non lue'),frames:NA('aucune capture'),audio:NA('non mesuré'),
    speech_transcript:NA('transcription non faite : le contenu parlé est inconnu'),
    sound_events:NA('non analysé'),on_screen_text:NA('lu par le modèle sur les captures, pas par un OCR local')};
  if(!file){const m='vidéo donnée par lien : aucune mesure locale possible';ev.video=NA(m);ev.audio=NA(m);return ev;}
  ev.file={name:file.name,size_mb:Math.round(file.size/104857.6)/10,type:file.type||null};
  const m=fr&&fr.meta;
  if(m){ev.video={status:'analyzed',duration_s:Math.round(m.duration*10)/10,width:m.width,height:m.height,
    orientation:m.width&&m.height?(m.height>m.width?'vertical':m.height<m.width?'horizontal':'carré'):null,fps:null,fps_note:'non mesuré'};}
  else ev.video=NA('métadonnées illisibles');
  if(fr&&fr.length&&fr.times&&fr.times.length===fr.length)ev.frames={status:'analyzed',count:fr.length,times_s:fr.times};
  else if(fr&&fr.length)ev.frames={status:'analyzed',count:fr.length,times_s:null,note:'heures exactes inconnues'};
  try{ev.audio=await ffAudioEvidence(file);}catch(e){ev.audio=NA('erreur pendant la mesure');}
  const ab=ev.audio&&ev.audio.__ab;
  if(ab&&!ev.audio.all_silent){const t=await ffTranscribe(ab);ev.speech_transcript=t.speech;ev.sound_events=t.events;}
  else if(ab){ev.speech_transcript={status:'analyzed',segments:[],note:'piste audio silencieuse'};ev.sound_events={status:'analyzed',events:[]};}
  return ev;
}

function ffEvidencePrompt(ev){
  return '\nDONNÉES BRUTES DE LA VIDÉO (mesures sur l\'appareil + transcription de l\'audio, pour ton usage interne) :\n'+JSON.stringify(ev)+
   '\nRÈGLES : (1) un champ "not_analyzed" ou null = INCONNU, jamais « absent » : ne dis pas « pas de musique », « pas de voix » ou « pas de texte » à partir de lui ; '+
   '(2) la transcription "analyzed_by_model" sert à comprendre de quoi parle la vidéo et à citer les paroles avec leur seconde ; [inaudible] = non compris, n\'invente aucun mot, aucune musique, aucun effet ; '+
   '(3) situe chaque remarque par une SECONDE de la vidéo (ex. « à 8 s »), jamais par un numéro de capture ; '+
   '(4) ce rapport s\'adresse au créateur qui veut devenir populaire : parle de LA VIDÉO elle-même (son sujet, ce qui est dit, ce qui est montré, ce qui peut la faire partager). Ne mentionne JAMAIS le fonctionnement interne ni de métalangage IA : ni « prompt », « instructions », « modèle », « IA », « capture n°X », « les dix premières captures », « rapport brut », « media_evidence », « not_analyzed » ou « statut ». '+
   'Si tu dois dire une limite, dis-la en mots simples (« je n\'ai pas pu écouter la musique ») ; '+
   '(5) le "resume" commence par « La vidéo parle de … » : le vrai sujet, tiré des paroles ; sans paroles, tire-le des textes à l\'écran ; sinon écris « sujet non établi » sans deviner. '+
    '(6) les légendes de publication ne sont jamais la transcription ni le résumé de la vidéo : ce sont des textes écrits pour le public, qui donnent envie de regarder, sans recopier les phrases prononcées.';
}
(function(){
  const orig=window.onFileAttach;
  window.onFileAttach=function(e){
    const vids=Array.from((e.target&&e.target.files)||[]).filter(f=>f.type&&f.type.startsWith('video/'));
    orig(e);
    vids.forEach(async f=>{
      toast('Capture de '+f.name+'...');
      const fr=await npsVideoFrames(f,12);
      if(!fr.length||!fr.mosaic){toast('Impossible de lire '+f.name+' (format non pris en charge par le navigateur)');return;}
      const base=f.name.replace(/\.[^.]+$/,''),du=fr.meta&&fr.meta.duration?'_'+Math.round(fr.meta.duration)+'s':'';
      S.attachments.push({id:uid(),name:base+'_mosaique_'+fr.length+'_captures'+du+'.jpg',type:'image/jpeg',size:Math.round(fr.mosaic.length*0.75),dataUrl:fr.mosaic});
      renderAttachRow();toast('Mosaïque de '+fr.length+' captures prête pour l\'analyse');
    });
  };
})();
