/* ═══════ Fable Fast v4 : pages qui suivent le doigt, des deux côtés — et qui se posent TOUJOURS entièrement ═══════
   Disposition :  [ Historique ]  [ Conversation ]  [ Paramètres ]
   Depuis la conversation : droite = Historique, gauche = Paramètres. Retour : sens inverse.
   Garde-fous : un deuxième doigt ne casse plus le geste, un relâchement perdu est rattrapé, tout état résiduel est nettoyé. */
(function(){
  const $ = id => document.getElementById(id);
  const sb = $('sidebar'), main = $('main'), ov = $('sb-overlay'), layout = $('layout');
  let sx = 0, sy = 0, st = 0, tracking = false, busy = false, busySince = 0, mode = null, state0 = 'chat';
  let W = 260, SW = 360, base = 0, curP = 0, lastX = 0, lastT = 0, lastMoveAt = 0, vx = 0, raf = 0, pendDx = 0, settleTimer = 0;
  const overlayOpen = () => !!document.querySelector('.nps-modal-bg.show, .nps-sheet-bg.show, #img-lightbox.show, #file-viewer.show, .conv-inline-menu');
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const clearInline = (el, props) => { if (el) props.forEach(p => el.style.removeProperty(p)); };
  function stateNow(){
    if (typeof sbOpen !== 'undefined' && sbOpen) return 'history';
    const v = currentViewId();
    return v === 'chat' ? 'chat' : (v === 'settings' ? 'settings' : 'sub');
  }
  function blockedTarget(t){
    return !!(t && t.closest && t.closest('pre,code,table,input,textarea,select,video,audio,iframe,canvas,.code-block,#attach-menu,.nps-file-menu'));
  }
  function silentShow(id){
    NAV.stack.length = 0; NAV.mode = 'back';
    showView(id);
    NAV.mode = null;
    const el = $('view-' + id);
    if (el) el.classList.remove('enter-fwd', 'enter-back');
    if (id === 'chat') { const c = S.convs.find(x => x.id === S.currentConv); setTitle(c ? c.title : 'Fable Fast'); }
    else setTitle('Paramètres');
  }
  // Remet l'écran dans un état net : plus aucun style de glissement, panneau Historique cohérent, un seul écran visible.
  function cleanAll(){
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    if (settleTimer) { clearTimeout(settleTimer); settleTimer = 0; }
    clearInline(sb, ['transition', 'transform', 'will-change']);
    clearInline(main, ['transition', 'transform', 'will-change']);
    clearInline(ov, ['transition', 'opacity', 'display']);
    const vs = $('view-settings'), vc = $('view-chat');
    clearInline(vs, ['transition', 'transform', 'position', 'z-index', 'background', 'box-shadow', 'will-change']);
    vs.classList.remove('peek'); vc.classList.remove('under');
    layout.classList.remove('dragging');
    try {
      const hasOpen = sb.classList.contains('open');
      if (typeof sbOpen !== 'undefined' && hasOpen !== sbOpen) { if (sbOpen) openSidebar(); else closeSidebar(); }
    } catch (e) {}
    busy = false; mode = null;
  }
  function begin(m){
    layout.classList.add('dragging');
    if (m === 'open' || m === 'close') {
      W = sb.offsetWidth || 260;
      base = m === 'close' ? W : 0;
      sb.style.transition = main.style.transition = ov.style.transition = 'none';
      sb.style.willChange = main.style.willChange = 'transform';
      ov.style.display = 'block';
    } else if (m === 'setIn') {
      SW = main.offsetWidth || window.innerWidth;
      const el = $('view-settings');
      el.classList.add('peek'); el.style.transition = 'none';
    } else if (m === 'setOut') {
      SW = main.offsetWidth || window.innerWidth;
      $('view-chat').classList.add('under');
      const el = $('view-settings');
      el.style.transition = 'none'; el.style.position = 'relative'; el.style.zIndex = '5';
      el.style.background = 'var(--bg)'; el.style.boxShadow = '-14px 0 32px rgba(0,0,0,.4)'; el.style.willChange = 'transform';
    }
  }
  function apply(dx, m){
    m = m || mode;
    if (m === 'open' || m === 'close') {
      const x = clamp(base + dx, 0, W); curP = x / W;
      sb.style.transform = 'translate3d(' + (x - W) + 'px,0,0)';
      main.style.transform = 'translate3d(' + x + 'px,0,0)';
      ov.style.opacity = curP;
    } else if (m === 'setIn') {
      curP = clamp(-dx / SW, 0, 1);
      $('view-settings').style.transform = 'translate3d(' + ((1 - curP) * 100) + '%,0,0)';
    } else if (m === 'setOut') {
      curP = clamp(dx / SW, 0, 1);
      $('view-settings').style.transform = 'translate3d(' + (curP * 100) + '%,0,0)';
    }
  }
  function settle(commitFn){
    // Toujours finir par un nettoyage complet, même si l'action lève une erreur.
    settleTimer = setTimeout(() => {
      settleTimer = 0;
      try { commitFn(); } catch (e) { console.warn('Balayage :', e); }
      finally { cleanAll(); }
    }, 285);
  }
  function end(dx){
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    const m = mode;
    if (!m) { cleanAll(); return; }
    if (m === 'page') { mode = null; if (dx > 70 && Date.now() - st < 900) goBack(); return; }
    apply(dx, m);                                  // dernière position exacte
    mode = null; busy = true; busySince = Date.now();
    const ease = '.26s cubic-bezier(.22,.8,.3,1)';
    const fast = Math.abs(vx) > 0.45;
    if (m === 'open' || m === 'close') {
      const open = fast ? vx > 0 : curP > 0.45;
      sb.style.transition = main.style.transition = 'transform ' + ease; ov.style.transition = 'opacity ' + ease;
      sb.style.transform = 'translate3d(' + (open ? 0 : -W) + 'px,0,0)';
      main.style.transform = 'translate3d(' + (open ? W : 0) + 'px,0,0)';
      ov.style.opacity = open ? 1 : 0;
      settle(() => { if (open) openSidebar(); else closeSidebar(); });
    } else if (m === 'setIn') {
      const commit = fast ? vx < 0 : curP > 0.4;
      const el = $('view-settings');
      el.style.transition = 'transform ' + ease;
      el.style.transform = 'translate3d(' + (commit ? 0 : 100) + '%,0,0)';
      settle(() => { if (commit) silentShow('settings'); });
    } else if (m === 'setOut') {
      const commit = fast ? vx > 0 : curP > 0.4;
      const el = $('view-settings');
      el.style.transition = 'transform ' + ease;
      el.style.transform = 'translate3d(' + (commit ? 100 : 0) + '%,0,0)';
      settle(() => { if (commit) silentShow('chat'); });
    }
  }
  document.addEventListener('touchstart', e => {
    if (mode) return;                                           // geste en cours : on ignore les autres doigts
    if (busy) { if (Date.now() - busySince > 900) cleanAll(); else { tracking = false; return; } }
    if (e.touches.length !== 1) { tracking = false; return; }
    // état résiduel d'un geste précédent : on repart d'un écran propre
    if (sb.style.transform || main.style.transform || ov.style.display || $('view-settings').classList.contains('peek') || $('view-chat').classList.contains('under')) cleanAll();
    const t = e.touches[0];
    sx = lastX = t.clientX; sy = t.clientY; st = lastT = lastMoveAt = Date.now(); vx = 0;
    state0 = stateNow();
    tracking = !overlayOpen() && !blockedTarget(e.target);
  }, { passive: true });
  document.addEventListener('touchmove', e => {
    if (!tracking) return;
    const t = e.touches[0];
    const dx = t.clientX - sx, dy = t.clientY - sy, now = Date.now();
    lastMoveAt = now;
    if (now > lastT) { vx = (t.clientX - lastX) / (now - lastT); lastX = t.clientX; lastT = now; }
    if (!mode) {
      if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
      if (Math.abs(dx) < Math.abs(dy) * 1.15) { tracking = false; return; }   // geste vertical : on laisse défiler
      if (state0 === 'chat') { if (sx > window.innerWidth - 28 && dx < -40 && window.ffMenuOpen && !document.getElementById('ffmenu').classList.contains('on')) window.ffMenuOpen(); tracking = false; return; }
      else if (state0 === 'sub' && dx > 0) mode = 'page';
      else { tracking = false; return; }
      if (!mode) { tracking = false; return; }
      begin(mode);
    }
    if (e.cancelable) e.preventDefault();
    pendDx = dx;
    if (mode !== 'page' && !raf) raf = requestAnimationFrame(() => { raf = 0; apply(pendDx); });
  }, { passive: false });
  function finish(e){
    if (!tracking && !mode) return;
    tracking = false;
    const t = e.changedTouches && e.changedTouches[0];
    end(t ? t.clientX - sx : pendDx);
  }
  document.addEventListener('touchend', finish, { passive: true });
  document.addEventListener('touchcancel', finish, { passive: true });
  // Rattrapage : relâchement jamais reçu (appli en arrière-plan, doigt perdu…) → on pose l'écran tout de suite.
  const rescue = () => { if (mode) { tracking = false; end(pendDx); } else if (busy && Date.now() - busySince > 1200) cleanAll(); };
  setInterval(() => { if (mode && Date.now() - lastMoveAt > 1200) rescue(); else if (busy && Date.now() - busySince > 1500) cleanAll(); }, 400);
  document.addEventListener('visibilitychange', rescue);
  window.addEventListener('pagehide', rescue);
  window.addEventListener('blur', rescue);
})();
