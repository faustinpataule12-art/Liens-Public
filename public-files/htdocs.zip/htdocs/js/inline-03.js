function safeSetItem(key, value) {
  try {
    localStorage.setItem(key, value);
    return true;
  } catch (e) {
    console.error("Storage quota exceeded or error", e);
    if (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
      // On libère de la place automatiquement : anciens suivis de terminal, puis les plus gros corps de
      // conversations (la liste reste, le contenu se recharge depuis GitHub), en gardant la conversation ouverte.
      try {
        let cur = ''; try { cur = 'nps_conv_' + S.currentConv; } catch (e0) {}
        for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k && k.indexOf('nps_pending_job_') === 0) localStorage.removeItem(k); }
        const victims = Object.keys(localStorage).filter(k => k.indexOf('nps_conv_') === 0 && k !== cur && k !== key)
          .sort((a, b) => (localStorage.getItem(b) || '').length - (localStorage.getItem(a) || '').length);
        for (let n = 0; n <= Math.min(victims.length, 6); n++) {
          try { localStorage.setItem(key, value); return true; } catch (e2) {}
          if (victims[n]) localStorage.removeItem(victims[n]);
        }
      } catch (e3) {}
      toast("Espace de stockage plein : certaines anciennes conversations n'ont pas pu être gardées en local", true);
    }
    return false;
  }
}

// ═══════ STATE ═══════
function getOrCreateUserId(){
  let id = localStorage.getItem('nps_user_id');
  if(!id || id.length<8){
    id = 'u_' + (crypto.randomUUID ? crypto.randomUUID().replace(/-/g,'') : (Date.now().toString(36)+Math.random().toString(36).slice(2)));
    safeSetItem('nps_user_id', id);
  }
  return id;
}
var NAV = { stack: [], mode: null, ignorePop: false };
const S = {
  uid: getOrCreateUserId(),
  tok: (localStorage.getItem('nps_gh_tok')||'').trim(),
  oai: (localStorage.getItem('nps_oai_tok')||'').trim(),
  ant: (localStorage.getItem('nps_ant_tok')||'').trim(),
  gem: (localStorage.getItem('nps_gem_tok')||'').trim(),
  model: localStorage.getItem('nps_model')||'gemini-3.5-flash-lite',
  ttsRate: parseFloat(localStorage.getItem('nps_tts_rate')||'1'),
  caps: JSON.parse(localStorage.getItem('nps_caps')||'{"web":true,"art":true,"code":true,"switch":true,"mem":true}'),
  prefs: localStorage.getItem('nps_prefs')||'',
  msgs: [],
  convs: JSON.parse(localStorage.getItem('nps_convs')||'[]'),
  attachments: [],
  customModel: JSON.parse(localStorage.getItem('nps_custom_model')||'null'),
  wsName: localStorage.getItem('nps_ws_name')||'MON ESPACE',
  pfName: localStorage.getItem('nps_pf_name')||'',
  pfNick: localStorage.getItem('nps_pf_nick')||'',
  globalHeaders: JSON.parse(localStorage.getItem('nps_global_headers')||'{}'),
};
const GM = 'https://models.inference.ai.azure.com/chat/completions';
const GHA = 'https://api.github.com';
const IMG_API = 'https://image.pollinations.ai/prompt/';

// ═══════ DÉTECTION AUTOMATIQUE DU FOURNISSEUR À PARTIR DE LA CLÉ ═══════
// L'utilisateur colle SEULEMENT sa clé API, peu importe où il l'a trouvée
// (Pollinations, Groq, OpenRouter, un serveur perso sur Replit, etc.).
// Fable Fast ne "choisit" rien : il teste automatiquement la clé sur les
// fournisseurs connus et garde celui qui répond. Deux formats de clé
// ont un format d'appel différent (Anthropic, Gemini) et sont reconnus
// instantanément par leur préfixe ; tous les autres sont testés en direct.
const KNOWN_FORMATS=[
  {test:/^sk-ant-/, provider:'anthropic', endpoint:'https://api.anthropic.com/v1/messages', model:'claude-sonnet-4-6', name:'Anthropic — Claude'},
  {test:/^AIza/, provider:'gemini', endpoint:'https://generativelanguage.googleapis.com/v1beta/models/', model:'gemini-2.0-flash', name:'Google — Gemini'},
];
const PROBE_CANDIDATES=[
  {name:'Pollinations', endpoint:'https://text.pollinations.ai/openai', model:'openai-large'},
  {name:'Groq', endpoint:'https://api.groq.com/openai/v1/chat/completions', model:'llama-3.3-70b-versatile'},
  {name:'OpenRouter', endpoint:'https://openrouter.ai/api/v1/chat/completions', model:'openai/gpt-4o-mini'},
  {name:'GitHub Models', endpoint:'https://models.inference.ai.azure.com/chat/completions', model:'gpt-4o'},
  {name:'Together AI', endpoint:'https://api.together.xyz/v1/chat/completions', model:'meta-llama/Llama-3.3-70B-Instruct-Turbo'},
  {name:'DeepSeek', endpoint:'https://api.deepseek.com/chat/completions', model:'deepseek-chat'},
  {name:'Mistral', endpoint:'https://api.mistral.ai/v1/chat/completions', model:'mistral-small-latest'},
  {name:'Fireworks AI', endpoint:'https://api.fireworks.ai/inference/v1/chat/completions', model:'accounts/fireworks/models/llama-v3p3-70b-instruct'},
  {name:'Perplexity', endpoint:'https://api.perplexity.ai/chat/completions', model:'llama-3.1-sonar-small-128k-online'},
  {name:'OpenAI', endpoint:'https://api.openai.com/v1/chat/completions', model:'gpt-4o-mini'},
];
function toggleManualUrl(){
  const w=document.getElementById('cm-manual-wrap');
  w.style.display=w.style.display==='none'?'block':'none';
}
function onCmKeyInput(){
  const key=document.getElementById('cm-key').value.trim();
  const label=document.getElementById('cm-provider-label');
  if(!key){label.textContent='Colle une clé, puis appuie sur Enregistrer';label.style.color='var(--text3)';return;}
  const known=KNOWN_FORMATS.find(f=>f.test.test(key));
  label.textContent=known?('Format reconnu : '+known.name+' — appuie sur Enregistrer'):'Appuie sur "Enregistrer et connecter" pour la tester';
  label.style.color='var(--text3)';
}
async function detectAndSaveCustomModel(){
  const key=document.getElementById('cm-key').value.trim();
  const manualUrl=document.getElementById('cm-manual-url')?.value.trim();
  const label=document.getElementById('cm-provider-label');
  if(!key){toast('Colle d\'abord ta clé API',true);return;}

  // Adresse fournie manuellement (serveur perso, ex. Replit) : pas de test, on l'utilise directement
  if(manualUrl){
    S.customModel={key,provider:'openai-compat',endpoint:manualUrl,model:document.getElementById('cm-name').value.trim()||'default',name:'Serveur personnalisé'};
    finishCustomModelSave('Serveur personnalisé');
    return;
  }

  // Format spécial reconnu instantanément (Anthropic / Gemini)
  const known=KNOWN_FORMATS.find(f=>f.test.test(key));
  if(known){
    S.customModel={key,provider:known.provider,endpoint:known.endpoint,model:known.model,name:known.name};
    finishCustomModelSave(known.name);
    return;
  }

  // Sinon : on teste la clé automatiquement sur les fournisseurs connus
  const btn=document.getElementById('cm-save-btn');
  btn.disabled=true; btn.textContent='Détection en cours…';
  label.textContent='Test de la clé sur les fournisseurs connus…';
  label.style.color='var(--text2)';
  for(const c of PROBE_CANDIDATES){
    try{
      const ctrl=new AbortController();
      const timer=setTimeout(()=>ctrl.abort(),7000);
      const r=await fetch(c.endpoint,{
        method:'POST', signal:ctrl.signal,
        headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},
        body:JSON.stringify({model:c.model,max_tokens:5,messages:[{role:'user',content:'ping'}]})
      });
      clearTimeout(timer);
      if(r.ok){
        S.customModel={key,provider:'openai-compat',endpoint:c.endpoint,model:c.model,name:c.name};
        btn.disabled=false; btn.textContent='Enregistrer et connecter';
        finishCustomModelSave(c.name);
        return;
      }
    }catch(e){ /* on passe au suivant */ }
  }
  btn.disabled=false; btn.textContent='Enregistrer et connecter';
  label.textContent='Clé non reconnue par les fournisseurs connus. Si c\'est un serveur perso (ex. Replit), ajoute son adresse ci-dessous.';
  label.style.color='#e05555';
  document.getElementById('cm-manual-wrap').style.display='block';
}
function finishCustomModelSave(name){
  clearOtherProviderKeys('custom');
  safeSetItem('nps_custom_model',JSON.stringify(S.customModel));
  document.getElementById('cm-provider-label').textContent=name+' détecté et connecté';
  document.getElementById('cm-provider-label').style.color='var(--green)';
  selectModel('custom',name);
  updateActiveProviderLabel();
  toast('Modèle connecté '+name);
}

// ═══════ UTILS ═══════
const esc = s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

/**
 * Retire le raisonnement interne (<think>...</think>) d'un texte, quel que
 * soit son état (balise ouvrante présente ou non — arrive après une relance
 * "réponse vide"). Tout ce qui précède un </think> est considéré interne.
 */
function stripThink(text, placeholder=''){
  let t = text || '';
  if (/<\/think>/i.test(t)) {
    t = t.replace(/^[\s\S]*?<\/think>/i, placeholder);
  } else if (/<think>/i.test(t)) {
    // <think> ouvert mais jamais refermé (réponse tronquée/coupée en cours
    // de route) : tout ce texte est encore du raisonnement interne, pas une
    // réponse finale. Avant, seules les balises étaient retirées et le
    // raisonnement brut s'affichait tel quel — c'est exactement la fuite
    // qu'on veut éviter, donc on le masque entièrement comme un <think> fermé.
    t = placeholder;
  }
  return t.replace(/<\/?think>/gi, '').replace(/\[SUITE\]/gi, '').replace(/\[FIN\]/gi, '').replace(/\[S(?:U(?:I(?:T(?:E)?)?)?)?$/i, '').replace(/\[F(?:I(?:N)?)?$/i, '').trim();
}

/**
 * Filet de sécurité anti-"bruit" : détecte un texte ou un code visiblement
 * corrompu/incohérent (répétitions dégénérées, caractères de remplacement
 * d'encodage, boucle de symboles, code manifestement tronqué au milieu d'un
 * token) AVANT de l'afficher à l'utilisateur. On ne devine jamais la qualité
 * du contenu (ça, c'est le travail du modèle) — on bloque seulement les
 * signaux objectifs et sans ambiguïté d'une sortie cassée.
 *
 * Detecte aussi un fragment manifestement tronque (ex: une reponse qui se
 * resume a "}" ou "👉}" ou "});") : trop court pour etre juge par les
 * heuristiques statistiques ci-dessous (ratio, boucle), mais clairement pas
 * un vrai message ni un vrai bloc de code complet — que des symboles/
 * ponctuation de code, aucun mot reel derriere.
 */
function isTruncatedFragment(str){
  // Desactive a la demande de l'utilisateur : plus aucun contenu (texte, code,
  // lien) n'est cache ou considere comme tronque avant affichage.
  return false;
}
function isNoiseText(str){
  // Desactive a la demande de l'utilisateur : plus aucun texte n'est
  // considere "corrompu" avant affichage, quel que soit son contenu.
  return false;
}
function isNoiseCode(content, lang){
  // Desactive a la demande de l'utilisateur : plus aucun bloc de code n'est
  // cache ou renvoye en regeneration avant affichage, quel que soit son contenu.
  return false;
}

/**
 * Détecte une fausse déclaration de succès : le texte affirme qu'un
 * livrable a été créé/terminé/enregistré alors qu'AUCUN livrable réel
 * (bloc de code substantiel ou export_file résolu) n'accompagne le
 * message. Empêche Fable Fast d'affirmer "c'est fait" sans jamais rien donner.
 */
function claimsUnverifiedSuccess(text, hasRealDeliverable){
  if (hasRealDeliverable) return false;
  const t = (text||'');
  if (t.length < 20) return false;
  const successPattern = /a été créé|a été généré|créée? avec succès|généré(e)? avec succès|terminé(e)? avec succès|enregistré(e)? avec succès|application complète|outil complet|est prêt(e)? à être|c'est fait|est en place (sur|dans)|prêt(e)? à être prévisualisé|configuré(e)? et enregistré|est en ligne|est accessible|accessible directement|avec succès|dépôt est configuré|bien en place|est disponible/i;
  return successPattern.test(t);
}

/**
 * Extrait les liens GitHub (fichier source "blob" ou site "*.github.io")
 * présents dans une réponse, pour pouvoir les vérifier réellement avant de
 * laisser Fable Fast affirmer qu'ils fonctionnent.
 */
function extractGithubLinks(text){
  const t = (text||'');
  const blobLinks = [...t.matchAll(/https:\/\/github\.com\/([^\/\s)]+)\/([^\/\s)]+)\/blob\/[^\/\s)]+\/([^\s)]+)/g)]
    .map(m => ({ type:'blob', owner:m[1], repo:m[2], path:decodeURIComponent(m[3]) }));
  const pagesLinks = [...t.matchAll(/https:\/\/[^\/\s)]+\.github\.io\/[^\s)]*/g)]
    .map(m => ({ type:'pages', url:m[0] }));
  return [...blobLinks, ...pagesLinks];
}

/**
 * Vérifie réellement qu'un lien GitHub donné par Fable Fast existe/fonctionne,
 * au lieu de laisser l'utilisateur découvrir un 404 lui-même. Pour un lien
 * "blob" (fichier source), on interroge l'API Contents (fiable, CORS ok).
 * Pour un lien GitHub Pages, on tente un fetch réel ; en cas d'échec réseau
 * ambigu (souvent lié au CORS, pas au 404), on ne bloque pas — on ne veut
 * bloquer que les cas où on est SÛR que ça ne marche pas.
 */
async function verifyGithubLink(link){
  if (link.type === 'blob') {
    try {
      await fetchGitHubFileContent(link.repo, link.path);
      return true;
    } catch(e) { return false; }
  }
  if (link.type === 'pages') {
    try {
      const res = await fetch(link.url, { method:'GET' });
      if (res.status === 404) return false;
      return true;
    } catch(e) { return null; } // Indéterminé (CORS/réseau) : on ne bloque pas sur un doute.
  }
  return true;
}

/**
 * Filet de sécurité : si le modèle laisse fuir du HTML brut dans sa réponse
 * visible (malgré la consigne du prompt), on le convertit en Markdown lisible
 * plutôt que d'afficher les balises telles quelles à l'utilisateur.
 */
function sanitizeHtmlLeak(text){
  if(!/<[a-z][\s\S]*>/i.test(text||'')) return text;
  let t = text;
  t = t.replace(/<a\s+[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi, '[$2]($1)');
  t = t.replace(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/gi, '\n### $1\n');
  t = t.replace(/<h[4-6][^>]*>([\s\S]*?)<\/h[4-6]>/gi, '\n#### $1\n');
  t = t.replace(/<(strong|b)[^>]*>([\s\S]*?)<\/\1>/gi, '**$2**');
  t = t.replace(/<(em|i)[^>]*>([\s\S]*?)<\/\1>/gi, '*$2*');
  t = t.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, '- $1\n');
  t = t.replace(/<br\s*\/?>/gi, '\n');
  t = t.replace(/<\/p>/gi, '\n\n').replace(/<p[^>]*>/gi, '');
  t = t.replace(/<\/div>/gi, '\n').replace(/<div[^>]*>/gi, '');
  t = t.replace(/<[^>]+>/g, '');
  t = t.replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'");
  t = t.replace(/\n{3,}/g,'\n\n').trim();
  return t;
}
const uid = ()=>Math.random().toString(36).slice(2,8)+Date.now().toString(36).slice(-4);
const sleep = ms=>new Promise(r=>setTimeout(r,ms));

function utob(str) {
  return window.btoa(unescape(encodeURIComponent(str)));
}
function btou(str) {
  return decodeURIComponent(escape(window.atob(str)));
}
function downloadCodeB64(b64, filename) {
  const content = btou(b64);
  downloadCodeDirectly(content, filename);
}
function downloadCodeDirectly(content, filename) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('Fichier téléchargé');
}
function downloadCode(id, filename) {
  const el = document.getElementById(id);
  if (!el) return;
  downloadCodeDirectly(el.textContent, filename);
}

// Partage le fichier via le partage natif d'Android (WhatsApp, Bluetooth,
// Drive, etc.). Tente d'abord de partager le vrai fichier ; si le navigateur/
// WebView ne le supporte pas, se rabat sur un partage texte du contenu.
async function shareArtifact(id, filename) {
  const el = document.getElementById(id);
  if (!el) return;
  const content = el.textContent;

  if (navigator.canShare) {
    try {
      const file = new File([content], filename, { type: 'text/plain' });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: filename });
        return;
      }
    } catch (err) {
      // L'utilisateur a annule le partage, ou le fichier n'est pas partageable : on continue vers le repli.
    }
  }

  if (navigator.share) {
    try {
      await navigator.share({ title: filename, text: content });
      return;
    } catch (err) {
      return;
    }
  }

  toast('Partage non disponible sur cet appareil', true);
}
async function downloadAllAsZip(mid) {
  const msg = S.msgs.find(m => m.id === mid);
  if (!msg || !msg.codeBlocks) return;
  if (typeof JSZip === 'undefined') {
      toast('Erreur: Bibliothèque ZIP indisponible', true);
      return;
  }
  const zip = new JSZip();
  let count = 0;
  msg.codeBlocks.forEach((b, idx) => {
     if (b.lang === 'plan' || (b.lang === 'json' && b.content.includes('"action"'))) return;
     const ext = getFileExtension(b.lang);
     const name = b.filename || `fichier_${idx + 1}.${ext}`;
     zip.file(name, b.content);
     count++;
  });
  if (count === 0) return;
  toast('Création de l\'archive ZIP...', 'info');
  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = `nps_projet_${mid}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('Archive ZIP téléchargée');
}
function getFileExtension(lang) {
  const l = (lang || '').toLowerCase().trim();
  if (l === 'javascript' || l === 'js') return 'js';
  if (l === 'typescript' || l === 'ts') return 'ts';
  if (l === 'python' || l === 'py') return 'py';
  if (l === 'html') return 'html';
  if (l === 'css') return 'css';
  if (l === 'json') return 'json';
  if (l === 'markdown' || l === 'md') return 'md';
  if (l === 'pdf') return 'pdf';
  if (l === 'java') return 'java';
  if (l === 'c' || l === 'cpp') return 'cpp';
  return 'txt';
}
function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' octets';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' Ko';
  return (bytes / 1048576).toFixed(1) + ' Mo';
}
let _connBannerInterval = null;
function showConnBanner(){
  const el = document.getElementById('conn-banner');
  if (!el) return;
  el.classList.add('show');
  setTimeout(() => { if (!navigator.onLine) el.classList.remove('show'); }, 15000);
}
function hideConnBanner(){
  const el = document.getElementById('conn-banner');
  if (el) el.classList.remove('show');
  if (_connBannerInterval) { clearInterval(_connBannerInterval); _connBannerInterval = null; }
}
/**
 * Attend le retour de la connexion, avec une bannière qui réapparaît toutes les
 * 30s (visible 15s) tant qu'on est hors-ligne. Renvoie false si maxWaitMs est
 * dépassé sans reconnexion (l'appelant doit alors abandonner proprement).
 */
async function ensureOnline(maxWaitMs = 120000, signal) {
  // signal (S.activeAbort?.signal) permet d'interrompre l'attente IMMÉDIATEMENT
  // si l'utilisateur appuie sur Stop — même hors-ligne / mode avion — au lieu
  // de rester bloqué ici jusqu'à maxWaitMs (2 à 5 minutes) ou une reconnexion.
  if (signal?.aborted) return 'cancelled';
  if (navigator.onLine) return true;
  showConnBanner();
  _connBannerInterval = setInterval(() => { if (!navigator.onLine) showConnBanner(); }, 30000);
  return new Promise(resolve => {
    const onlineHandler = () => { cleanup(); resolve(true); };
    const abortHandler = () => { cleanup(); resolve('cancelled'); };
    const timeoutId = setTimeout(() => { cleanup(); resolve(false); }, maxWaitMs);
    function cleanup(){
      window.removeEventListener('online', onlineHandler);
      signal?.removeEventListener('abort', abortHandler);
      clearTimeout(timeoutId);
      hideConnBanner();
    }
    window.addEventListener('online', onlineHandler);
    signal?.addEventListener('abort', abortHandler);
  });
}
async function syncMemoryFromGitHub() {
  if (!S.tok) return;
  const repoName = 'Maker';
  const headers = {
    'Authorization': 'Bearer ' + S.tok,
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json'
  };

  try {
    let userLogin = '';
    const userRes = await fetch('https://api.github.com/user', { headers });
    if (userRes.ok) {
      const userData = await userRes.json();
      userLogin = userData.login;
    } else {
      console.warn("Could not fetch GitHub user info for memory sync.");
      return;
    }

    const repoUrl = `https://api.github.com/repos/${userLogin}/${repoName}`;
    const checkRepo = await fetch(repoUrl, { headers });
    
    if (checkRepo.status === 404) {
      toast("Création du dépôt privé 'Maker' pour la mémoire...", "info");
      const createRes = await fetch('https://api.github.com/user/repos', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          name: repoName,
          private: true,
          description: "Mémoire longue durée sécurisée pour Fable Fast Agent IA",
          auto_init: true
        })
      });
      if (!createRes.ok) {
        throw new Error("Impossible de créer le dépôt Maker: " + createRes.statusText);
      }
      toast("Dépôt 'Maker' créé");
      await new Promise(r => setTimeout(r, 1500));
    }

    const fileUrl = `https://api.github.com/repos/${userLogin}/${repoName}/contents/memory.txt`;
    const checkFile = await fetch(fileUrl, { headers });
    
    if (checkFile.ok) {
      const fileData = await checkFile.json();
      const binaryString = atob(fileData.content.replace(/\s/g, ''));
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const text = new TextDecoder('utf-8').decode(bytes);
      
      if (text && text.trim()) {
        safeSetItem('nps_long_term_memory', text);
        const memTextarea = document.getElementById('mem-content');
        if (memTextarea) memTextarea.value = text;
        console.log("Mémoire longue durée synchronisée depuis GitHub.");
      }
    }
  } catch(e) {
    console.warn("Error in syncMemoryFromGitHub:", e.message);
  }
}

async function saveMemoryToGitHub(content) {
  if (!S.tok) return;
  const repoName = 'Maker';
  const headers = {
    'Authorization': 'Bearer ' + S.tok,
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json'
  };

  try {
    let userLogin = '';
    const userRes = await fetch('https://api.github.com/user', { headers });
    if (userRes.ok) {
      const userData = await userRes.json();
      userLogin = userData.login;
    } else {
      return;
    }

    const fileUrl = `https://api.github.com/repos/${userLogin}/${repoName}/contents/memory.txt`;
    const checkFile = await fetch(fileUrl, { headers });
    
    let sha = '';
    if (checkFile.ok) {
      const fileData = await checkFile.json();
      sha = fileData.sha;
    }

    const bytes = new TextEncoder().encode(content);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64Content = btoa(binary);

    const updateRes = await fetch(fileUrl, {
      method: 'PUT',
      headers,
      body: JSON.stringify({
        message: "Mise à jour de la mémoire longue durée",
        content: base64Content,
        sha: sha || undefined
      })
    });

    if (updateRes.ok) {
      toast("Mémoire sauvegardée sur GitHub");
    }
  } catch(e) {
    console.warn("Error in saveMemoryToGitHub:", e.message); toast("Impossible de sauvegarder la mémoire sur GitHub", true);
  }
}
