/* Ecran de selection : pas de zone de saisie tant qu'aucun mode n'est choisi */
(function(){
  var feed=document.getElementById('feed');if(!feed)return;
  var raf=0;
  function sync(){
    raf=0;
    var es=document.getElementById('empty-state');
    var on=!!(es&&es.style.display!=='none'&&es.querySelector('.eg-grid'));
    document.body.classList.toggle('ff-select',on);
  }
  function sched(){if(!raf)raf=requestAnimationFrame(sync);}
  try{new MutationObserver(sched).observe(feed,{childList:true,subtree:true,attributes:true,attributeFilter:['style']});}catch(e){}
  window.addEventListener('pageshow',sched);
  sync();
})();
