// ═══════ SETTINGS LOGIC ═══════
function toggleAttachMenu(e) {
  e.stopPropagation();
  const menu = document.getElementById('attach-menu');
  if (menu.style.display === 'none') {
    menu.style.display = 'block';
    setTimeout(() => document.addEventListener('click', closeAttachMenu, {once:true}), 0);
  } else {
    menu.style.display = 'none';
  }
}
function closeAttachMenu() {
  const menu = document.getElementById('attach-menu');
  if (menu) menu.style.display = 'none';
}
function onCameraCapture() {
  const inp = document.createElement('input');
  inp.type = 'file'; inp.accept = 'image/*'; inp.capture = 'environment';
  inp.onchange = (e) => onFileAttach(e);
  inp.click();
}
function startQuickVoice() { toggleMic(); }

function growTA(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,168)+'px'; const btn=document.getElementById('send-btn'); if(btn){ if(S.isAgentRunning){btn.classList.add('sending');btn.classList.remove('mic');} else if(el.value.trim().length>0) btn.classList.remove('mic'); else btn.classList.add('mic'); }}
function compKey(e){
  if(window.innerWidth <= 768) return; // Laisse l'Entrée faire un retour à la ligne sur mobile
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMsg();}
}

function selectModel(model,label){
  S.model=model; safeSetItem('nps_model',model);
  document.querySelectorAll('.model-check').forEach(el=>el.style.opacity='0');
  const el=document.getElementById('m-'+model.replace(/[^a-z0-9]/gi,''));
  if(el)el.style.opacity='1';
  document.getElementById('api-status-row').textContent=label;
  toast('Modèle: '+label);
}

function savePrefs(){
  S.prefs=document.getElementById('pf-prefs').value;
  safeSetItem('nps_prefs',S.prefs);
  toast('Préférences enregistrées');
}

function onFileAttach(e){
  const files=Array.from(e.target.files||[]);
  if(!files.length)return;
  files.forEach(f=>{
    const item={id:uid(),name:f.name,type:f.type,size:f.size,dataUrl:null,file:f};
    S.attachments.push(item);
    // Les fichiers texte (md, json, csv, svg, html, code…) gardent leur contenu : la carte reste
    // ouvrable et rendue même après rechargement de la page.
    const _ext=(f.name.split('.').pop()||'').toLowerCase();
    const _isText=/^text\//.test(f.type)||/^(md|markdown|txt|log|json|csv|tsv|xml|html?|svg|css|js|mjs|ts|tsx|jsx|py|java|kt|c|h|cpp|sh|sql|ya?ml|toml|ini|env|conf|gradle|properties|php|go|rs|rb|swift|dart|vue|lua|srt|vtt|ics|vcf|tex|bib)$/.test(_ext);
    if(_isText && f.size<=300*1024){ item._textP=f.text().then(t=>{item.text=t;}).catch(()=>{}); }
    if(f.type.startsWith('image/') || f.type.startsWith('audio/')){
      const reader=new FileReader();
      reader.onload=ev=>{item.dataUrl=ev.target.result; renderAttachRow();};
      reader.readAsDataURL(f);
    }
  });
  renderAttachRow();
  toast(files.length>1?files.length+' fichiers joints':''+files[0].name+' joint');
  e.target.value='';
}
function renderAttachRow(){
  const row=document.getElementById('attach-row');
  if(!S.attachments.length){row.style.display='none';row.innerHTML='';return;}
  row.style.display='flex';
  row.innerHTML=S.attachments.map(a=>`
    <div class="attach-chip" onclick="previewAttachment('${a.id}')" style="cursor:pointer">
      ${a.type?.startsWith('image/')&&a.dataUrl?`<img src="${a.dataUrl}"/>`:npsFileIcon(a.name,{mime:a.type,size:22})}
      <span>${esc(a.name)}</span>
      <button class="attach-x" onclick="event.stopPropagation();removeAttachment('${a.id}')"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
    </div>`).join('');
}
function removeAttachment(id){
  S.attachments=S.attachments.filter(a=>a.id!==id);
  renderAttachRow();
}

// ═══════ INIT ═══════
function cleanupOrphanedConvs() {
  if (!S.convs) return;
  const validIds = new Set(S.convs.map(c => 'nps_conv_' + c.id));
  let removedCount = 0;
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith('nps_conv_') && key !== 'nps_convs') {
      if (!validIds.has(key)) {
        console.log("Nettoyage auto de conversation orpheline pour liberer l'espace :", key);
        localStorage.removeItem(key);
        removedCount++;
        i--; // Adjust index because length changed
      }
    }
  }
  if (removedCount > 0) {
      console.log(removedCount + " conversation(s) fantôme(s) nettoyée(s).");
  }
}

function init(){
  cleanupOrphanedConvs();
  pickGreeting();
  // Thème & police sauvegardés
  if(localStorage.getItem('nps_theme')==='light'){
    document.body.classList.add('light');
    document.getElementById('theme-icon').innerHTML='<svg class="nps-ic-row" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
    document.getElementById('theme-sub-label').textContent='Clair';
  }
  const savedFont=localStorage.getItem('nps_font');
  if(savedFont){
    document.body.classList.add(savedFont);
    const f=FONTS.find(x=>x.cls===savedFont);
    if(f)document.getElementById('font-sub-label').textContent=fontLabelWithNumber(f);
  }
  // Restore API statuses
  if(S.tok){setApiStatus('gh-status','ok');document.getElementById('ghtoken').value=S.tok;}
  if(S.oai){setApiStatus('oai-status','ok');document.getElementById('oaitoken').value=S.oai;}
  if(S.ant){setApiStatus('ant-status','ok');document.getElementById('anttoken').value=S.ant;}
  if(S.gem){setApiStatus('gem-status','ok');document.getElementById('gemtoken').value=S.gem;}
  if(S.prefs)document.getElementById('pf-prefs').value=S.prefs;
  
  const memContent = localStorage.getItem('nps_long_term_memory') || '';
  const memTextarea = document.getElementById('mem-content');
  if (memTextarea) memTextarea.value = memContent;
  
  const rawKey = localStorage.getItem('nps_global_key');
  if (rawKey) {
      setApiStatus('global-status','ok');
      document.getElementById('global-key').value = rawKey;
  }
  
  // Cap toggles
  Object.entries(S.caps).forEach(([k,v])=>{
    const el=document.getElementById('cap-'+k);
    if(el){if(v)el.classList.add('on');else el.classList.remove('on');}
  });
  const count=Object.values(S.caps).filter(Boolean).length;
  document.getElementById('cap-count-row').textContent=count+' activée'+(count>1?'s':'');
  // Model
  const mEl=document.getElementById('m-'+S.model.replace(/[^a-z0-9]/gi,''));
  if(mEl){document.querySelectorAll('.model-check').forEach(e=>e.style.opacity='0');mEl.style.opacity='1';}
  document.getElementById('api-status-row').textContent=S.model==='custom'?(S.customModel?.name||'Personnalisé'):S.model;
  // Modèle personnalisé
  if(S.customModel){
    document.getElementById('cm-key').value=S.customModel.key||'';
    document.getElementById('cm-provider-label').textContent=(S.customModel.name||'Modèle')+' connecté';
    document.getElementById('cm-provider-label').style.color='var(--green)';
    if(S.customModel.name==='Serveur personnalisé'){
      document.getElementById('cm-manual-wrap').style.display='block';
      document.getElementById('cm-manual-url').value=S.customModel.endpoint||'';
      document.getElementById('cm-name').value=S.customModel.model||'';
    }
  }
  // Afficher le champ du fournisseur actif + libellé
  if(S.gem) pickProviderSilent('gemini');
  else if(S.ant) pickProviderSilent('anthropic');
  else if(S.oai) pickProviderSilent('openai');
  else if(S.customModel) pickProviderSilent('universel');
  updateActiveProviderLabel();
  document.querySelectorAll('.tts-rate-btn').forEach(b => b.classList.toggle('active', parseFloat(b.dataset.rate) === S.ttsRate));
  // Nom d'espace personnalisable (MON ESPACE -> nom choisi par l'utilisateur)
  document.getElementById('pf-name').value=S.pfName||S.wsName;
  document.getElementById('pf-nick').value=S.pfNick||S.wsName;
  applyWorkspaceName();
  // Popup unique d'autorisations groupées au tout premier lancement
  if(!localStorage.getItem('nps_perm_asked')){
    setTimeout(()=>document.getElementById('perm-modal').classList.add('show'),600);
  }
  syncMemoryFromGitHub();
  // Synchroniser toutes les conversations depuis GitHub en arrière-plan
  // (sans bloquer l'affichage — l'UI répond immédiatement depuis le cache local)
  if (S.tok) {
    const syncIndicator = document.getElementById('recent-list');
    if (syncIndicator && S.convs.length === 0) { S._convsLoading = true; renderRecents(); }
    syncConvsFromGitHub();
    startAutoSyncConvs();
  }
}
function applyWorkspaceName(){
  document.querySelectorAll('.sb-uname').forEach(el=>el.textContent=S.wsName);
  const av=(S.wsName||'Fable Fast').trim().split(/\s+/).map(w=>w[0]).join('').slice(0,2).toUpperCase();
  const avEl=document.getElementById('sb-av-txt'); if(avEl)avEl.textContent=av;
}
function saveMainProfile(){
  const u=document.getElementById('pf-main-user').value.trim().replace(/^@+/,'').replace(/\s+/g,''),p=document.getElementById('pf-main-plat').value;
  if(!u){try{localStorage.removeItem('ff_main');}catch(e){}toast('Profil principal retiré');return;}
  try{localStorage.setItem('ff_main',JSON.stringify({p:p,u:u}));}catch(e){}
  toast('Profil principal enregistré : @'+u);
}
(function(){try{const m=JSON.parse(localStorage.getItem('ff_main')||'null');if(m){const f=()=>{const a=document.getElementById('pf-main-user'),b=document.getElementById('pf-main-plat');if(a){a.value=m.u||'';b.value=m.p||'tiktok';}};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',f);else f();}}catch(e){}})();
function saveWorkspaceName(){
  S.pfName = document.getElementById('pf-name').value.trim();
  S.pfNick = document.getElementById('pf-nick').value.trim();
  safeSetItem('nps_pf_name', S.pfName);
  safeSetItem('nps_pf_nick', S.pfNick);
  const name=S.pfNick || S.pfName || 'MON ESPACE';
  S.wsName=name; safeSetItem('nps_ws_name',name);
  applyWorkspaceName();
  toast('Profil mis à jour');
}

// ═══════ AUTORISATIONS GROUPÉES ═══════
// Regroupe les demandes d'autorisation navigateur disponibles (micro, caméra,
// notifications, position). Les autorisations système complètes (accès à
// tous les fichiers, calendrier) doivent être accordées depuis les
// Paramètres Android car un navigateur/WebView ne peut pas les déclencher
// directement — le bouton "Paramètres" de l'écran Autorisations y renvoie.
function closePermModal(){
  document.getElementById('perm-modal').classList.remove('show');
  safeSetItem('nps_perm_asked','1');
}
async function requestAllPermissions(){
  closePermModal();
  toast('Demande des autorisations…','info');
  try{ if(navigator.mediaDevices?.getUserMedia){ const s=await navigator.mediaDevices.getUserMedia({video:true}); s.getTracks().forEach(t=>t.stop()); } }catch(e){}
  try{ if(window.Notification&&Notification.requestPermission) await Notification.requestPermission(); }catch(e){}
  toast('Autorisations demandées — pour l\'accès complet au téléphone, va dans Autorisations > Paramètres');
}
init();
checkOrphanedTerminalJobs();

// ═══════ RÉCUPÉRATION DES JOBS TERMINAL EN ATTENTE ═══════
// Si l'app a été fermée/rechargée pendant qu'un terminal_exec attendait son
// résultat (dispatch GitHub Actions déjà lancé), on vérifie une fois au
// démarrage si le résultat est arrivé entre-temps, et on le dépose dans la
// conversation concernée au lieu de le perdre. Limite honnête : ceci ne
// tourne qu'au moment où l'app est rouverte (un navigateur ne peut pas
// surveiller en tâche de fond une fois complètement fermé) — mais ça évite
// de perdre un résultat déjà prêt quand on revient.
async function checkOrphanedTerminalJobs(){
  const pending = Object.keys(localStorage).filter(k => k.startsWith('nps_pending_job_'));
  for (const key of pending) {
    try {
      const job = JSON.parse(localStorage.getItem(key));
      if (!job || !S.tok) continue;
      const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' };
      const res = await fetch(`https://api.github.com/repos/${job.owner}/${job.repo}/contents/nps-terminal-results/${job.requestId}.json`, { headers, cache: 'no-store' });
      if (res.ok) {
        const fileData = await res.json();
        const parsed = JSON.parse(btou(fileData.content.replace(/\s/g, '')));
        localStorage.removeItem(key);
        const conv = S.convs.find(c => c.id === job.convId);
        if (conv) {
          // Résultat ignoré volontairement : aucune note automatique n'est ajoutée à la conversation.
        }
      } else if (Date.now() - (job.startedAt||0) > 20*60*1000) {
        // Job introuvable après 20 min : on abandonne le suivi pour ne pas
        // accumuler des entrées mortes indéfiniment.
        localStorage.removeItem(key);
      } else {
        // Toujours en cours sur GitHub Actions (ça tourne bien côté serveur,
        // indépendamment du navigateur) — on le signale clairement au lieu de
        // laisser l'utilisateur deviner si sa tâche a été perdue.
        const mins = Math.max(1, Math.round((Date.now() - (job.startedAt||0)) / 60000));
        toast(`Une tâche terminal lancée avant fermeture tourne toujours (${mins} min) — revérifie dans un instant ou rouvre l'app plus tard.`, 'info');
      }
    } catch(e) { console.warn('checkOrphanedTerminalJobs error:', e.message); }
  }
}

// ═══════ VERROU ANTI-ZOOM (pinch + double-tap) ═══════
// Complément au viewport meta : certains navigateurs Android l'ignorent partiellement.
document.addEventListener('touchmove', e => { if (e.touches.length > 1) e.preventDefault(); }, { passive: false });
let __lastTouchEnd = 0;
document.addEventListener('touchend', e => {
  const now = Date.now();
  if (now - __lastTouchEnd <= 300) e.preventDefault();
  __lastTouchEnd = now;
}, { passive: false });
document.addEventListener('gesturestart', e => e.preventDefault());


document.addEventListener('click', (e) => {
    if (!e.target.closest('.msg-bubble') && !e.target.closest('.msg-content-final') && !e.target.closest('.inline-copy-btn')) {
        document.querySelectorAll('.inline-copy-btn').forEach(b => b.remove());
    }
});

window.toggleCopyButton = function(el, id) {
  let existingRow = el.querySelector('.inline-actions-row');
  if (existingRow) {
    existingRow.remove();
    npsGoogleStop();
  } else {
    document.querySelectorAll('.inline-actions-row').forEach(r => r.remove());
    npsGoogleStop();

    const msgObj = S.msgs.find(m => m.id === id);
    const rawText = msgObj ? stripThink(msgObj.text) : el.innerText.trim();

    const row = document.createElement('div');
    row.className = 'inline-actions-row';
    row.style.cssText = 'position:absolute;top:-10px;right:0;display:flex;gap:6px;z-index:10;white-space:nowrap;width:max-content';

    let copyBtn = document.createElement('button');
    copyBtn.className = 'inline-copy-btn';
    copyBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:12px;height:12px;vertical-align:-2px;margin-right:4px"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copier';
    copyBtn.style.cssText = 'background:var(--bg3);border:1px solid var(--border);padding:4px 8px;border-radius:4px;color:var(--text);font-size:13.5px;cursor:pointer;display:flex;align-items:center;flex-shrink:0;white-space:nowrap';
    copyBtn.onclick = (e) => {
      e.stopPropagation();
      const textToCopy = rawText || el.innerText.replace('Copier', '').trim();
      robustCopy(textToCopy).then(() => {
        copyBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:12px;height:12px;vertical-align:-2px;margin-right:4px"><polyline points="20 6 9 17 4 12"/></svg>Copié';
        toast('Texte copié dans le presse-papiers');
      }).catch((err) => {
        copyBtn.textContent = 'Erreur';
        console.error("Copy failed: ", err);
      });
      setTimeout(() => row.remove(), 1500);
    };

    let listenBtn = document.createElement('button');
    listenBtn.className = 'inline-listen-btn';
    const speakerIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:12px;height:12px;vertical-align:-2px;margin-right:4px"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>';
    const stopIcon = '<svg viewBox="0 0 24 24" fill="currentColor" style="width:12px;height:12px;vertical-align:-2px;margin-right:4px"><rect x="6" y="6" width="12" height="12" rx="1"/></svg>';
    listenBtn.innerHTML = speakerIcon + 'Écouter';
    listenBtn.style.cssText = 'background:var(--bg3);border:1px solid var(--border);padding:4px 8px;border-radius:4px;color:var(--text);font-size:13.5px;cursor:pointer;display:flex;align-items:center;flex-shrink:0;white-space:nowrap';
    // Si la synthèse vocale n'est pas disponible (typiquement une WebView
    // Android compilée en APK), le bouton reste visible mais informe
    // clairement au lieu de planter silencieusement au clic.
    const _resetListen = () => { listenBtn.innerHTML = speakerIcon + 'Écouter'; };
    listenBtn.onclick = (e) => {
      e.stopPropagation();
      if (window._npsTts && window._npsTts.active) { npsGoogleStop(); _resetListen(); return; }
      const cleanText = sanitizeHtmlLeak(rawText).replace(/[#*_`>]/g, '').trim();
      if (!cleanText) return;
      listenBtn.innerHTML = stopIcon + 'Stop';
      npsGoogleSpeak(cleanText, {
        rate: S.ttsRate || 1,
        onEnd: _resetListen,
        onFail: () => { toast('Voix Google indisponible (réseau ?)', true); _resetListen(); }
      });
    };

    row.appendChild(copyBtn);
    row.appendChild(listenBtn);
    el.appendChild(row);
  }
};

/* ═══════════ SPLASH SCREEN — particules + séquence ═══════════ */
