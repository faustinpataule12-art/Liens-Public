/* ===== Accueil en page longue + navigation vers les flux ===== */
window.ffHomeGo=function(k){
  if(k==='serie'){if(window.ffSerieSoon)window.ffSerieSoon();return;}
  if(k==='agent'){if(window.agOpen)window.agOpen();return;}
  if(window.ffSetMode)window.ffSetMode(k);
};
document.addEventListener('click',function(e){
  var h=e.target.closest&&e.target.closest('.hm-head');if(!h)return;
  var c=h.parentElement,open=!c.classList.contains('on');
  document.querySelectorAll('.hm-card.on').forEach(function(x){x.classList.remove('on');var b=x.querySelector('.hm-head');if(b)b.setAttribute('aria-expanded','false');});
  if(open){c.classList.add('on');h.setAttribute('aria-expanded','true');setTimeout(function(){try{c.scrollIntoView({block:'nearest',behavior:'smooth'});}catch(x){}},60);}
});
/* logo de l'en-tête */
(function(){var l=document.getElementById('hd-logo');if(l&&window.FF_LOGO)l.src=window.FF_LOGO;})();
