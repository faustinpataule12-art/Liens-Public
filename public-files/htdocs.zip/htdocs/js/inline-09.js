// ═══════ RENDU "STYLE META" DES ÉTAPES ═══════
// Chaque étape : puce + titre en gras + description, reliées par une ligne verticale.
// Transforme le raisonnement interne brut (<think>) en une courte phrase de
// progression "en direct" présentable, SANS jamais montrer la stratégie elle-
// même : on retire les liens (Markdown et bruts) et on ne garde que le début,
// façon "je vérifie l'étape suivante…" plutôt que le raisonnement complet.
function summarizeThinkForDisplay(rawThink) {
  let t = rawThink
    .replace(/\[([^\]]+)\]\(https?:\/\/[^\s)]+\)/g, '$1')   // liens Markdown -> juste le texte
    .replace(/https?:\/\/[^\s)]+/g, '')                       // liens bruts restants
    .replace(/\s+/g, ' ')
    .trim();
  // On garde la première phrase complète (jusqu'au premier point/exclamation
  // suivi d'un espace), tronquée si besoin, pour rester "en direct" et court.
  const firstSentence = (t.match(/^[^.!?]+[.!?]?/) || [t])[0].trim();
  // Pas de "…" ajouté à la main : le CSS (text-overflow) coupe proprement si c'est trop long.
  let short = firstSentence.length > 110 ? firstSentence.slice(0, 110).replace(/\s+\S*$/, '').trim() : firstSentence;
  short = short.replace(/[.…]+$/, '').trim();
  return short || "Réflexion en cours";
}

function stepIcon(name, status) {
  const spin = status === 'loading' ? ' class="step-icon-spin"' : '';
  const icons = {
    'Réflexion': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2.05V17h6v-.25c0-.85.4-1.55 1-2.05A7 7 0 0 0 12 2z"/></svg>`,
    'Approfondissement': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polygon points="16 8 14 14 8 16 10 10 16 8"/></svg>`,
    'Terminal': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 5 10 12 4 19"/><line x1="12" y1="19" x2="20" y2="19"/></svg>`,
    'Vérifié': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><polyline points="8 11 10.5 13.5 14 9"/></svg>`,
    'Recherché': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
    'Consulté': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18z"/></svg>`,
    'Calculé': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="11" x2="8" y2="11"/><line x1="12" y1="11" x2="12" y2="11"/><line x1="16" y1="11" x2="16" y2="11"/><line x1="8" y1="15" x2="8" y2="15"/><line x1="12" y1="15" x2="12" y2="15"/><line x1="16" y1="15" x2="16" y2="18"/><line x1="8" y1="18" x2="8" y2="18"/><line x1="12" y1="18" x2="12" y2="18"/></svg>`,
    'Interaction': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>`,
    'Édité': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/></svg>`,
    'Créé': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="12" x2="12" y2="18"/><line x1="9" y1="15" x2="15" y2="15"/></svg>`,
    'API GitHub': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 19c-4.3 1.4-4.3-2.5-6-3m12 5v-3.5c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.2 4.2 0 0 0-.1-3.2s-1.1-.3-3.5 1.3a12.3 12.3 0 0 0-6.2 0C6.5 2.8 5.4 3.1 5.4 3.1a4.2 4.2 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 9.5c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2V21"/></svg>`,
    'Appel API': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07L11.5 4.5"/><path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07l1.36-1.36"/></svg>`,
    'Outil': `<svg${spin} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`
  };
  return icons[name === 'Résultat' ? 'Vérifié' : name] || icons['Outil'];
}

// Sépare le texte de step.details (format fixe : "Paramètres de l'action :\n{...}"
// puis "\n\nRésultat de l'action :\n...") pour pouvoir copier chaque partie seule.
function splitStepDetails(details) {
  const marker = "\n\nRésultat de l'action :\n";
  const idx = details.indexOf(marker);
  if (idx === -1) return { params: details.replace(/^Paramètres de l'action :\n/, ''), result: '' };
  return {
    params: details.slice(0, idx).replace(/^Paramètres de l'action :\n/, ''),
    result: details.slice(idx + marker.length)
  };
}
function toggleStepMenu(stepId, anchorBtn) {
  const menu = document.getElementById('stepmenu-' + stepId);
  if (!menu) return;
  const isOpen = menu.style.display === 'block';
  document.querySelectorAll('.nps-file-menu').forEach(m => m.style.display = 'none');
  if (isOpen) return;
  menu.style.display = 'block';
  positionFileMenu(menu, anchorBtn);
}
function copyStepPart(stepId, which) {
  let d = (S.msgs.flatMap(m => m.steps || [])).find(s => s.id === stepId)?.details || '';
  if (!d) { // étape encore en cours de diffusion : relire le texte affiché
    try {
      const det = document.getElementById('stepmenu-' + stepId)?.closest('details');
      d = det?.querySelector(':scope > div')?.textContent || '';
    } catch (e) {}
  }
  const parts = splitStepDetails(d);
  const text = String(which === 'params' ? parts.params : parts.result).trim();
  const label = which === 'params' ? 'Paramètres' : 'Résultat';
  // La copie doit s'exécuter AVANT de masquer le menu (geste utilisateur actif).
  if (!text) {
    toast(label + ' : rien à copier');
  } else {
    robustCopy(text)
      .then(() => toast(label + ' copiés'))
      .catch(() => { toast('Copie auto impossible — copie manuelle'); showManualCopy(text, label); });
  }
  document.querySelectorAll('.nps-file-menu').forEach(m => m.style.display = 'none');
}
function renderStepMeta(step) {
  const status = step.status || 'done';
  const isReflection = (step.name === 'Réflexion' || step.name === 'Approfondissement') && step.details;
  const detailsHtml = (step.details && !isReflection) ? `<details class="meta-step-details">
      <summary>
        <span>Détails</span>
        <span class="nps-file-menu-wrap" style="position:relative;flex-shrink:0;" onclick="event.preventDefault();event.stopPropagation();">
          <button onclick="toggleStepMenu('${step.id}', this)" style="background:none;border:none;color:var(--text3);cursor:pointer;padding:2px 6px;line-height:1;display:inline-flex;align-items:center;justify-content:center;vertical-align:middle;"><svg style="width:16px;height:16px;flex-shrink:0" viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg></button>
          <div id="stepmenu-${step.id}" class="nps-file-menu" style="display:none;position:fixed;background:var(--bg3);border:1px solid var(--border);border-radius:10px;min-width:200px;max-width:calc(100vw - 16px);z-index:9999;overflow:hidden;box-shadow:0 6px 20px rgba(0,0,0,.5);">
            <button onclick="copyStepPart('${step.id}','params')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copier les paramètres</button>
            <button onclick="copyStepPart('${step.id}','result')" style="display:flex;width:100%;align-items:center;gap:8px;padding:10px 14px;background:none;border:none;color:var(--text);font-size:15.5px;text-align:left;cursor:pointer;border-top:1px solid var(--border);"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copier le résultat</button>
          </div>
        </span>
      </summary>
      <div>${esc(step.details)}</div>
    </details>` : '';
  const reflectionHtml = isReflection ? `<div class="think-flow">${renderThinkLines(step.details, true)}</div>` : '';
  // Le texte complet du raisonnement (reflectionHtml) commence déjà par la
  // même phrase que le résumé court (step.summary) — les afficher tous les
  // deux produit un doublon visible. On n'affiche le résumé court QUE quand
  // il n'y a pas encore de texte complet (étape encore en cours de streaming).
  const descHtml = isReflection ? '' : `<div class="meta-step-desc">${esc(step.summary || '')}</div>`;
  const diagHtml = step.diagnosis ? `<div class="meta-step-diag">${esc(step.diagnosis)}</div>` : '';
  const liveHtml = step.live ? renderBuildLiveCard(step.live, step.id) : '';
  const sourcesHtml = (step.sources && step.sources.length) ? renderInlineSources(step.sources, step.id) : '';
  return `<div class="meta-step ${status}">
    <div class="meta-step-title"><span class="step-icon">${stepIcon(step.name, status)}</span><span class="meta-step-title-text${status === 'loading' ? ' loading-title' : ''}">${esc(step.name || 'Étape')}</span></div>
    ${descHtml}
    ${diagHtml}
    ${sourcesHtml}
    ${liveHtml}
    ${reflectionHtml}
    ${detailsHtml}
  </div>`;
}

// Carte de suivi en direct d'un build GitHub Actions (temps écoulé, statut, lien du run).
// Porte un id stable (stepcard-<id>) pour pouvoir la mettre à jour sans
// redessiner tout le message (voir updateStepLiveDOM) — sinon ce petit
// minuteur qui change toutes les 3s faisait clignoter le message entier.
function renderBuildLiveCard(live, stepId) {
  const dotClass = live.done ? (live.error ? 'fail' : 'ok') : '';
  const mins = Math.floor((live.elapsed || 0) / 60);
  const secs = (live.elapsed || 0) % 60;
  const timeStr = `${mins}:${String(secs).padStart(2, '0')}`;
  const linkHtml = live.htmlUrl ? `<a href="${esc(live.htmlUrl)}" target="_blank" rel="noopener noreferrer" style="color:var(--accent2);font-size:13.5px;">Voir le run ↗</a>` : '';
  return `<div class="build-live-card" id="stepcard-${stepId}">
    <div class="build-live-dot ${dotClass}"></div>
    <div class="build-live-body">
      <div class="build-live-title">${esc(live.text || 'Build en cours…')}</div>
      <div class="build-live-sub">${linkHtml}</div>
    </div>
    <div class="build-live-time">${timeStr}</div>
  </div>`;
}

// Met à jour UNIQUEMENT la petite carte "en direct" d'une étape (minuteur,
// texte, point de statut) sans toucher au reste du message — évite de
// redessiner (et donc faire clignoter/trembler) tout le message à chaque
// tic de progression (toutes les ~3s pendant qu'un outil tourne).
// Retourne true si la mise à jour ciblée a réussi ; false s'il faut se
// rabattre sur un rendu complet (ex. la carte n'existe pas encore).
function updateStepLiveDOM(step) {
  const card = document.getElementById('stepcard-' + step.id);
  if (!card || !step.live) return false;
  const live = step.live;
  const titleEl = card.querySelector('.build-live-title');
  const timeEl = card.querySelector('.build-live-time');
  const dotEl = card.querySelector('.build-live-dot');
  const subEl = card.querySelector('.build-live-sub');
  if (titleEl) titleEl.textContent = live.text || 'Build en cours…';
  if (timeEl) {
    const mins = Math.floor((live.elapsed || 0) / 60);
    const secs = (live.elapsed || 0) % 60;
    timeEl.textContent = `${mins}:${String(secs).padStart(2, '0')}`;
  }
  if (dotEl) dotEl.className = 'build-live-dot ' + (live.done ? (live.error ? 'fail' : 'ok') : '');
  if (subEl) subEl.innerHTML = live.htmlUrl ? `<a href="${esc(live.htmlUrl)}" target="_blank" rel="noopener noreferrer" style="color:var(--accent2);font-size:13.5px;">Voir le run ↗</a>` : '';
  return true;
}

// ═══════ RENDU DES SOURCES ═══════
function faviconFor(url) {
  try { const h = new URL(url).hostname; return `https://www.google.com/s2/favicons?domain=${h}&sz=32`; }
  catch(e) { return ''; }
}
function renderSourceCard(src) {
  const fav = src.favicon || faviconFor(src.url || '');
  const url = src.url || '#';
  const safeUrl = url.replace(/'/g, '%27');
  const safeTitle = (src.title || url).replace(/'/g, '%27');
  return `<a class="source-card" href="${esc(url)}" onclick="event.preventDefault();openLink('${safeUrl}','${safeTitle}')">
    ${fav ? `<img class="source-fav" src="${fav}" loading="lazy" onerror="this.style.display='none'"/>` : ''}
    <div class="source-body">
      <div class="source-title">${esc(src.title || src.url || 'Source')}</div>
      <div class="source-url">${esc(src.url || '')}</div>
      ${src.snippet ? `<div class="source-snippet">${esc(src.snippet)}</div>` : ''}
    </div>
  </a>`;
}

// Ligne "N pages web trouvées" avec favicons empilés, directement sous l'étape de
// recherche — repliée par défaut, cliquable pour dérouler les cartes de sources.
// C'est le comportement demandé (voir captures de référence) : pas d'onglet séparé,
// les sources vivent dans le flux des étapes, au même endroit que la recherche qui
// les a produites.
function renderInlineSources(sources, stepId) {
  const favs = sources.slice(0, 5).map(s => `<img class="src-inline-fav" src="${faviconFor(s.url)}" onerror="this.style.display='none'"/>`).join('');
  const n = sources.length;
  const label = `${n} page${n>1?'s':''} web trouvée${n>1?'s':''}`;
  const safeId = 'src-inline-' + stepId;
  return `
  <div class="src-inline-row" onclick="toggleInlineSources(event,'${safeId}')">
    <div class="src-inline-favs">${favs}</div>
    <span class="src-inline-count">${label}</span>
    <svg class="src-inline-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>
  </div>
  <div class="src-inline-list" id="${safeId}">
    ${sources.map(s => renderSourceCard(s)).join('')}
  </div>`;
}
function toggleInlineSources(evt, id) {
  evt.stopPropagation();
  const el = document.getElementById(id);
  if (!el) return;
  const row = evt.currentTarget;
  const isOpen = el.classList.toggle('open');
  row.classList.toggle('open', isOpen);
}

// ═══════ BLOC DE RÉFLEXION ═══════
// Libellé dynamique de l'étape en cours : reflète l'action RÉELLE en train de
// tourner (Terminal, Recherche, Consultation...) au lieu de toujours afficher
// "réflexion", qui n'a pas de sens quand c'est par exemple un terminal_exec.
function currentStepLabel(steps) {
  const loadingStep = [...steps].reverse().find(s => s.status === 'loading');
  if (!loadingStep) return "Traitement en cours…";
  const labels = {
    'Réflexion': 'Réflexion en cours…',
    'Approfondissement': 'Approfondissement de la demande…',
    'Terminal': 'Terminal en cours…',
    'Recherché': 'Recherche en cours…',
    'Consulté': 'Consultation en cours…',
    'Calculé': 'Calcul en cours…',
    'Vérifié': 'Vérification en cours…',
    'Interaction': 'Prise en compte du message…',
    'Édité': 'Édition en cours…',
    'Créé': 'Création en cours…',
    'API GitHub': 'Appel GitHub en cours…',
    'Appel API': 'Appel API en cours…',
    'Outil': 'Action en cours…'
  };
  return labels[loadingStep.name] || `${loadingStep.name} en cours…`;
}

function buildReflectionBlock(msgId, isClosed, steps, sources, startTs) {
  if (isClosed) return '';
  return '<div class="ff-work"><i></i><i></i><i></i></div>';
}
function buildReflectionBlockOrig(msgId, isClosed, steps, sources, startTs) {
  // Une fois terminé, le titre reflète le NOMBRE réel d'étapes effectuées
  // (recherche, terminal, réflexion, vérification...) plutôt que de tout
  // appeler "réflexion" — un terminal_exec n'est pas une réflexion.
  // Pendant le traitement, pas de libellé nommé par étape : un simple compteur
  // de secondes écoulées (1s, 2s…), pour ne pas laisser croire que l'interface
  // sait précisément ce que le modèle est en train de faire à chaque instant.
  const _clean = t => String(t || '').replace(/\s+/g, ' ').replace(/(\.{2,}|…)+\s*$/, '').trim();
  const _live = [...steps].reverse().find(s => s.status === 'loading');
  const _liveLabel = _live ? (_clean(_live.summary) && !/^(R[ée]flexion|Traitement) en cours$/i.test(_clean(_live.summary)) ? _clean(_live.summary) : _clean(currentStepLabel(steps))) : '';
  const _tm = S.msgs.find(x => x.id === msgId);
  if (isClosed && _tm && _tm.reflectionStartTs && !_tm.reflectionEndTs && S.activeSendMsgId === msgId) _tm.reflectionEndTs = Date.now();
  const _fmt = ms => { const t = Math.max(0, Math.floor(ms / 1000)); return t < 60 ? t + 's' : Math.floor(t / 60) + 'min ' + String(t % 60).padStart(2, '0') + 's'; };
  const title = isClosed
    ? (`${steps.length} étape${steps.length>1?'s':''} effectuée${steps.length>1?'s':''}` + ((_tm && _tm.reflectionStartTs && _tm.reflectionEndTs) ? ' · ' + _fmt(_tm.reflectionEndTs - _tm.reflectionStartTs) : ''))
    : `<span class="nps-step-live-label">${esc(_liveLabel || 'Traitement en cours…')}</span> · <span class="nps-step-timer">${_fmt(Date.now() - (startTs || Date.now()))}</span>`;
  const timerHtml = '';
  const statusClass = isClosed ? "done" : "loading";
  const statusContent = isClosed ? `<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"></polyline></svg>` : '';
  const stepsHtml = `<div class="meta-step-list">${steps.map(s => renderStepMeta(s)).join('')}</div>`;

  // L'icône de l'en-tête (collapsed) doit elle aussi refléter l'action réelle
  // en cours (Terminal, Recherche...) et pas rester une simple flèche fixe —
  // c'est le même stepIcon() que celui déjà utilisé par étape individuelle.
  const activeStep = isClosed
    ? steps[steps.length - 1]
    : ([...steps].reverse().find(s => s.status === 'loading') || steps[steps.length - 1]);
  const headerIconHtml = activeStep
    ? `<span class="nps-step-action-icon" style="display:flex;align-items:center;margin-right:6px;flex-shrink:0;">${stepIcon(activeStep.name, isClosed ? 'done' : 'loading')}</span>`
    : '';

  return `
  <details class="nps-step" style="width:100%; margin-bottom: 8px; border:none; background:transparent; border-bottom: 1px solid var(--border); border-radius: 0; padding-bottom: 4px;">
    <summary class="nps-step-header" style="background:transparent; padding: 4px 0; border: none; font-size: 15.5px; color: var(--text2); display: flex; align-items: center;">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px;margin-right:6px;flex-shrink:0"><polyline points="9 18 15 12 9 6"></polyline></svg>
      ${headerIconHtml}
      <span class="nps-step-title${isClosed ? '' : ' nps-title-shimmer'}" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${title}</span>${timerHtml}
      <button type="button" class="nps-steps-dl" title="Télécharger les étapes (.md)" aria-label="Télécharger les étapes en .md" onclick="event.preventDefault();event.stopPropagation();downloadStepsTxt('${msgId}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
      <div class="nps-step-status ${statusClass}" style="margin-left:8px; display:flex; align-items:center;">${statusContent}</div>
    </summary>
    <div class="nps-step-content" style="padding: 8px 0 12px 6px;">
      ${stepsHtml}
    </div>
  </details>`;
}

function renderThinkLines(content, isThinkClosed) {
  if (!content) return '';
  const lines = content.split('\n').filter(l => l.trim().length > 0);
  return lines.map((line, idx) => {
     let text = line.replace(/^[\d\.\-\s\*]+/, '').trim();
     text = text.replace(/\s*(\u2713|\u2705|\u274c)\s*$/, '');
     // Liens Markdown [texte](url) -> cliquables, ouverture interne
     let html = esc(text).replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (m, label, url) => {
       const safeUrl = url.replace(/'/g, '%27');
       return `<a href="${url}" onclick="event.preventDefault();event.stopPropagation();openLink('${safeUrl}')" style="color:var(--accent);text-decoration:underline">${esc(label)}</a>`;
     });
     const isLast = idx === lines.length - 1;
     const stillTyping = isLast && !isThinkClosed;
     const color = stillTyping ? 'var(--text)' : 'var(--text2)';
     const opacity = stillTyping ? '1' : '0.85';
     return `<span style="color:${color}; opacity:${opacity}; transition: color .4s, opacity .4s;">${html}</span> `;
  }).join('');
}
