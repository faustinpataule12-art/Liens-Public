// ═══════ LIENS & PARTAGE ═══════
// Les liens s'ouvrent DANS l'application (iframe plein écran) au lieu du
// navigateur externe : l'URL réelle n'est jamais visible à l'utilisateur.
// Exception : les liens WhatsApp sont transmis directement à l'app WhatsApp
// (deep link), sans passer par un navigateur non plus.
let S_inappUrl = '';
let S_inappTimeout = null;
function openLink(url,title){
  if(/whatsapp\.com|wa\.me/.test(url)){
    window.location.href=url;
    return;
  }
  openInApp(url,title);
}
function openInApp(url,title){
  S_inappUrl = url;
  document.getElementById('inapp-title').textContent=title||'Fable Fast';
  document.getElementById('inapp-fallback').style.display='none';
  const frame = document.getElementById('inapp-frame');
  frame.style.display='block';
  frame.src=url;
  document.getElementById('inapp-view').classList.add('show');

  // Certains sites (ex: claude.ai) bloquent l'affichage en iframe (X-Frame-Options/CSP).
  // Dans ce cas la page reste blanche sans jamais signaler d'erreur : on détecte ça avec
  // un délai et on propose alors clairement d'ouvrir dans le vrai navigateur.
  if (S_inappTimeout) clearTimeout(S_inappTimeout);
  let loaded = false;
  frame.onload = () => {
    loaded = true;
    try {
      // Si le contenu du frame est vide/inaccessible malgré le "load", c'est probablement bloqué.
      if (!frame.contentWindow || !frame.contentDocument || frame.contentDocument.body?.innerHTML.trim() === '') {
        showInAppFallback();
      }
    } catch(e) {
      // Erreur cross-origin normale pour un site externe qui a bien chargé : on considère que c'est OK.
    }
  };
  S_inappTimeout = setTimeout(() => { if(!loaded) showInAppFallback(); }, 4000);
}
function showInAppFallback(){
  document.getElementById('inapp-fallback').style.display='block';
  document.getElementById('inapp-frame').style.display='none';
}
function openInAppExternally(){
  if (S_inappUrl) window.open(S_inappUrl, '_blank', 'noopener');
}
function closeInApp(){
  document.getElementById('inapp-view').classList.remove('show');
  document.getElementById('inapp-frame').src='about:blank';
  document.getElementById('inapp-fallback').style.display='none';
  document.getElementById('inapp-frame').style.display='block';
  if (S_inappTimeout) { clearTimeout(S_inappTimeout); S_inappTimeout = null; }
}
function shareApp(){
  const shareData={
    title:'Fable Fast — Assistant IA',
    text:'Découvre Fable Fast, mon assistant IA',
    url:'https://nps-nelson-hub.gamer.free/'
  };
  if(navigator.share){
    navigator.share(shareData).catch(()=>{});
  } else {
    robustCopy(shareData.url).then(()=>toast('Lien copié — colle-le dans WhatsApp')).catch(()=>toast('Partage non supporté sur ce navigateur',true));
  }
}

// ═══════ THÈME & POLICE ═══════
function toggleTheme(){
  const light=document.body.classList.toggle('light');
  safeSetItem('nps_theme',light?'light':'dark');
  document.getElementById('theme-icon').innerHTML=light
    ? '<svg class="nps-ic-row" viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="12" y1="20" x2="12" y2="22" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="2" y1="12" x2="4" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="20" y1="12" x2="22" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="4.93" y1="4.93" x2="6.34" y2="6.34" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="17.66" y1="17.66" x2="19.07" y2="19.07" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="4.93" y1="19.07" x2="6.34" y2="17.66" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="17.66" y1="6.34" x2="19.07" y2="4.93" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'
    : '<svg class="nps-ic-row" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  document.getElementById('theme-sub-label').textContent=light?'Clair':'Sombre';
}
const FONTS=[
  {cls:'',label:'Par défaut'},
  {cls:'font-round',label:'Arrondie'},
  {cls:'font-serif',label:'Serif'},
  {cls:'font-mono',label:'Monospace'},
  {cls:'font-light',label:'Fine'},
  {cls:'font-thin',label:'Ultra-fine'},
  {cls:'font-medium',label:'Moyenne'},
  {cls:'font-black',label:'Grasse'},
  {cls:'font-condensed',label:'Condensée'},
  {cls:'font-condensed-light',label:'Condensée fine'},
  {cls:'font-condensed-medium',label:'Condensée moyenne'},
  {cls:'font-serif-mono',label:'Machine à écrire'},
  {cls:'font-cursive',label:'Manuscrite'},
  {cls:'font-casual',label:'Décontractée'},
  {cls:'font-serif-italic',label:'Serif italique'},
  {cls:'font-sans-italic',label:'Sans italique'},
  {cls:'font-uppercase',label:'Majuscules espacées'},
  {cls:'font-compact',label:'Compacte'},
  {cls:'font-elegant',label:'Élégante'},
  {cls:'font-airy',label:'Aérée'},
];
function fontLabelWithNumber(f){
  // Numéroté (1 à FONTS.length) pour qu'on puisse s'en souvenir et y revenir,
  // vu le nombre de styles disponibles.
  const n=FONTS.indexOf(f)+1;
  return n+'/'+FONTS.length+' · '+f.label;
}
function cycleFont(){
  let idx=FONTS.findIndex(f=>f.cls&&document.body.classList.contains(f.cls));
  if(idx===-1)idx=0;
  FONTS.forEach(f=>f.cls&&document.body.classList.remove(f.cls));
  const next=FONTS[(idx+1)%FONTS.length];
  if(next.cls)document.body.classList.add(next.cls);
  document.getElementById('font-sub-label').textContent=fontLabelWithNumber(next);
  safeSetItem('nps_font',next.cls);
}

// ═══════ SIDEBAR ═══════
let sbOpen=false;
function toggleSidebar(){sbOpen?closeSidebar():openSidebar()}
function openSidebar(){
  if(window.ffMenuOpen){window.ffMenuOpen();return;}
  sbOpen=true;
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('sb-overlay').classList.add('show');
  renderRecents();
  syncHeaderBtns();
}
function closeSidebar(){
  sbOpen=false;
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sb-overlay').classList.remove('show');
  syncHeaderBtns();
}


let touchStartTs = 0;
let touchTimer = null;
let activeCtxConvId = null;

window.handleTouchStart = function(e, id) {
  touchStartTs = Date.now();
  if (touchTimer) clearTimeout(touchTimer);
  touchTimer = setTimeout(() => {
    openCtxModal(id);
  }, 650);
};

window.handleTouchEnd = function(e, id) {
  if (touchTimer) clearTimeout(touchTimer);
  if (Date.now() - touchStartTs > 600) {
    if (e.cancelable) e.preventDefault();
  }
};

function openCtxModal(id) {
  if (touchTimer) clearTimeout(touchTimer);
  activeCtxConvId = id;
  const conv = S.convs.find(c => c.id === id);
  if (conv) document.getElementById('ctx-title').textContent = conv.title.substring(0,25) + '...';
  document.getElementById('ctx-modal').classList.add('show');
}

function closeCtxModal() {
  document.getElementById('ctx-modal').classList.remove('show');
  activeCtxConvId = null;
}

async function deleteConvFromGitHub(id) {
  if (!S.tok) return;
  try {
    const owner = await getGhLogin();
    if (!owner) return;
    const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json', 'Content-Type': 'application/json' };

    // 1) Supprimer réellement le fichier historique/{id}.json sur GitHub
    const _dm = npsConvMode(id);
    const fileUrl = `https://api.github.com/repos/${owner}/Maker/contents/${npsP(_dm, 'historique/' + id + '.json')}`;
    const check = await fetch(fileUrl, { headers, cache: 'no-cache' });
    if (check.ok) {
      const sha = (await check.json()).sha;
      await fetch(fileUrl, {
        method: 'DELETE',
        headers,
        body: JSON.stringify({ message: `Suppression de la conversation ${id}`, sha })
      });
    }

    // 2) Retirer l'entrée de l'index chat-history.json (lecture fiable, jamais d'écrasement sur erreur)
    const idxCur = await npsReadIndex(owner, _dm);
    if (idxCur) {
      _idxKnown.delete(id);
      await npsIndexWrite(owner, idxCur.filter(c => c.id !== id), `Retrait de ${id} de l'index`, _dm);
    }
  } catch(e) {
    console.warn('deleteConvFromGitHub error:', e.message);
    toast('Suppression locale ok, mais la suppression sur GitHub a échoué (réessaie plus tard)', 'warn');
  }
}

function deleteConv() {
  if (!activeCtxConvId) return;
  if (!confirm("Supprimer cette conversation ? (elle sera aussi supprimée définitivement de GitHub)")) return;
  const idToDelete = activeCtxConvId;
  S.convs = S.convs.filter(c => c.id !== idToDelete);
  safeSetItem('nps_convs', JSON.stringify(S.convs.map(c=>({...c,msgs:[]}))))
  localStorage.removeItem('nps_conv_'+idToDelete);
  renderRecents();
  closeCtxModal();
  if (S.currentConv === idToDelete) {
    newConv();
  }
  // La suppression locale est immédiate pour l'UI ; la suppression réelle sur
  // GitHub (fichier + index) suit en arrière-plan tant que le token a les
  // autorisations nécessaires (repo scope) — sans ça, rien ne serait vraiment
  // effacé, juste caché localement.
  deleteConvFromGitHub(idToDelete);
}

function exportConv() {
  if (!activeCtxConvId) return;
  const conv = S.convs.find(c => c.id === activeCtxConvId);
  if (!conv) return;
  
  // Actually we need to load msgs if not in current state
  // But wait, they are not in S.convs?
  // Ah! S.convs only stores metadata. msgs are saved as `nps_conv_${id}`!
  // Wait, looking at saveConv earlier, how is loadConv implemented?
  let msgsToExport = conv.msgs;
  if (!msgsToExport || msgsToExport.length === 0) {
      const stored = localStorage.getItem('nps_conv_'+activeCtxConvId);
      if (stored) {
          try { msgsToExport = JSON.parse(stored); } catch(e){}
      }
  }
  
  if (!msgsToExport || msgsToExport.length === 0) {
      toast("Impossible de charger l'historique.");
      return;
  }
  
  let txt = "Conversation: " + conv.title + "\nDate: " + new Date(conv.ts).toLocaleString('fr-FR') + "\n\n";
  msgsToExport.forEach(m => {
      let role = m.role === 'user' ? (S.wsName || 'User') : 'Fable Fast';
      txt += `[${role} - ${new Date(m.ts).toLocaleTimeString('fr-FR')}]\n`;
      txt += stripThink(m.text, '[Processus de réflexion masqué]') + "\n\n";
  });
  
  const blob = new Blob(['\ufeff' + txt], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `nps_export_${activeCtxConvId}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  closeCtxModal();
}

function renameConvUI() {
  if (!activeCtxConvId) return;
  const conv = S.convs.find(c => c.id === activeCtxConvId);
  if (!conv) return;
  const newTitle = prompt("Renommer la conversation :", conv.title);
  if (newTitle && newTitle.trim()) {
    conv.title = newTitle.trim(); conv.titlePending = false;
    safeSetItem('nps_convs', JSON.stringify(S.convs.map(c=>({...c,msgs:[]}))))
    renderRecents();
    if (S.currentConv === activeCtxConvId) {
      setTitle(newTitle.trim());
    }
    closeCtxModal();
    toast('Conversation renommée');
  }
}

function loadConvAndClose(id, e) {
  // Prevent if long press triggered
  if (document.getElementById('ctx-modal').classList.contains('show')) return;
  loadConv(id);
  closeSidebar();
}
