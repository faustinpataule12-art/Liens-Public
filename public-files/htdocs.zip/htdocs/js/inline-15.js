/* ═══════════ Fable Fast v2 : chargement, scroll, barre de saisie, menus ═══════════ */
(function(){
  const $ = id => document.getElementById(id);

  /* — Barre de chargement façon YouTube + rond qui tourne — */
  const Loader = { start(){}, done(){}, pulse(){} }; // barre du haut retirée : l'API reste, sans effet visuel
  window.NPSLoader = Loader;

  /* — Navigation : bouton retour matériel (Android) — */
  try { history.replaceState({nps:0}, ''); } catch(e){}
  window.addEventListener('popstate', () => {
    if (NAV.ignorePop) { NAV.ignorePop = false; return; }
    if (window.ixIsOpen && window.ixIsOpen()) return;
    const openSheetEl = document.querySelector('.nps-sheet-bg.show');
    if (openSheetEl) { openSheetEl.classList.remove('show'); try{history.pushState({nps:NAV.stack.length},'');}catch(e){} return; }
    if (typeof sbOpen !== 'undefined' && sbOpen) { closeSidebar(); try{history.pushState({nps:NAV.stack.length},'');}catch(e){} return; }
    if (NAV.stack.length) goBack(true);
  });

  /* — Barre de saisie : se cache en montant, revient en descendant — */
  const feed = $('feed'), comp = $('composer'), fab = $('scroll-fab'), view = $('view-chat'), input = $('comp-input');
  if (feed && comp && fab && view) {
    let last = feed.scrollTop, hidden = false, idle = null, lock = 0;
    const setH = () => view.style.setProperty('--comp-h', comp.offsetHeight + 'px');
    if (window.ResizeObserver) new ResizeObserver(() => { setH(); if (hidden) comp.style.marginBottom = (-comp.offsetHeight) + 'px'; }).observe(comp);
    setH();

    function setHidden(h){
      if (h === hidden) return;
      if (h && (document.activeElement === input || ($('attach-menu') && $('attach-menu').style.display === 'block'))) return;
      hidden = h; lock = Date.now() + 380;
      comp.style.marginBottom = h ? (-comp.offsetHeight) + 'px' : '0px';
      comp.classList.toggle('comp-hidden', h);
      view.classList.toggle('comp-off', h);
    }
    window.npsShowComposer = () => setHidden(false);
    input && input.addEventListener('focus', () => setHidden(false));

    const hideFab = () => fab.classList.remove('show');
    function showFab(dir){
      fab.classList.toggle('up', dir === 'up');
      fab.classList.add('show');
      clearTimeout(idle); idle = setTimeout(hideFab, 2600);
    }
    feed.addEventListener('scroll', () => {
      const top = feed.scrollTop, max = feed.scrollHeight - feed.clientHeight;
      if (Date.now() < lock) { last = top; return; }
      if (max < 160) { setHidden(false); hideFab(); last = top; return; }
      const delta = top - last;
      if (Math.abs(delta) < 4) return;
      last = top;
      const dir = delta < 0 ? 'up' : 'down';
      if (dir === 'up') { if (top > 40) setHidden(true); } else setHidden(false);
      if (top > max - 40) setHidden(false);
      const nearTop = top < 80, nearBottom = top > max - 80;
      if ((dir === 'up' && nearTop) || (dir === 'down' && nearBottom)) { hideFab(); return; }
      showFab(dir);
    }, { passive: true });
    fab.addEventListener('click', () => {
      const up = fab.classList.contains('up');
      if (!up) setHidden(false);
      feed.scrollTo({ top: up ? 0 : feed.scrollHeight, behavior: 'smooth' });
      hideFab();
    });
  }

  /* — Feuilles du bas — */
  window.openSheet = id => { const el = $(id); if (!el) return; el.classList.add('show'); try{history.pushState({nps:NAV.stack.length},'');}catch(e){} };
  window.closeSheet = id => { const el = $(id); if (el) el.classList.remove('show'); };

  window.NPS_PIN_SVG = '<svg class="nps-pin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"/></svg>';
  window.NPS_PROJECT_SVG = '<svg class="nps-project-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';

  const persistConvs = () => safeSetItem('nps_convs', JSON.stringify(S.convs.map(c => ({...c, msgs: []}))));

  /* — Menu ⋮ du haut (conversation en cours) — */
  const more = $('more-btn');
  if (more) more.addEventListener('click', e => { e.stopPropagation(); openConvMenu(S.currentConv, more); });

  /* — Épingler — */
  window.togglePinConv = id => {
    const c = S.convs.find(x => x.id === id); if (!c) return;
    c.pinned = !c.pinned; persistConvs(); renderRecents();
    toast(c.pinned ? 'Conversation épinglée' : 'Épinglage retiré');
  };

  /* — Renommer — */
  let renId = null;
  window.openRenameSheet = id => {
    const c = S.convs.find(x => x.id === id); if (!c) return;
    renId = id; $('rename-input').value = c.title;
    openSheet('rename-sheet');
    setTimeout(() => { const i = $('rename-input'); i.focus(); i.select(); }, 340);
  };
  window.confirmRename = () => {
    const v = $('rename-input').value.trim(); if (!v) return;
    const c = S.convs.find(x => x.id === renId); if (!c) return;
    c.title = v; persistConvs(); renderRecents();
    if (S.currentConv === renId) setTitle(v);
    closeSheet('rename-sheet'); toast('Conversation renommée');
    if (S.tok) {
      npsResolveConvMsgs(renId).then(msgs => saveConvToGitHubNow(c.id, c.title, c.ts, msgs)).catch(() => {});
    }
  };

  /* — Projets — */
  const getProjects = () => { try { return JSON.parse(localStorage.getItem('nps_projects') || '[]'); } catch(e){ return []; } };
  const saveProjects = p => safeSetItem('nps_projects', JSON.stringify(p));
  let projConv = null, projMode = 'browse', projOpen = null;
  const FOLDER = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
  const CHECK = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9b6cf0" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
  const TRASH = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';

  function renderProjects(){
    const list = $('project-list'), projects = getProjects();
    $('project-sheet-title').textContent = projMode === 'assign' ? 'Ajouter au projet' : 'Projets';
    const conv = projMode === 'assign' ? S.convs.find(c => c.id === projConv) : null;
    let html = '';
    if (!projects.length) html += '<div class="sh-empty">Aucun projet pour l’instant. Crée le premier ci-dessous.</div>';
    projects.forEach(p => {
      const convs = S.convs.filter(c => c.projectId === p.id);
      if (projMode === 'assign') {
        html += `<div class="sh-row" onclick="assignProject('${p.id}')">${FOLDER}<span class="sh-label">${esc(p.name)}</span>${conv && conv.projectId === p.id ? CHECK : `<span class="sh-sub">${convs.length}</span>`}</div>`;
      } else {
        html += `<div class="sh-row" onclick="toggleProjectOpen('${p.id}')">${FOLDER}<span class="sh-label">${esc(p.name)}</span><span class="sh-sub">${convs.length} conv.</span><span onclick="event.stopPropagation();deleteProject('${p.id}')" style="display:flex;padding:6px;color:var(--text3)">${TRASH}</span></div>`;
        if (projOpen === p.id) {
          html += '<div class="sh-sub-list">' + (convs.length
            ? convs.map(c => `<div class="sh-row" onclick="openConvFromProject('${c.id}')"><span class="sh-label">${esc(c.title)}</span></div>`).join('')
            : '<div class="sh-empty">Aucune conversation dans ce projet.</div>') + '</div>';
        }
      }
    });
    if (conv && conv.projectId) html += `<div class="sh-row" style="color:#ef6b6b" onclick="assignProject(null)"><span class="sh-label">Retirer du projet</span></div>`;
    list.innerHTML = html;
  }
  window.openProjectSheet = id => { projConv = id; projMode = 'assign'; renderProjects(); openSheet('project-sheet'); };
  window.openProjectsBrowse = () => { closeSidebar(); projConv = null; projMode = 'browse'; projOpen = null; renderProjects(); openSheet('project-sheet'); };
  window.toggleProjectOpen = id => { projOpen = projOpen === id ? null : id; renderProjects(); };
  window.openConvFromProject = id => { closeSheet('project-sheet'); loadConv(id); };
  window.assignProject = pid => {
    const c = S.convs.find(x => x.id === projConv); if (!c) return;
    if (pid) c.projectId = pid; else delete c.projectId;
    persistConvs(); closeSheet('project-sheet');
    const p = getProjects().find(x => x.id === pid);
    toast(pid ? 'Ajouté au projet « ' + (p ? p.name : '') + ' »' : 'Retiré du projet');
  };
  window.createProject = () => {
    const inp = $('project-new-input'), name = inp.value.trim(); if (!name) return;
    const projects = getProjects();
    const p = { id: 'p' + Date.now().toString(36), name };
    projects.push(p); saveProjects(projects); inp.value = '';
    if (projMode === 'assign') { assignProject(p.id); return; }
    renderProjects(); toast('Projet créé');
  };
  window.deleteProject = pid => {
    saveProjects(getProjects().filter(p => p.id !== pid));
    S.convs.forEach(c => { if (c.projectId === pid) delete c.projectId; });
    persistConvs(); if (projOpen === pid) projOpen = null; renderProjects();
    toast('Projet supprimé');
  };

  /* — Ajouter à l'écran d'accueil — */
  let deferredInstall = null, homeConv = null;
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; });
  window.addEventListener('appinstalled', () => { deferredInstall = null; });
  const baseUrl = () => location.href.split('#')[0];
  const deepLink = id => baseUrl() + '#c=' + encodeURIComponent(id);

  function setConvManifest(c){
    try {
      const icon = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="110" fill="#0b0d12"/><g fill="none" stroke="#9b6cf0"><circle cx="256" cy="256" r="170" stroke-width="5" opacity=".7"/><circle cx="256" cy="256" r="145" stroke-width="14" stroke-dasharray="20 30"/></g><text x="256" y="262" font-family="Arial,sans-serif" font-size="100" font-weight="900" fill="#9b6cf0" text-anchor="middle" dominant-baseline="central">Fable Fast</text></svg>');
      const m = { name: c.title, short_name: (c.title || 'Fable Fast').slice(0, 12), start_url: deepLink(c.id), scope: baseUrl().replace(/[^/]*$/, ''), display: 'standalone', background_color: '#0b0d12', theme_color: '#0b0d12', icons: [{ src: icon, sizes: '512x512', type: 'image/svg+xml', purpose: 'any' }] };
      let link = document.querySelector('link[rel="manifest"]');
      if (!link) { link = document.createElement('link'); link.rel = 'manifest'; document.head.appendChild(link); }
      link.href = URL.createObjectURL(new Blob([JSON.stringify(m)], { type: 'application/manifest+json' }));
    } catch(e){}
  }
  window.openHomeSheet = id => {
    const c = S.convs.find(x => x.id === id); if (!c) return;
    homeConv = id; setConvManifest(c);
    $('home-title').textContent = c.title;
    $('home-steps').style.display = 'none';
    $('home-preview').style.display = 'flex';
    $('home-add').style.display = 'block';
    openSheet('home-sheet');
  };
  window.confirmAddHome = async () => {
    const c = S.convs.find(x => x.id === homeConv); if (!c) return;
    const link = deepLink(c.id);
    // 1) pont natif Android si l'app est compilée en WebView
    try { if (window.Android && typeof window.Android.addShortcut === 'function') { window.Android.addShortcut(c.title, link); closeSheet('home-sheet'); toast('Raccourci ajouté à l’écran d’accueil'); return; } } catch(e){}
    // 2) vraie fenêtre native d'installation du navigateur
    if (deferredInstall) {
      try {
        deferredInstall.prompt();
        const r = await deferredInstall.userChoice; deferredInstall = null;
        closeSheet('home-sheet');
        toast(r && r.outcome === 'accepted' ? 'Ajouté à l’écran d’accueil' : 'Ajout annulé');
        return;
      } catch(e){}
    }
    // 3) sinon : le navigateur doit le faire lui-même → guide + lien copié
    try { await navigator.clipboard.writeText(link); } catch(e){}
    const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
    $('home-steps').innerHTML = ios
      ? '1. Touche <b>Partager</b> dans Safari.<br>2. Choisis <b>Sur l’écran d’accueil</b>.<br>3. Valide avec <b>Ajouter</b>.'
      : '1. Ouvre le menu <b>⋮</b> de ton navigateur.<br>2. Choisis <b>Ajouter à l’écran d’accueil</b> (ou <b>Installer l’application</b>).<br>3. Valide avec <b>Ajouter</b>.';
    $('home-steps').style.display = 'block';
    $('home-preview').style.display = 'none';
    $('home-add').style.display = 'none';
    toast('Lien de la conversation copié', true);
  };

  /* — Ouverture directe d'une conversation depuis l'écran d'accueil — */
  function openFromHash(){
    const m = location.hash.match(/^#c=(.+)$/); if (!m) return;
    const id = decodeURIComponent(m[1]);
    const c = S.convs.find(x => x.id === id);
    if (c) { loadConv(id); setTitle(c.title); }
  }
  window.addEventListener('hashchange', openFromHash);
  setTimeout(openFromHash, 900);
})();
