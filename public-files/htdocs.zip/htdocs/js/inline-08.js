// ═══════ TERMINAL CLOUD 100% GITHUB ACTIONS (aucun backend externe) ═══════
// Principe : on déclenche un `repository_dispatch` sur le dépôt de travail de
// l'utilisateur (par défaut "MyBot", auto-créé comme saveOverflowToGitHub
// le fait déjà). Le workflow (auto-installé au premier appel s'il n'existe pas)
// exécute la commande dans un vrai Ubuntu, puis COMMIT le résultat en JSON dans
// le dépôt lui-même (nps-terminal-results/<id>.json) avec le GITHUB_TOKEN natif
// du workflow — aucun secret à configurer. On relit ensuite ce fichier via
// l'API Contents (déjà utilisée partout ailleurs, jamais bloquée par CORS),
// plutôt que de tenter de lire les logs du run (ceux-ci redirigent vers un
// domaine de stockage qui, lui, bloque bien les requêtes cross-origin).
const NPS_TERMINAL_WORKFLOW_PATH = '.github/workflows/nps-terminal.yml';
const NPS_TERMINAL_WORKFLOW_YML = `name: NPS Terminal
# nps-terminal-v6
run-name: NPS \${{ github.event.client_payload.request_id }}
on:
  repository_dispatch:
    types: [nps_exec]

permissions:
  contents: write

jobs:
  run:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Authentification GitHub
        run: |
          NPS_TOKEN=$(jq -r '.client_payload.token // empty' "$GITHUB_EVENT_PATH")
          if [ -n "$NPS_TOKEN" ]; then
            echo "::add-mask::$NPS_TOKEN"
            echo "GH_TOKEN=$NPS_TOKEN" >> "$GITHUB_ENV"
            git config --local --unset-all http.https://github.com/.extraheader || true
            git config --global url."https://x-access-token:$NPS_TOKEN@github.com/".insteadOf "https://github.com/"
          fi

      - name: Exécuter la commande
        id: run_cmd
        continue-on-error: true
        env:
          NPS_COMMAND: \${{ github.event.client_payload.command }}
        run: |
          set +e
          echo "$NPS_COMMAND" > /tmp/nps_cmd.sh
          bash /tmp/nps_cmd.sh > /tmp/nps_output.txt 2>&1
          echo "exit_code=$?" >> "$GITHUB_OUTPUT"
          exit 0

      - name: Écrire le résultat
        env:
          REQ_ID: \${{ github.event.client_payload.request_id }}
          EXIT_CODE: \${{ steps.run_cmd.outputs.exit_code }}
        run: |
          mkdir -p nps-terminal-results
          cat > /tmp/nps_write.js <<'NPSJS'
          const fs = require('fs');
          const cp = require('child_process');
          const NUL = String.fromCharCode(0);
          let output = '';
          try { output = fs.readFileSync('/tmp/nps_output.txt', 'utf8').slice(0, 50000); } catch (e) {}
          const createdFiles = [];
          try {
            const listing = cp.execSync('git -c core.quotepath=false ls-files -m -o --exclude-standard -z', { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
            for (const p of listing.split(NUL)) {
              if (!p) continue;
              const name = p.split('/').pop().toLowerCase();
              if (name === 'readme.md' || name.startsWith('.git') || p.startsWith('nps-terminal-results') || p.startsWith('node_modules/') || name.endsWith('.part') || name.endsWith('.ytdl') || name.endsWith('.tmp')) continue;
              try {
                const st = fs.statSync(p);
                if (st.isFile() && st.size > 0) createdFiles.push(p);
              } catch (e) {}
            }
          } catch (e) {}
          const code = process.env.EXIT_CODE === undefined || process.env.EXIT_CODE === '' ? 1 : Number(process.env.EXIT_CODE);
          const data = { success: code === 0, exit_code: code, output: output, createdFiles: createdFiles };
          fs.writeFileSync('nps-terminal-results/' + process.env.REQ_ID + '.json', JSON.stringify(data));
          NPSJS
          node /tmp/nps_write.js

      - name: Commit et push le résultat
        run: |
          git config user.name "NPS Terminal Bot"
          git config user.email "nps-bot@users.noreply.github.com"
          git add -A
          git commit -m "Exécution terminal NPS et fichiers: \${{ github.event.client_payload.request_id }}" || echo "Rien à committer"
          for i in 1 2 3 4 5; do
            git pull --rebase && git push && exit 0
            sleep $((i * 3))
          done
          exit 1
`;

async function ensureNpsWorkflow(owner, repo, headers) {
  const repoCheck = await fetch(`https://api.github.com/repos/${owner}/${repo}`, { headers });
  let justCreatedRepo = false;
  if (repoCheck.status === 404) {
    await fetch('https://api.github.com/user/repos', {
      method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: repo, private: false, description: "Espace de travail de l'agent Fable Fast", auto_init: true })
    });
    justCreatedRepo = true;
    await sleep(1500);
  }
  const wfUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${NPS_TERMINAL_WORKFLOW_PATH}`;
  const wfCheck = await fetch(wfUrl, { headers });
  if (wfCheck.status === 404) {
    const putRes = await fetch(wfUrl, {
      method: 'PUT', headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: "Installation du terminal cloud Fable Fast (GitHub Actions)", content: utob(NPS_TERMINAL_WORKFLOW_YML) })
    });
    if (!putRes.ok) throw new Error("Impossible d'installer le workflow du terminal (" + putRes.status + ")");
    // GitHub met quelques secondes à enregistrer un tout nouveau workflow avant
    // d'accepter des repository_dispatch dessus.
    await sleep(justCreatedRepo ? 4000 : 6000);
    return true; // vient d'être installé, à signaler à l'utilisateur
  } else if (wfCheck.ok) {
    try {
      const wfData = await wfCheck.json();
      const currentYml = btou((wfData.content||'').replace(/\s/g, ''));
      if (!currentYml.includes('# nps-terminal-v6')) {
        await fetch(wfUrl, {
          method: 'PUT', headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: "Mise à jour du terminal cloud Fable Fast (authentification GitHub dans le runner)", content: utob(NPS_TERMINAL_WORKFLOW_YML), sha: wfData.sha })
        });
      }
    } catch(e) {}
  }
  return false;
}

async function npsFindRun(owner, repo, headers, requestId, startedAt){
  try {
    const r = await fetch(`https://api.github.com/repos/${owner}/${repo}/actions/runs?event=repository_dispatch&per_page=20`, { headers, cache: 'no-store' });
    if (!r.ok) return null;
    const runs = (await r.json()).workflow_runs || [];
    return runs.find(x => (x.display_title || '') === 'Fable Fast ' + requestId)
      || runs.find(x => new Date(x.created_at).getTime() >= startedAt - 15000 && !String(x.display_title || '').startsWith('Fable Fast req-'))
      || null;
  } catch (e) { return null; }
}

async function npsDescribeRunFailure(owner, repo, headers, run){
  let step = '';
  const notes = [];
  try {
    const jr = await fetch(`https://api.github.com/repos/${owner}/${repo}/actions/runs/${run.id}/jobs`, { headers, cache: 'no-store' });
    if (jr.ok) {
      for (const j of ((await jr.json()).jobs || [])) {
        const bad = (j.steps || []).find(st => st.conclusion === 'failure');
        if (bad && !step) step = bad.name;
        try {
          const ar = await fetch(`https://api.github.com/repos/${owner}/${repo}/check-runs/${j.id}/annotations`, { headers, cache: 'no-store' });
          if (ar.ok) for (const an of (await ar.json())) { if (an.message && notes.length < 4) notes.push(String(an.message).slice(0, 300)); }
        } catch (e) {}
      }
    }
  } catch (e) {}
  return `Le workflow GitHub Actions s'est arrêté avec une erreur (statut: completed, conclusion: ${run.conclusion}, run ID: ${run.id}${step ? ', étape en échec : « ' + step + ' »' : ''}).` + (notes.length ? ' Détails GitHub : ' + notes.join(' | ') : '');
}

async function npsFindRunFailure(owner, repo, headers, requestId, startedAt){
  const mine = await npsFindRun(owner, repo, headers, requestId, startedAt);
  if (!mine || mine.status !== 'completed') return null;
  if (!['failure', 'timed_out', 'cancelled', 'startup_failure'].includes(mine.conclusion)) return null;
  return await npsDescribeRunFailure(owner, repo, headers, mine);
}

async function runCloudTerminal(command, owner, repo, onProgress) {
  const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' };
  const requestId = 'req-' + uid();

  const justInstalled = await ensureNpsWorkflow(owner, repo, headers);
  if (typeof onProgress === 'function') {
    onProgress({ text: justInstalled ? "Premier lancement : installation du terminal cloud sur le dépôt…" : "Déclenchement du workflow GitHub Actions…", live: true, elapsed: 0 });
  }

  const dispatchRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/dispatches`, {
    method: 'POST',
    headers: { ...headers, 'Content-Type': 'application/json' },
    body: JSON.stringify({ event_type: 'nps_exec', client_payload: { command, request_id: requestId, token: S.tok } })
  });
  if (!dispatchRes.ok) {
    throw new Error(`Impossible de déclencher le workflow (${dispatchRes.status}). Vérifie que le token GitHub a la permission "workflow".`);
  }

  const resultUrl = `https://api.github.com/repos/${owner}/${repo}/contents/nps-terminal-results/${requestId}.json`;
  const jobKey = 'nps_pending_job_' + requestId;
  safeSetItem(jobKey, JSON.stringify({ requestId, owner, repo, command: command.slice(0,200), convId: S.currentConv, startedAt: Date.now() }));
  // Aucune échéance fixe imposée par l'interface : on suit le run GitHub jusqu'à
  // un état terminal. Seules les limites propres à GitHub s'appliquent
  // (6 h max par job). Garde-fou ultime légèrement au-dessus de cette limite.
  const start = Date.now();
  const hardCeilingMs = 6 * 3600 * 1000 + 10 * 60 * 1000;
  const noRunGraceMs = 120000;      // aucun run créé par le dispatch au bout de 2 min
  const postSuccessGraceMs = 60000; // run réussi mais fichier résultat pas encore lisible
  let lastRunCheck = 0, runStatus = '', runSeen = false, completedAt = 0;
  while (Date.now() - start < hardCeilingMs) {
    if (S.cancelRequested) { localStorage.removeItem(jobKey); throw new Error('NPS_CANCELLED'); }
    const elapsed = Math.round((Date.now() - start) / 1000);
    if (typeof onProgress === 'function') {
      const label = !runSeen ? 'Démarrage du terminal cloud…'
        : runStatus === 'queued' ? 'En file d\'attente GitHub Actions…'
        : 'Exécution du terminal cloud en cours…';
      onProgress({ text: label, live: true, elapsed });
    }
    await sleep(3000);
    const checkRes = await fetch(resultUrl, { headers, cache: 'no-store' });
    if (checkRes.ok) {
      const fileData = await checkRes.json();
      let parsed;
      try { parsed = JSON.parse(btou(fileData.content.replace(/\s/g, ''))); }
      catch (e) { localStorage.removeItem(jobKey); throw new Error("Résultat du terminal illisible (JSON corrompu)"); }
      localStorage.removeItem(jobKey);
      if (typeof onProgress === 'function') onProgress({ text: parsed.success ? 'Exécution terminée.' : 'Exécution terminée avec erreur.', live: false, elapsed, done: true, error: !parsed.success });
      if (Array.isArray(parsed.createdFiles) && parsed.createdFiles.length) {
        S._pendingSync = S._pendingSync || [];
        for (const f of parsed.createdFiles) {
          if (!S._pendingSync.some(p => p.repo === repo && p.path === f)) {
            S._pendingSync.push({ repo, path: f });
          }
        }
      }
      return parsed;
    }
    // Suivi du run de CETTE requête (statut réel côté GitHub)
    if (elapsed > 6 && Date.now() - lastRunCheck > 8000) {
      lastRunCheck = Date.now();
      const run = await npsFindRun(owner, repo, headers, requestId, start);
      if (run) {
        runSeen = true;
        runStatus = run.status;
        if (run.status === 'completed') {
          if (['failure', 'timed_out', 'cancelled', 'startup_failure'].includes(run.conclusion)) {
            const msg = await npsDescribeRunFailure(owner, repo, headers, run);
            localStorage.removeItem(jobKey);
            throw new Error(msg);
          }
          if (!completedAt) completedAt = Date.now();
          if (Date.now() - completedAt > postSuccessGraceMs) {
            localStorage.removeItem(jobKey);
            throw new Error(`Le run GitHub Actions s'est terminé (conclusion: ${run.conclusion}, run ID: ${run.id}) mais aucun fichier résultat n'a été lu dans nps-terminal-results/. Le push du résultat a probablement échoué (branche protégée ou droits d'écriture).`);
          }
        }
      } else if (Date.now() - start > noRunGraceMs) {
        localStorage.removeItem(jobKey);
        throw new Error(`Aucun run GitHub Actions n'a démarré après le déclenchement (repository_dispatch). Vérifie que le workflow .github/workflows/nps-terminal.yml est sur la branche par défaut du dépôt et que GitHub Actions est activé.`);
      }
    }
  }
  localStorage.removeItem(jobKey);
  const limitErr = new Error(`Limite GitHub atteinte (6 h) : le job n'a pas rendu de résultat.`);
  limitErr.isTimeout = true;
  throw limitErr;
}

function diagnoseTerminalError(code, exitCode, output = '') {
  const lower = (output || '').toLowerCase();
  
  if (exitCode === 127 || lower.includes('command not found') || lower.includes('commande introuvable')) {
    const missingMatch = output.match(/([a-zA-Z0-9_\-]+):\s*(?:command not found|commande introuvable)/i);
    const missingCmd = missingMatch ? missingMatch[1] : 'commande inconnue';
    return `[DIAGNOSTIC AUTOMATIQUE : COMMANDE INTROUVABLE (Code 127)]\nLa commande "${missingCmd}" n'est pas installée sur le runner cloud.\n→ Action requise : Installe-la (ex: pip install -q ${missingCmd} ou sudo apt-get update && sudo apt-get install -y ${missingCmd}). Interdiction de relancer la même commande sans l'installer d'abord !`;
  }
  
  if (lower.includes('403: forbidden') || lower.includes('http error 403') || lower.includes('sign in to confirm') || lower.includes('bot detection') || lower.includes('cloudflare')) {
    return `[DIAGNOSTIC AUTOMATIQUE : BLOCAGE HTTP 403 / ANTI-ROBOT]\nLa plateforme cible bloque l'accès direct (HTTP 403 / détection de bot).\n→ Action requise : Répéter la même commande échouera systématiquement ! Utilise des en-têtes (User-Agent), cookies, Playwright, ou explique directement ce blocage à l'utilisateur sans tourner en rond.`;
  }
  
  if (lower.includes('404: not found') || lower.includes('http error 404')) {
    return `[DIAGNOSTIC AUTOMATIQUE : RESSOURCE INTROUVABLE (HTTP 404)]\nL'URL ou le fichier demandé n'existe pas.\n→ Action requise : Ne réessaie pas la même URL erronée. Vérifie l'adresse ou informe l'utilisateur.`;
  }
  
  if (lower.includes('modulenotfounderror') || lower.includes('no module named')) {
    const modMatch = output.match(/No module named ['"]([^'"]+)['"]/i);
    const mod = modMatch ? modMatch[1] : 'module';
    const _pipMap = { PIL:'Pillow', cv2:'opencv-python-headless', yaml:'pyyaml', sklearn:'scikit-learn', bs4:'beautifulsoup4', skimage:'scikit-image', docx:'python-docx', dotenv:'python-dotenv', Crypto:'pycryptodome', dateutil:'python-dateutil', fitz:'pymupdf', magic:'python-magic', OpenSSL:'pyOpenSSL', serial:'pyserial' };
    const pipName = _pipMap[String(mod).split('.')[0]] || String(mod).split('.')[0];
    return `[DIAGNOSTIC AUTOMATIQUE : MODULE PYTHON MANQUANT]\nLe module Python "${mod}" n'est pas installé (paquet pip : ${pipName}).\n→ Action requise : chaque commande tourne sur un runner NEUF, rien ne persiste d'une commande à l'autre. Mets l'installation ET le script dans la MÊME commande : pip install -q ${pipName} && python3 ton_script.py`;
  }

  if (lower.includes('authentication failed') || lower.includes('could not read username') || lower.includes('invalid username or password') || lower.includes('terminal prompts disabled') || (lower.includes('remote:') && lower.includes('denied'))) {
    return `[DIAGNOSTIC AUTOMATIQUE : AUTHENTIFICATION GIT REFUSÉE]\nLe dépôt distant a refusé l'authentification. Le runner reçoit le token GitHub de l'utilisateur (variable GH_TOKEN, git déjà configuré pour https://github.com/…).\n→ Action requise : vérifie que l'URL est bien de la forme https://github.com/<compte>/<dépôt>.git, que le dépôt existe et appartient au compte du token. Ne relance jamais la même commande à l'identique ; si le blocage persiste, explique-le tel quel à l'utilisateur.`;
  }

  if (lower.includes('permission denied') || lower.includes('permission non accordée')) {
    return `[DIAGNOSTIC AUTOMATIQUE : PERMISSION REFUSÉE]\nDroits d'accès insuffisants sur le fichier ou répertoire.\n→ Action requise : Vérifie les permissions (chmod +x) ou utilise un chemin accessible.`;
  }

  if (lower.includes('no space left on device')) {
    return `[DIAGNOSTIC AUTOMATIQUE : ESPACE DISQUE INSUFFISANT]\nLe disque du runner est plein.`;
  }

  if (lower.includes('video unavailable') || lower.includes('private video') || lower.includes('this video is not available')) {
    return `[DIAGNOSTIC AUTOMATIQUE : VIDÉO INDISPONIBLE OU PRIVÉE]\nLa vidéo demandée est privée, supprimée ou géo-restreinte.\n→ Action requise : Inutile d'insister ou de tourner en rond, aucun outil ne peut la forcer. Explique la situation avec honnêteté à l'utilisateur.`;
  }

  if (/ffmpeg|ffprobe/i.test(output) && /not found|not installed|requires|introuvable/i.test(output)) {
    return `[DIAGNOSTIC AUTOMATIQUE : FFMPEG MANQUANT]\nLa conversion audio/vidéo a besoin de ffmpeg, absent du runner.\n→ Action requise : mets dans la MÊME commande : sudo apt-get install -y -qq ffmpeg && <ta commande>.`;
  }
  if (lower.includes('429') && (lower.includes('too many requests') || lower.includes('http error 429'))) {
    return `[DIAGNOSTIC AUTOMATIQUE : TROP DE REQUÊTES (HTTP 429)]\nLe site limite le nombre de requêtes.\n→ Action requise : n'insiste pas tout de suite : change de source ou de méthode, ou explique la limite à l'utilisateur.`;
  }
  // Cause réelle : on remonte les lignes d'erreur significatives de la sortie, jamais un message générique.
  const _errLines = String(output || '').split('\n').map(l => l.trim()).filter(l => /error|erreur|traceback|exception|failed|fatal|not found|no such|denied|refused|unable|cannot|can't|invalid|unavailable|\bHTTP \d{3}\b/i.test(l)).slice(-5);
  const _cause = (_errLines.length ? _errLines : String(output || '').trim().split('\n').filter(Boolean).slice(-4)).join('\n').slice(0, 700);
  return `[DIAGNOSTIC AUTOMATIQUE : ÉCHEC DU SCRIPT (Code ${exitCode})]\nCause relevée dans la sortie :\n${_cause || '(aucune sortie)'}\n→ Action requise : explique cette cause précise à l'utilisateur et applique la correction adaptée (installer l'outil manquant, changer d'URL ou de méthode). Ne relance jamais la même commande à l'identique.`;
}


/**
 * Ne perd JAMAIS de contenu : si un fichier collé/importé dépasse la limite
 * envoyée au modèle, l'excédent est sauvegardé intégralement dans l'espace
 * de travail GitHub plutôt que d'être supprimé. Le modèle peut ensuite aller
 * le relire par sections (api_call) s'il en a besoin.
 */
async function truncateToSafeLimit(text, filename = 'fichier.txt', limit = 12000) {
  if (!text) return '';
  if (text.length <= limit) return text;
  const head = text.substring(0, limit);
  if (S.tok) {
    try {
      const fullPath = await saveOverflowToGitHub(filename, text);
      return head + `\n\n[... Ce fichier fait ${text.length} caractères, trop long pour tenir ici en entier. RIEN N'A ÉTÉ PERDU : le contenu COMPLET a été sauvegardé dans le dépôt GitHub à "${fullPath}". Si tu as besoin de la suite, lis ce fichier via l'API GitHub Contents. ...]`;
    } catch (e) {
      toast('Sauvegarde GitHub du fichier complet a échoué : ' + e.message, true);
      return head + `\n\n[... Fichier de ${text.length} caractères coupé ici : la sauvegarde automatique dans l'espace GitHub a échoué (${e.message}). ...]`;
    }
  }
  return head + `\n\n[... Fichier de ${text.length} caractères coupé ici : configure un token GitHub dans "Modèle & Clés API" pour que Fable Fast sauvegarde automatiquement le contenu complet au lieu de le tronquer. ...]`;
}

function renderStep(step) {
  // Conservé pour compat (plus utilisé par le rendu principal, voir renderStepMeta).
  const isLoading = step.status === 'loading';
  const isError = step.status === 'error';
  const color = isError ? '#ff8a8a' : (isLoading ? 'var(--text)' : 'var(--text2)');
  const opacity = isLoading ? '1' : '0.85';
  return `<span style="color:${color}; opacity:${opacity}; font-style:italic;">${esc(step.summary)}</span> `;
}
