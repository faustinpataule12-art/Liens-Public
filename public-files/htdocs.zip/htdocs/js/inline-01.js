window.FF_LOGO="https://raw.githubusercontent.com/nps-nelson/Fable-fast-icon/main/icone-512.png";
