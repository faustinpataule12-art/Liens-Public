/* ================= MENU (icône en haut à gauche) ================= */
(function(){
var host=document.createElement('div');host.id='ffmenu';document.body.appendChild(host);
function ic(p){return '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>';}
var P={
 new:'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
 cal:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
 diag:'<path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/>',
 proj:'<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
 key:'<circle cx="8" cy="15" r="4"/><path d="M10.800 12.200L20 3M16 7l3 3"/>',
 lib:'<rect x="3" y="3" width="7" height="7" rx="1.500"/><rect x="14" y="3" width="7" height="7" rx="1.500"/><rect x="3" y="14" width="7" height="7" rx="1.500"/><rect x="14" y="14" width="7" height="7" rx="1.500"/>',
 store:'<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.700 3.600 3 8 3s8-1.300 8-3V5M4 11v6c0 1.700 3.600 3 8 3s8-1.300 8-3v-6"/>',
 pin:'<path d="M12 21s7-6.200 7-11.500A7 7 0 0 0 5 9.500C5 14.800 12 21 12 21z"/><circle cx="12" cy="9.500" r="2.500"/>',
 mail:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3.500 7l8.500 6 8.500-6"/>',
 bot:'<path d="M21 12a8 8 0 0 1-11.600 7.100L4 20l1-4.600A8 8 0 1 1 21 12z"/><path d="M9 11h.01M12 11h.01M15 11h.01"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M19.400 15a1.700 1.700 0 0 0 .3 1.800l.1.100a2 2 0 1 1-2.800 2.800l-.1-.1a1.700 1.700 0 0 0-1.800-.3 1.700 1.700 0 0 0-1 1.500V21a2 2 0 1 1-4 0v-.1a1.700 1.700 0 0 0-1.100-1.500 1.700 1.700 0 0 0-1.800.3l-.1.1a2 2 0 1 1-2.800-2.800l.1-.1a1.700 1.700 0 0 0 .3-1.800 1.700 1.700 0 0 0-1.500-1H3a2 2 0 1 1 0-4h.1a1.700 1.700 0 0 0 1.500-1.100 1.700 1.700 0 0 0-.3-1.800l-.1-.1a2 2 0 1 1 2.800-2.800l.1.1a1.700 1.700 0 0 0 1.800.3H9a1.700 1.700 0 0 0 1-1.500V3a2 2 0 1 1 4 0v.1a1.700 1.700 0 0 0 1 1.500 1.700 1.700 0 0 0 1.800-.3l.1-.1a2 2 0 1 1 2.800 2.800l-.1.1a1.700 1.700 0 0 0-.3 1.800V9a1.700 1.700 0 0 0 1.500 1H21a2 2 0 1 1 0 4h-.1a1.700 1.700 0 0 0-1.500 1z"/>',
 x:'<path d="M18 6L6 18M6 6l12 12"/>'};
var SEC=[
 {t:'',i:[['new','Nouvelle conversation',"ffHome()"]]},
 {t:'Mon espace',i:[['cal','Notifications & programme',"openNotifCenter('plans')"],['diag','Diagnostic & Monétisation',"openNotifCenter('ai')"],['bot','Flux agent',"agOpen()"]]},
 {t:'Compte',i:[['user','Profil',"showView('profile')"],['key','Modèle & Clés API',"showView('apikeys')"]]},
 {t:'Données',i:[['lib','Bibliothèque',"ffLibOpen()"],['store','Stockage',"ffStoreOpen()"],['pin','Position',"ffGeoOpen()"]]},
 {t:'Aide',i:[['mail','Nous contacter',"ffContactOpen()"]]}];
var h='<style>'+
'#ffmenu{position:fixed;inset:0;z-index:940;display:none}#ffmenu.on{display:block}'+
'#ffmenu .mv{position:absolute;inset:0;background:rgba(0,0,0,.55);opacity:0;transition:opacity .25s;backdrop-filter:blur(2px)}'+
'#ffmenu .mp{position:absolute;top:0;bottom:0;right:0;width:min(86vw,340px);background:var(--bg);border-left:1px solid var(--border);display:flex;flex-direction:column;transform:translateX(100%);transition:transform .28s cubic-bezier(.4,0,.2,1);padding-top:env(safe-area-inset-top)}'+
'#ffmenu.go .mv{opacity:1}#ffmenu.go .mp{transform:none}'+
'#ffmenu .mh{display:flex;align-items:center;gap:12px;padding:16px 14px 14px 18px}#ffmenu .mh img{width:44px;height:44px;border-radius:13px}#ffmenu .mh b{flex:1;font-size:19px;font-weight:800;color:var(--text)}'+
'#ffmenu .mx{width:40px;height:40px;border-radius:12px;border:0;background:none;color:var(--text2);display:grid;place-items:center;cursor:pointer}'+
'#ffmenu .ms{flex:1;overflow-y:auto;padding:0 10px 10px}'+
'#ffmenu .mt{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--text2);font-weight:700;margin:16px 10px 6px}'+
'#ffmenu .mi{display:flex;align-items:center;gap:14px;width:100%;padding:12px 10px;border:0;border-radius:14px;background:none;color:var(--text);font:inherit;font-size:16px;text-align:left;cursor:pointer;-webkit-tap-highlight-color:transparent}#ffmenu .mi:active{background:var(--bg3)}#ffmenu .mi svg{color:#b9a3f5;flex:none}'+
'#ffmenu .mf{border-top:1px solid var(--border);padding:8px 10px calc(10px + env(safe-area-inset-bottom))}#ffmenu .mc{text-align:center;font-size:12px;color:var(--text3,#8a8fa3);padding:6px 0 0}'+
'</style><div class="mv" id="mn-v"></div><div class="mp"><div class="mh"><img src="'+(window.FF_LOGO||'')+'" alt=""><b>Fable Fast</b><button class="mx" id="mn-x" aria-label="Fermer">'+ic(P.x)+'</button></div><div class="ms">'+
 SEC.map(function(s){return (s.t?'<div class="mt">'+s.t+'</div>':'')+s.i.map(function(i){return '<button class="mi" data-a="'+i[2].replace(/"/g,'&quot;')+'">'+ic(P[i[0]])+'<span>'+i[1].replace(/&/g,'&amp;')+'</span></button>';}).join('');}).join('')+
 '</div><div class="mf"><button class="mi" data-a="showView(\'settings\')">'+ic(P.gear)+'<span>Paramètres</span></button><div class="mc">© 2026 Fable Fast. Tous droits réservés.</div></div></div>';
host.innerHTML=h;
var depth=0;
function show(){host.classList.add('on');requestAnimationFrame(function(){requestAnimationFrame(function(){host.classList.add('go');});});}
function hide(fast){host.classList.remove('go');setTimeout(function(){host.classList.remove('on');},fast?0:280);}
function close(){hide();if(depth>0){var d=depth;depth=0;try{window.NAV&&(NAV.ignorePop=true);}catch(e){}try{history.go(-d);}catch(e){}}}
window.addEventListener('popstate',function(){if(!host.classList.contains('on'))return;depth=Math.max(0,depth-1);hide();});
window.ffMenuOpen=function(){
  if(host.classList.contains('on')){close();return;}
  try{history.pushState({mn:1},'');depth++;}catch(e){}
  show();
};
host.querySelector('#mn-v').onclick=close;host.querySelector('#mn-x').onclick=close;
host.querySelectorAll('[data-a]').forEach(function(b){b.onclick=function(){var a=b.getAttribute('data-a');close();var w=0;try{var f=document.getElementById('ff-flow');if(f&&f.classList.contains('on')&&window.ffFlowClose){window.ffFlowClose(false);w=350;}}catch(e){}try{if(window.agIsOpen&&window.agIsOpen()&&a.indexOf('agOpen')<0){var ah=document.getElementById('ag-host');ah.style.display='none';}}catch(e){}setTimeout(function(){try{(new Function(a))();}catch(e){console.warn(e);}},320+w);};});
})();
