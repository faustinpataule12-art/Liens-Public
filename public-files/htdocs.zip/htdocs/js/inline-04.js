// ═══════ HISTORIQUE DE CONVERSATION → GITHUB (dépôt Maker) ═══════
// Le localStorage reste utilisé comme cache rapide (lecture instantanée), mais
// GitHub devient la source durable : ça élimine complètement le plafond de
// 5-10 Mo du navigateur, quelle que soit la façon dont l'app est ouverte
// (fichier local ou en ligne). Écriture "debounce" (3s) pour ne pas déclencher
// un commit GitHub à chaque message.
/**
 * Upload une pièce jointe (image, audio, fichier) en tant que VRAI fichier
 * binaire dans le dépôt privé "Maker", pour qu'elle survive à un
 * rafraîchissement de page et à un changement d'appareil — jamais gardée
 * seulement dans le navigateur. Retourne l'URL brute permanente du fichier
 * (download_url), ou null si l'upload échoue (pas de token, hors-ligne...).
 */

const NPS_MODE_DIR={download:'telechargement',profile:'profil',ideas:'idees',analyze:'video',compare:'comparaison',stats:'statistiques'};
const NPS_MODES=Object.keys(NPS_MODE_DIR);
const _npsModeMemo={};
function npsConvMode(id){const c=S.convs.find(x=>x.id===id);if(c&&c.mode){_npsModeMemo[id]=c.mode;return c.mode;}return _npsModeMemo[id]||window.ffMode||'download';}
function npsP(mode,path){const d=NPS_MODE_DIR[mode];return d?d+'/'+path:path;}
function npsMD(){const d=NPS_MODE_DIR[window.ffMode];return d?d+'/':'';}
const NPS_MODE_TOOLS={
  download:['terminal_exec','export_file','build_logs','web_fetch','web_search','api_call','search_conversations'],
  profile:['terminal_exec','web_fetch','web_search','api_call','extract_site','search_conversations'],
  ideas:['web_search','web_fetch','search_conversations'],
  analyze:['terminal_exec','web_fetch','web_search','api_call','transcribe_audio','search_conversations','export_file'],
  compare:['terminal_exec','web_fetch','web_search','api_call','extract_site','search_conversations'],
  stats:['terminal_exec','web_fetch','web_search','api_call','extract_site','search_conversations']
};
const NPS_MODE_NAME={download:'Télécharger une vidéo',profile:'Analyser un profil',ideas:'Idées créatives',analyze:'Analyser une vidéo',compare:'Comparer un profil',stats:'Statistiques du compte'};
function npsModeGate(td){
  const m=window.ffMode; if(!m||!td) return null;
  const a=td.action, code=String((td.params&&td.params.code)||'');
  const no=why=>`⛔ MODE « ${NPS_MODE_NAME[m]} » : ${why} Cette action appartient à un autre mode. Ne la contourne pas : explique en une phrase à l'utilisateur qu'il doit revenir à l'accueil et choisir le bon mode.`;
  if(!NPS_MODE_TOOLS[m].includes(a)) return no(`l'outil « ${a} » n'est pas autorisé dans ce mode.`);
  if(a==='terminal_exec'){
    const dl=/\b(wget|aria2c)\b|\bcurl\b[^\n|;&]*\s(-o|-O|--output)\b/i.test(code)||(/\byt-dlp\b|youtube-dl/i.test(code)&&!/--(skip-download|flat-playlist|dump-json|dump-single-json|simulate)|\s-J\b|--print\b/.test(code));
    if((m==='profile'||m==='compare'||m==='stats')&&(dl||/\bffmpeg\b/.test(code))) return no('le téléchargement de médias est interdit ici (analyse seulement : métadonnées avec --skip-download / --flat-playlist / --dump-json).');
    if(m==='analyze'&&/\bexports?\//.test(code)) return no('aucun fichier ne doit être écrit dans exports (travaille dans un dossier temporaire, le fichier ne sert qu\'à extraire les captures).');
  }
  return null;
}
function npsWithDeps(code){
  code=String(code||''); let pre='';
  if(/\byt-dlp\b/.test(code)){
    pre+='(command -v yt-dlp >/dev/null 2>&1 && python3 -c "import curl_cffi" >/dev/null 2>&1) || pip install -q -U "yt-dlp[default,curl-cffi]" >/dev/null 2>&1 || pip install -q -U yt-dlp >/dev/null 2>&1\n';
    if(/tiktok\.com/i.test(code)&&!/--impersonate/.test(code)) code=code.replace(/(^|&&|;|\|\||\n|\()(\s*)yt-dlp\b/g,'$1$2yt-dlp --impersonate chrome');
  }
  if(/\b(ffmpeg|ffprobe)\b/.test(code)) pre+='command -v ffmpeg >/dev/null 2>&1 || (sudo apt-get update -qq >/dev/null 2>&1; sudo apt-get install -y -qq ffmpeg >/dev/null 2>&1)\n';
  return pre+code;
}
async function ensureNpsDualRepos() {
  if (!S.tok) return;
  try {
    const owner = await getGhLogin();
    if (!owner) return;
    const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json', 'Content-Type': 'application/json' };

    // 1. Dépôt 1 : MyBot (terminal cloud runner)
    const wsUrl = 'https://api.github.com/repos/' + owner + '/MyBot';
    const wsCheck = await fetch(wsUrl, { headers });
    if (wsCheck.status === 404) {
      await fetch('https://api.github.com/user/repos', {
        method: 'POST', headers,
        body: JSON.stringify({
          name: 'MyBot',
          private: true,
          description: "Espace de travail et terminal cloud autonome de l'agent Fable Fast",
          auto_init: true
        })
      });
      await sleep(1500);
      await ensureNpsWorkflow(owner, 'MyBot', headers);
    } else if (wsCheck.ok) {
      ensureNpsWorkflow(owner, 'MyBot', headers).catch(e => console.warn(e));
    }

    // 2. Dépôt 2 : Maker (mémoire, conversations, uploads, exports)
    const memUrl = 'https://api.github.com/repos/' + owner + '/Maker';
    const memCheck = await fetch(memUrl, { headers });
    if (memCheck.status === 404) {
      await fetch('https://api.github.com/user/repos', {
        method: 'POST', headers,
        body: JSON.stringify({
          name: 'Maker',
          private: true,
          description: "Mémoire persistante, conversations, uploads et exports de l'agent Fable Fast",
          auto_init: true
        })
      });
      await sleep(1500);
    }

    // Arborescence requise dans Maker :
    // - historique/ : historique de chat
    // - envoyes/ : fichiers uploadés par l'utilisateur
    // - exports/ : fichiers générés et exportés depuis le terminal ou l'agent
    const requiredDirs = NPS_MODES.flatMap(m => ['historique','exports','envoyes'].map(d => ({ path: NPS_MODE_DIR[m] + '/' + d + '/.gitkeep', msg: 'Initialisation ' + NPS_MODE_DIR[m] + '/' + d })));

    for (const d of requiredDirs) {
      try {
        const check = await fetch('https://api.github.com/repos/' + owner + '/Maker/contents/' + d.path, { headers });
        if (check.status === 404) {
          await fetch('https://api.github.com/repos/' + owner + '/Maker/contents/' + d.path, {
            method: 'PUT', headers,
            body: JSON.stringify({
              message: d.msg,
              content: btoa("# Dossier initialisé pour Fable Fast\n")
            })
          });
        }
      } catch(e) {}
    }
  } catch(e) {
    console.warn("ensureNpsDualRepos error:", e.message);
  }
}

async function uploadAttachmentToGitHub(att) {
  if (!S.tok || !att.dataUrl) return null;
  try {
    const owner = await getGhLogin();
    if (!owner) return null;
    const repoName = 'Maker';
    const headers = { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json', 'Content-Type': 'application/json' };
    const b64 = att.dataUrl.split(',')[1] || '';
    if (!b64) return null;
    const safeName = (att.name || 'fichier').replace(/[^\w.\-]+/g, '_').slice(0, 80);
    const path = `${npsMD()}envoyes/${att.id}-${safeName}`;
    const fileUrl = `https://api.github.com/repos/${owner}/${repoName}/contents/${path}`;
    const res = await fetch(fileUrl, {
      method: 'PUT', headers,
      body: JSON.stringify({ message: `Pièce jointe : ${att.name}`, content: b64 })
    });
    if (res.status === 422) { att.ghRepo = repoName; att.ghPath = path; return null; } // déjà présent sur GitHub
    if (!res.ok) { console.warn('Upload pièce jointe échoué:', res.status); return null; }
    const data = await res.json();
    att.ghRepo = repoName; att.ghPath = path;
    return data.content?.download_url || null;
  } catch (e) {
    console.warn('uploadAttachmentToGitHub error:', e.message);
    return null;
  }
}

// Upload en arrière-plan chaque pièce jointe d'un message tout juste envoyé,
// puis met à jour le message (githubUrl permanent) et resauvegarde — pour
// qu'aucune image/fichier ne reste "seulement dans le navigateur". Si
// l'upload échoue (pas de token GitHub configuré, hors-ligne), l'app
// continue de fonctionner normalement avec juste l'aperçu en mémoire vive,
// perdu au prochain rafraîchissement — c'est la seule limite qui reste.
// ── File d'attente locale (IndexedDB) : si l'app est fermée avant la fin de l'envoi,
// la pièce jointe reste en attente et part au prochain lancement. ──
function npsQOpen(){ return new Promise((res,rej)=>{ const r=indexedDB.open('nps-att-queue',1); r.onupgradeneeded=()=>r.result.createObjectStore('q',{keyPath:'id'}); r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error); }); }
async function npsQPut(att){ try{ const db=await npsQOpen(); await new Promise((res,rej)=>{ const tx=db.transaction('q','readwrite'); tx.objectStore('q').put({id:att.id,name:att.name,type:att.type,dataUrl:att.dataUrl}); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }catch(e){} }
async function npsQDel(id){ try{ const db=await npsQOpen(); await new Promise((res,rej)=>{ const tx=db.transaction('q','readwrite'); tx.objectStore('q').delete(id); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }catch(e){} }
async function npsQAll(){ try{ const db=await npsQOpen(); return await new Promise((res,rej)=>{ const r=db.transaction('q','readonly').objectStore('q').getAll(); r.onsuccess=()=>res(r.result||[]); r.onerror=()=>rej(r.error); }); }catch(e){ return []; } }
const _attInFlight = new Set();
async function npsDrainAttQueue(){
  if (!S.tok || npsDrainAttQueue._run) return;
  npsDrainAttQueue._run = true;
  try {
    for (const it of await npsQAll()) {
      if (_attInFlight.has(it.id)) continue;
      const att = { ...it };
      await uploadAttachmentToGitHub(att);
      if (att.ghPath) await npsQDel(it.id);
    }
  } finally { npsDrainAttQueue._run = false; }
}
setTimeout(npsDrainAttQueue, 4000);
setInterval(npsDrainAttQueue, 30000);
window.addEventListener('online', npsDrainAttQueue);

async function persistAttachmentsToGitHub(msg) {
  if (!msg.attachments?.length) return;
  for (const att of msg.attachments) { if (att.dataUrl && !att.ghPath) await npsQPut(att); }
  if (!S.tok) return;
  let changed = false;
  for (const att of msg.attachments) {
    if (att.githubUrl || att.ghPath || !att.dataUrl) continue;
    _attInFlight.add(att.id);
    try {
      const url = await uploadAttachmentToGitHub(att);
      if (url) att.githubUrl = url;
      if (url || att.ghPath) { changed = true; await npsQDel(att.id); }
    } finally { _attInFlight.delete(att.id); }
  }
  if (changed) { updateMsgEl(msg); saveConv(); }
}

// Chemin GitHub d'une pièce jointe (le chemin d'envoi est déterministe : envoyes/<id>-<nom>).
function npsAttGhPath(a){
  if (a.ghPath) return a.ghPath;
  const m = /\/Maker\/[^/]+\/(envoyes\/[^?]+)/.exec(a.githubUrl || '');
  if (m) return decodeURIComponent(m[1]);
  if (a.id) return npsMD() + 'envoyes/' + a.id + '-' + String(a.name || 'fichier').replace(/[^\w.\-]+/g, '_').slice(0, 80);
  return null;
}
// Recharge une pièce jointe média depuis GitHub (authentifié) quand l'historique est rouvert.
async function npsHydrateAtt(a, msgId, force){
  if (a.dataUrl || a._hyd === 'loading') return;
  if (a._hyd && !force) return;
  a._hyd = 'loading';
  const done = () => {
    const mm = S.msgs.find(x => x.id === msgId || (x.attachments || []).includes(a));
    if (mm) updateMsgEl(mm);
  };
  const path = npsAttGhPath(a);
  if (!path) { a._hyd = 'fail'; a._hydErr = 'Chemin du fichier inconnu.'; done(); return; }
  if (!S.tok) { a._hyd = 'fail'; a._hydErr = 'Token GitHub manquant.'; done(); return; }
  try {
    a.dataUrl = await fetchGitHubFileContent('Maker', path, { binary: true, mime: a.type || 'application/octet-stream' });
    a._hyd = 'ok'; a._hydErr = '';
  } catch (e) { a._hyd = 'fail'; a._hydErr = e.message || 'Échec du chargement.'; }
  done();
}
// Au retour dans l'app / reconnexion : on retente les pièces jointes qui avaient échoué.
function npsRetryFailedAtts(){
  S.msgs.forEach(m => (m.attachments || []).forEach(a => { if (a._hyd === 'fail' && !a.dataUrl) npsHydrateAtt(a, m.id, true); }));
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') npsRetryFailedAtts(); });
window.addEventListener('online', npsRetryFailedAtts);

async function getGhLogin() {
  if (S._ghLogin) return S._ghLogin;
  if (!S.tok) return null;
  try {
    const res = await fetch('https://api.github.com/user', { headers: { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' } });
    if (!res.ok) return null;
    S._ghLogin = (await res.json()).login;
    return S._ghLogin;
  } catch (e) { return null; }
}

function bufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  const chunkSize = 16384;
  for (let i = 0; i < len; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunkSize, len)));
  }
  return btoa(binary);
}

async function saveExportToNpsMemory(fileName, dataUrlOrContent) {
  if (!S.tok || !dataUrlOrContent) return false;
  try {
    const owner = await getGhLogin();
    if (!owner) return false;
    const repo = 'Maker';
    const headers = {
      'Authorization': 'Bearer ' + S.tok,
      'Accept': 'application/vnd.github.v3+json',
      'Content-Type': 'application/json'
    };
    const cleanName = fileName.split('/').pop().replace(/[^\w.\-]+/g, '_');
    let b64 = '';
    if (typeof dataUrlOrContent === 'string' && dataUrlOrContent.startsWith('data:')) {
      b64 = dataUrlOrContent.split(',')[1] || '';
    } else if (typeof dataUrlOrContent === 'string' && /^https?:\/\//i.test(dataUrlOrContent)) {
      // URL brute : télécharger les vrais octets binaires sans en-tête CORS bloquant
      try {
        const dlRes = await fetch(dataUrlOrContent);
        if (dlRes.ok) {
          const buf = await dlRes.arrayBuffer();
          if (buf.byteLength > 0) b64 = bufferToBase64(buf);
        }
      } catch(e) {}
    } else if (typeof dataUrlOrContent === 'string') {
      b64 = utob(dataUrlOrContent);
    }
    b64 = (b64 || '').replace(/\s+/g, '');
    if (!b64 || b64.length < 8) {
      console.warn("saveExportToNpsMemory : contenu vide ou corrompu pour " + cleanName);
      return false;
    }

    let savedExp = false;
    let savedUp = false;
    // 1. Sauvegarder dans exports/ (fichiers générés/exportés par Fable Fast)
    try {
      const expPath = `${npsMD()}exports/${cleanName}`;
      const expUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${expPath}`;
      const checkExp = await fetch(expUrl, { headers, cache: 'no-cache' });
      const expSha = checkExp.ok ? (await checkExp.json()).sha : undefined;
      const resExp = await fetch(expUrl, {
        method: 'PUT', headers,
        body: JSON.stringify({
          message: `Export Fable Fast : ${cleanName}`,
          content: b64,
          sha: expSha
        })
      });
      if (resExp.ok) savedExp = true;
    } catch(e) {}

    // 2. Sauvegarder AUSSI dans envoyes/ (là où l'utilisateur et ses outils automatisés cherchent)
    try {
      const upPath = `${npsMD()}envoyes/${cleanName}`;
      const upUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${upPath}`;
      const checkUp = await fetch(upUrl, { headers, cache: 'no-cache' });
      const upSha = checkUp.ok ? (await checkUp.json()).sha : undefined;
      const resUp = await fetch(upUrl, {
        method: 'PUT', headers,
        body: JSON.stringify({
          message: `Fichier synchronisé dans uploads : ${cleanName}`,
          content: b64,
          sha: upSha
        })
      });
      if (resUp.ok) savedUp = true;
    } catch(e) {}

    if (savedExp && savedUp) {
      return true;
    }
    if (savedExp || savedUp) {
      console.warn('Synchronisation partielle : exports=' + savedExp + ', uploads=' + savedUp);
    }
    return false;
  } catch(e) {
    console.warn("saveExportToNpsMemory error:", e.message);
    return false;
  }
}

/**
 * Va chercher le VRAI contenu d'un fichier écrit sur GitHub par Fable Fast, pour
 * l'exporter dans le chat en artefact — jamais une copie retapée de mémoire
 * par le modèle. Utilisé par le bloc "export_file".
 */
async function fetchGitHubFileContent(repo, path, opts){
  const owner = await getGhLogin();
  if (!owner || !S.tok) throw new Error('Non connecté à GitHub.');

  const cleanPath = path.replace(/^\.\//, '');
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${cleanPath}`;
  const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' } });
  if (!res.ok) throw new Error(`Fichier introuvable sur GitHub (${res.status}) : ${cleanPath}`);
  const data = await res.json();
  
  if (opts && opts.binary) {
    // Vérification de la taille : un fichier de 0 octet est vide ou corrompu
    if (typeof data.size === 'number' && data.size === 0) {
      throw new Error(`Le fichier "${cleanPath}" existe sur GitHub mais fait 0 octet (fichier vide ou téléchargement incomplet/échoué).`);
    }

    // 1. Contenu base64 déjà présent dans la réponse JSON (fichiers <= 1 Mo)
    if (data.content && data.content.trim().length > 0) {
      const cleanB64 = data.content.replace(/\s+/g, '');
      return `data:${opts.mime || 'application/octet-stream'};base64,${cleanB64}`;
    }

    // 2. Si le fichier fait > 1 Mo, interroger l'API Git Blobs (/git/blobs/{sha}) qui fonctionne jusqu'à 100 Mo avec CORS
    if (data.sha) {
      try {
        const blobRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/blobs/${data.sha}`, {
          headers: { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' }
        });
        if (blobRes.ok) {
          const blobData = await blobRes.json();
          if (blobData.content && blobData.content.trim().length > 0) {
            const cleanB64 = blobData.content.replace(/\s+/g, '');
            return `data:${opts.mime || 'application/octet-stream'};base64,${cleanB64}`;
          }
        }
      } catch(blobErr) {
        console.warn("Git Blobs fallback failed:", blobErr.message);
      }
    }

    // 3. Téléchargement direct sans en-tête d'authentification (raw.githubusercontent n'accepte pas Authorization en préflight CORS)
    if (data.download_url) {
      try {
        const dlRes = await fetch(data.download_url);
        if (dlRes.ok) {
          const buf = await dlRes.arrayBuffer();
          if (buf.byteLength > 0) {
            const cleanB64 = bufferToBase64(buf);
            return `data:${opts.mime || 'application/octet-stream'};base64,${cleanB64}`;
          }
        }
      } catch(dlErr) {
        console.warn("Raw download_url fallback failed:", dlErr.message);
      }
    }

    throw new Error(`Données binaires introuvables ou vides pour "${cleanPath}".`);
  }

  if (data.encoding === 'base64') {
    return decodeURIComponent(escape(atob(data.content.replace(/\s+/g,''))));
  }
  return data.content || '';
}

// Détermine si un chemin de fichier est un type binaire connu (à ne jamais
// faire transiter par un décodage texte) et son type MIME associé.
function binaryFileInfo(path) {
  const ext = (path.split('.').pop() || '').toLowerCase();
  const map = {
    png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', gif:'image/gif', webp:'image/webp', svg:'image/svg+xml',
    pdf:'application/pdf', zip:'application/zip', apk:'application/vnd.android.package-archive',
    gz:'application/gzip', tgz:'application/gzip', tar:'application/x-tar', bz2:'application/x-bzip2', xz:'application/x-xz', '7z':'application/x-7z-compressed', rar:'application/vnd.rar',
    docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    mp3:'audio/mpeg', wav:'audio/wav', ogg:'audio/ogg', m4a:'audio/mp4',
    mp4:'video/mp4', webm:'video/webm', mov:'video/quicktime', mkv:'video/x-matroska', ico:'image/x-icon'
  };
  if (!map[ext]) return null;
  return {
    ext,
    mime: map[ext],
    isImage: /^image\//.test(map[ext]),
    isVideo: /^video\//.test(map[ext]),
    isAudio: /^audio\//.test(map[ext])
  };
}

// ── Livraison d'un fichier du dépôt dans le chat : archives et gros fichiers = carte avec téléchargement à la demande ──
async function npsGhMeta(repo, path){
  const owner = await getGhLogin();
  if (!owner || !S.tok) throw new Error('Non connecté à GitHub.');
  const clean = path.replace(/^\.\//, '');
  const r = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${clean}`, { headers: { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.v3+json' } });
  if (!r.ok) throw new Error(`Fichier introuvable sur GitHub (${r.status}) : ${clean}`);
  const d = await r.json();
  if (Array.isArray(d)) throw new Error('Ce chemin est un dossier : ' + clean);
  return { size: d.size || 0, sha: d.sha, owner, path: clean };
}
const NPS_ARCHIVE_RE = /\.(zip|tar\.gz|tgz|tar|gz|bz2|xz|7z|rar)$/i;
function npsAddRemoteCard(uiBMsg, repo, path, meta){
  const fname = path.split('/').pop();
  uiBMsg.codeBlocks = uiBMsg.codeBlocks || [];
  if (uiBMsg.codeBlocks.some(b => b.filename === fname)) return;
  uiBMsg.codeBlocks.push({ lang: (fname.split('.').pop() || 'bin'), content: '', filename: fname, isRemoteFile: true, size: meta.size, remote: { repo, path: meta.path } });
}
async function downloadRemoteFile(key){
  const it = (window._npsRemote || {})[key]; if (!it) return;
  try {
    toast('Téléchargement en cours…');
    const owner = await getGhLogin();
    const r = await fetch(`https://api.github.com/repos/${owner}/${it.repo}/contents/${it.path}`, { headers: { 'Authorization': 'Bearer ' + S.tok, 'Accept': 'application/vnd.github.raw' } });
    if (!r.ok) throw new Error('GitHub a répondu ' + r.status);
    const blob = await r.blob();
    if (!blob.size) throw new Error('fichier vide');
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = it.name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    toast('Fichier téléchargé');
  } catch (e) { toast('Téléchargement impossible : ' + e.message, true); }
}
function npsRemoteCardHtml(b){
  window._npsRemote = window._npsRemote || {};
  const key = 'nr' + Math.random().toString(36).slice(2, 9);
  window._npsRemote[key] = { repo: b.remote.repo, path: b.remote.path, name: b.filename };
  return `<div style="margin-top:8px;border-radius:12px;background:var(--bg2);border:1px solid var(--border);overflow:hidden">
    <div style="padding:10px 12px;display:flex;align-items:center;gap:10px;">
      <div style="display:flex;align-items:center;">${npsFileIcon(b.filename, { lang: b.lang })}</div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:15.5px;font-weight:600;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(b.filename)}</div>
        <div style="font-size:13.5px;color:var(--text2);margin-top:2px;">${esc(npsTypeLabel(b.filename, b.lang))} · ${formatBytes(b.size || 0)}</div>
      </div>
      <button onclick="event.stopPropagation();downloadRemoteFile('${key}')" aria-label="Télécharger" style="background:none;border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:14.5px;padding:6px 10px;cursor:pointer;display:flex;align-items:center;gap:6px;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>Télécharger</button>
    </div></div>`;
}

// ── Aides GitHub (Maker) ──
// IMPORTANT : l'API GitHub répond avec « Cache-Control: max-age=60 ». Sans "no-cache", le navigateur
// ressert pendant 1 minute un ANCIEN « sha » : l'écriture suivante est refusée (409) et la sauvegarde
// échoue sans bruit. Toutes les lectures qui servent à écrire passent donc par cache:'no-cache'.
const NPS_MEM = 'Maker';
function npsGhH(accept){ return { 'Authorization': 'Bearer ' + S.tok, 'Accept': accept || 'application/vnd.github.v3+json' }; }
// Lecture brute d'un fichier (aucune limite de 1 Mo, contrairement au champ « content » en base64).
async function npsGhRaw(owner, path){
  const r = await fetch(`https://api.github.com/repos/${owner}/${NPS_MEM}/contents/${path}`, { headers: npsGhH('application/vnd.github.raw'), cache: 'no-cache' });
  if (!r.ok) return { status: r.status, text: null };
  return { status: 200, text: await r.text() };
}
// Écriture avec sha frais et nouvelles tentatives en cas de conflit ; lève une erreur claire sinon.
async function npsGhFindSha(owner, path){
  // 1) lecture directe avec contournement total du cache ; 2) repli : listage du dossier parent
  try {
    const g = await fetch(`https://api.github.com/repos/${owner}/${NPS_MEM}/contents/${path}?_=${Date.now()}`, { headers: npsGhH(), cache: 'no-store' });
    if (g.ok) { const d = await g.json(); if (d && d.sha) return d.sha; }
  } catch (e) {}
  try {
    const dir = path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '';
    const name = path.split('/').pop();
    const l = await fetch(`https://api.github.com/repos/${owner}/${NPS_MEM}/contents/${dir}?_=${Date.now()}`, { headers: npsGhH(), cache: 'no-store' });
    if (l.ok) { const arr = await l.json(); const f = Array.isArray(arr) ? arr.find(x => x.name === name) : null; if (f && f.sha) return f.sha; }
  } catch (e) {}
  return undefined;
}
async function npsGhPut(owner, path, b64, message){
  const url = `https://api.github.com/repos/${owner}/${NPS_MEM}/contents/${path}`;
  let last = '', sha;
  for (let attempt = 0; attempt < 4; attempt++) {
    sha = await npsGhFindSha(owner, path);
    const r = await fetch(url, { method: 'PUT', headers: { ...npsGhH(), 'Content-Type': 'application/json' }, body: JSON.stringify({ message, content: b64, sha }) });
    if (r.ok) return true;
    last = 'HTTP ' + r.status;
    let detail = ''; try { detail = (await r.json()).message || ''; } catch (e) {}
    if (r.status === 409 || r.status === 422) { last += detail ? ' — ' + detail : ''; await new Promise(res => setTimeout(res, 600 * (attempt + 1))); continue; }
    throw new Error(path + ' : écriture refusée (' + last + (detail ? ' — ' + detail : '') + ')');
  }
  throw new Error(path + " : conflit d'écriture persistant (" + last + ')');
}
let _syncToastAt = 0;
function npsSyncFail(e){
  S._syncErr = (e && e.message) || String(e);
  console.warn('Synchro GitHub :', S._syncErr);
  if (Date.now() - _syncToastAt > 60000) { _syncToastAt = Date.now(); toast('Sauvegarde GitHub impossible : ' + S._syncErr, 'warn'); }
}
// ── Index des conversations (chat-history.json) ──
const _idxKnown = new Map();
let _idxChain = Promise.resolve();
async function npsReadIndex(owner, mode){
  mode = mode || window.ffMode || 'download';
  const r = await npsGhRaw(owner, npsP(mode, 'chat-history.json'));
  if (r.status === 404) return null;
  if (r.status !== 200) throw new Error('index indisponible (HTTP ' + r.status + (r.status === 401 ? ' : token refusé' : (r.status === 403 ? ' : accès refusé ou limite GitHub atteinte' : '')) + ')');
  // Index abîmé ou d'un autre format : on ne bloque plus la synchro, il est reconstruit depuis les fichiers réels du dépôt.
  let idx; try { idx = JSON.parse(r.text); } catch (e) { idx = null; S._idxRepaired = true; }
  if (!Array.isArray(idx)) {
    const alt = idx && (idx.conversations || idx.convs || idx.items || idx.list || idx.chats);
    if (Array.isArray(alt)) idx = alt;
    else if (idx && typeof idx === 'object') idx = Object.entries(idx).filter(([k, v]) => v && typeof v === 'object').map(([k, v]) => ({ id: v.id || k, title: v.title, ts: v.ts }));
    else idx = [];
    S._idxRepaired = true;
  }
  idx = idx.filter(e => e && typeof e.id === 'string' && e.id);
  return idx;
}
function npsIndexUpsert(owner, id, title, ts){
  const run = async () => {
    const _m = npsConvMode(id);
    const idx = (await npsReadIndex(owner, _m)) || [];   // en cas d'erreur de lecture on n'écrase JAMAIS l'index
    const cur = idx.find(c => c.id === id);
    if (cur && cur.title === title) { _idxKnown.set(id, title); return; }
    const next = [{ id, title, ts }, ...idx.filter(c => c.id !== id)];
    await npsGhPut(owner, npsP(_m, 'chat-history.json'), utob(JSON.stringify(next, null, 2)), "Mise à jour de l'index des conversations");
    _idxKnown.set(id, title);
  };
  _idxChain = _idxChain.then(run, run);
  return _idxChain;
}
function npsIndexWrite(owner, idx, message, mode){
  mode = mode || window.ffMode || 'download';
  const run = () => npsGhPut(owner, npsP(mode, 'chat-history.json'), utob(JSON.stringify(idx, null, 2)), message || "Synchronisation de l'index des conversations");
  _idxChain = _idxChain.then(run, run);
  return _idxChain;
}
const _convSaveChain = {};
function saveConvToGitHubNow(id, title, ts, msgs) {
  if (!S.tok) return Promise.resolve();
  const run = async () => {
    try {
      const owner = await getGhLogin();
      if (!owner) throw new Error('compte GitHub introuvable (token invalide ou réseau coupé)');
      const _m = npsConvMode(id);
      const payload = { id, title, ts, mode: _m, msgs: stripHeavyDataForStorage(msgs) };
      await npsGhPut(owner, npsP(_m, `historique/${id}.json`), utob(JSON.stringify(payload)), `Sauvegarde conversation : ${title}`);
      S._syncErr = '';
      const c = S.convs.find(x => x.id === id); if (c) c.synced = true;
      if (_idxKnown.get(id) !== title) await npsIndexUpsert(owner, id, title, ts);
    } catch (e) { npsSyncFail(e); }
  };
  _convSaveChain[id] = (_convSaveChain[id] || Promise.resolve()).then(run, run);
  return _convSaveChain[id];
}
const _convSaveTimers = {};
const _convSavePend = {};
function saveConvToGitHub(id, title, ts, msgs) {
  if (!S.tok) return;
  clearTimeout(_convSaveTimers[id]);
  _convSavePend[id] = [id, title, ts, msgs];
  _convSaveTimers[id] = setTimeout(() => { delete _convSavePend[id]; saveConvToGitHubNow(id, title, ts, msgs); }, 3000);
}
// App quittée / mise en arrière-plan : on envoie tout de suite ce qui attendait le délai de 3 s.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'hidden') return;
  Object.keys(_convSavePend).forEach(id => {
    clearTimeout(_convSaveTimers[id]);
    const args = _convSavePend[id]; delete _convSavePend[id];
    saveConvToGitHubNow(...args);
  });
});

async function loadConvFromGitHub(id) {
  if (!S.tok) return null;
  try {
    const owner = await getGhLogin();
    if (!owner) { S._lastLoadErr = 'compte GitHub introuvable (token invalide ou réseau coupé)'; return null; }
    const r = await npsGhRaw(owner, npsP(npsConvMode(id), `historique/${id}.json`));
    if (r.status !== 200) {
      S._lastLoadErr = r.status === 404 ? "ce fichier n'existe pas sur GitHub (la conversation n'a jamais été envoyée depuis l'appareil d'origine)" : 'GitHub a répondu HTTP ' + r.status;
      return null;
    }
    const payload = JSON.parse(r.text);
    S._lastLoadErr = '';
    return Array.isArray(payload) ? payload : (payload.msgs || []);
  } catch (e) {
    S._lastLoadErr = e.message;
    console.warn('loadConvFromGitHub error:', e.message);
    return null;
  }
}

function saveMemoryUI() {
  const content = document.getElementById('mem-content').value.trim();
  safeSetItem('nps_long_term_memory', content);
  toast('Mémoire longue durée mise à jour');
  if (S.tok) {
    saveMemoryToGitHub(content);
  }
}
function clearMemoryUI() {
  if (confirm('Effacer toute la mémoire de Fable Fast ?')) {
     const traceNote = `[Mémoire effacée par l'utilisateur le ${new Date().toLocaleString('fr-FR')}. Aucun souvenir antérieur à cette date.]`;
     safeSetItem('nps_long_term_memory', traceNote);
     document.getElementById('mem-content').value = traceNote;
     toast('Mémoire effacée');
     if (S.tok) {
       saveMemoryToGitHub(traceNote);
     }
  }
}

// ═══════ SYNC CONVERSATIONS DEPUIS GITHUB (SOURCE DE VÉRITÉ) ═══════
// - La liste vient de l'index « chat-history.json », complétée par la liste réelle des fichiers
//   du dépôt (une conversation présente sur GitHub mais absente de l'index y est ajoutée).
// - Une conversation qui n'existe QUE sur cet appareil n'est plus effacée de la liste :
//   elle est envoyée sur GitHub (rattrapage) pour être retrouvée partout.
// - Toute erreur est visible (message précis) au lieu d'échouer en silence.
async function syncConvsFromGitHub(silent) {
  if (!S.tok) return;
  if (S._syncRunning) return;
  S._syncRunning = true;
  try {
    if (!S.convs.length) { S._convsLoading = true; renderRecents(); }
    const owner = await getGhLogin();
    if (!owner) throw new Error('compte GitHub introuvable (token invalide ou réseau coupé)');

    let idxAll = [];
    for (const _m of NPS_MODES) {
    const treeP = npsListConvFiles(owner, _m);
    let idx = await npsReadIndex(owner, _m);            // lève une erreur claire si GitHub refuse
    const files = await treeP;                      // identifiants réels, ou null
    let changed = false;
    if (idx === null) { idx = []; changed = true; }
    if (S._idxRepaired) { S._idxRepaired = false; changed = true; }
    if (files) {
      const known = new Set(idx.map(e => e.id));
      const missing = files.filter(id => !known.has(id));
      for (let i = 0; i < missing.length; i += 6) {
        await Promise.all(missing.slice(i, i + 6).map(async id => {
          try {
            const r = await npsGhRaw(owner, npsP(_m, `historique/${id}.json`));
            if (r.status !== 200) return;
            const pl = JSON.parse(r.text);
            idx.push({ id, title: pl.title || 'Conversation', ts: pl.ts || Date.now() }); changed = true;
          } catch (e) {}
        }));
      }
      if (changed && idx.length) {
        idx.sort((a, b) => new Date(b.ts || 0) - new Date(a.ts || 0));
        npsIndexWrite(owner, idx, null, _m).catch(npsSyncFail);
      }
      // Entrée d'index sans fichier (supprimée ailleurs) : on ne l'affiche plus.
      const fileSet = new Set(files);
      idx = idx.filter(e => fileSet.has(e.id));
    }
    idx.forEach(e => { e.mode = _m; _idxKnown.set(e.id, e.title); _npsModeMemo[e.id] = _m; });
    idxAll = idxAll.concat(idx);
    }
    const idx = idxAll;

    const idSet = new Set(idx.map(e => e.id));
    const prevById = new Map(S.convs.map(c => [c.id, c]));
    const pendKeep = S.convs.filter(c => c.titlePending && !idSet.has(c.id));
    const localOnly = S.convs.filter(c => !idSet.has(c.id) && !c.titlePending && !c.synced);
    const fromGh = idx.map(e => {
      const p = prevById.get(e.id) || {};
      return { id: e.id, mode: e.mode, title: e.title || 'Conversation', ts: e.ts ? new Date(e.ts) : new Date(), msgs: (p.msgs && p.msgs.length) ? p.msgs : [], pinned: p.pinned, projectId: p.projectId, synced: true };
    });
    S.convs = [...fromGh, ...localOnly].sort((a, b) => new Date(b.ts) - new Date(a.ts));
    if (pendKeep.length) S.convs = [...pendKeep, ...S.convs];
    safeSetItem('nps_convs', JSON.stringify(S.convs.map(c => ({...c, msgs: []}))));
    renderRecents();
    S._syncErr = '';
    if (!silent) toast(`${S.convs.length} conversation${S.convs.length > 1 ? 's' : ''} synchronisée${S.convs.length > 1 ? 's' : ''} depuis GitHub`, true);

    // Rattrapage : ce qui n'existait que sur cet appareil part sur GitHub.
    if (localOnly.length) (async () => {
      for (const c of localOnly) {
        let msgs = c.msgs;
        if (!msgs || !msgs.length) { try { msgs = JSON.parse(localStorage.getItem('nps_conv_' + c.id) || '[]'); } catch (e) { msgs = []; } }
        if (msgs && msgs.length) await saveConvToGitHubNow(c.id, c.title || 'Conversation', c.ts, msgs);
      }
      safeSetItem('nps_convs', JSON.stringify(S.convs.map(c => ({...c, msgs: []}))));
    })();
  } catch(e) {
    S._syncErr = e.message;
    console.warn('syncConvsFromGitHub error:', e.message);
    if (!silent) toast('Synchronisation impossible : ' + e.message, 'warn');
  } finally {
    S._syncRunning = false;
    if (S._convsLoading) { S._convsLoading = false; renderRecents(); }
  }
}

// Bouton « Récents » : synchronisation visible, suivie d'un rapport précis si quelque chose ne va pas.
async function npsManualSyncConvs(btn) {
  if (!S.tok) { toast('Connecte un token GitHub (Paramètres) pour charger l\'historique', true); return; }
  if (btn) { btn.classList.add('spinning'); btn.disabled = true; }
  try {
    await syncConvsFromGitHub(false);
    const lines = await npsSyncDiagnostic();
    if (lines.some(l => l.startsWith('✗')) || !S.convs.length) npsShowSyncReport(lines);
  } finally {
    if (btn) { btn.classList.remove('spinning'); btn.disabled = false; }
  }
}

// Liste réelle des fichiers historique/*.json (identifiants), ou null si indisponible.
async function npsListConvFiles(owner, mode) {
  mode = mode || window.ffMode || 'download';
  const dir = npsP(mode, 'historique');
  try {
    if (!S._memBranch) {
      const repoRes = await fetch(`https://api.github.com/repos/${owner}/${NPS_MEM}`, { headers: npsGhH(), cache: 'no-cache' });
      if (!repoRes.ok) return null;
      S._memBranch = (await repoRes.json()).default_branch || 'main';
    }
    const r = await fetch(`https://api.github.com/repos/${owner}/${NPS_MEM}/git/trees/${S._memBranch}?recursive=1`, { headers: npsGhH(), cache: 'no-cache' });
    if (!r.ok) return null;
    const t = await r.json();
    if (t.truncated) {
      const d = await fetch(`https://api.github.com/repos/${owner}/${NPS_MEM}/contents/${dir}`, { headers: npsGhH(), cache: 'no-cache' });
      if (d.status === 404) return [];
      if (!d.ok) return null;
      const arr = await d.json();
      return Array.isArray(arr) ? arr.filter(f => f.type === 'file' && /\.json$/.test(f.name)).map(f => f.name.slice(0, -5)) : null;
    }
    return (t.tree || []).filter(f => f.type === 'blob' && f.path.startsWith(dir + '/') && f.path.endsWith('.json') && f.path.indexOf('/', dir.length + 1) < 0).map(f => f.path.slice(dir.length + 1, -5));
  } catch (e) { return null; }
}

// Diagnostic complet de la synchronisation (aucune donnée secrète affichée).
async function npsSyncDiagnostic() {
  const L = [];
  const ok = t => L.push('✓ ' + t), ko = t => L.push('✗ ' + t), inf = t => L.push('• ' + t);
  if (!S.tok) { ko('Aucun token GitHub enregistré dans CE navigateur (Paramètres → GitHub). Chaque navigateur a son propre stockage : il faut y saisir le token.'); return L; }
  ok('Token présent (' + (S.tok.startsWith('github_pat_') ? 'fine-grained' : (S.tok.startsWith('ghp_') ? 'classique' : 'autre')) + ', ' + S.tok.length + ' caractères)');
  let owner = null;
  try {
    const r = await fetch('https://api.github.com/user', { headers: npsGhH(), cache: 'no-cache' });
    if (r.ok) {
      owner = (await r.json()).login; ok('Compte GitHub : ' + owner);
      const sc = r.headers.get('x-oauth-scopes'); if (sc !== null) inf('Permissions du token : ' + (sc || 'aucune'));
      const rem = r.headers.get('x-ratelimit-remaining'); if (rem !== null) inf('Requêtes GitHub restantes cette heure : ' + rem);
    } else ko('Token refusé par GitHub (HTTP ' + r.status + ')' + (r.status === 401 ? ' : token invalide, expiré ou révoqué.' : ''));
  } catch (e) { ko('GitHub injoignable : ' + e.message + ' (réseau coupé ou bloqué).'); }
  if (!owner) return L;
  try {
    const r = await fetch(`https://api.github.com/repos/${owner}/${NPS_MEM}`, { headers: npsGhH(), cache: 'no-cache' });
    if (r.ok) { const j = await r.json(); ok('Dépôt ' + NPS_MEM + ' trouvé (' + (j.private ? 'privé' : 'public') + ', branche ' + (j.default_branch || '?') + ')'); }
    else if (r.status === 404) { ko('Dépôt ' + owner + '/' + NPS_MEM + ' introuvable : aucune conversation n\'a jamais été sauvegardée avec CE compte (ou le token n\'a pas accès à ce dépôt).'); return L; }
    else ko('Dépôt ' + NPS_MEM + ' : HTTP ' + r.status);
  } catch (e) { ko('Dépôt : ' + e.message); }
  let idxCount = null;
  try {
    const idx = await npsReadIndex(owner);
    if (idx === null) ko('Index chat-history.json absent du dépôt.'); else { idxCount = idx.length; ok('Index chat-history.json : ' + idx.length + ' conversation(s)'); }
  } catch (e) { ko(e.message); }
  const files = await npsListConvFiles(owner);
  if (files === null) ko('Impossible de lister le dossier historique/.');
  else {
    if (files.length) ok('Dossier historique/ : ' + files.length + ' fichier(s)'); else ko('Dossier historique/ : aucun fichier — rien n\'a été sauvegardé sur GitHub.');
    if (idxCount !== null && idxCount !== files.length) inf('Écart index/fichiers : ' + idxCount + ' dans l\'index, ' + files.length + ' fichier(s) (réparé automatiquement à la synchro).');
    if (files.length) {
      try {
        const r = await npsGhRaw(owner, npsP(window.ffMode || 'download', 'historique/') + files[0] + '.json');
        if (r.status === 200) { const pl = JSON.parse(r.text); ok('Lecture test d\'une conversation : ' + ((pl.msgs || []).length) + ' message(s), ' + Math.round(r.text.length / 1024) + ' Ko'); }
        else ko('Lecture test d\'une conversation : HTTP ' + r.status);
      } catch (e) { ko('Lecture test : ' + e.message); }
    }
  }
  const unsynced = S.convs.filter(c => !c.synced && !c.titlePending).length;
  inf('Conversations dans cet appareil : ' + S.convs.length + (unsynced ? ' (dont ' + unsynced + ' pas encore envoyée(s) sur GitHub)' : ''));
  if (S._syncErr) ko('Dernière erreur : ' + S._syncErr);
  return L;
}
function npsShowSyncReport(lines) {
  const old = document.getElementById('nps-sync-report'); if (old) old.remove();
  const ov = document.createElement('div');
  ov.id = 'nps-sync-report';
  ov.style.cssText = 'position:fixed;inset:0;z-index:99998;background:rgba(0,0,0,.72);display:flex;align-items:flex-end;justify-content:center;';
  ov.onclick = e => { if (e.target === ov) ov.remove(); };
  const box = document.createElement('div');
  box.style.cssText = 'width:100%;max-width:560px;max-height:82vh;overflow:auto;background:var(--bg2);color:var(--text);border-radius:16px 16px 0 0;padding:16px;font-size:15.5px;line-height:1.6;';
  const h = document.createElement('div'); h.textContent = 'Rapport de synchronisation'; h.style.cssText = 'font-weight:700;font-size:16.5px;margin-bottom:10px;';
  const pre = document.createElement('div'); pre.textContent = lines.join('\n'); pre.style.cssText = 'white-space:pre-wrap;word-break:break-word;';
  const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:10px;margin-top:14px;';
  const mk = (t, fn, prim) => { const b = document.createElement('button'); b.textContent = t; b.onclick = fn; b.style.cssText = 'flex:1;padding:10px;border-radius:10px;font-size:15.5px;font-weight:600;cursor:pointer;border:1px solid var(--border);' + (prim ? 'background:var(--accent);color:#ffffff;border-color:transparent;' : 'background:var(--bg3);color:var(--text);'); return b; };
  row.append(
    mk('Copier le rapport', () => { const t = lines.join('\n'); (typeof robustCopy === 'function' ? robustCopy(t) : navigator.clipboard.writeText(t)).then(() => toast('Rapport copié')).catch(() => toast('Copie impossible', true)); }),
    mk('Fermer', () => ov.remove(), true)
  );
  box.append(h, pre, row); ov.append(box); document.body.appendChild(ov);
}

// Resynchronisation périodique : GitHub reste la référence, on revient la
// consulter chaque minute pendant que l'app est ouverte (couvre les
// suppressions/ajouts faits depuis un autre appareil ou une autre session).
let _convAutoSyncTimer = null;
function startAutoSyncConvs() {
  if (_convAutoSyncTimer) clearInterval(_convAutoSyncTimer);
  _convAutoSyncTimer = setInterval(() => {
    if (S.tok && document.visibilityState === 'visible') {
      syncConvsFromGitHub(true);
      if (S.currentConv && !S.isAgentRunning) npsRefreshCurrentConv(S.currentConv);
    }
  }, 60000);
}
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && S.tok) {
    syncConvsFromGitHub(true);
    if (S.currentConv && !S.isAgentRunning) npsRefreshCurrentConv(S.currentConv);
  }
});
// Fusion par identifiant de message : on ne perd JAMAIS un message local pas encore envoyé,
// et on récupère ceux qui existent seulement sur GitHub.
function npsMergeMsgs(local, remote) {
  const byId = new Map();
  (remote || []).forEach(m => byId.set(m.id, m));
  (local || []).forEach(m => {
    const r = byId.get(m.id);
    if (!r) { byId.set(m.id, m); return; }
    const remoteRicher = String(r.text || '').length > String(m.text || '').length || (r.steps || []).length > (m.steps || []).length;
    byId.set(m.id, remoteRicher ? { ...r, attachments: m.attachments || r.attachments, ...(m.video ? { video: m.video } : {}), ...(m.image ? { image: m.image } : {}) } : m);
  });
  return [...byId.values()].sort((a, b) => new Date(a.ts) - new Date(b.ts));
}
async function npsRefreshCurrentConv(id) {
  const c = S.convs.find(x => x.id === id);
  if (!c || S.currentConv !== id || S.isAgentRunning) return;
  const remote = await loadConvFromGitHub(id);
  if (!remote || S.currentConv !== id || S.isAgentRunning) return;
  remote.forEach(m => { m.ts = new Date(m.ts); });
  const local = S.msgs || [];
  const localIds = new Set(local.map(m => m.id)), remoteIds = new Set(remote.map(m => m.id));
  const newFromRemote = remote.filter(m => !localIds.has(m.id)).length;
  const onlyLocal = local.filter(m => !remoteIds.has(m.id)).length;
  if (!newFromRemote && !onlyLocal) return;
  const merged = npsMergeMsgs(local, remote);
  if (newFromRemote) {
    c.msgs = merged; S.msgs = [...merged];
    safeSetItem('nps_conv_' + id, JSON.stringify(stripHeavyDataForStorage(merged)));
    const feed = document.getElementById('feed');
    feed.innerHTML = '';
    S.msgs.forEach(m => appendMsgEl(m));
    feed.scrollTop = feed.scrollHeight;
    toast('Historique mis à jour depuis GitHub');
  }
  if (onlyLocal && c.title && !c.titlePending) saveConvToGitHubNow(id, c.title, c.ts, merged);   // pousse ce qui manquait sur GitHub
}


let _tt;
function toast(msg,type=false){
  const t=document.getElementById('toast');
  // Plus d'emoji dans les confirmations : on les retire du texte et on met une petite icône SVG.
  msg=String(msg==null?'':msg).replace(/[\u2190-\u21FF\u2300-\u23FF\u2460-\u27BF\u2900-\u2BFF\u{1F000}-\u{1FAFF}\uFE0F\u200D]/gu,'').replace(/\s{2,}/g,' ').trim();
  const bad=(type==='warn'||type===true);
  const ico=bad
    ?'<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="12.5"/><line x1="12" y1="16" x2="12" y2="16"/></svg>'
    :'<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
  t.innerHTML='<span style="display:inline-flex;align-items:center;gap:7px">'+ico+'<span>'+esc(msg)+'</span></span>';
  let cls='show';
  if(type==='warn') cls+=' warn';
  else if(type===true||type==='info') cls+=' info';
  t.className=cls;
  clearTimeout(_tt); _tt=setTimeout(()=>t.className='',3000);
}
