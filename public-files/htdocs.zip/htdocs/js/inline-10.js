// ═══════ TEXTE VOCAL ═══════
let recog=null, isRecording=false;
function toggleMic(){return;
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){toast('Reconnaissance vocale non supportée par ce navigateur',true);return;}
  const btn=document.getElementById('mic-btn');
  if(isRecording){
    recog&&recog.stop();
    return;
  }
  recog=new SR();
  recog.lang='fr-FR';
  recog.interimResults=true;
  recog.continuous=false;
  const inp=document.getElementById('comp-input');
  const base=inp.value?inp.value+' ':'';
  recog.onstart=()=>{isRecording=true;btn.classList.add('recording');toast('Parlez maintenant...','info');};
  recog.onresult=(ev)=>{
    let transcript='';
    for(let i=0;i<ev.results.length;i++) transcript+=ev.results[i][0].transcript;
    inp.value=base+transcript;
    growTA(inp);
  };
  recog.onerror=()=>{toast('Micro : échec de la reconnaissance',true);};
  recog.onend=()=>{isRecording=false;btn.classList.remove('recording');};
  recog.start();
}

const PROVIDER_FIELD_MAP={gemini:'field-gemini',anthropic:'field-anthropic',openai:'field-openai',universel:'field-universel'};

let _fvCurrent = null;
async function previewAttachment(id){
  let att = S.attachments.find(a=>a.id===id);
  if(!att){ for(const m of S.msgs){ const found=(m.attachments||[]).find(a=>a.id===id); if(found){att=found;break;} } }
  if(!att) return;
  if(!att.dataUrl && !att.file && typeof att.text!=='string'){ toast('Chargement du fichier…'); await npsHydrateAtt(att, null, true); }
  if(att.type?.startsWith('image/') && !/svg/i.test(att.type) && att.dataUrl){ openLightbox(att.dataUrl); return; }
  _fvCurrent = att;
  document.getElementById('fv-name').textContent = att.name;
  const isHtml = /\.html?$/i.test(att.name) || att.type === 'text/html';
  document.getElementById('fv-render-btn').style.display = 'none';
  document.getElementById('fv-iframe').style.display = 'none';
  document.getElementById('fv-text').style.display = 'none';
  const box = document.getElementById('fv-doc'); box.style.display = 'block'; box.innerHTML = '';
  document.getElementById('file-viewer').classList.add('show');
  if (typeof att.text === 'string') { npsPreviewInto(box, att.text, att.name, ''); return; }
  let blob = att.file || null;
  if (!blob && att.dataUrl) { try { blob = npsDataUrlToBlob(att.dataUrl); } catch(e){} }
  if (blob) { npsPreviewBlobInto(box, blob, att.name, att.type || blob.type || ''); return; }
  box.innerHTML = '<div class="nps-pv"><div class="nps-pv-note">Impossible de charger ce fichier depuis GitHub' + (att._hydErr ? ' : ' + esc(att._hydErr) : '') + '. Vérifie le token GitHub puis touche à nouveau le fichier.</div></div>';
}
function toggleFileRender(){
  const iframe = document.getElementById('fv-iframe');
  const pre = document.getElementById('fv-text');
  if (iframe.style.display === 'none') {
    iframe.src = URL.createObjectURL(_fvCurrent.file);
    iframe.style.display = 'block'; pre.style.display = 'none';
  } else {
    iframe.style.display = 'none'; pre.style.display = 'block';
  }
}
function closeFileViewer(){
  document.getElementById('file-viewer').classList.remove('show');
  document.getElementById('fv-iframe').src = 'about:blank';
  const _d=document.getElementById('fv-doc'); if(_d){ _d.innerHTML=''; }
}
function downloadFileViewer(){
  if (!_fvCurrent) return;
  const blob = _fvCurrent.file || (typeof _fvCurrent.text === 'string' ? new Blob([_fvCurrent.text], {type:_fvCurrent.type||'text/plain'}) : (_fvCurrent.dataUrl ? npsDataUrlToBlob(_fvCurrent.dataUrl) : null));
  if (!blob) { toast('Fichier non conservé, renvoie-le pour le télécharger', true); return; }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = _fvCurrent.name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ── Cartes média + aperçu plein écran (vidéo / audio) avec bouton Fermer ──
window._npsMedia = window._npsMedia || {};
function npsMediaReg(src, kind, name){
  const id = 'nm' + Math.random().toString(36).slice(2, 9);
  window._npsMedia[id] = { src, kind, name: name || (kind === 'video' ? 'video.mp4' : 'fichier') };
  return id;
}
function npsMediaSize(src){
  try {
    const m = /^data:[^;,]*;base64,(.*)$/.exec(src || '');
    if (!m) return '';
    const b = Math.floor(m[1].length * 0.75);
    return b > 1048576 ? (b / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(b / 1024)) + ' Ko';
  } catch(e){ return ''; }
}
function npsVideoCard(src, name){
  const id = npsMediaReg(src, 'video', name);
  const size = npsMediaSize(src);
  const nm = String(name || 'video.mp4').replace(/[<>"&]/g, '');
  return `<div onclick="event.stopPropagation();openMediaViewer('${id}')" style="margin:8px 0;display:flex;align-items:center;gap:12px;max-width:320px;padding:8px;border-radius:12px;background:var(--bg2);border:1px solid var(--border);cursor:pointer;">
    <div style="position:relative;width:84px;height:62px;border-radius:8px;overflow:hidden;background:#000;flex-shrink:0;">
      <video muted playsinline preload="metadata" src="${src}#t=0.1" style="width:100%;height:100%;object-fit:cover;pointer-events:none;display:block;" onerror="this.style.display='none'"></video>
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;"><div style="width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;"><svg viewBox="0 0 24 24" fill="#fff" style="width:12px;height:12px;margin-left:2px"><path d="M8 5v14l11-7z"/></svg></div></div>
    </div>
    <div style="min-width:0;flex:1;"><div style="font-size:15.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${nm}</div><div style="font-size:13.5px;opacity:.7;margin-top:2px;">${size ? size + ' · ' : ''}Touche pour ouvrir</div></div>
  </div>`;
}
function openMediaViewer(id){
  const it = window._npsMedia[id]; if (!it) return;
  closeMediaViewer();
  const ov = document.createElement('div');
  ov.id = 'nps-media-viewer';
  ov.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.96);display:flex;flex-direction:column;';
  const bar = document.createElement('div');
  bar.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;color:#fff;';
  const title = document.createElement('div');
  title.style.cssText = 'font-size:15.5px;opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;';
  title.textContent = it.name;
  const dl = document.createElement('a');
  dl.href = it.src; dl.download = it.name; dl.textContent = 'Télécharger';
  dl.style.cssText = 'color:#fff;font-size:15.5px;text-decoration:underline;padding:8px;';
  const cl = document.createElement('button');
  cl.textContent = 'Fermer';
  cl.style.cssText = 'background:#fff;color:#000;border:none;border-radius:20px;padding:8px 16px;font-size:15.5px;font-weight:700;';
  cl.onclick = closeMediaViewer;
  bar.append(title, dl, cl);
  const body = document.createElement('div');
  body.style.cssText = 'flex:1;display:flex;align-items:center;justify-content:center;min-height:0;padding:0 0 12px;';
  const el = document.createElement(it.kind === 'audio' ? 'audio' : 'video');
  el.controls = true; el.autoplay = true; el.playsInline = true; el.src = it.src;
  el.style.cssText = it.kind === 'audio' ? 'width:90%;' : 'max-width:100%;max-height:100%;width:100%;background:#000;';
  body.appendChild(el);
  ov.append(bar, body);
  document.body.appendChild(ov);
}
function closeMediaViewer(){
  const ov = document.getElementById('nps-media-viewer');
  if (!ov) return;
  ov.querySelectorAll('video,audio').forEach(v => { try { v.pause(); v.removeAttribute('src'); v.load(); } catch(e){} });
  ov.remove();
}

function openLightbox(src){
  const img = document.getElementById('lightbox-img');
  img.src = src;
  img.classList.remove('zoomed');
  document.getElementById('img-lightbox').classList.add('show');
}
function closeLightbox(){
  document.getElementById('img-lightbox').classList.remove('show');
}
async function downloadLightboxImage(){
  const src = document.getElementById('lightbox-img').src;
  const ext = (/image\/(\w+)/.exec(src)?.[1]) || (/\.(\w+)(\?|$)/.exec(src)?.[1]) || 'jpg';
  const filename = 'nps-image-' + Date.now() + '.' + ext.replace('jpeg','jpg');
  // Une image distante (http/https cross-origin, ex: générée par l'IA) fait
  // que le navigateur IGNORE l'attribut "download" et se contente d'ouvrir
  // l'URL — c'est exactement le "ça ouvre le navigateur au lieu de télécharger"
  // remonté. On récupère donc d'abord les vrais octets en Blob (data:/blob:
  // sont toujours honorés par "download", contrairement à une URL distante).
  try {
    const res = await fetch(src);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    toast('Image téléchargée');
  } catch(e) {
    // Repli si le fetch échoue (CORS strict) : au moins un lien direct.
    const a = document.createElement('a');
    a.href = src; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    toast('Téléchargement direct bloqué (CORS) — ouverture dans le navigateur', 'warn');
  }
}

// Détection de disponibilité RÉELLE de la synthèse vocale — indispensable
// avant compilation en APK : la WebView Android standard (contrairement à
// Chrome navigateur) n'implémente généralement PAS l'API Web Speech
// Synthesis. Sans cette garde, "speechSynthesis.getVoices()" plante au
// chargement même de la page (ReferenceError), ce qui casserait TOUT le
// script, pas seulement la fonctionnalité vocale.
const hasTTS = (typeof speechSynthesis !== 'undefined');

let _cachedVoices = [];
function refreshVoices(){ if (hasTTS) _cachedVoices = speechSynthesis.getVoices(); }
refreshVoices();
if (hasTTS) speechSynthesis.onvoiceschanged = refreshVoices;

function pickBestVoice(){
  if (!hasTTS) return null;
  const voices = _cachedVoices.length ? _cachedVoices : speechSynthesis.getVoices();
  const frVoices = voices.filter(v => v.lang && v.lang.toLowerCase().startsWith('fr'));
  const male = frVoices.find(v => /male|homme|paul|thomas|nicolas|antoine|guillaume|daniel/i.test(v.name) && !/female|femme/i.test(v.name));
  return male || frVoices[0] || voices[0] || null;
}

// ═══════ VOIX GOOGLE (Google Translate TTS, voix publique non officielle) ═══════
// Texte découpé en morceaux courts (limite ~200 caractères par requête), puis lu d'une seule voix :
// 1) si le navigateur autorise la récupération, les morceaux sont fusionnés en UN seul fichier audio ;
// 2) sinon (cas courant hors serveur : pas de CORS) lecture enchaînée morceau par morceau, sans coupure audible ;
// 3) en dernier recours, l'appli bascule sur la voix de l'appareil.
window._npsTts = { active: false, stop() {} };
function npsGoogleStop(){ try { window._npsTts.stop(); } catch (e) {} }
function npsTtsLang(text){
  const t = ' ' + String(text).toLowerCase() + ' ';
  const en = (t.match(/ (the|and|is|are|you|with|for|this|that) /g) || []).length;
  const fr = (t.match(/ (le|la|les|des|et|est|une|un|que|pour|avec|dans|je|tu|il) /g) || []).length;
  return en > fr * 1.5 ? 'en' : 'fr';
}
function npsTtsChunks(text, max){
  max = max || 180;
  const clean = String(text).replace(/https?:\/\/\S+/g, ' ').replace(/\s+/g, ' ').trim();
  const sentences = clean.match(/[^.!?…:;]+[.!?…:;]*\s*/g) || [clean];
  const chunks = []; let cur = '';
  const push = t => { t = t.trim(); if (t) chunks.push(t); };
  for (let s of sentences) {
    while (s.length > max) {
      let cut = s.lastIndexOf(',', max);
      if (cut < 60) cut = s.lastIndexOf(' ', max);
      if (cut < 1) cut = max - 1;
      if (cur) { push(cur); cur = ''; }
      push(s.slice(0, cut + 1)); s = s.slice(cut + 1);
    }
    if (cur.length + s.length > max) { push(cur); cur = s; } else cur += s;
  }
  push(cur);
  return chunks;
}
function npsGoogleSpeak(text, opt){
  opt = opt || {};
  const clean = String(text || '').replace(/https?:\/\/\S+/g, ' ').replace(/[#*_`>~]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!clean) { opt.onEnd && opt.onEnd(); return; }
  const chunks = npsTtsChunks(clean, 350);
  if (!chunks.length) { opt.onEnd && opt.onEnd(); return; }
  const lang = opt.lang || npsTtsLang(clean);

  // URLs proxy /api/tts pour éliminer tout blocage CORS et découpage serveur sans limite
  const proxyUrls = chunks.map(c => '/api/tts?tl=' + encodeURIComponent(lang) + '&q=' + encodeURIComponent(c));

  const T = window._npsTts || (window._npsTts = { active: false, stop() {} });
  if (T.active && typeof T.stop === 'function') {
    try { T.stop(); } catch (e) {}
  }

  let stopped = false, audio = null, idx = 0;
  T.active = true;

  const cleanup = () => {
    T.active = false;
    audio = null;
  };

  T.stop = () => {
    stopped = true;
    try {
      if (audio) {
        audio.pause();
        audio.src = '';
      }
    } catch (e) {}
    cleanup();
  };

  const finish = () => {
    if (stopped) return;
    cleanup();
    opt.onEnd && opt.onEnd();
  };

  const fail = () => {
    if (stopped) return;
    stopped = true;
    try {
      if (audio) {
        audio.pause();
        audio.src = '';
      }
    } catch (e) {}
    cleanup();
    opt.onFail && opt.onFail();
  };

  function playIdx(i, useProxy) {
    if (stopped) return;
    if (i >= chunks.length) { finish(); return; }
    idx = i;

    const url = useProxy 
      ? proxyUrls[i] 
      : ('https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' + encodeURIComponent(lang) + '&q=' + encodeURIComponent(chunks[i].slice(0, 160)));

    const a = new Audio(url);
    a.preload = 'auto';
    a.playbackRate = opt.rate || 1;
    audio = a;

    // Préchargement du segment suivant
    if (i + 1 < chunks.length) {
      try {
        const nextUrl = useProxy ? proxyUrls[i + 1] : ('https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' + encodeURIComponent(lang) + '&q=' + encodeURIComponent(chunks[i + 1].slice(0, 160)));
        const pre = new Audio();
        pre.preload = 'auto';
        pre.src = nextUrl;
      } catch (e) {}
    }

    let started = false;
    a.onplaying = () => { started = true; };
    a.onended = () => { playIdx(i + 1, useProxy); };
    a.onerror = () => {
      if (!started && i === 0) {
        fail();
      } else {
        playIdx(i + 1, useProxy);
      }
    };

    a.play().catch(() => {
      if (i === 0) {
        fail();
      } else {
        playIdx(i + 1, useProxy);
      }
    });
  }

  playIdx(0, true);
}
function npsSyncTtsEngineBtns(){
  const cur = 'google';
  document.querySelectorAll('.tts-engine-btn[data-engine]').forEach(b => b.classList.toggle('active', b.dataset.engine === cur));
}
function setTtsEngine(e){
  e = 'google';
  safeSetItem('nps_tts_engine', e);
  npsSyncTtsEngineBtns();
  toast('Voix Google activée');
}
function testCurrentVoice(){
  toast("Lecture en cours...");
  npsGoogleSpeak("Bonjour ! La synthèse vocale Google fonctionne.", {
    rate: S.ttsRate || 1,
    onEnd: () => toast('Test vocal terminé'),
    onFail: () => toast('Voix Google indisponible (réseau ?)', true)
  });
}
