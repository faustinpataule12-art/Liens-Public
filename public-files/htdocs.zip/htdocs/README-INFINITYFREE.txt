Fable Fast – version séparée pour InfinityFree

Envoyer tout le contenu de ce dossier dans le dossier htdocs d’InfinityFree.

Page principale : index.html
Pages liées : agent.html, profil.html, analyse.html, telechargement.html,
parametres.html, bibliotheque.html, stockage.html et contact.html.

Les styles sont dans css/style.css. Le JavaScript est séparé dans js/inline-01.js,
js/inline-02.js, etc. Chaque fichier HTML, PHP et JS reste sous la limite de 1 Mo.
Les images et series.html d’origine ont été conservées.
